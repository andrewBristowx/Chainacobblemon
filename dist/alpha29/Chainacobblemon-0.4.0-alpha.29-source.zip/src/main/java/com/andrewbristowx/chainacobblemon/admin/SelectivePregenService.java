package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Selective campaign pregenerator for the 67 static regional locations.
 *
 * It deliberately does not fill the huge bounding rectangles reported by mapstatus. Instead it generates a
 * 1024-block square radius around each registered/located structure, center-out, one chunk at a time. The two
 * template-only destinations (Nightmare/Newmoon and Origin/Arceus in the current Cobbleverse data) stay dynamic.
 *
 * Progress is persisted per world seed. Disk protection uses the smaller of physical free space and a configurable
 * hosting allocation budget. The Chaina server currently defaults to 146 GiB allocated with a hard 30 GiB reserve.
 */
public final class SelectivePregenService {
    public static final int ZONE_RADIUS_BLOCKS = 1024;
    public static final int ZONE_RADIUS_CHUNKS = (ZONE_RADIUS_BLOCKS + 15) / 16;
    public static final int CHUNKS_PER_ZONE = (ZONE_RADIUS_CHUNKS * 2 + 1) * (ZONE_RADIUS_CHUNKS * 2 + 1);

    private static final double DEFAULT_DISK_CAP_GIB = 146.0;
    private static final double MIN_FREE_GIB = 30.0;
    private static final double THROTTLE_FREE_GIB = 35.0;
    private static final double WARNING_FREE_GIB = 45.0;
    private static final long GIB = 1024L * 1024L * 1024L;
    private static final int NORMAL_INTERVAL_TICKS = 2;
    private static final int WARNING_INTERVAL_TICKS = 4;
    private static final int THROTTLED_INTERVAL_TICKS = 10;
    private static final int SAVE_EVERY_CHUNKS = 128;
    private static final int DISK_RESCAN_TICKS = 600;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final ExecutorService DISK_EXECUTOR = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "Chaina-Campaign-Disk-Scanner");
        thread.setDaemon(true);
        return thread;
    });

    private static ConfigManager configManager;
    private static boolean initialized;
    private static long loadedSeed = Long.MIN_VALUE;
    private static State state = new State();
    private static List<Zone> zones = List.of();
    private static List<ChunkTarget> currentChunkOrder = List.of();
    private static UUID requester;
    private static int tickCounter;
    private static int diskTickCounter;
    private static volatile long measuredDirectoryBytes = -1L;
    private static volatile boolean diskScanRunning;
    private static volatile String diskScanError = "";
    private static boolean warning45Sent;
    private static boolean warning35Sent;

    private SelectivePregenService() {}

    public static synchronized void initialize(ConfigManager config) {
        configManager = config;
        if (initialized) return;
        initialized = true;
        ServerTickEvents.END_SERVER_TICK.register(SelectivePregenService::tick);
    }

    public record Status(boolean mapReady, boolean running, boolean pausedForDisk, int completedZones, int totalZones,
                         String currentZone, int currentZoneChunk, int chunksPerZone, long processedChunkOps,
                         long plannedChunkOps, double diskCapacityGiB, double usedGiB, double freeGiB,
                         boolean diskMeasurementReady, String lastError) {}

    private record Zone(String key, String region, int order, String label, String dimensionId, int x, int y, int z) {}
    private record ChunkTarget(int x, int z, int distanceSq) {}

    private static final class State {
        long seed;
        boolean running;
        boolean pausedForDisk;
        double diskCapacityGiB = DEFAULT_DISK_CAP_GIB;
        Set<String> completedZones = new LinkedHashSet<>();
        String currentZoneKey = "";
        int currentChunkCursor;
        long processedChunkOps;
        String lastError = "";
    }

    public static synchronized int startOrResume(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        rebuildZones(server);
        ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
        if (!map.complete()) {
            source.sendFeedback(() -> Text.literal("§cNo se puede pregenerar todavía: el plan de ubicaciones está en §f"
                    + map.located() + "/" + map.total() + "§c. Completa primero 69/69."), false);
            return 0;
        }
        if (zones.isEmpty()) {
            source.sendFeedback(() -> Text.literal("§cNo hay ubicaciones estáticas registradas para pregenerar."), false);
            return 0;
        }
        if (state.completedZones.containsAll(zones.stream().map(Zone::key).toList())) {
            state.running = false;
            save(server);
            source.sendFeedback(() -> Text.literal("§aLa campaña ya está pregenerada: §f" + zones.size() + "/" + zones.size()
                    + "§a zonas estáticas. Las 2 ubicaciones dinámicas quedan verificadas por el plan 69/69."), false);
            return 1;
        }

        requester = source.getEntity() instanceof ServerPlayerEntity player ? player.getUuid() : null;
        state.running = true;
        state.pausedForDisk = false;
        state.lastError = "";
        warning45Sent = false;
        warning35Sent = false;
        prepareCurrentZone();
        requestDiskScan(true);
        save(server);

        source.sendFeedback(() -> Text.literal("§d§lPregeneración selectiva Chaina iniciada"), false);
        source.sendFeedback(() -> Text.literal("§7Zonas estáticas: §f" + zones.size() + " §7· radio por ubicación: §f"
                + ZONE_RADIUS_BLOCKS + " bloques §7· " + CHUNKS_PER_ZONE + " operaciones de chunk por zona."), false);
        source.sendFeedback(() -> Text.literal("§7Protección de disco: aviso §f45 GiB§7 · velocidad reducida §f35 GiB§7 · pausa automática §c30 GiB libres§7."), false);
        source.sendFeedback(() -> Text.literal("§7Capacidad configurada del hosting: §f" + format(state.diskCapacityGiB)
                + " GiB§7. Puedes cambiarla con §f... structures generate diskcap <GiB>§7 si HolyHosting te amplía el espacio."), false);
        source.sendFeedback(() -> Text.literal("§8No se generan masivamente las 2 ubicaciones dinámicas/plantillas; se conservan como verificadas en el 69/69."), false);
        return 1;
    }

    public static synchronized int pause(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        if (!state.running) {
            source.sendFeedback(() -> Text.literal("§eLa pregeneración ya está pausada."), false);
            return 0;
        }
        state.running = false;
        state.pausedForDisk = false;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§ePregeneración pausada. §7El progreso quedó guardado; usa §f... generate resume§7 para continuar."), false);
        return 1;
    }

    public static synchronized int resume(ServerCommandSource source) {
        return startOrResume(source);
    }

    public static synchronized int reportStatus(ServerCommandSource source) {
        Status status = status(source.getServer());
        source.sendFeedback(() -> Text.literal("§d§lPregeneración de campaña · §f" + status.completedZones() + "/" + status.totalZones() + " zonas"), false);
        source.sendFeedback(() -> Text.literal("§7Estado: " + (status.running() ? "§aEN CURSO" : status.pausedForDisk() ? "§cPAUSADA POR DISCO" : "§ePAUSADA")
                + " §7· mapa 69/69: " + (status.mapReady() ? "§aSÍ" : "§cNO")), false);
        if (!status.currentZone().isBlank()) {
            source.sendFeedback(() -> Text.literal("§7Actual: §f" + status.currentZone() + " §7· chunk §f"
                    + status.currentZoneChunk() + "/" + status.chunksPerZone()), false);
        }
        source.sendFeedback(() -> Text.literal("§7Operaciones: §f" + status.processedChunkOps() + "/" + status.plannedChunkOps()
                + " §8(los solapamientos se reutilizan y no implican worldgen duplicado)"), false);
        if (status.diskMeasurementReady()) {
            source.sendFeedback(() -> Text.literal("§7Disco Chaina: usado §f" + format(status.usedGiB()) + " GiB§7 / capacidad configurada §f"
                    + format(status.diskCapacityGiB()) + " GiB§7 · libre seguro §f" + format(status.freeGiB()) + " GiB"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§7Disco: §emedición en curso..."), false);
        }
        source.sendFeedback(() -> Text.literal("§7Reserva mínima: §c" + format(MIN_FREE_GIB) + " GiB libres§7."), false);
        if (!status.lastError().isBlank()) source.sendFeedback(() -> Text.literal("§cÚltimo error: §f" + status.lastError()), false);
        return status.mapReady() ? 1 : 0;
    }

    public static synchronized int setDiskCapacity(ServerCommandSource source, int gib) {
        ensureLoaded(source.getServer());
        state.diskCapacityGiB = gib;
        save(source.getServer());
        requestDiskScan(true);
        source.sendFeedback(() -> Text.literal("§aCapacidad de disco configurada en §f" + gib
                + " GiB§a. La reserva de 30 GiB no cambia."), false);
        return 1;
    }

    public static synchronized int reset(ServerCommandSource source, boolean confirm) {
        ensureLoaded(source.getServer());
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eEsto solo borra el PROGRESO de pregeneración de Chaina; no borra chunks del mundo. "
                    + "Ejecuta §f... structures generate reset confirm§e."), false);
            return 0;
        }
        double cap = state.diskCapacityGiB > 0 ? state.diskCapacityGiB : DEFAULT_DISK_CAP_GIB;
        state = new State();
        state.seed = source.getServer().getOverworld().getSeed();
        state.diskCapacityGiB = cap;
        currentChunkOrder = List.of();
        requester = null;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aProgreso de pregeneración reiniciado. §7No se eliminó ningún chunk ya generado."), false);
        return 1;
    }

    public static synchronized Status status(MinecraftServer server) {
        ensureLoaded(server);
        rebuildZones(server);
        ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
        long planned = (long) zones.size() * CHUNKS_PER_ZONE;
        long done = (long) state.completedZones.stream().filter(key -> zones.stream().anyMatch(z -> z.key().equals(key))).count() * CHUNKS_PER_ZONE;
        if (!state.currentZoneKey.isBlank() && !state.completedZones.contains(state.currentZoneKey)) done += Math.max(0, state.currentChunkCursor);
        Zone current = zoneByKey(state.currentZoneKey);
        DiskSnapshot disk = diskSnapshot();
        return new Status(map.complete(), state.running, state.pausedForDisk, completedZoneCount(), zones.size(),
                current == null ? "" : current.region() + " #" + current.order() + " · " + current.label(),
                state.currentChunkCursor, CHUNKS_PER_ZONE, Math.max(done, state.processedChunkOps), planned,
                state.diskCapacityGiB, disk.usedGiB, disk.freeGiB, disk.ready, state.lastError == null ? "" : state.lastError);
    }

    private static void tick(MinecraftServer server) {
        synchronized (SelectivePregenService.class) {
            if (!state.running) return;
            ensureLoaded(server);
            rebuildZones(server);
            if (zones.isEmpty()) {
                pauseWithError(server, "No hay zonas estáticas disponibles.");
                return;
            }

            if (++diskTickCounter >= DISK_RESCAN_TICKS) {
                diskTickCounter = 0;
                requestDiskScan(false);
            }
            DiskSnapshot disk = diskSnapshot();
            if (!disk.ready) {
                requestDiskScan(false);
                return;
            }
            if (disk.freeGiB <= MIN_FREE_GIB) {
                state.running = false;
                state.pausedForDisk = true;
                state.lastError = "Reserva de disco alcanzada: " + format(disk.freeGiB) + " GiB libres.";
                save(server);
                notifyRequester(server, "§c§lPREGENERACIÓN PAUSADA AUTOMÁTICAMENTE §7· quedan §f" + format(disk.freeGiB)
                        + " GiB libres§7. Solicita más espacio y usa §f... structures generate resume§7.");
                Chainacobblemon.LOGGER.warn("Campaign pregeneration paused at {} GiB free (30 GiB safety reserve)", format(disk.freeGiB));
                return;
            }
            if (disk.freeGiB <= WARNING_FREE_GIB && !warning45Sent) {
                warning45Sent = true;
                notifyRequester(server, "§6Aviso de disco: quedan §f" + format(disk.freeGiB) + " GiB libres§6; Chaina reducirá la velocidad.");
            }
            if (disk.freeGiB <= THROTTLE_FREE_GIB && !warning35Sent) {
                warning35Sent = true;
                notifyRequester(server, "§cDisco bajo: quedan §f" + format(disk.freeGiB) + " GiB libres§c; pregeneración muy reducida hasta el límite de 30 GiB.");
            }

            int interval = disk.freeGiB <= THROTTLE_FREE_GIB ? THROTTLED_INTERVAL_TICKS
                    : disk.freeGiB <= WARNING_FREE_GIB ? WARNING_INTERVAL_TICKS : NORMAL_INTERVAL_TICKS;
            if (++tickCounter < interval) return;
            tickCounter = 0;

            Zone zone = currentZone();
            if (zone == null) {
                if (!advanceToNextZone(server)) finish(server);
                return;
            }
            if (currentChunkOrder.isEmpty()) buildChunkOrder(zone);
            if (state.currentChunkCursor >= currentChunkOrder.size()) {
                completeZone(server, zone);
                return;
            }

            ServerWorld world = world(server, zone.dimensionId());
            if (world == null) {
                pauseWithError(server, "La dimensión " + zone.dimensionId() + " no está cargada.");
                return;
            }
            ChunkTarget target = currentChunkOrder.get(state.currentChunkCursor);
            try {
                // Synchronous FULL chunk acquisition is intentional: only one chunk is requested at a time, then the
                // service yields back to the normal server tick loop. Existing chunks are simply loaded/reused.
                world.getChunk(target.x(), target.z());
                state.currentChunkCursor++;
                state.processedChunkOps++;
                if (state.currentChunkCursor % SAVE_EVERY_CHUNKS == 0) save(server);
                if (state.currentChunkCursor >= currentChunkOrder.size()) completeZone(server, zone);
            } catch (RuntimeException exception) {
                Chainacobblemon.LOGGER.error("Campaign pregeneration failed in {} at chunk {},{}", zone.dimensionId(), target.x(), target.z(), exception);
                pauseWithError(server, "Falló " + zone.label() + " en chunk " + target.x() + "," + target.z()
                        + ": " + exception.getClass().getSimpleName());
            }
        }
    }

    private static void completeZone(MinecraftServer server, Zone zone) {
        state.completedZones.add(zone.key());
        state.currentZoneKey = "";
        state.currentChunkCursor = 0;
        currentChunkOrder = List.of();
        save(server);
        requestDiskScan(false);
        notifyRequester(server, "§a✓ Zona pregenerada §f" + zone.region() + " #" + zone.order() + " · " + zone.label()
                + " §7(" + completedZoneCount() + "/" + zones.size() + ")");
        if (!advanceToNextZone(server)) finish(server);
    }

    private static boolean advanceToNextZone(MinecraftServer server) {
        for (Zone zone : zones) {
            if (state.completedZones.contains(zone.key())) continue;
            state.currentZoneKey = zone.key();
            state.currentChunkCursor = 0;
            currentChunkOrder = List.of();
            save(server);
            return true;
        }
        return false;
    }

    private static void finish(MinecraftServer server) {
        state.running = false;
        state.pausedForDisk = false;
        state.currentZoneKey = "";
        state.currentChunkCursor = 0;
        state.lastError = "";
        currentChunkOrder = List.of();
        save(server);
        requestDiskScan(false);
        notifyRequester(server, "§a§lMAPA DE CAMPAÑA PREGENERADO §7· §f" + zones.size() + "/" + zones.size()
                + "§a zonas estáticas preparadas + §f2/2§a destinos dinámicos verificados.");
        Chainacobblemon.LOGGER.info("Selective campaign pregeneration finished: {}/{} static zones", zones.size(), zones.size());
    }

    private static void pauseWithError(MinecraftServer server, String error) {
        state.running = false;
        state.lastError = error;
        save(server);
        notifyRequester(server, "§cPregeneración pausada: §f" + error + " §7El progreso quedó guardado.");
    }

    private static void prepareCurrentZone() {
        if (currentZone() == null) {
            for (Zone zone : zones) {
                if (!state.completedZones.contains(zone.key())) {
                    state.currentZoneKey = zone.key();
                    state.currentChunkCursor = 0;
                    break;
                }
            }
        }
        currentChunkOrder = List.of();
    }

    private static Zone currentZone() {
        return zoneByKey(state.currentZoneKey);
    }

    private static Zone zoneByKey(String key) {
        if (key == null || key.isBlank()) return null;
        for (Zone zone : zones) if (zone.key().equals(key)) return zone;
        return null;
    }

    private static int completedZoneCount() {
        int count = 0;
        for (Zone zone : zones) if (state.completedZones.contains(zone.key())) count++;
        return count;
    }

    private static void buildChunkOrder(Zone zone) {
        int centerX = Math.floorDiv(zone.x(), 16);
        int centerZ = Math.floorDiv(zone.z(), 16);
        List<ChunkTarget> result = new ArrayList<>(CHUNKS_PER_ZONE);
        for (int dx = -ZONE_RADIUS_CHUNKS; dx <= ZONE_RADIUS_CHUNKS; dx++) {
            for (int dz = -ZONE_RADIUS_CHUNKS; dz <= ZONE_RADIUS_CHUNKS; dz++) {
                result.add(new ChunkTarget(centerX + dx, centerZ + dz, dx * dx + dz * dz));
            }
        }
        result.sort(Comparator.comparingInt(ChunkTarget::distanceSq).thenComparingInt(ChunkTarget::x).thenComparingInt(ChunkTarget::z));
        currentChunkOrder = List.copyOf(result);
    }

    private static void rebuildZones(MinecraftServer server) {
        ImportantLocationService.MapSnapshot snapshot = ImportantLocationService.snapshot(server);
        List<Zone> result = new ArrayList<>();
        for (ImportantLocationService.RegionView region : snapshot.regions()) {
            for (ImportantLocationService.LocationView location : region.locations()) {
                if (!location.registered() || !location.located() || location.dimensionId().isBlank()) continue;
                result.add(new Zone(location.key(), region.name(), location.order(), location.label(), location.dimensionId(),
                        location.x(), location.y(), location.z()));
            }
        }
        result.sort(Comparator.comparingInt((Zone zone) -> regionPriority(zone.region())).thenComparingInt(Zone::order));
        zones = List.copyOf(result);
        state.completedZones.retainAll(zones.stream().map(Zone::key).collect(java.util.stream.Collectors.toSet()));
    }


    private static int regionPriority(String region) {
        if (region == null) return 99;
        return switch (region.toLowerCase(java.util.Locale.ROOT)) {
            case "kanto" -> 0;
            case "johto" -> 1;
            case "hoenn" -> 2;
            case "sinnoh" -> 3;
            default -> 10;
        };
    }

    private static ServerWorld world(MinecraftServer server, String dimensionId) {
        Identifier id = Identifier.tryParse(dimensionId);
        if (id == null) return null;
        RegistryKey<World> key = RegistryKey.of(RegistryKeys.WORLD, id);
        return server.getWorld(key);
    }

    private static void notifyRequester(MinecraftServer server, String message) {
        if (requester != null) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(requester);
            if (player != null) {
                player.sendMessage(Text.literal(message), false);
                return;
            }
        }
        Chainacobblemon.LOGGER.info(message.replaceAll("§.", ""));
    }

    private static void requestDiskScan(boolean force) {
        if (diskScanRunning) return;
        diskScanRunning = true;
        Path gameDir = FabricLoader.getInstance().getGameDir();
        CompletableFuture.supplyAsync(() -> directorySize(gameDir), DISK_EXECUTOR).whenComplete((size, error) -> {
            if (error != null) {
                diskScanError = error.getClass().getSimpleName() + ": " + error.getMessage();
            } else {
                measuredDirectoryBytes = Math.max(0L, size);
                diskScanError = "";
            }
            diskScanRunning = false;
        });
    }

    private static long directorySize(Path root) {
        try (var stream = Files.walk(root)) {
            return stream.filter(Files::isRegularFile).mapToLong(path -> {
                try {
                    return Files.size(path);
                } catch (IOException ignored) {
                    return 0L;
                }
            }).sum();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private record DiskSnapshot(boolean ready, double usedGiB, double freeGiB) {}

    private static DiskSnapshot diskSnapshot() {
        if (measuredDirectoryBytes < 0) return new DiskSnapshot(false, 0.0, 0.0);
        double used = measuredDirectoryBytes / (double) GIB;
        double logicalFree = Math.max(0.0, state.diskCapacityGiB - used);
        double physicalFree = Double.MAX_VALUE;
        try {
            FileStore store = Files.getFileStore(FabricLoader.getInstance().getGameDir());
            physicalFree = store.getUsableSpace() / (double) GIB;
        } catch (IOException exception) {
            if (diskScanError.isBlank()) diskScanError = exception.getClass().getSimpleName();
        }
        return new DiskSnapshot(true, used, Math.min(logicalFree, physicalFree));
    }

    private static void ensureLoaded(MinecraftServer server) {
        if (configManager == null || server == null || server.getOverworld() == null) return;
        long seed = server.getOverworld().getSeed();
        if (loadedSeed == seed) return;
        loadedSeed = seed;
        state = new State();
        state.seed = seed;
        Path file = stateFile(seed);
        if (Files.exists(file)) {
            try {
                State loaded = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), State.class);
                if (loaded != null && loaded.seed == seed) {
                    if (loaded.completedZones == null) loaded.completedZones = new LinkedHashSet<>();
                    if (loaded.diskCapacityGiB <= 0) loaded.diskCapacityGiB = DEFAULT_DISK_CAP_GIB;
                    // Never resume world generation silently after a restart. Progress is preserved and /resume is explicit.
                    loaded.running = false;
                    state = loaded;
                }
            } catch (Exception exception) {
                Chainacobblemon.LOGGER.warn("Could not read selective pregeneration state {}", file, exception);
            }
        }
        requester = null;
        currentChunkOrder = List.of();
        measuredDirectoryBytes = -1L;
        requestDiskScan(true);
    }

    private static void save(MinecraftServer server) {
        if (configManager == null || server == null) return;
        Path file = stateFile(state.seed);
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(temp, GSON.toJson(state), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            Chainacobblemon.LOGGER.warn("Could not save selective pregeneration state {}", file, exception);
        }
    }

    private static Path stateFile(long seed) {
        return configManager.configDirectory().resolve("campaign-pregen-" + Long.toUnsignedString(seed) + ".json");
    }

    private static String format(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }
}
