package com.andrewbristowx.chainacobblemon.command;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.admin.PlayerResetService;
import com.andrewbristowx.chainacobblemon.admin.ImportantLocationService;
import com.andrewbristowx.chainacobblemon.admin.PregenCheckService;
import com.andrewbristowx.chainacobblemon.admin.RegionalStructureAuditService;
import com.andrewbristowx.chainacobblemon.admin.SelectivePregenService;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.data.PlayerDataManager;
import com.andrewbristowx.chainacobblemon.dungeon.DungeonTrainerService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class ChainacobblemonCommands {
    private ChainacobblemonCommands() {
    }

    public static void register(ConfigManager configManager, PlayerDataManager playerDataManager) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                register(dispatcher, configManager, playerDataManager));
    }

    private static void register(
            CommandDispatcher<ServerCommandSource> dispatcher,
            ConfigManager configManager,
            PlayerDataManager playerDataManager
    ) {
        dispatcher.register(literal("chainacobblemon")
                .then(literal("version")
                        .executes(context -> {
                            context.getSource().sendFeedback(
                                    () -> Text.literal("Chainacobblemon " + Chainacobblemon.VERSION + " | Minecraft 1.21.1 | Cobblemon 1.7.3"),
                                    false
                            );
                            return 1;
                        }))
                .then(literal("status")
                        .executes(context -> {
                            String message = "Chainacobblemon OK | config v" + configManager.get().configVersion
                                    + " | player data loaded: " + playerDataManager.loadedCount();
                            context.getSource().sendFeedback(() -> Text.literal(message), false);
                            return 1;
                        }))
                .then(literal("reload")
                        .requires(source -> source.hasPermissionLevel(4))
                        .executes(context -> {
                            boolean success = configManager.reload();
                            context.getSource().sendFeedback(
                                    () -> Text.literal(success
                                            ? "Chainacobblemon: configuracion recargada."
                                            : "Chainacobblemon: fallo al recargar; se conserva la ultima configuracion valida."),
                                    false
                            );
                            return success ? 1 : 0;
                        }))
                .then(literal("admin")
                        .requires(source -> source.hasPermissionLevel(4))
                        .then(literal("structures")
                                .then(literal("verify")
                                        .executes(context -> RegionalStructureAuditService.report(context.getSource(), false))
                                        .then(literal("details")
                                                .executes(context -> RegionalStructureAuditService.report(context.getSource(), true))))
                                .then(literal("mapplan")
                                        .executes(context -> ImportantLocationService.startPlan(context.getSource(), false))
                                        .then(literal("refresh")
                                                .executes(context -> ImportantLocationService.startPlan(context.getSource(), true))))
                                .then(literal("mapstatus")
                                        .executes(context -> ImportantLocationService.reportStatus(context.getSource())))
                                .then(literal("mapmissing")
                                        .executes(context -> ImportantLocationService.reportMissing(context.getSource())))
                                .then(literal("mapclear")
                                        .executes(context -> ImportantLocationService.clearPlan(context.getSource())))
                                .then(literal("mapmark")
                                        .then(argument("region", StringArgumentType.word())
                                                .then(argument("number", IntegerArgumentType.integer(1, 24))
                                                        .executes(context -> ImportantLocationService.markCurrent(
                                                                context.getSource(),
                                                                StringArgumentType.getString(context, "region"),
                                                                IntegerArgumentType.getInteger(context, "number"))))))
                                // alpha.29: keep selective pregeneration under /admin structures.
                                .then(literal("generate")
                                        .executes(context -> SelectivePregenService.startOrResume(context.getSource()))
                                        .then(literal("start")
                                                .executes(context -> SelectivePregenService.startOrResume(context.getSource())))
                                        .then(literal("resume")
                                                .executes(context -> SelectivePregenService.resume(context.getSource())))
                                        .then(literal("pause")
                                                .executes(context -> SelectivePregenService.pause(context.getSource())))
                                        .then(literal("status")
                                                .executes(context -> SelectivePregenService.reportStatus(context.getSource())))
                                        .then(literal("diskcap")
                                                .then(argument("gib", IntegerArgumentType.integer(40, 4096))
                                                        .executes(context -> SelectivePregenService.setDiskCapacity(
                                                                context.getSource(), IntegerArgumentType.getInteger(context, "gib")))))
                                        .then(literal("reset")
                                                .executes(context -> SelectivePregenService.reset(context.getSource(), false))
                                                .then(literal("confirm")
                                                        .executes(context -> SelectivePregenService.reset(context.getSource(), true))))))
                        .then(literal("pregencheck")
                                .executes(context -> PregenCheckService.report(context.getSource())))
                        .then(literal("dungeontrainers")
                                .then(literal("status")
                                        .executes(context -> {
                                            int count = DungeonTrainerService.countLoaded(context.getSource().getServer());
                                            context.getSource().sendFeedback(() -> Text.literal(
                                                    "§dDungeon Trainers · cargados=§f" + count
                                                            + "§d · integraciones=§f" + String.join(", ", DungeonTrainerService.supportedNamespaces())), false);
                                            return 1;
                                        }))
                                .then(literal("scan")
                                        .executes(context -> {
                                            ServerPlayerEntity player = context.getSource().getPlayer();
                                            if (player == null) {
                                                context.getSource().sendFeedback(() -> Text.literal("§cEjecuta este comando como jugador dentro de una mazmorra."), false);
                                                return 0;
                                            }
                                            return DungeonTrainerService.inspectPlayer(player, true) >= 0 ? 1 : 0;
                                        })))
                        .then(literal("resetplayer")
                                .then(argument("player", EntityArgumentType.player())
                                        .executes(context -> {
                                            ServerPlayerEntity target = EntityArgumentType.getPlayer(context, "player");
                                            context.getSource().sendFeedback(() -> Text.literal(
                                                    "§eRESET DE PRUEBAS preparado para §f" + target.getGameProfile().getName()
                                                            + "§e. Esto borrará Pokémon y progreso de pruebas, pero §aNO cambiará tu límite de nivel ni tu serie RCT§e. "
                                                            + "Ejecuta el mismo comando añadiendo §cconfirm§e."), false);
                                            return 1;
                                        })
                                        .then(literal("confirm")
                                                .executes(context -> {
                                                    ServerPlayerEntity target = EntityArgumentType.getPlayer(context, "player");
                                                    PlayerResetService.ResetResult result = PlayerResetService.reset(target, playerDataManager);
                                                    context.getSource().sendFeedback(() -> Text.literal(
                                                            "§dReset final de §f" + target.getGameProfile().getName()
                                                                    + "§d | Chainacobblemon=" + ok(result.chainacobblemon())
                                                                    + " | Cobblemon=" + ok(result.cobblemon())
                                                                    + " | RCT=" + ok(result.rct())
                                                                    + " | derrotas RCT reiniciadas=" + result.resetTrainerDefeats()
                                                                    + " §a| límite de nivel preservado"), true);
                                                    target.sendMessage(Text.literal("§dTu progreso de pruebas fue reiniciado por un administrador. §aTu límite de nivel/serie RCT se conserva."), false);
                                                    return result.success() ? 1 : 0;
                                                }))))
                        .then(literal("resetall")
                                .executes(context -> {
                                    context.getSource().sendFeedback(() -> Text.literal(
                                            "§c§lRESET GLOBAL DE PRUEBAS. §eCon §cconfirm§e se reiniciarán Party/PC + progreso Chainacobblemon/RCT seguro de TODOS los jugadores conectados "
                                                    + "y se borrarán perfiles Chainacobblemon offline. §aNO se reduce el límite de nivel/serie RCT§e y NO se toca el mundo. "
                                                    + "Los datos Cobblemon/RCT de jugadores offline no se editan a ciegas."), false);
                                    return 1;
                                })
                                .then(literal("confirm")
                                        .executes(context -> {
                                            PlayerResetService.ResetAllResult result = PlayerResetService.resetAllOnlineAndOfflineChainacobblemon(
                                                    context.getSource().getServer(), playerDataManager);
                                            context.getSource().sendFeedback(() -> Text.literal(
                                                    "§dReset global terminado | online=" + result.onlineSuccessful() + "/" + result.onlinePlayers()
                                                            + " | perfiles Chainacobblemon offline borrados=" + result.offlineChainacobblemonProfilesRemoved()
                                                            + " | fallos Cobblemon=" + result.cobblemonFailures()
                                                            + " | RCT parcial/no disponible=" + result.rctPartialOrUnavailable()
                                                            + " §a| límite de nivels preservados"), true);
                                            return result.success() ? 1 : 0;
                                        }))))
                .then(literal("debug")
                        .requires(source -> source.hasPermissionLevel(4))
                        .executes(context -> {
                            ServerCommandSource source = context.getSource();
                            if (source.getPlayer() == null) {
                                source.sendFeedback(() -> Text.literal("Chainacobblemon debug: ejecuta este subcomando como jugador."), false);
                                return 0;
                            }
                            PlayerData data = playerDataManager.getOrLoad(source.getPlayer().getUuid());
                            data.debugCounter++;
                            source.sendFeedback(
                                    () -> Text.literal("Chainacobblemon debugCounter=" + data.debugCounter + " para " + data.playerId),
                                    false
                            );
                            return 1;
                        })));
    }


    private static String ok(boolean value) {
        return value ? "§aOK§d" : "§cNO§d";
    }
}
