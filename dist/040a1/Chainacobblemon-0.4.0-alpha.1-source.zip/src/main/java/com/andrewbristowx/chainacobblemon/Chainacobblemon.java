package com.andrewbristowx.chainacobblemon;

import com.andrewbristowx.chainacobblemon.command.ChainacobblemonCommands;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeCommands;
import com.andrewbristowx.chainacobblemon.armor.ChainaSetBonusService;
import com.andrewbristowx.chainacobblemon.command.GachaCommands;
import com.andrewbristowx.chainacobblemon.command.HubCommands;
import com.andrewbristowx.chainacobblemon.command.Phase3Commands;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.andrewbristowx.chainacobblemon.data.PlayerDataManager;
import com.andrewbristowx.chainacobblemon.dungeon.DungeonTrainerService;
import com.andrewbristowx.chainacobblemon.dungeon.ChainaDungeonLootService;
import com.andrewbristowx.chainacobblemon.events.ChainaEventManager;
import com.andrewbristowx.chainacobblemon.events.EventCommands;
import com.andrewbristowx.chainacobblemon.events.EventNetworking;
import com.andrewbristowx.chainacobblemon.events.FishingMinigameService;
import com.andrewbristowx.chainacobblemon.events.treasure.TreasureHuntService;
import com.andrewbristowx.chainacobblemon.gacha.GachaService;
import com.andrewbristowx.chainacobblemon.gacha.GachaNetworking;
import com.andrewbristowx.chainacobblemon.gacha.treasure.TreasureGachaService;
import com.andrewbristowx.chainacobblemon.gacha.banner.BannerManager;
import com.andrewbristowx.chainacobblemon.gacha.banner.FeaturedRotationService;
import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogService;
import com.andrewbristowx.chainacobblemon.integration.StreamotesServerIntegration;
import com.andrewbristowx.chainacobblemon.npc.command.NpcCommands;
import com.andrewbristowx.chainacobblemon.npc.NpcNetworking;
import com.andrewbristowx.chainacobblemon.npc.NpcBattleService;
import com.andrewbristowx.chainacobblemon.progress.ProgressionService;
import com.andrewbristowx.chainacobblemon.progress.command.ProgressionCommands;
import com.andrewbristowx.chainacobblemon.progress.network.ProgressionNetworking;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.andrewbristowx.chainacobblemon.shop.ShopCatalog;
import com.andrewbristowx.chainacobblemon.shop.ShopService;
import com.andrewbristowx.chainacobblemon.shop.command.ShopCommands;
import com.andrewbristowx.chainacobblemon.shop.network.ShopNetworking;
import com.andrewbristowx.chainacobblemon.visual.VisualAssetNetworking;
import com.andrewbristowx.chainacobblemon.visual.VisualAssetService;
import com.andrewbristowx.chainacobblemon.visual.command.MediaCommands;
import com.andrewbristowx.chainacobblemon.hologram.HologramCommands;
import com.andrewbristowx.chainacobblemon.hologram.HologramService;
import com.andrewbristowx.chainacobblemon.hologram.HologramViewerTextService;
import com.andrewbristowx.chainacobblemon.admin.AdminNetworking;
import com.andrewbristowx.chainacobblemon.rewards.BattlePassCommands;
import com.andrewbristowx.chainacobblemon.rewards.BattlePassNetworking;
import com.andrewbristowx.chainacobblemon.rewards.BattlePassService;
import com.andrewbristowx.chainacobblemon.rewards.DailyRewardCommands;
import com.andrewbristowx.chainacobblemon.rewards.DailyRewardNetworking;
import com.andrewbristowx.chainacobblemon.rewards.DailyRewardService;
import com.andrewbristowx.chainacobblemon.rewards.RewardWalletService;
import com.andrewbristowx.chainacobblemon.rewards.KitCommands;
import com.andrewbristowx.chainacobblemon.tower.ChallengeTowerCommands;
import com.andrewbristowx.chainacobblemon.tower.ChallengeTowerService;
import com.andrewbristowx.chainacobblemon.tower.TowerRouletteNetworking;
import com.andrewbristowx.chainacobblemon.twitch.TwitchCommands;
import com.andrewbristowx.chainacobblemon.twitch.TwitchNetworking;
import com.andrewbristowx.chainacobblemon.twitch.TwitchService;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Chainacobblemon implements ModInitializer {
    public static final String MOD_ID = "chainacobblemon";
    public static final String VERSION = "0.4.0-alpha.1+1.21.1";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final ConfigManager CONFIG_MANAGER = new ConfigManager();
    private static final PlayerDataManager PLAYER_DATA_MANAGER = new PlayerDataManager();
    private static final PokemonCatalogService POKEMON_CATALOG = new PokemonCatalogService();
    private static final BannerManager BANNER_MANAGER = new BannerManager();
    private static final FeaturedRotationService FEATURED_ROTATION = new FeaturedRotationService(POKEMON_CATALOG);
    private static final RewardWalletService REWARD_WALLET = new RewardWalletService(PLAYER_DATA_MANAGER);
    private static final GachaService GACHA_SERVICE = new GachaService(
            POKEMON_CATALOG, BANNER_MANAGER, PLAYER_DATA_MANAGER, REWARD_WALLET);
    private static final TreasureGachaService TREASURE_GACHA_SERVICE = new TreasureGachaService(PLAYER_DATA_MANAGER, REWARD_WALLET);
    private static final ChainaSetBonusService CHAINA_SET_BONUS_SERVICE = new ChainaSetBonusService();
    private static final BattlePassService BATTLE_PASS = new BattlePassService(PLAYER_DATA_MANAGER, CONFIG_MANAGER);
    private static final DailyRewardService DAILY_REWARDS = new DailyRewardService(PLAYER_DATA_MANAGER, CONFIG_MANAGER);
    private static final ProgressionService PROGRESSION_SERVICE = new ProgressionService(
            PLAYER_DATA_MANAGER, POKEMON_CATALOG, CONFIG_MANAGER);
    private static final ShopCatalog SHOP_CATALOG = new ShopCatalog();
    private static final ShopService SHOP_SERVICE = new ShopService(SHOP_CATALOG, PROGRESSION_SERVICE, CONFIG_MANAGER);
    private static final VisualAssetService VISUAL_ASSETS = new VisualAssetService();
    private static final TwitchService TWITCH_SERVICE = new TwitchService(CONFIG_MANAGER);

    @Override
    public void onInitialize() {
        LOGGER.info("Starting Chainacobblemon {}", VERSION);

        CONFIG_MANAGER.initialize();
        TWITCH_SERVICE.initialize();
        TwitchNetworking.initializeServer(TWITCH_SERVICE);
        TwitchCommands.register(TWITCH_SERVICE);
        BANNER_MANAGER.initialize();
        SHOP_CATALOG.initialize();
        VISUAL_ASSETS.initialize();
        ModRegistries.initialize();
        ChainacobblemonCommands.register(CONFIG_MANAGER, PLAYER_DATA_MANAGER);
        HubCommands.register(CONFIG_MANAGER);
        GachaCommands.register(POKEMON_CATALOG, BANNER_MANAGER, GACHA_SERVICE, PLAYER_DATA_MANAGER);
        GachaNetworking.initializeServer();
        Phase3Commands.register();
        ProgressionNetworking.initializeServer(PROGRESSION_SERVICE);
        ProgressionCommands.register(PROGRESSION_SERVICE);
        PROGRESSION_SERVICE.initialize();
        CHAINA_SET_BONUS_SERVICE.initialize();
        ShopNetworking.initializeServer(SHOP_SERVICE);
        ShopCommands.register(SHOP_CATALOG);
        VisualAssetNetworking.initializeServer();
        NpcNetworking.initializeServer(VISUAL_ASSETS);
        NpcCommands.register(VISUAL_ASSETS);
        ChallengeCommands.register(VISUAL_ASSETS);
        ChallengeTowerCommands.register();
        TowerRouletteNetworking.initializeServer();
        ChallengeTowerService.initialize();
        MediaCommands.register(VISUAL_ASSETS);
        HologramCommands.register();
        HologramViewerTextService.initialize();
        AdminNetworking.initializeServer();
        BattlePassNetworking.initializeServer(BATTLE_PASS);
        BattlePassCommands.register();
        DailyRewardNetworking.initializeServer(DAILY_REWARDS);
        DailyRewardCommands.register();
        KitCommands.register();
        DAILY_REWARDS.initialize();
        DungeonTrainerService.initialize();
        ChainaDungeonLootService.initialize();
        EventNetworking.initializeServer();
        FishingMinigameService.initialize();
        EventCommands.register();
        TreasureHuntService.initialize();
        ChainaEventManager.initialize();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            PROGRESSION_SERVICE.playerJoined(handler.player);
            BATTLE_PASS.playerJoined(handler.player);
            DAILY_REWARDS.playerJoined(handler.player);
            VISUAL_ASSETS.syncAll(handler.player);
            ChallengeTowerService.playerJoined(handler.player);
            TreasureHuntService.playerJoined(handler.player);
            ChainaEventManager.playerJoined(handler.player);
            TWITCH_SERVICE.playerJoined(handler.player);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            PROGRESSION_SERVICE.playerLeft(handler.player.getUuid());
            BATTLE_PASS.playerLeft(handler.player.getUuid());
            DAILY_REWARDS.playerLeft(handler.player.getUuid());
            ChallengeTowerService.playerLeft(handler.player.getUuid());
            TreasureHuntService.playerLeft(handler.player.getUuid());
            FishingMinigameService.playerLeft(handler.player.getUuid());
            ChainaEventManager.playerLeft(handler.player.getUuid());
            TWITCH_SERVICE.playerLeft(handler.player.getUuid());
            PLAYER_DATA_MANAGER.saveAndUnload(handler.player.getUuid());
        });
        ServerLifecycleEvents.SERVER_STARTING.register(server -> StreamotesServerIntegration.ensureOfficialChannel());
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            TWITCH_SERVICE.serverStarted(server);
            POKEMON_CATALOG.rebuild();
            NpcBattleService.auditCompatibility(server);
            HologramService.restoreAll(server);
            LOGGER.info("Chainacobblemon backends ready: {} Pokemon, {} banners, {} shop products",
                    POKEMON_CATALOG.size(), BANNER_MANAGER.size(), SHOP_CATALOG.availableProductCount());
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            TWITCH_SERVICE.serverStopping();
            PLAYER_DATA_MANAGER.saveAll();
        });

        LOGGER.info("Chainacobblemon core initialized successfully");
    }

    public static ConfigManager configManager() {
        return CONFIG_MANAGER;
    }

    public static PlayerDataManager playerDataManager() {
        return PLAYER_DATA_MANAGER;
    }

    public static PokemonCatalogService pokemonCatalog() {
        return POKEMON_CATALOG;
    }

    public static BannerManager bannerManager() {
        return BANNER_MANAGER;
    }

    public static FeaturedRotationService featuredRotation() {
        return FEATURED_ROTATION;
    }

    public static GachaService gachaService() {
        return GACHA_SERVICE;
    }

    public static TreasureGachaService treasureGachaService() { return TREASURE_GACHA_SERVICE; }

    public static ProgressionService progressionService() {
        return PROGRESSION_SERVICE;
    }

    public static ShopCatalog shopCatalog() {
        return SHOP_CATALOG;
    }

    public static ShopService shopService() {
        return SHOP_SERVICE;
    }

    public static RewardWalletService rewardWalletService() { return REWARD_WALLET; }
    public static BattlePassService battlePassService() { return BATTLE_PASS; }
    public static DailyRewardService dailyRewardService() { return DAILY_REWARDS; }
}
