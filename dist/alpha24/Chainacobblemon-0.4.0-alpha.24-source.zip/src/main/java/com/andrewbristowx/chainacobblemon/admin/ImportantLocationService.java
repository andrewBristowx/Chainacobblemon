package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.gen.structure.Structure;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.UUID;

/**
 * World-specific route planner for the 69 official regional locations audited by Chaina.
 *
 * Registered structures are located with Minecraft's own ChunkGenerator locator, one at a time so a
 * 69-location plan does not execute in a single server tick. Datapack/template-only assets stay visible
 * in the route and can be marked at the player's current position once the pack places them in-world.
 */
public final class ImportantLocationService {
    public static final int EXPECTED_TOTAL = 69;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int SEARCH_RADIUS_CHUNKS = 4096;
    private static final int LOCATE_INTERVAL_TICKS = 20;
    private static final int DEFAULT_PADDING = 1024;

    private static ConfigManager configManager;
    private static long loadedSeed = Long.MIN_VALUE;
    private static SavedState saved = new SavedState();
    private static PlanJob job;
    private static int tickCounter;
    private static boolean initialized;

    private ImportantLocationService() {}

    public static synchronized void initialize(ConfigManager config) {
        configManager = config;
        if (initialized) return;
        initialized = true;
        ServerTickEvents.END_SERVER_TICK.register(ImportantLocationService::tick);
    }

    public record LocationView(String key, String region, int order, String label, String structureId,
                               boolean registered, boolean located, boolean assetOnly,
                               int x, int y, int z) {}

    public record RegionView(String id, String name, int located, int total, List<LocationView> locations) {}

    public record MapSnapshot(List<RegionView> regions, int located, int total, int registered,
                              int assetOnly, boolean planning, int planDone, int planTotal,
                              boolean hasBounds, int minX, int maxX, int minZ, int maxZ,
                              int centerX, int centerZ, int width, int length, int padding) {}

    private record Definition(String key, String regionId, String regionName, int order, String label,
                              Identifier registeredId, String bestAssetId) {}

    private static final class SavedState {
        long seed;
        int padding = DEFAULT_PADDING;
        Map<String, SavedLocation> locations = new LinkedHashMap<>();
    }

    private static final class SavedLocation {
        String structureId = "";
        int x;
        int y;
        int z;
        boolean located;
        boolean manuallyMarked;
    }

    private static final class PlanJob {
        final Queue<Definition> pending;
        final int total;
        final UUID requester;
        int done;
        PlanJob(List<Definition> definitions, UUID requester) {
            this.pending = new ArrayDeque<>(definitions);
            this.total = definitions.size();
            this.requester = requester;
        }
    }

    public static synchronized int startPlan(ServerCommandSource source, boolean refresh) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        if (job != null) {
            source.sendFeedback(() -> Text.literal("§eYa hay un plan de ubicaciones ejecutándose: " + job.done + "/" + job.total + "."), false);
            return 0;
        }
        List<Definition> definitions = definitions(server);
        List<Definition> pending = new ArrayList<>();
        for (Definition definition : definitions) {
            if (definition.registeredId() == null) continue;
            SavedLocation existing = saved.locations.get(definition.key());
            if (refresh || existing == null || !existing.located) pending.add(definition);
        }
        if (refresh) {
            for (Definition definition : definitions) {
                if (definition.registeredId() == null) continue;
                SavedLocation existing = saved.locations.get(definition.key());
                if (existing != null && !existing.manuallyMarked) existing.located = false;
            }
        }
        UUID requester = source.getEntity() instanceof ServerPlayerEntity player ? player.getUuid() : null;
        job = new PlanJob(pending, requester);
        tickCounter = LOCATE_INTERVAL_TICKS;
        int assetOnly = (int) definitions.stream().filter(d -> d.registeredId() == null).count();
        source.sendFeedback(() -> Text.literal("§dChaina · Plan de 69 ubicaciones iniciado. §f" + pending.size()
                + "§7 estructuras registradas por localizar; §f" + assetOnly
                + "§7 ubicaciones son assets/plantillas y se conservarán en el menú para marcarlas cuando aparezcan."), false);
        if (pending.isEmpty()) finishPlan(server);
        return 1;
    }

    public static synchronized int reportStatus(ServerCommandSource source) {
        MapSnapshot snapshot = snapshot(source.getServer());
        source.sendFeedback(() -> Text.literal("§d§lUbicaciones importantes · §f" + snapshot.located() + "/" + snapshot.total()), false);
        for (RegionView region : snapshot.regions()) {
            source.sendFeedback(() -> Text.literal("§f" + region.name() + ": §a" + region.located() + "§7/§f" + region.total()), false);
        }
        if (snapshot.planning()) {
            source.sendFeedback(() -> Text.literal("§ePlan en curso: §f" + snapshot.planDone() + "/" + snapshot.planTotal()), false);
        }
        if (snapshot.hasBounds()) {
            source.sendFeedback(() -> Text.literal("§7Área localizada + margen " + snapshot.padding() + ": §f"
                    + snapshot.width() + " × " + snapshot.length() + " bloques §7| centro §fX "
                    + snapshot.centerX() + " Z " + snapshot.centerZ()), false);
        }
        int unresolvedAsset = snapshot.assetOnly() - countLocatedAssetOnly(source.getServer());
        if (unresolvedAsset > 0) {
            source.sendFeedback(() -> Text.literal("§eQuedan " + unresolvedAsset
                    + " ubicaciones de plantilla sin ID STRUCTURE. Cuando estés físicamente en una, usa mapmark <región> <número>."), false);
        }
        return snapshot.located() == snapshot.total() ? 1 : 0;
    }

    public static synchronized int markCurrent(ServerCommandSource source, String rawRegion, int order) {
        ServerPlayerEntity player;
        try {
            player = source.getPlayerOrThrow();
        } catch (Exception exception) {
            source.sendFeedback(() -> Text.literal("§cEste comando debe ejecutarlo un jugador situado en la ubicación."), false);
            return 0;
        }
        String region = normalizeRegion(rawRegion);
        Definition target = definitions(source.getServer()).stream()
                .filter(d -> d.regionId().equals(region) && d.order() == order)
                .findFirst().orElse(null);
        if (target == null) {
            source.sendFeedback(() -> Text.literal("§cNo existe " + rawRegion + " #" + order + " en la ruta de 69 ubicaciones."), false);
            return 0;
        }
        ensureLoaded(source.getServer());
        SavedLocation location = saved.locations.computeIfAbsent(target.key(), ignored -> new SavedLocation());
        BlockPos pos = player.getBlockPos();
        location.structureId = target.registeredId() != null ? target.registeredId().toString() : target.bestAssetId();
        location.x = pos.getX();
        location.y = pos.getY();
        location.z = pos.getZ();
        location.located = true;
        location.manuallyMarked = true;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aUbicación guardada: §f" + target.regionName() + " #" + target.order()
                + " · " + target.label() + " §7→ §fX " + pos.getX() + " Y " + pos.getY() + " Z " + pos.getZ()), false);
        return 1;
    }

    public static synchronized int clearPlan(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        saved.locations.clear();
        job = null;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§eSe borraron las coordenadas guardadas de las 69 ubicaciones. No se modificó el mundo."), false);
        return 1;
    }

    public static synchronized MapSnapshot snapshot(MinecraftServer server) {
        ensureLoaded(server);
        List<Definition> definitions = definitions(server);
        Map<String, List<LocationView>> grouped = new LinkedHashMap<>();
        Map<String, String> regionNames = new LinkedHashMap<>();
        int located = 0;
        int registered = 0;
        int assetOnly = 0;
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
        for (Definition definition : definitions) {
            SavedLocation entry = saved.locations.get(definition.key());
            boolean found = entry != null && entry.located;
            if (found) {
                located++;
                minX = Math.min(minX, entry.x);
                maxX = Math.max(maxX, entry.x);
                minZ = Math.min(minZ, entry.z);
                maxZ = Math.max(maxZ, entry.z);
            }
            if (definition.registeredId() != null) registered++; else assetOnly++;
            String structureId = entry != null && entry.structureId != null && !entry.structureId.isBlank()
                    ? entry.structureId
                    : definition.registeredId() != null ? definition.registeredId().toString() : definition.bestAssetId();
            LocationView view = new LocationView(definition.key(), definition.regionId(), definition.order(), definition.label(),
                    structureId == null ? "" : structureId, definition.registeredId() != null, found,
                    definition.registeredId() == null,
                    found ? entry.x : 0, found ? entry.y : 0, found ? entry.z : 0);
            grouped.computeIfAbsent(definition.regionId(), ignored -> new ArrayList<>()).add(view);
            regionNames.put(definition.regionId(), definition.regionName());
        }
        List<RegionView> regions = new ArrayList<>();
        for (Map.Entry<String, List<LocationView>> entry : grouped.entrySet()) {
            int count = (int) entry.getValue().stream().filter(LocationView::located).count();
            regions.add(new RegionView(entry.getKey(), regionNames.getOrDefault(entry.getKey(), entry.getKey()), count,
                    entry.getValue().size(), List.copyOf(entry.getValue())));
        }
        boolean hasBounds = located > 0;
        int padding = Math.max(0, saved.padding);
        if (hasBounds) {
            minX -= padding; maxX += padding; minZ -= padding; maxZ += padding;
        } else {
            minX = maxX = minZ = maxZ = 0;
        }
        int centerX = hasBounds ? minX + (maxX - minX) / 2 : 0;
        int centerZ = hasBounds ? minZ + (maxZ - minZ) / 2 : 0;
        int width = hasBounds ? maxX - minX + 1 : 0;
        int length = hasBounds ? maxZ - minZ + 1 : 0;
        return new MapSnapshot(List.copyOf(regions), located, definitions.size(), registered, assetOnly,
                job != null, job == null ? 0 : job.done, job == null ? 0 : job.total,
                hasBounds, minX, maxX, minZ, maxZ, centerX, centerZ, width, length, padding);
    }

    private static void tick(MinecraftServer server) {
        synchronized (ImportantLocationService.class) {
            if (job == null) return;
            if (++tickCounter < LOCATE_INTERVAL_TICKS) return;
            tickCounter = 0;
            Definition definition = job.pending.poll();
            if (definition == null) {
                finishPlan(server);
                return;
            }
            locateOne(server, definition);
            job.done++;
            notifyRequester(server, "§dUbicaciones §f[" + job.done + "/" + job.total + "] §7"
                    + definition.regionName() + " · " + definition.label());
            if (job.pending.isEmpty()) finishPlan(server);
        }
    }

    private static void locateOne(MinecraftServer server, Definition definition) {
        if (definition.registeredId() == null) return;
        ServerWorld world = server.getOverworld();
        try {
            Registry<Structure> registry = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
            Optional<RegistryEntry.Reference<Structure>> optional = registry.getEntry(definition.registeredId());
            if (optional.isEmpty()) return;
            RegistryEntryList<Structure> list = RegistryEntryList.of(List.of(optional.get()));
            Pair<BlockPos, RegistryEntry<Structure>> found = world.getChunkManager().getChunkGenerator()
                    .locateStructure(world, list, world.getSpawnPos(), SEARCH_RADIUS_CHUNKS, false);
            if (found == null) return;
            BlockPos pos = found.getFirst();
            SavedLocation location = saved.locations.computeIfAbsent(definition.key(), ignored -> new SavedLocation());
            location.structureId = definition.registeredId().toString();
            location.x = pos.getX();
            location.y = pos.getY();
            location.z = pos.getZ();
            location.located = true;
            location.manuallyMarked = false;
            save(server);
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not locate important structure {} ({})", definition.label(), definition.registeredId(), exception);
        }
    }

    private static void finishPlan(MinecraftServer server) {
        PlanJob finished = job;
        job = null;
        save(server);
        MapSnapshot snapshot = snapshot(server);
        if (finished != null && finished.requester != null) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(finished.requester);
            if (player != null) {
                player.sendMessage(Text.literal("§aPlan terminado: §f" + snapshot.located() + "/" + snapshot.total()
                        + "§a ubicaciones con coordenadas."), false);
                if (snapshot.hasBounds()) {
                    player.sendMessage(Text.literal("§7Área mínima con margen: §f" + snapshot.width() + " × "
                            + snapshot.length() + " §7| centro §fX " + snapshot.centerX() + " Z " + snapshot.centerZ()), false);
                }
            }
        }
    }

    private static void notifyRequester(MinecraftServer server, String message) {
        if (job == null || job.requester == null) return;
        ServerPlayerEntity player = server.getPlayerManager().getPlayer(job.requester);
        if (player != null) player.sendMessage(Text.literal(message), true);
    }

    private static int countLocatedAssetOnly(MinecraftServer server) {
        int count = 0;
        for (Definition definition : definitions(server)) {
            if (definition.registeredId() != null) continue;
            SavedLocation location = saved.locations.get(definition.key());
            if (location != null && location.located) count++;
        }
        return count;
    }

    private static List<Definition> definitions(MinecraftServer server) {
        RegionalStructureAuditService.AuditResult audit = RegionalStructureAuditService.audit(server);
        List<Definition> result = new ArrayList<>();
        for (Map.Entry<String, List<String>> expectedRegion : RegionalStructureAuditService.expectedLabels().entrySet()) {
            String regionName = expectedRegion.getKey();
            String regionId = normalizeRegion(regionName);
            RegionalStructureAuditService.RegionResult region = audit.regions().get(regionName);
            for (int index = 0; index < expectedRegion.getValue().size(); index++) {
                String label = expectedRegion.getValue().get(index);
                List<String> matches = region == null ? List.of() : region.matches().getOrDefault(label, List.of());
                Identifier registered = null;
                String bestAsset = "";
                for (String display : matches) {
                    String raw = stripSource(display);
                    if (bestAsset.isBlank()) bestAsset = raw;
                    if (display.startsWith("[REGISTRY] ")) {
                        Identifier parsed = Identifier.tryParse(raw);
                        if (parsed != null) { registered = parsed; break; }
                    }
                }
                result.add(new Definition(regionId + ":" + (index + 1), regionId, regionName, index + 1,
                        label, registered, bestAsset));
            }
        }
        return List.copyOf(result);
    }

    private static String stripSource(String display) {
        if (display == null) return "";
        int end = display.indexOf("] ");
        return end >= 0 ? display.substring(end + 2).trim() : display.trim();
    }

    private static String normalizeRegion(String region) {
        if (region == null) return "";
        return region.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
    }

    private static void ensureLoaded(MinecraftServer server) {
        if (configManager == null || server == null || server.getOverworld() == null) return;
        long seed = server.getOverworld().getSeed();
        if (loadedSeed == seed) return;
        loadedSeed = seed;
        saved = new SavedState();
        saved.seed = seed;
        Path file = stateFile(seed);
        if (!Files.exists(file)) return;
        try {
            SavedState loaded = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), SavedState.class);
            if (loaded != null && loaded.seed == seed) {
                if (loaded.locations == null) loaded.locations = new LinkedHashMap<>();
                if (loaded.padding <= 0) loaded.padding = DEFAULT_PADDING;
                saved = loaded;
            }
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.warn("Could not read important-location plan {}", file, exception);
        }
    }

    private static void save(MinecraftServer server) {
        if (configManager == null || server == null) return;
        ensureLoaded(server);
        Path file = stateFile(saved.seed);
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(temp, GSON.toJson(saved), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            Chainacobblemon.LOGGER.warn("Could not save important-location plan {}", file, exception);
        }
    }

    private static Path stateFile(long seed) {
        return configManager.configDirectory().resolve("important-locations-" + Long.toUnsignedString(seed) + ".json");
    }
}
