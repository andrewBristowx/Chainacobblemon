package com.andrewbristowx.chainacobblemon.npc;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Canonical presets for Chaina's custom region. Locations and ordinary rewards intentionally remain
 * server-owner controlled. Every spawned preset is a normal editable ServiceNpcEntity: its dialogue,
 * name, team and skin can still be changed with the existing NPC editor/skin commands without rebuilding.
 */
public final class CustomRegionTrainerCatalog {
    public enum Kind { NORMAL, ELITE_FOUR, CHAMPION, MEGA_MENTOR }
    public enum BattleMode { SINGLE, DOUBLE }

    public record Profile(String id, String displayName, Kind kind, BattleMode battleMode,
                          String defaultDialogue, List<String> team) {
        public Profile { team = List.copyOf(team); }
    }

    private static final Map<String, Profile> PROFILES = new LinkedHashMap<>();
    private static final List<String> MEGA_MENTOR_ACES = List.of(
            "absol level=50 moves=knockoff,suckerpunch,playrough,swordsdance ability=pressure helditem=mega_showdown:absolite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "alakazam level=50 moves=psychic,shadowball,focusblast,calmmind ability=synchronize helditem=mega_showdown:alakazite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "ampharos level=50 moves=thunderbolt,dragonpulse,focusblast,voltswitch ability=static helditem=mega_showdown:ampharosite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "blaziken level=50 moves=closecombat,flareblitz,thunderpunch,swordsdance ability=speedboost helditem=mega_showdown:blazikenite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "garchomp level=50 moves=earthquake,dragonclaw,stoneedge,swordsdance ability=roughskin helditem=mega_showdown:garchompite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "gardevoir level=50 moves=moonblast,psychic,shadowball,calmmind ability=trace helditem=mega_showdown:gardevoirite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "gengar level=50 moves=shadowball,sludgewave,thunderbolt,focusblast ability=cursedbody helditem=mega_showdown:gengarite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "gyarados level=50 moves=waterfall,crunch,earthquake,dragondance ability=intimidate helditem=mega_showdown:gyaradosite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "lucario level=50 moves=closecombat,bulletpunch,crunch,swordsdance ability=steadfast helditem=mega_showdown:lucarionite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "mawile level=50 moves=playrough,ironhead,suckerpunch,swordsdance ability=intimidate helditem=mega_showdown:mawilite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "metagross level=50 moves=meteormash,zenheadbutt,earthquake,bulletpunch ability=clearbody helditem=mega_showdown:metagrossite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "salamence level=50 moves=doubleedge,dragonclaw,earthquake,dragondance ability=intimidate helditem=mega_showdown:salamencite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "scizor level=50 moves=bulletpunch,xscissor,closecombat,swordsdance ability=technician helditem=mega_showdown:scizorite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
            "tyranitar level=50 moves=stoneedge,crunch,earthquake,icepunch ability=sandstream helditem=mega_showdown:tyranitarite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
    );

    static {
        add(new Profile("region_hio", "Hio", Kind.NORMAL, BattleMode.SINGLE,
                "Mi equipo cambia de ritmo rápido. Si vienes a combatir, no esperes que te regale ningún turno.", List.of(
                        "flareon level=50 moves=flareblitz,doubleedge,superpower,batonpass ability=flashfire helditem=auto:choice_band hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "leafeon level=50 moves=swordsdance,substitute,xscissor,leafblade ability=leafguard helditem=auto:liechi_berry hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "jolteon level=50 moves=shadowball,voltswitch,thunderbolt,hiddenpowerice ability=voltabsorb helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "umbreon level=50 shiny=true moves=wish,protect,healbell,foulplay ability=synchronize helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "sylveon level=50 moves=hypervoice,psychic,hiddenpowerfighting,dazzlinggleam ability=pixilate helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "glaceon level=50 moves=signalbeam,icebeam,hiddenpowerground,freezedry ability=snowcloak helditem=auto:choice_scarf hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_next", "Next", Kind.NORMAL, BattleMode.SINGLE,
                "La arena no perdona errores. Prepárate para cambios, presión y una Mega cuando encuentre el momento.", List.of(
                        "tyranitar level=50 moves=pursuit,superpower,stoneedge,fireblast ability=sandstream helditem=auto:assault_vest hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "mawile level=50 moves=swordsdance,ironhead,playrough,suckerpunch ability=intimidate helditem=mega_showdown:mawilite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "garchomp level=50 moves=earthquake,dragonclaw,swordsdance,rockslide ability=sandveil helditem=auto:lum_berry hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "excadrill level=50 moves=earthquake,rockslide,ironhead,rapidspin ability=sandrush helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "gholdengo level=50 moves=nastyplot,shadowball,recover,makeitrain ability=goodasgold helditem=auto:air_balloon hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "rotom level=50 appliance=wash moves=hydropump,willowisp,voltswitch,thunderbolt ability=levitate helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_shipti", "Shipti", Kind.NORMAL, BattleMode.SINGLE,
                "No te fíes de lo adorable. Mi equipo está preparado para castigarte en cuanto pierdas el control del combate.", List.of(
                        "meowscarada level=50 moves=knockoff,tripleaxel,flowertrick,uturn ability=protean helditem=auto:choice_scarf hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "mimikyu level=50 moves=swordsdance,shadowclaw,shadowsneak,drainpunch ability=disguise helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "sylveon level=50 moves=hypervoice,psychic,shadowball,drainingkiss ability=pixilate helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "volcarona level=50 moves=quiverdance,flamethrower,willowisp,morningsun ability=flamebody helditem=auto:heavy_duty_boots hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "lopunny level=50 moves=frustration,closecombat,fakeout,uturn ability=cutecharm helditem=mega_showdown:lopunnite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "vaporeon level=50 moves=scald,wish,protect,flipturn ability=waterabsorb helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_javitd", "JaviTD", Kind.NORMAL, BattleMode.SINGLE,
                "Si me das un turno libre, voy a convertirlo en ventaja. Ven preparado para jugar alrededor de estados y cambios.", List.of(
                        "scolipede level=50 moves=toxicspikes,protect,earthquake,megahorn ability=speedboost helditem=auto:black_sludge hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "rotom level=50 appliance=heat moves=overheat,voltswitch,willowisp,nastyplot ability=levitate helditem=auto:sitrus_berry hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "buzzwole level=50 moves=drainpunch,icepunch,earthquake,roost ability=beastboost helditem=auto:rocky_helmet hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "weavile level=50 moves=swordsdance,tripleaxel,knockoff,lowkick ability=pickpocket helditem=auto:heavy_duty_boots hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "hatterene level=50 moves=drainingkiss,painsplit,nuzzle,dazzlinggleam ability=magicbounce helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "greninja level=50 moves=surf,darkpulse,icebeam,sludgewave ability=protean helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_somita", "Somita", Kind.NORMAL, BattleMode.SINGLE,
                "Tengo más de una forma de romper tu plan. Si crees que ya entendiste mi equipo, seguramente llegaste tarde.", List.of(
                        "great_tusk level=50 moves=headlongrush,icespinner,stealthrock,knockoff ability=protosynthesis helditem=auto:rocky_helmet hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "zoroark level=50 moves=darkpulse,sludgebomb,flamethrower,grassknot ability=illusion helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "aegislash level=50 moves=toxic,kingsshield,shadowball,substitute ability=stancechange helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "magnezone level=50 moves=voltswitch,hiddenpowerfire,thunderbolt,flashcannon ability=pickpocket helditem=auto:heavy_duty_boots hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "salamence level=50 moves=dragondance,dragonclaw,earthquake,firefang ability=intimidate helditem=mega_showdown:salamencite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "slurpuff level=50 moves=bellydrum,playrough,drainpunch,substitute ability=unburden helditem=auto:sitrus_berry hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_muffin", "Muffin", Kind.NORMAL, BattleMode.SINGLE,
                "Primero aguanto, después presiono. Tendrás que abrirte paso sin dejar que mi equipo tome el control del campo.", List.of(
                        "grimmsnarl level=50 moves=reflect,lightscreen,taunt,playrough ability=prankster helditem=auto:light_clay hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "corviknight level=50 moves=bodypress,irondefense,roost,uturn ability=pressure helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "golisopod level=50 moves=firstimpression,liquidation,leechlife,aquajet ability=emergencyexit helditem=auto:sitrus_berry hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "ursaluna level=50 moves=facade,headlongrush,icepunch,protect ability=guts helditem=auto:flame_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "metagross level=50 moves=meteormash,zenheadbutt,pursuit,hammerarm ability=clearbody helditem=auto:assault_vest hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "gengar level=50 moves=shadowball,sludgewave,thunderbolt,icywind ability=cursedbody helditem=mega_showdown:gengarite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_lulita_duber", "Lulita + Duber", Kind.NORMAL, BattleMode.DOUBLE,
                "Aquí se pelea de dos en dos. Si solo miras a un rival, el otro ya estará preparando la jugada que te derrota.", List.of(
                        "sylveon level=50 moves=hyperbeam,hypervoice,mysticalfire,protect ability=pixilate helditem=auto:fairy_feather hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "dewgong level=50 moves=protect,fakeout,toxic,flipturn ability=thickfat helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "naganadel level=50 moves=sludgebomb,dracometeor,airslash,flamethrower ability=beastboost helditem=auto:assault_vest hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "garchomp level=50 moves=ironhead,stompingtantrum,protect,rockslide ability=roughskin helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "primarina level=50 moves=hypervoice,protect,moonblast,dazzlinggleam ability=liquidvoice helditem=auto:throat_spray hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "dragapult level=50 moves=dragondarts,phantomforce,protect,willowisp ability=infiltrator helditem=auto:focus_band hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_cerre", "Cerre", Kind.ELITE_FOUR, BattleMode.SINGLE,
                "Has llegado al Alto Mando. Aquí una mala decisión cuesta el combate completo.", List.of(
                        "clefable level=50 moves=stealthrock,moonblast,softboiled,thunderwave ability=magicguard helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "raichu level=50 moves=thunderbolt,focusblast,hiddenpowerice,nastyplot ability=lightningrod helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "kingambit level=50 moves=swordsdance,suckerpunch,ironhead,lowkick ability=supremeoverlord helditem=auto:air_balloon hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "toxapex level=50 moves=recover,haze,toxic,knockoff ability=regenerator helditem=auto:black_sludge hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "charizard level=50 moves=dragondance,dragonclaw,flareblitz,earthquake ability=blaze helditem=mega_showdown:charizardite_x hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "dragonite level=50 moves=dragondance,extremespeed,earthquake,icespinner ability=multiscale helditem=auto:heavy_duty_boots hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_roland", "Roland", Kind.ELITE_FOUR, BattleMode.SINGLE,
                "La fuerza no basta: tendrás que leer cada cambio y sobrevivir a un equipo construido para castigarte.", List.of(
                        "palafin level=50 moves=flipturn,drainpunch,icepunch,jetpunch ability=zerotohero helditem=auto:choice_band hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "ursaluna level=50 form=bloodmoon moves=moonblast,earthpower,bloodmoon,calmmind ability=mindseye helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "amoonguss level=50 moves=spore,clearsmog,gigadrain,foulplay ability=regenerator helditem=auto:black_sludge hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "salamence level=50 moves=doubleedge,dragonclaw,roost,dragondance ability=intimidate helditem=mega_showdown:salamencite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "blaziken level=50 moves=drainpunch,swordsdance,firepunch,thunderpunch ability=speedboost helditem=auto:covert_cloak hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "kingambit level=50 moves=kowtowcleave,swordsdance,ironhead,aerialace ability=supremeoverlord helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_lynn", "Lynn", Kind.ELITE_FOUR, BattleMode.SINGLE,
                "Mi equipo juega con el ritmo del combate. Si te precipitas, vas a hacer exactamente lo que necesito.", List.of(
                        "gliscor level=50 moves=stealthrock,roost,earthquake,icefang ability=poisonheal helditem=auto:toxic_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "morpeko level=50 moves=aurawheel,crunch,seedbomb,partingshot ability=hungerswitch helditem=auto:choice_band hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "gengar level=50 moves=shadowball,sludgewave,thunderbolt,icywind ability=cursedbody helditem=mega_showdown:gengarite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "mimikyu level=50 moves=swordsdance,shadowclaw,shadowsneak,drainpunch ability=disguise helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "greninja level=50 moves=surf,darkpulse,icebeam,watershuriken ability=protean helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "chandelure level=50 moves=substitute,calmmind,shadowball,flamethrower ability=flamebody helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_alu", "Alu", Kind.ELITE_FOUR, BattleMode.SINGLE,
                "Para superar esta sala tendrás que romper defensas, soportar presión y encontrar el turno exacto para atacar.", List.of(
                        "skarmory level=50 moves=spikes,roost,whirlwind,toxic ability=sturdy helditem=auto:rocky_helmet hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "typhlosion level=50 form=hisui moves=eruption,flamethrower,shadowball,focusblast ability=blaze helditem=auto:choice_scarf hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "charizard level=50 moves=flamethrower,hurricane,dragonpulse,focusblast ability=blaze helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "swampert level=50 moves=stealthrock,waterfall,earthquake,roar ability=torrent helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "lucario level=50 moves=swordsdance,bulletpunch,crunch,closecombat ability=steadfast helditem=mega_showdown:lucarionite hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "toxapex level=50 moves=scald,banefulbunker,recover,haze ability=regenerator helditem=auto:black_sludge hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("region_chaina", "Chaina", Kind.CHAMPION, BattleMode.SINGLE,
                "Llegaste hasta la Campeona. No habrá una prueba después de esta: demuestra aquí todo lo que aprendiste.", List.of(
                        "meowscarada level=50 moves=knockoff,tripleaxel,flowertrick,uturn ability=protean helditem=auto:choice_band hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "gengar level=50 moves=shadowball,sludgewave,thunderbolt,icywind ability=cursedbody helditem=auto:choice_specs hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "rayquaza level=50 moves=earthquake,dragondance,dragonascent,extremespeed ability=airlock helditem=auto:life_orb hp_iv=20 attack_iv=20 defence_iv=20 special_attack_iv=20 special_defence_iv=20 speed_iv=20",
                        "dragapult level=50 moves=dragondarts,hex,willowisp,uturn ability=infiltrator helditem=auto:heavy_duty_boots hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "groudon level=50 moves=stealthrock,precipiceblades,firepunch,thunderwave ability=drought helditem=mega_showdown:red_orb hp_iv=20 attack_iv=20 defence_iv=20 special_attack_iv=20 special_defence_iv=20 speed_iv=20",
                        "charizard level=50 moves=flamethrower,hurricane,dragonpulse,focusblast ability=blaze helditem=auto:focus_band hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
        add(new Profile("mega_mentor", "Maestro de la Mega Evolución", Kind.MEGA_MENTOR, BattleMode.SINGLE,
                "La Mega Evolución exige sincronía, no solo poder. Derrótame y te entregaré lo necesario para comenzar tu propio entrenamiento.", List.of(
                        "rotom level=50 appliance=wash moves=voltswitch,hydropump,willowisp,thunderbolt ability=levitate helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "corviknight level=50 moves=bodypress,irondefense,roost,uturn ability=pressure helditem=auto:leftovers hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "garchomp level=50 moves=earthquake,dragonclaw,rockslide,swordsdance ability=roughskin helditem=auto:life_orb hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "primarina level=50 moves=hypervoice,moonblast,icebeam,protect ability=liquidvoice helditem=auto:throat_spray hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31",
                        "dragapult level=50 moves=dragondarts,shadowball,willowisp,uturn ability=infiltrator helditem=auto:heavy_duty_boots hp_iv=31 attack_iv=31 defence_iv=31 special_attack_iv=31 special_defence_iv=31 speed_iv=31"
                )));
    }

    private CustomRegionTrainerCatalog() {}

    private static void add(Profile profile) {
        if (PROFILES.put(profile.id(), profile) != null) throw new IllegalStateException("Duplicate custom trainer: " + profile.id());
    }

    public static List<Profile> all() { return List.copyOf(PROFILES.values()); }

    public static List<String> ids() { return List.copyOf(PROFILES.keySet()); }

    /** Short names accepted by the admin spawn command (hio, next, chaina, mega_mentor...). */
    public static List<String> commandKeys() {
        List<String> keys = new ArrayList<>();
        for (String id : PROFILES.keySet()) {
            keys.add(id.startsWith("region_") ? id.substring("region_".length()) : id);
        }
        return List.copyOf(keys);
    }

    public static Profile byId(String id) {
        if (id == null) return null;
        String normalized = id.trim().toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        Profile direct = PROFILES.get(normalized);
        if (direct != null) return direct;
        if (!normalized.startsWith("region_")) return PROFILES.get("region_" + normalized);
        return null;
    }

    public static boolean isManaged(ServiceNpcEntity npc) {
        return npc != null && byId(npc.npcId()) != null;
    }

    public static boolean isMegaMentor(ServiceNpcEntity npc) {
        Profile profile = npc == null ? null : byId(npc.npcId());
        return profile != null && profile.kind() == Kind.MEGA_MENTOR;
    }

    public static boolean isDouble(ServiceNpcEntity npc) {
        Profile profile = npc == null ? null : byId(npc.npcId());
        return profile != null && profile.battleMode() == BattleMode.DOUBLE;
    }

    public static int difficulty(ServiceNpcEntity npc) { return isManaged(npc) ? 4 : 1; }

    /** Resolves namespace-flexible held items before persisting a preset in the normal NPC editor. */
    public static List<String> teamForStorage(Profile profile) {
        if (profile == null) return List.of();
        List<String> result = new ArrayList<>(profile.team().size());
        for (String spec : profile.team()) result.add(resolveAutoItem(spec));
        return List.copyOf(result);
    }

    /** Team seen by RCT for this exact battle. NPC NBT is never mutated. */
    public static List<String> teamForBattle(ServerPlayerEntity player, ServiceNpcEntity npc) {
        Profile profile = byId(npc == null ? null : npc.npcId());
        if (profile == null) return npc == null ? List.of() : npc.pokemonTeam();
        List<String> authored = npc.pokemonTeam().isEmpty() ? profile.team() : npc.pokemonTeam();
        List<String> source = profile.kind() == Kind.MEGA_MENTOR ? randomMegaMentorTeam(authored) : authored;
        int target = targetLevel(player, profile);
        List<String> result = new ArrayList<>(Math.min(6, source.size()));
        for (String spec : source) {
            if (result.size() >= 6) break;
            result.add(resolveAutoItem(withLevel(spec, target)));
        }
        return List.copyOf(result);
    }

    public static int targetLevel(ServerPlayerEntity player, Profile profile) {
        int base = averageTopThree(player);
        if (base <= 0) base = 50;
        int bonus = switch (profile.kind()) {
            case NORMAL -> 0;
            case ELITE_FOUR, MEGA_MENTOR -> 2;
            case CHAMPION -> 3;
        };
        return Math.max(1, Math.min(100, base + bonus));
    }

    private static List<String> randomMegaMentorTeam(List<String> authored) {
        List<String> team = new ArrayList<>();
        if (authored != null) {
            for (String spec : authored) {
                if (team.size() >= 5) break;
                if (spec != null && !spec.isBlank()) team.add(stripMegaHeldItem(spec));
            }
        }
        // Always exactly one Mega-capable ace. The choice is made again for every battle start.
        String ace = MEGA_MENTOR_ACES.get(ThreadLocalRandom.current().nextInt(MEGA_MENTOR_ACES.size()));
        team.add(ace);
        return List.copyOf(team);
    }

    private static String stripMegaHeldItem(String spec) {
        if (spec == null || spec.isBlank()) return "";
        StringBuilder out = new StringBuilder();
        for (String token : spec.trim().split("\\s+")) {
            if (token.toLowerCase(Locale.ROOT).startsWith("helditem=mega_showdown:")) continue;
            if (!out.isEmpty()) out.append(' ');
            out.append(token);
        }
        return out.toString();
    }

    private static String withLevel(String spec, int level) {
        if (spec == null) return "";
        StringBuilder out = new StringBuilder();
        boolean replaced = false;
        for (String token : spec.trim().split("\\s+")) {
            String current = token;
            if (token.toLowerCase(Locale.ROOT).startsWith("level=")) {
                current = "level=" + level;
                replaced = true;
            }
            if (!out.isEmpty()) out.append(' ');
            out.append(current);
        }
        if (!replaced) out.append(" level=").append(level);
        return out.toString().trim();
    }

    /**
     * Competitive items moved between Cobblemon/Mega Showdown across pack versions. Presets use
     * helditem=auto:<path>; at battle time the first actually registered namespace is selected.
     */
    private static String resolveAutoItem(String spec) {
        if (spec == null || !spec.contains("helditem=auto:")) return spec;
        StringBuilder out = new StringBuilder();
        for (String token : spec.trim().split("\\s+")) {
            if (token.startsWith("helditem=auto:")) {
                String path = token.substring("helditem=auto:".length());
                token = "helditem=" + resolveItem(path);
            }
            if (!out.isEmpty()) out.append(' ');
            out.append(token);
        }
        return out.toString();
    }

    private static String resolveItem(String path) {
        for (String namespace : List.of("cobblemon", "mega_showdown")) {
            Identifier id = Identifier.tryParse(namespace + ":" + path);
            if (id != null && Registries.ITEM.containsId(id)) {
                Item item = Registries.ITEM.get(id);
                if (item != null && item != Items.AIR) return id.toString();
            }
        }
        // Keep the authored Cobblemon identifier so the battle error is explicit instead of silently
        // changing the requested held item. This also makes missing addon content easy to diagnose.
        Chainacobblemon.LOGGER.warn("Custom region trainer held item is not currently registered: {}", path);
        return "cobblemon:" + path;
    }

    private static int averageTopThree(ServerPlayerEntity player) {
        if (player == null) return 0;
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                List<Integer> levels = new ArrayList<>();
                for (Pokemon pokemon : party) if (pokemon != null) levels.add(pokemon.getLevel());
                levels.sort(Collections.reverseOrder());
                int count = Math.min(3, levels.size());
                if (count == 0) return 0;
                int total = 0;
                for (int i = 0; i < count; i++) total += levels.get(i);
                return Math.max(1, Math.min(100, Math.round((float) total / count)));
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not calculate custom region trainer target level: {}", exception.toString());
        }
        return 0;
    }
}
