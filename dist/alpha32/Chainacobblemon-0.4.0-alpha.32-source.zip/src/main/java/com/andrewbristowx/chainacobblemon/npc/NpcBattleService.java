package com.andrewbristowx.chainacobblemon.npc;

import com.cobblemon.mod.common.api.pokemon.PokemonProperties;
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeCatalog;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeService;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeProfile;
import com.andrewbristowx.chainacobblemon.challenge.DynamicTrainerLevelService;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.andrewbristowx.chainacobblemon.dungeon.DungeonTrainerService;
import com.andrewbristowx.chainacobblemon.events.treasure.TreasureHuntService;
import com.andrewbristowx.chainacobblemon.tower.ChallengeTowerService;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;

import java.lang.reflect.Array;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class NpcBattleService {
    private static final long START_COOLDOWN_MS = 5_000L;
    private static final Map<UUID, Long> LAST_START = new ConcurrentHashMap<>();
    private static final Map<UUID, ActiveBattle> ACTIVE_BATTLES = new ConcurrentHashMap<>();
    private static Object battleEndListener;

    private NpcBattleService() {
    }

    public static boolean auditCompatibility(MinecraftServer server) {
        if (!FabricLoader.getInstance().isModLoaded("rctapi") || !FabricLoader.getInstance().isModLoaded("rctmod")) {
            Chainacobblemon.LOGGER.error("Custom trainer battles disabled: exact rctapi/rctmod dependencies are missing");
            return false;
        }
        try {
            Class<?> trainerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.Trainer");
            Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
            Class<?> trainerPlayerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerPlayer");
            Class<?> trainerBagClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerBag");
            Class<?> battleAiClass = Class.forName("com.cobblemon.mod.common.api.battles.model.ai.BattleAI");
            Class<?> rctApiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
            Class<?> pokemonArrayClass = Array.newInstance(Pokemon.class, 0).getClass();
            trainerNpcClass.getConstructor(String.class, pokemonArrayClass, trainerBagClass,
                    battleAiClass, LivingEntity.class);
            trainerNpcClass.getConstructor(trainerNpcClass);
            trainerNpcClass.getMethod("getGimmicks");
            Class<?> gimmicksClass = Class.forName("com.gitlab.srcmc.rctapi.api.models.Gimmicks");
            gimmicksClass.getConstructor(String.class, boolean.class, boolean.class);
            Class<?> aiConfigClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.config.RCTBattleAIConfig");
            Class<?> aiConfigBuilderClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.config.RCTBattleAIConfig$Builder");
            aiConfigBuilderClass.getMethod("withMoveBias", double.class);
            aiConfigBuilderClass.getMethod("withStatusMoveBias", double.class);
            aiConfigBuilderClass.getMethod("withSwitchBias", double.class);
            aiConfigBuilderClass.getMethod("withMaxSelectMargin", double.class);
            aiConfigBuilderClass.getMethod("build");
            Class.forName("com.gitlab.srcmc.rctapi.api.ai.RCTBattleAI").getConstructor(aiConfigClass);
            trainerPlayerClass.getConstructor(ServerPlayerEntity.class);
            Object rct = rctApiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
            if (rct == null) throw new IllegalStateException("rctmod instance missing");
            Object battleManager = rctApiClass.getMethod("getBattleManager").invoke(rct);
            battleManager.getClass().getMethod("startSingle", trainerClass, trainerClass);
            Class<?> providerClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormatProvider");
            Class<?> battleFormatClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormat");
            Object singlesProvider = battleFormatClass.getField("GEN_9_SINGLES").get(null);
            battleFormatClass.getField("GEN_9_DOUBLES").get(null);
            Object cobblemonFormat = providerClass.getMethod("getCobblemonBattleFormat").invoke(singlesProvider);
            copyCobblemonFormatWithLevel(cobblemonFormat, 50);
            Class<?> rulesBuilderClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleRules$Builder");
            rulesBuilderClass.getMethod("withAdjustPlayerLevels", boolean.class);
            rulesBuilderClass.getMethod("withAdjustNPCLevels", boolean.class);
            registerBattleEndListener(rct, rctApiClass);
            Chainacobblemon.LOGGER.info("Exact RCT custom trainer battle API validated on {}", server.getVersion());
            return true;
        } catch (Exception | LinkageError exception) {
            Chainacobblemon.LOGGER.error("Custom trainer battles disabled: exact RCT API audit failed", exception);
            return false;
        }
    }

    public static List<String> validateTeam(List<String> rawSpecs) {
        if (rawSpecs == null) return List.of();
        List<String> result = new ArrayList<>();
        for (String raw : rawSpecs) {
            if (result.size() >= 6) throw new IllegalArgumentException("El equipo admite como máximo 6 Pokémon.");
            String spec = raw == null ? "" : raw.strip();
            if (spec.isBlank()) continue;
            if (spec.length() > 256) throw new IllegalArgumentException("Cada Pokémon admite como máximo 256 caracteres.");
            PokemonProperties properties = PokemonProperties.Companion.parse(spec);
            if (!properties.hasSpecies() || PokemonSpecies.getByName(properties.getSpecies()) == null) {
                throw new IllegalArgumentException("Pokémon no válido en el equipo: " + spec);
            }
            Integer level = properties.getLevel();
            if (level != null && (level < 1 || level > 100)) {
                throw new IllegalArgumentException("El nivel debe estar entre 1 y 100: " + spec);
            }
            // Crear una copia durante la validación hace que Cobblemon compruebe forma, habilidad y movimientos.
            properties.create();
            result.add(spec);
        }
        return List.copyOf(result);
    }

    public static boolean start(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null || npc.isRemoved()) return false;
        ChallengeProfile profile = ChallengeCatalog.byNpcId(npc.npcId());
        if (DungeonTrainerService.isDungeonTrainer(npc) && !DungeonTrainerService.canChallenge(player, npc, true)) return false;
        if (profile != null && !ChallengeService.canChallenge(player, profile, true)) return false;
        if (player.getWorld() != npc.getWorld() || (!ChallengeTowerService.isTowerTrainer(npc) && player.squaredDistanceTo(npc) > 100.0D)) {
            player.sendMessage(net.minecraft.text.Text.literal("§cDebes estar cerca del NPC para luchar."), false);
            return false;
        }
        if (profile != null) {
            RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
            if (!cap.allowed()) {
                player.sendMessage(net.minecraft.text.Text.literal("§cTu equipo supera el límite de nivel de Cobbleverse/RCT. "
                        + "§7Límite actual: §f" + cap.cap() + " §7· nivel más alto: §f" + cap.highestPartyLevel()), false);
                return false;
            }
        }
        long now = System.currentTimeMillis();
        long previous = LAST_START.getOrDefault(player.getUuid(), 0L);
        if (now - previous < START_COOLDOWN_MS) {
            player.sendMessage(net.minecraft.text.Text.literal("§eEspera unos segundos antes de iniciar otro combate."), false);
            return false;
        }
        if (!FabricLoader.getInstance().isModLoaded("rctapi") || !FabricLoader.getInstance().isModLoaded("rctmod")) {
            player.sendMessage(net.minecraft.text.Text.literal("§cCobbleverse no tiene cargados RCT API y RCT Mod."), false);
            return false;
        }
        if (CustomRegionTrainerCatalog.isMegaMentor(npc) && !FabricLoader.getInstance().isModLoaded("mega_showdown")) {
            player.sendMessage(net.minecraft.text.Text.literal("§cLa misión de Mega Evolución necesita Mega Showdown cargado."), false);
            return false;
        }
        try {
            Class<?> trainerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.Trainer");
            Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
            Class<?> trainerPlayerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerPlayer");
            Class<?> rctApiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
            Object rct = rctApiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
            if (rct == null) throw new IllegalStateException("La instancia rctmod no está inicializada.");

            Object npcTrainer = null;
            DynamicTrainerLevelService.ScalingResult scaling = profile == null
                    ? new DynamicTrainerLevelService.ScalingResult(List.of(), 0, 0, false)
                    : DynamicTrainerLevelService.scale(player, profile);
            // Keep the exact native Cobbleverse trainer when its authored level curve is still appropriate.
            // Once a player has progressed beyond it, build an RCTBattleAI trainer from Chainacobblemon's same
            // species composition shifted upward to that player's current progression.
            // Gym leaders keep their authored Cobbleverse teams/moves, but we clone the trainer and
            // explicitly remove RCT battle gimmicks. Elite Four and Champions are rebuilt below so
            // Chainacobblemon can guarantee exactly the requested special-mechanic policy.
            RctCobbleverseBridge.NativeTrainer nativeTrainer = profile == null || scaling.scaled()
                    || profile.isEliteFour() || profile.isChampion() ? null
                    : RctCobbleverseBridge.attachNativeTrainer(player.getServer(), profile, npc);
            if (nativeTrainer != null) {
                npcTrainer = createControlledNativeTrainer(nativeTrainer.trainer(), profile, npc);
                Chainacobblemon.LOGGER.info("Challenge {} uses controlled copy of native Cobbleverse/RCT trainer {} (gym gimmicks disabled)",
                        profile.key(), nativeTrainer.trainerId());
            }

            if (npcTrainer == null) {
                List<String> specs;
                try {
                    List<String> requestedTeam = profile != null
                            ? prepareRegionalTeam(profile, scaling.team())
                            : CustomRegionTrainerCatalog.isManaged(npc)
                                ? CustomRegionTrainerCatalog.teamForBattle(player, npc)
                                : DungeonTrainerService.isDungeonTrainer(npc)
                                    ? DungeonTrainerService.scaledTeam(player, npc)
                                    : npc.pokemonTeam();
                    specs = validateTeam(requestedTeam);
                } catch (IllegalArgumentException exception) {
                    player.sendMessage(net.minecraft.text.Text.literal("§cEquipo inválido: " + exception.getMessage()), false);
                    return false;
                }
                if (specs.isEmpty()) {
                    player.sendMessage(net.minecraft.text.Text.literal("§eEste NPC todavía no tiene equipo Pokémon."), false);
                    return false;
                }
                Pokemon[] team = new Pokemon[specs.size()];
                for (int index = 0; index < specs.size(); index++) {
                    team[index] = PokemonProperties.Companion.parse(specs.get(index)).create();
                }
                Class<?> trainerBagClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerBag");
                Class<?> battleAiClass = Class.forName("com.cobblemon.mod.common.api.battles.model.ai.BattleAI");
                Class<?> rctBattleAiClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.RCTBattleAI");
                Object bag = trainerBagClass.getConstructor().newInstance();
                Object ai = createBattleAi(rctBattleAiClass, battleDifficulty(profile, npc));
                Class<?> pokemonArrayClass = Array.newInstance(Pokemon.class, 0).getClass();
                boolean treasureBattleName = npc.dungeonStructureKey() != null && npc.dungeonStructureKey().startsWith("treasure_event:");
                String trainerName = treasureBattleName
                        ? ("guardian".equalsIgnoreCase(npc.dungeonRole()) ? "Guardián del Tesoro" : "Entrenador del Pasillo")
                        : npc.getCustomName() == null ? npc.npcId() : npc.getCustomName().getString();
                npcTrainer = trainerNpcClass.getConstructor(String.class, pokemonArrayClass, trainerBagClass,
                        battleAiClass, LivingEntity.class).newInstance(trainerName, team, bag, ai, npc);
                applyRegionalGimmickPolicy(npcTrainer, profile);
                if (CustomRegionTrainerCatalog.isManaged(npc)) {
                    CustomRegionTrainerCatalog.Profile custom = CustomRegionTrainerCatalog.byId(npc.npcId());
                    int target = CustomRegionTrainerCatalog.targetLevel(player, custom);
                    String mode = CustomRegionTrainerCatalog.isDouble(npc) ? " §7· §dcombate doble" : "";
                    String mega = CustomRegionTrainerCatalog.isMegaMentor(npc) ? " §7· §dMega aleatoria" : "";
                    player.sendMessage(net.minecraft.text.Text.literal("§c⚔ Región custom · IA difícil · §fRival ~Nv. "
                            + target + mode + mega + "§7 · basado en tus 3 Pokémon más altos."), false);
                } else if (DungeonTrainerService.isDungeonTrainer(npc)) {
                    int target = DungeonTrainerService.targetLevel(player, npc);
                    boolean treasureEvent = npc.dungeonStructureKey().startsWith("treasure_event:");
                    player.sendMessage(net.minecraft.text.Text.literal(treasureEvent
                            ? "§6🗺 Cacería adaptativa · §fRival ~Nv. " + target + " §7· basado en tus 3 Pokémon más altos; tu equipo conserva sus niveles reales."
                            : "§d⚔ Mazmorra adaptativa · §fRival ~Nv. " + target + " §7· basado en tus niveles reales; tu equipo conserva sus niveles."), false);
                } else if (ChallengeTowerService.isTowerTrainer(npc)) {
                    player.sendMessage(net.minecraft.text.Text.literal("§d🏰 Torre adaptativa · §fRival generado alrededor de Nv. "
                            + ChallengeTowerService.targetLevel(player) + "§7 · tu equipo conserva sus niveles reales."), false);
                } else if (profile != null && scaling.scaled()) {
                    player.sendMessage(net.minecraft.text.Text.literal("§d⚔ Equipo adaptado a tu progreso: §fNv. "
                            + scaling.authoredMax() + " → " + scaling.targetMax()
                            + " §7(sin modificar tu límite de nivel)."), false);
                } else if (profile != null) {
                    player.sendMessage(net.minecraft.text.Text.literal("§eNo encontré el perfil nativo de este entrenador en RCT; se usará el equipo de respaldo de Chainacobblemon."), false);
                }
            }

            Object playerTrainer = trainerPlayerClass.getConstructor(ServerPlayerEntity.class).newInstance(player);
            Object battleManager = rctApiClass.getMethod("getBattleManager").invoke(rct);
            BattleLaunchConfig launchConfig;
            if (CustomRegionTrainerCatalog.isDouble(npc)) {
                launchConfig = customDoubleBattleConfig(npcTrainer);
            } else if (DungeonTrainerService.isDungeonTrainer(npc)) {
                // All dungeon encounters scale the OPPONENT to the player's real party. Never normalize
                // the player's battle clones down to the regional RCT cap.
                launchConfig = BattleLaunchConfig.fromTrainer(npcTrainer);
            } else {
                // The Challenge Tower scales the NPC team to the player's real party.
                // Do not normalize the player's battle clones downward: the visible enemy
                // levels should be the adaptation, exactly as the Tower design intends.
                launchConfig = BattleLaunchConfig.fromTrainer(npcTrainer);
            }
            boolean started = startConfiguredBattle(battleManager, trainerClass, playerTrainer, npcTrainer, launchConfig);
            if (started) {
                if (launchConfig.levelSyncTarget() > 0) {
                    player.sendMessage(net.minecraft.text.Text.literal("§d↕ Sincronización de nivel activa · §ftu equipo combate temporalmente a Nv. "
                            + launchConfig.levelSyncTarget() + "§7. Tus Pokémon reales conservan su nivel, EXP y datos."), false);
                }
                LAST_START.put(player.getUuid(), now);
                ACTIVE_BATTLES.put(player.getUuid(), new ActiveBattle(npc, System.currentTimeMillis()));
                return true;
            }
            player.sendMessage(net.minecraft.text.Text.literal("§eNo se pudo iniciar: revisa tu límite de nivel, tu equipo y que no estés ya en combate."), false);
            return false;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError exception) {
            Chainacobblemon.LOGGER.error("Could not start exact RCT battle for NPC {}", npc.npcId(), exception);
            player.sendMessage(net.minecraft.text.Text.literal("§cNo se pudo conectar con el sistema de combates RCT."), false);
            return false;
        }
    }

    /**
     * Rebuilds a native gym trainer as an isolated RCT TrainerNPC. The Pokémon are deep-copied by
     * RCT's own copy constructor, so authored moves/natures/items stay intact, while gimmicks and
     * AI decisions are under this battle's control instead of mutating the global trainer registry.
     */
    private static Object createControlledNativeTrainer(Object original, ChallengeProfile profile, ServiceNpcEntity npc)
            throws ReflectiveOperationException {
        Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
        Object copied = trainerNpcClass.getConstructor(trainerNpcClass).newInstance(original);
        Pokemon[] team = (Pokemon[]) trainerNpcClass.getMethod("getTeam").invoke(copied);
        Object originalBag = trainerNpcClass.getMethod("getBag").invoke(copied);
        Object bag;
        try {
            bag = originalBag.getClass().getMethod("clone").invoke(originalBag);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            bag = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerBag").getConstructor().newInstance();
        }
        Class<?> battleAiClass = Class.forName("com.cobblemon.mod.common.api.battles.model.ai.BattleAI");
        Class<?> rctBattleAiClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.RCTBattleAI");
        Object ai = createBattleAi(rctBattleAiClass, battleDifficulty(profile, npc));
        Class<?> trainerBagClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerBag");
        Class<?> pokemonArrayClass = Array.newInstance(Pokemon.class, 0).getClass();
        Object controlled = trainerNpcClass.getConstructor(String.class, pokemonArrayClass, trainerBagClass,
                battleAiClass, LivingEntity.class).newInstance(profile.displayName(), team, bag, ai, npc);
        applyRegionalGimmickPolicy(controlled, profile);
        return controlled;
    }

    /**
     * RCTBattleAI already evaluates estimated damage, status value and switches. We reduce its random
     * selection margin as opponents become more advanced so it stops choosing low-value actions when
     * a clearly better damaging/switching line exists.
     */
    private static Object createBattleAi(Class<?> rctBattleAiClass, int difficulty) throws ReflectiveOperationException {
        try {
            Class<?> configClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.config.RCTBattleAIConfig");
            Class<?> builderClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.config.RCTBattleAIConfig$Builder");
            Object builder = builderClass.getConstructor().newInstance();
            double moveBias = difficulty >= 4 ? 1.15D : difficulty >= 3 ? 1.10D : difficulty >= 2 ? 1.05D : 1.0D;
            double statusBias = difficulty >= 4 ? 1.00D : difficulty >= 3 ? 0.95D : difficulty >= 2 ? 0.88D : 0.78D;
            double switchBias = difficulty >= 4 ? 1.15D : difficulty >= 3 ? 1.05D : difficulty >= 2 ? 0.90D : 0.72D;
            double margin = difficulty >= 4 ? 0.015D : difficulty >= 3 ? 0.04D : difficulty >= 2 ? 0.10D : 0.18D;
            builder = builderClass.getMethod("withMoveBias", double.class).invoke(builder, moveBias);
            builder = builderClass.getMethod("withStatusMoveBias", double.class).invoke(builder, statusBias);
            builder = builderClass.getMethod("withSwitchBias", double.class).invoke(builder, switchBias);
            builder = builderClass.getMethod("withMaxSelectMargin", double.class).invoke(builder, margin);
            Object config = builderClass.getMethod("build").invoke(builder);
            return rctBattleAiClass.getConstructor(configClass).newInstance(config);
        } catch (ClassNotFoundException | NoSuchMethodException exception) {
            Chainacobblemon.LOGGER.warn("Advanced RCT AI tuning unavailable; using RCT defaults: {}", exception.toString());
            return rctBattleAiClass.getConstructor().newInstance();
        }
    }

    private static int battleDifficulty(ChallengeProfile profile, ServiceNpcEntity npc) {
        if (CustomRegionTrainerCatalog.isManaged(npc)) return CustomRegionTrainerCatalog.difficulty(npc);
        if (profile != null) {
            if (profile.isChampion()) return 4;
            if (profile.isEliteFour()) return 3;
            return profile.order() >= 6 ? 2 : 1;
        }
        if (ChallengeTowerService.isTowerTrainer(npc)) {
            int floor = towerFloor(npc);
            return floor >= 10 ? 4 : floor >= 7 ? 3 : floor >= 4 ? 2 : 1;
        }
        if (DungeonTrainerService.isDungeonTrainer(npc)) {
            return "guardian".equalsIgnoreCase(npc.dungeonRole()) ? 3 : 2;
        }
        return 1;
    }

    private static int towerFloor(ServiceNpcEntity npc) {
        if (npc == null || npc.npcId() == null) return 1;
        String id = npc.npcId();
        int start = id.indexOf("tower_f");
        if (start < 0) return 1;
        start += "tower_f".length();
        int end = id.indexOf('_', start);
        if (end < 0) end = id.length();
        try { return Math.max(1, Math.min(10, Integer.parseInt(id.substring(start, end)))); }
        catch (NumberFormatException ignored) { return 1; }
    }

    private static List<String> prepareRegionalTeam(ChallengeProfile profile, List<String> source) {
        if (profile == null || source == null || source.isEmpty()) return source == null ? List.of() : source;
        List<String> result = new ArrayList<>(source);
        if (!profile.isChampion() || !FabricLoader.getInstance().isModLoaded("mega_showdown")) return List.copyOf(result);

        String aceSpecies;
        String megaStone;
        String aceMoves;
        switch (profile.key()) {
            case "kanto:champion_blue" -> {
                aceSpecies = "pidgeot";
                megaStone = "mega_showdown:pidgeotite";
                aceMoves = "hurricane,heatwave,uturn,airslash";
            }
            case "johto:champion_lance" -> {
                aceSpecies = "dragonite";
                megaStone = "mega_showdown:dragoninite";
                aceMoves = "dragonclaw,earthquake,firepunch,extremespeed";
            }
            case "hoenn:champion_steven" -> {
                aceSpecies = "metagross";
                megaStone = "mega_showdown:metagrossite";
                aceMoves = "meteormash,zenheadbutt,earthquake,bulletpunch";
            }
            case "sinnoh:champion_cynthia" -> {
                aceSpecies = "garchomp";
                megaStone = "mega_showdown:garchompite";
                aceMoves = "earthquake,dragonclaw,stoneedge,firefang";
            }
            default -> { return List.copyOf(result); }
        }

        for (int i = result.size() - 1; i >= 0; i--) {
            String spec = result.get(i);
            PokemonProperties props = PokemonProperties.Companion.parse(spec);
            if (aceSpecies.equalsIgnoreCase(props.getSpecies())) {
                String clean = spec.replaceAll("(?i)\\s+held(?:item|_item)=\\S+", "")
                        .replaceAll("(?i)\\s+moves=\\S+", "");
                result.set(i, clean + " moves=" + aceMoves + " helditem=" + megaStone);
                Chainacobblemon.LOGGER.info("Champion {} configured with exactly one Mega ace: {} / {}", profile.key(), aceSpecies, megaStone);
                break;
            }
        }
        return List.copyOf(result);
    }

    /**
     * Regional mechanic contract:
     * - Gym Leaders: no RCT Tera/Dynamax/G-Max gimmicks.
     * - Elite Four: exactly one ace gets one RCT gimmick. Members 1/3 use Tera, 2/4 use Dynamax.
     * - Champions: no RCT gimmick; their only special mechanic is the single Mega Stone added above.
     */
    private static void applyRegionalGimmickPolicy(Object trainer, ChallengeProfile profile) {
        if (trainer == null || profile == null) return;
        try {
            Object gimmicksMap = trainer.getClass().getMethod("getGimmicks").invoke(trainer);
            Pokemon[] team = (Pokemon[]) trainer.getClass().getMethod("getTeam").invoke(trainer);
            Class<?> gimmicksClass = Class.forName("com.gitlab.srcmc.rctapi.api.models.Gimmicks");
            var constructor = gimmicksClass.getConstructor(String.class, boolean.class, boolean.class);
            var assign = gimmicksMap.getClass().getMethod("to", Pokemon.class, gimmicksClass);
            Object none = constructor.newInstance(null, false, false);
            for (Pokemon pokemon : team) assign.invoke(gimmicksMap, pokemon, none);

            if (!profile.isEliteFour() || team.length == 0) return;
            boolean teraBattle = (profile.order() % 2) == 1;
            Object special = teraBattle
                    ? constructor.newInstance(teraTypeId(profile.typeName()), false, false)
                    : constructor.newInstance(null, true, false);
            assign.invoke(gimmicksMap, team[team.length - 1], special);
            Chainacobblemon.LOGGER.info("Elite Four {} configured with one {} gimmick on its ace only", profile.key(),
                    teraBattle ? "Terastallization" : "Dynamax");
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not apply regional RCT gimmick policy for {}: {}", profile.key(), exception.toString());
        }
    }

    private static String teraTypeId(String typeName) {
        if (typeName == null) return "normal";
        return switch (typeName.toLowerCase(java.util.Locale.ROOT)) {
            case "agua" -> "water";
            case "acero" -> "steel";
            case "bicho" -> "bug";
            case "dragón", "dragon" -> "dragon";
            case "eléctrico", "electrico" -> "electric";
            case "fantasma" -> "ghost";
            case "fuego" -> "fire";
            case "hielo" -> "ice";
            case "lucha" -> "fighting";
            case "planta" -> "grass";
            case "psíquico", "psiquico" -> "psychic";
            case "roca" -> "rock";
            case "siniestro" -> "dark";
            case "tierra" -> "ground";
            case "veneno" -> "poison";
            case "volador" -> "flying";
            case "hada" -> "fairy";
            default -> "normal";
        };
    }

    private static boolean startConfiguredBattle(Object battleManager, Class<?> trainerClass, Object playerTrainer,
                                                 Object npcTrainer, BattleLaunchConfig config)
            throws ReflectiveOperationException {
        Object rules = config.rules();
        Object format = config.format();
        for (String name : List.of("startBattle", "start")) {
            for (java.lang.reflect.Method method : battleManager.getClass().getMethods()) {
                if (!method.getName().equals(name)) continue;
                Class<?>[] params = method.getParameterTypes();
                try {
                    Object result;
                    if (params.length == 4 && rules != null && format != null
                            && params[0].isInstance(playerTrainer) && params[1].isInstance(npcTrainer)
                            && params[2].isInstance(format) && params[3].isInstance(rules)) {
                        result = method.invoke(battleManager, playerTrainer, npcTrainer, format, rules);
                    } else if (params.length == 3 && rules != null
                            && params[0].isInstance(playerTrainer) && params[1].isInstance(npcTrainer)
                            && params[2].isInstance(rules)) {
                        result = method.invoke(battleManager, playerTrainer, npcTrainer, rules);
                    } else continue;
                    if (result == null) return false;
                    return !(result instanceof Boolean value) || value;
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        return (boolean) battleManager.getClass().getMethod("startSingle", trainerClass, trainerClass)
                .invoke(battleManager, playerTrainer, npcTrainer);
    }

    /** Forces the authored Lulita + Duber preset into RCT's Gen 9 doubles format without touching other NPCs. */
    private static BattleLaunchConfig customDoubleBattleConfig(Object npcTrainer) throws ReflectiveOperationException {
        Class<?> battleFormatClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormat");
        Object doublesProvider = battleFormatClass.getField("GEN_9_DOUBLES").get(null);
        return new BattleLaunchConfig(doublesProvider, invokeOptional(npcTrainer, "getBattleRules"), 0);
    }

    /**
     * Builds a dungeon-only flat level format through RCT's public BattleFormatProvider + BattleRules APIs.
     * RCT clones the player's party whenever Cobblemon's BattleFormat.adjustLevel is positive, then applies
     * the requested level only to those battle clones. The stored Cobblemon party is therefore never rewritten.
     */
    private static BattleLaunchConfig dungeonLevelSyncConfig(Object npcTrainer, int targetLevel)
            throws ReflectiveOperationException {
        int target = Math.max(1, Math.min(100, targetLevel));
        Object baseProvider = invokeOptional(npcTrainer, "getBattleFormat");
        if (baseProvider == null) {
            Class<?> battleFormatClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormat");
            baseProvider = battleFormatClass.getField("GEN_9_SINGLES").get(null);
        }
        Object baseCobblemonFormat = baseProvider.getClass().getMethod("getCobblemonBattleFormat").invoke(baseProvider);
        Object syncedCobblemonFormat = copyCobblemonFormatWithLevel(baseCobblemonFormat, target);

        Class<?> providerClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormatProvider");
        Object syncedProvider = Proxy.newProxyInstance(providerClass.getClassLoader(), new Class<?>[]{providerClass},
                (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) {
                        return switch (method.getName()) {
                            case "toString" -> "ChainacobblemonDungeonLevelSync(" + target + ")";
                            case "hashCode" -> System.identityHashCode(proxy);
                            case "equals" -> proxy == (args == null || args.length == 0 ? null : args[0]);
                            default -> null;
                        };
                    }
                    if (method.getName().equals("getCobblemonBattleFormat") && method.getParameterCount() == 0) {
                        return syncedCobblemonFormat;
                    }
                    throw new UnsupportedOperationException("Unsupported BattleFormatProvider method: " + method);
                });

        Object rules = buildLevelSyncRules(invokeOptional(npcTrainer, "getBattleRules"));
        return new BattleLaunchConfig(syncedProvider, rules, target);
    }

    private static Object copyCobblemonFormatWithLevel(Object baseFormat, int targetLevel)
            throws ReflectiveOperationException {
        Class<?> formatClass = baseFormat.getClass();
        Object mod = formatClass.getMethod("getMod").invoke(baseFormat);
        Object battleType = formatClass.getMethod("getBattleType").invoke(baseFormat);
        Object rawRules = formatClass.getMethod("getRuleSet").invoke(baseFormat);
        Object gen = formatClass.getMethod("getGen").invoke(baseFormat);
        Set<?> ruleSet = rawRules instanceof Set<?> set ? new HashSet<>(set) : Set.of();

        for (var constructor : formatClass.getConstructors()) {
            Class<?>[] params = constructor.getParameterTypes();
            if (params.length == 5 && params[0] == String.class && Set.class.isAssignableFrom(params[2])
                    && params[3] == int.class && params[4] == int.class) {
                return constructor.newInstance(mod, battleType, ruleSet, gen, targetLevel);
            }
        }
        throw new NoSuchMethodException("Cobblemon BattleFormat(String, BattleType, Set, int, int)");
    }

    private static Object buildLevelSyncRules(Object originalRules) throws ReflectiveOperationException {
        Class<?> builderClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleRules$Builder");
        Object builder = builderClass.getConstructor().newInstance();
        Object maxItemUses = originalRules == null ? null : invokeOptional(originalRules, "getMaxItemUses");
        if (maxItemUses instanceof Integer max) {
            builder = builderClass.getMethod("withMaxItemUses", int.class).invoke(builder, max);
        }
        builder = builderClass.getMethod("withAdjustPlayerLevels", boolean.class).invoke(builder, true);
        builder = builderClass.getMethod("withAdjustNPCLevels", boolean.class).invoke(builder, false);
        // The synced party consists of battle clones. Healing therefore never changes the real stored party.
        builder = builderClass.getMethod("withHealPlayers", boolean.class).invoke(builder, true);
        return builderClass.getMethod("build").invoke(builder);
    }

    private record BattleLaunchConfig(Object format, Object rules, int levelSyncTarget) {
        static BattleLaunchConfig fromTrainer(Object trainer) {
            return new BattleLaunchConfig(invokeOptional(trainer, "getBattleFormat"),
                    invokeOptional(trainer, "getBattleRules"), 0);
        }
    }

    private static Object invokeOptional(Object owner, String name) {
        try {
            return owner.getClass().getMethod(name).invoke(owner);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }

    private static synchronized void registerBattleEndListener(Object rct, Class<?> rctApiClass)
            throws ReflectiveOperationException {
        if (battleEndListener != null) return;
        Class<?> eventsClass = Class.forName("com.gitlab.srcmc.rctapi.api.events.Events");
        Class<?> eventTypeClass = Class.forName("com.gitlab.srcmc.rctapi.api.events.EventType");
        Class<?> eventListenerClass = Class.forName("com.gitlab.srcmc.rctapi.api.events.EventListener");
        Object battleEnded = eventsClass.getField("BATTLE_ENDED").get(null);
        Object context = rctApiClass.getMethod("getEventContext").invoke(rct);
        Object listener = Proxy.newProxyInstance(eventListenerClass.getClassLoader(),
                new Class<?>[]{eventListenerClass}, (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) {
                        return switch (method.getName()) {
                            case "equals" -> proxy == (args == null || args.length == 0 ? null : args[0]);
                            case "hashCode" -> System.identityHashCode(proxy);
                            case "toString" -> "ChainacobblemonBattleEndListener";
                            default -> null;
                        };
                    }
                    if ("notify".equals(method.getName()) && args != null && args.length == 1) {
                        handleBattleEnded(args[0]);
                    }
                    return null;
                });
        context.getClass().getMethod("register", eventTypeClass, eventListenerClass)
                .invoke(context, battleEnded, listener);
        battleEndListener = listener;
    }

    private static void handleBattleEnded(Object event) {
        try {
            Object state = event.getClass().getMethod("getValue").invoke(event);
            Set<UUID> participants = trainerPlayerIds(state, "getParticipants1");
            participants.addAll(trainerPlayerIds(state, "getParticipants2"));
            Set<UUID> winners = trainerPlayerIds(state, "getWinners");
            Set<UUID> losingNpcs = trainerNpcIds(state, "getLosers");
            Set<UUID> battleNpcs = trainerNpcIds(state, "getParticipants1");
            battleNpcs.addAll(trainerNpcIds(state, "getParticipants2"));

            for (UUID playerId : participants) {
                ActiveBattle active = ACTIVE_BATTLES.remove(playerId);
                if (active == null || !battleNpcs.contains(active.npc().getUuid())) continue;
                boolean won = winners.contains(playerId) && losingNpcs.contains(active.npc().getUuid());
                MinecraftServer server = active.npc().getServer();
                if (server == null) continue;
                server.execute(() -> {
                    ServerPlayerEntity player = server.getPlayerManager().getPlayer(playerId);
                    if (player == null) return;
                    if (active.npc().dungeonStructureKey().startsWith("treasure_event:")) {
                        TreasureHuntService.cleanupTrainerPokemon(player, active.npc());
                    }
                    if (ChallengeTowerService.isTowerTrainer(active.npc())) {
                        ChallengeTowerService.onBattleResult(player, active.npc(), won);
                        return;
                    }
                    if (!won || active.npc().isRemoved()) return;
                    if (ChallengeService.isChallengeNpc(active.npc())) {
                        ChallengeService.onVictory(player, active.npc());
                    }
                    if (DungeonTrainerService.isDungeonTrainer(active.npc())) {
                        DungeonTrainerService.onVictory(player, active.npc());
                    }
                    NpcRewardService.grantAfterVictory(player, active.npc());
                });
            }
            long cutoff = System.currentTimeMillis() - 3_600_000L;
            ACTIVE_BATTLES.entrySet().removeIf(entry -> entry.getValue().startedAt() < cutoff);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.error("Could not process RCT battle result for custom NPC rewards", exception);
        }
    }

    private static Set<UUID> trainerPlayerIds(Object state, String methodName) throws ReflectiveOperationException {
        Set<UUID> result = new HashSet<>();
        Object value = state.getClass().getMethod(methodName).invoke(state);
        if (!(value instanceof Iterable<?> trainers)) return result;
        for (Object trainer : trainers) {
            Object entity = trainer.getClass().getMethod("getEntity").invoke(trainer);
            if (entity instanceof ServerPlayerEntity player) result.add(player.getUuid());
        }
        return result;
    }

    private static Set<UUID> trainerNpcIds(Object state, String methodName) throws ReflectiveOperationException {
        Set<UUID> result = new HashSet<>();
        Object value = state.getClass().getMethod(methodName).invoke(state);
        if (!(value instanceof Iterable<?> trainers)) return result;
        for (Object trainer : trainers) {
            Object entity = trainer.getClass().getMethod("getEntity").invoke(trainer);
            if (entity instanceof ServiceNpcEntity npc) result.add(npc.getUuid());
        }
        return result;
    }

    private record ActiveBattle(ServiceNpcEntity npc, long startedAt) {
    }
}
