package com.andrewbristowx.chainacobblemon.twitch;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TwitchService {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("dd/MM HH:mm").withZone(ZoneId.systemDefault());
    private final ConfigManager configManager;
    private final TwitchProfileStore store;
    private final StreamBonusService streamBonuses;
    private final TwitchSupportRewardService supportRewards;
    private final Set<UUID> joinPromptSent = ConcurrentHashMap.newKeySet();
    private final Set<UUID> linkFlowActive = ConcurrentHashMap.newKeySet();
    private final Set<UUID> directLinkFlowActive = ConcurrentHashMap.newKeySet();
    private volatile TwitchBridgeClient bridge;
    private volatile MinecraftServer server;
    private volatile boolean channelOnline;
    private volatile boolean channelKnown;
    private long ticks;
    private long nextChannelPollTick;
    private long nextPlayerPollTick;
    private long nextDirectLinkPollTick;
    private int playerCursor;

    public TwitchService(ConfigManager configManager) {
        this.configManager = configManager;
        this.store = new TwitchProfileStore(configManager.configDirectory());
        this.streamBonuses = new StreamBonusService(configManager);
        this.supportRewards = new TwitchSupportRewardService(configManager, store);
    }

    public void initialize() {
        store.load();
        streamBonuses.initialize();
        supportRewards.initialize();
        rebuildBridge();
        ServerTickEvents.END_SERVER_TICK.register(this::tick);
        Chainacobblemon.LOGGER.info("Chaina Twitch Integration initialized in {} mode", settings().mode);
    }

    public void serverStarted(MinecraftServer server) {
        this.server = server;
        this.nextChannelPollTick = 20L;
        this.nextPlayerPollTick = 40L;
        this.nextDirectLinkPollTick = 40L;
        supportRewards.serverStarted(server);
    }

    public void serverStopping() {
        store.save();
        streamBonuses.save();
        supportRewards.serverStopping();
        server = null;
    }

    public void reload() {
        rebuildBridge();
    }

    public void playerJoined(ServerPlayerEntity player) {
        joinPromptSent.remove(player.getUuid());
        linkFlowActive.remove(player.getUuid());
        directLinkFlowActive.remove(player.getUuid());
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        if (isBridgeMode() && profile.twitchUserId != null && profile.twitchUserId.startsWith("dev-")) {
            profile.linked = false;
            profile.twitchUserId = "";
            profile.twitchLogin = "";
            profile.tier = 0;
            clearTwitchRoles(profile);
            profile.touch();
            store.save();
        }
        TwitchRankService.sync(player, profile, settings());
        if (isBridgeMode()) syncPlayer(player, false, true);
        supportRewards.playerJoined(player);
        sendHudSnapshot(player);
    }

    public void playerLeft(UUID playerId) {
        joinPromptSent.remove(playerId);
        linkFlowActive.remove(playerId);
        directLinkFlowActive.remove(playerId);
        store.save();
    }

    public void handleAction(ServerPlayerEntity player, String action) {
        if (player == null) return;
        String value = action == null ? "open" : action.strip().toLowerCase(Locale.ROOT);
        if (value.startsWith("admin_")) {
            handleAdminAction(player, value);
            return;
        }
        switch (value) {
            case "link_direct" -> startDirectLink(player);
            case "link_poll" -> pollLink(player);
            case "open", "status", "link", "sync", "unlink" -> {
                if (!isAdmin(player)) {
                    sendDirectError(player, "El panel Twitch es exclusivo para administradores.");
                    return;
                }
                switch (value) {
                    case "open", "status" -> openAdmin(player, player, "Panel administrativo Twitch.");
                    case "link" -> startLink(player);
                    case "sync" -> adminSync(player, player);
                    case "unlink" -> adminUnlink(player, player);
                    default -> { }
                }
            }
            default -> sendDirectError(player, "Acción Twitch desconocida.");
        }
    }

    public void open(ServerPlayerEntity player, String message) {
        TwitchNetworking.send(player, snapshot(player, message));
    }

    public void openAdmin(ServerPlayerEntity admin, ServerPlayerEntity target, String message) {
        if (admin == null || target == null) return;
        if (!isAdmin(admin)) {
            sendDirectError(admin, "No tienes permiso para abrir el panel Twitch de administración.");
            return;
        }
        TwitchNetworking.send(admin, adminSnapshot(target, message));
    }

    private void handleAdminAction(ServerPlayerEntity admin, String value) {
        if (!isAdmin(admin)) {
            sendDirectError(admin, "No tienes permiso para administrar Twitch.");
            return;
        }
        int separator = value.indexOf(':');
        if (separator < 0 || separator == value.length() - 1) {
            sendDirectError(admin, "Acción administrativa Twitch inválida.");
            return;
        }
        UUID targetId;
        try {
            targetId = UUID.fromString(value.substring(separator + 1));
        } catch (IllegalArgumentException exception) {
            sendDirectError(admin, "Jugador Twitch inválido.");
            return;
        }
        ServerPlayerEntity target = server == null ? null : server.getPlayerManager().getPlayer(targetId);
        if (target == null) {
            admin.sendMessage(Text.literal("✦ CHAINA × TWITCH ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                    .append(Text.literal("Ese jugador ya no está conectado.").formatted(Formatting.RED)), false);
            return;
        }
        String operation = value.substring(0, separator);
        switch (operation) {
            case "admin_sync" -> adminSync(admin, target);
            case "admin_unlink" -> adminUnlink(admin, target);
            case "admin_prompt" -> adminPrompt(admin, target);
            default -> sendDirectError(admin, "Acción administrativa Twitch desconocida.");
        }
    }

    private void adminSync(ServerPlayerEntity admin, ServerPlayerEntity target) {
        if (isDevelopmentMode()) {
            TwitchProfile profile = store.getOrCreate(target.getUuid(), target.getGameProfile().getName());
            profile.touch();
            store.save();
            openAdmin(admin, target, "Estado de prueba actualizado.");
            return;
        }
        if (bridge == null || !bridge.configured()) {
            openAdmin(admin, target, "ChainaBridge no está configurado.");
            return;
        }
        bridge.playerStatus(target.getUuidAsString()).whenComplete((status, error) -> execute(() -> {
            if (error != null) {
                openAdmin(admin, target, "No se pudo actualizar: " + safeError(error));
                return;
            }
            boolean changed = applyBridgeStatus(target, status);
            openAdmin(admin, target, changed ? "Estado del jugador actualizado." : "El jugador ya estaba sincronizado.");
        }));
    }

    private void adminUnlink(ServerPlayerEntity admin, ServerPlayerEntity target) {
        linkFlowActive.remove(target.getUuid());
        directLinkFlowActive.remove(target.getUuid());
        if (isDevelopmentMode()) {
            setUnlinked(target);
            target.sendMessage(Text.literal("✦ CHAINA × TWITCH ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                    .append(Text.literal("Un administrador desvinculó tu cuenta de Twitch.").formatted(Formatting.GRAY)), false);
            openAdmin(admin, target, "Cuenta Twitch desvinculada.");
            return;
        }
        if (bridge == null || !bridge.configured()) {
            openAdmin(admin, target, "No se puede desvincular: ChainaBridge no está configurado.");
            return;
        }
        bridge.unlink(target.getUuidAsString()).whenComplete((ok, error) -> execute(() -> {
            if (error != null || !Boolean.TRUE.equals(ok)) {
                openAdmin(admin, target, "No se pudo desvincular" + (error == null ? "." : ": " + safeError(error)));
                return;
            }
            setUnlinked(target);
            target.sendMessage(Text.literal("✦ CHAINA × TWITCH ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                    .append(Text.literal("Un administrador desvinculó tu cuenta de Twitch.").formatted(Formatting.GRAY)), false);
            openAdmin(admin, target, "Cuenta Twitch desvinculada.");
        }));
    }

    private void adminPrompt(ServerPlayerEntity admin, ServerPlayerEntity target) {
        TwitchProfile profile = store.getOrCreate(target.getUuid(), target.getGameProfile().getName());
        if (profile.linked) {
            openAdmin(admin, target, "El jugador ya está vinculado. Desvincúlalo primero para reenviar el aviso.");
            return;
        }
        joinPromptSent.remove(target.getUuid());
        sendLinkPrompt(target);
        openAdmin(admin, target, "Aviso privado de vinculación reenviado.");
    }

    private boolean isAdmin(ServerPlayerEntity player) {
        return player != null && player.hasPermissionLevel(2);
    }

    public void startLink(ServerPlayerEntity player) {
        startLink(player, false);
    }

    private void startDirectLink(ServerPlayerEntity player) {
        startLink(player, true);
    }

    private void startLink(ServerPlayerEntity player, boolean direct) {
        if (!settings().enabled) {
            if (direct) sendDirectError(player, "La integración Twitch está desactivada.");
            else open(player, "La integracion Twitch esta desactivada.");
            return;
        }
        if (isDevelopmentMode()) {
            TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
            profile.linked = true;
            profile.twitchUserId = "dev-" + player.getUuid();
            profile.twitchLogin = "dev_" + player.getGameProfile().getName().toLowerCase(Locale.ROOT);
            profile.tier = 0;
            clearTwitchRoles(profile);
            profile.touch();
            store.save();
            TwitchRankService.sync(player, profile, settings());
            if (direct) sendLinkedSuccess(player);
            else open(player, "Cuenta Twitch de prueba vinculada. Usa /chaina twitch test sub 1|2|3 para probar rangos.");
            return;
        }
        if (bridge == null || !bridge.configured()) {
            if (direct) sendDirectError(player, "Twitch no está disponible ahora mismo. Avisa a un administrador.");
            else open(player, "ChainaBridge no esta configurado. No se guarda ningun token de Chaina en el mod.");
            return;
        }
        bridge.startLink(player.getUuidAsString(), player.getGameProfile().getName())
                .whenComplete((result, error) -> execute(() -> {
                    if (error != null) {
                        if (direct) sendDirectError(player, "No se pudo iniciar la vinculación: " + safeError(error));
                        else open(player, "No se pudo iniciar la vinculacion: " + safeError(error));
                        return;
                    }
                    boolean setup = "CONFIG".equalsIgnoreCase(result.userCode());
                    if (setup && direct) {
                        sendDirectError(player, "ChainaBridge necesita configuración. Avisa a un administrador.");
                        return;
                    }
                    TwitchSnapshot snapshot = snapshot(player, setup
                            ? "Configura primero el Client ID publico de Twitch. Nunca pegues un Client Secret."
                            : (direct ? "" : "Autoriza TU cuenta Twitch. El token queda solo en ChainaBridge y nunca se envia a Minecraft."));
                    snapshot.linkUrl = result.verificationUrl();
                    snapshot.linkCode = result.userCode();
                    snapshot.visible = !direct;
                    if (!setup) {
                        linkFlowActive.add(player.getUuid());
                        if (direct) directLinkFlowActive.add(player.getUuid());
                    }
                    TwitchNetworking.send(player, snapshot);
                    if (direct && !setup) {
                        player.sendMessage(Text.literal("✦ Código Twitch copiado: ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                                .append(Text.literal(result.userCode()).formatted(Formatting.YELLOW, Formatting.BOLD))
                                .append(Text.literal(" · Si Twitch te lo pide, pégalo con Ctrl+V.").formatted(Formatting.GRAY)), false);
                    }
                }));
    }

    public void syncPlayer(ServerPlayerEntity player, boolean userRequested) {
        syncPlayer(player, userRequested, false);
    }

    private void syncPlayer(ServerPlayerEntity player, boolean userRequested, boolean promptIfUnlinked) {
        if (player == null) return;
        if (isDevelopmentMode()) {
            TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
            profile.touch();
            store.save();
            if (userRequested) open(player, "Estado Twitch de desarrollo sincronizado.");
            return;
        }
        if (bridge == null || !bridge.configured()) {
            if (userRequested) open(player, "ChainaBridge no esta configurado.");
            return;
        }
        bridge.playerStatus(player.getUuidAsString()).whenComplete((status, error) -> execute(() -> {
            if (error != null) {
                if (userRequested) open(player, "No se pudo sincronizar Twitch: " + safeError(error));
                return;
            }
            boolean changed = applyBridgeStatus(player, status);
            if (userRequested) {
                open(player, changed ? "Estado Twitch actualizado." : "Twitch ya estaba sincronizado.");
            } else if (promptIfUnlinked && !status.linked() && !status.pending()) {
                sendLinkPrompt(player);
            }
        }));
    }

    private void pollLink(ServerPlayerEntity player) {
        if (player == null || bridge == null || !bridge.configured()) return;
        bridge.playerStatus(player.getUuidAsString()).whenComplete((status, error) -> execute(() -> {
            if (error != null || !status.linked()) return;
            applyBridgeStatus(player, status);
            boolean directFlow = directLinkFlowActive.remove(player.getUuid());
            boolean activeFlow = linkFlowActive.remove(player.getUuid());
            if (!directFlow) {
                TwitchSnapshot snapshot = snapshot(player, "¡Twitch vinculado correctamente! Tu rango ya fue actualizado.");
                TwitchNetworking.send(player, snapshot);
            }
            if (activeFlow) sendLinkedSuccess(player);
        }));
    }

    private boolean applyBridgeStatus(ServerPlayerEntity player, TwitchBridgeClient.PlayerStatus status) {
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        boolean nextLinked = status.linked();
        boolean nextRolesKnown = nextLinked && status.rolesKnown();
        boolean nextVip = nextRolesKnown && status.vip();
        boolean nextModerator = nextRolesKnown && status.moderator();
        long nextObservedAt = nextRolesKnown ? Math.max(0L, status.rolesObservedAt()) : 0L;
        boolean changed = profile.linked != nextLinked || profile.tier != status.tier()
                || !profile.twitchLogin.equals(status.twitchLogin())
                || profile.twitchVip != nextVip || profile.twitchModerator != nextModerator
                || profile.twitchRolesKnown != nextRolesKnown;
        profile.linked = nextLinked;
        profile.twitchUserId = nextLinked ? status.twitchUserId() : "";
        profile.twitchLogin = nextLinked ? status.twitchLogin() : "";
        profile.tier = nextLinked ? status.tier() : 0;
        profile.twitchRolesKnown = nextRolesKnown;
        profile.twitchVip = nextVip;
        profile.twitchModerator = nextModerator;
        profile.twitchRolesObservedAtEpochSeconds = nextObservedAt;
        profile.touch();
        store.save();
        supportRewards.onProfileSynced(player.getUuid());
        if (changed) TwitchRankService.sync(player, profile, settings());
        return changed;
    }

    private void sendLinkPrompt(ServerPlayerEntity player) {
        if (player == null || !joinPromptSent.add(player.getUuid())) return;
        MutableText prefix = Text.literal("✦ CHAINA × TWITCH ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD);
        MutableText body = Text.literal("Vincula tu cuenta de Twitch ").formatted(Formatting.WHITE);
        MutableText here = Text.literal("AQUÍ").styled(style -> style
                .withColor(Formatting.AQUA)
                .withUnderline(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/twitch vincular_directo"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal("Clic para abrir Twitch y vincular tu cuenta"))));
        MutableText suffix = Text.literal(" para comprobar tu suscripción y beneficios.").formatted(Formatting.GRAY);
        player.sendMessage(prefix.append(body).append(here).append(suffix), false);
    }

    private void sendDirectError(ServerPlayerEntity player, String error) {
        if (player == null) return;
        player.sendMessage(Text.literal("✦ CHAINA × TWITCH ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                .append(Text.literal(error).formatted(Formatting.RED)), false);
    }

    private void sendLinkedSuccess(ServerPlayerEntity player) {
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        String tier = profile.tier <= 0 ? "sin suscripción" : "Tier " + profile.tier;
        MutableText message = Text.literal("✓ Twitch vinculado: ").formatted(Formatting.GREEN, Formatting.BOLD)
                .append(Text.literal("@" + profile.twitchLogin + " · " + tier + " · ").formatted(Formatting.WHITE))
                .append(Text.literal(TwitchRankService.label(profile)).formatted(Formatting.LIGHT_PURPLE));
        player.sendMessage(message, false);
    }

    public void unlink(ServerPlayerEntity player) {
        linkFlowActive.remove(player.getUuid());
        directLinkFlowActive.remove(player.getUuid());
        if (isDevelopmentMode()) {
            applyUnlinked(player, "Cuenta Twitch de prueba desvinculada.");
            return;
        }
        if (bridge == null || !bridge.configured()) {
            open(player, "No se puede desvincular: ChainaBridge no esta configurado.");
            return;
        }
        bridge.unlink(player.getUuidAsString()).whenComplete((ok, error) -> execute(() -> {
            if (error != null || !Boolean.TRUE.equals(ok)) {
                open(player, "No se pudo desvincular Twitch" + (error == null ? "." : ": " + safeError(error)));
                return;
            }
            applyUnlinked(player, "Cuenta Twitch desvinculada.");
        }));
    }

    private void applyUnlinked(ServerPlayerEntity player, String message) {
        setUnlinked(player);
        if (isAdmin(player)) openAdmin(player, player, message);
        else player.sendMessage(Text.literal("✦ CHAINA × TWITCH ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                .append(Text.literal(message).formatted(Formatting.GRAY)), false);
    }

    private void setUnlinked(ServerPlayerEntity player) {
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        profile.linked = false;
        profile.twitchUserId = "";
        profile.twitchLogin = "";
        profile.tier = 0;
        clearTwitchRoles(profile);
        profile.touch();
        store.save();
        TwitchRankService.sync(player, profile, settings());
    }

    private static void clearTwitchRoles(TwitchProfile profile) {
        profile.twitchVip = false;
        profile.twitchModerator = false;
        profile.twitchRolesKnown = false;
        profile.twitchRolesObservedAtEpochSeconds = 0L;
    }

    public boolean debugSetTier(ServerPlayerEntity player, int tier) {
        if (player == null || !isDevelopmentMode()) return false;
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        if (!profile.linked) {
            profile.linked = true;
            profile.twitchUserId = "dev-" + player.getUuid();
            profile.twitchLogin = "dev_" + player.getGameProfile().getName().toLowerCase(Locale.ROOT);
        }
        profile.tier = Math.clamp(tier, 0, 3);
        profile.touch();
        store.save();
        TwitchRankService.sync(player, profile, settings());
        open(player, tier == 0 ? "Prueba: sin suscripcion." : "Prueba: Sub Tier " + tier + " aplicada.");
        return true;
    }

    public boolean debugSetChannel(boolean online) {
        if (!isDevelopmentMode()) return false;
        updateChannelState(online, true);
        return true;
    }

    public String statusLine(ServerPlayerEntity player) {
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        return "Twitch=" + settings().mode + " | Chaina=" + (channelOnline ? "ONLINE" : "OFFLINE")
                + " | bonus=" + (channelOnline && streamBonuses.active() ? streamBonuses.summary() : "inactivos")
                + " | vinculado=" + profile.linked + " | tier=" + profile.tier + " | rango=" + TwitchRankService.label(profile)
                + " | twitch_role=" + (TwitchRankService.roleLabel(profile).isBlank() ? "sin detectar" : TwitchRankService.roleLabel(profile));
    }

    private TwitchSnapshot snapshot(ServerPlayerEntity player, String message) {
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        TwitchSnapshot snapshot = new TwitchSnapshot();
        snapshot.enabled = settings().enabled;
        snapshot.mode = settings().mode;
        snapshot.broadcaster = settings().broadcasterLogin;
        snapshot.channelOnline = channelOnline;
        snapshot.channelKnown = channelKnown;
        snapshot.styledPlayerListIntegrated = StyledPlayerListIntegration.active();
        snapshot.streamHudEnabled = settings().streamHudEnabled
                && !(settings().hideStreamHudWhenTabIntegrated && snapshot.styledPlayerListIntegrated);
        snapshot.streamBonusesActive = channelKnown && channelOnline && streamBonuses.active();
        snapshot.streamJackpot = snapshot.streamBonusesActive && streamBonuses.jackpot();
        snapshot.streamSessionId = snapshot.streamBonusesActive ? streamBonuses.sessionId() : "";
        snapshot.streamBonuses = snapshot.streamBonusesActive ? streamBonuses.hudLabels() : java.util.List.of();
        snapshot.linked = profile.linked;
        snapshot.twitchLogin = profile.twitchLogin;
        snapshot.tier = profile.tier;
        String roleLabel = TwitchRankService.roleLabel(profile);
        snapshot.rankLabel = TwitchRankService.label(profile) + (roleLabel.isBlank() ? "" : " · " + roleLabel);
        snapshot.lastSync = profile.lastSyncEpochSeconds <= 0 ? "Nunca" : TIME.format(Instant.ofEpochSecond(profile.lastSyncEpochSeconds));
        snapshot.message = message == null ? "" : message;
        return snapshot;
    }

    private TwitchSnapshot adminSnapshot(ServerPlayerEntity target, String message) {
        TwitchSnapshot snapshot = snapshot(target, message);
        snapshot.visible = true;
        snapshot.adminView = true;
        snapshot.targetUuid = target.getUuidAsString();
        snapshot.targetName = target.getGameProfile().getName();
        snapshot.linkUrl = "";
        snapshot.linkCode = "";
        return snapshot;
    }

    private void tick(MinecraftServer minecraftServer) {
        if (server == null) server = minecraftServer;
        ticks++;
        supportRewards.tick(minecraftServer, ticks, bridge);
        if (!settings().enabled || !isBridgeMode() || bridge == null || !bridge.configured()) return;
        if (ticks >= nextChannelPollTick) {
            nextChannelPollTick = ticks + Math.max(20L, settings().channelPollSeconds * 20L);
            pollChannel();
        }
        if (ticks >= nextDirectLinkPollTick) {
            nextDirectLinkPollTick = ticks + 40L;
            for (UUID playerId : directLinkFlowActive.toArray(UUID[]::new)) {
                ServerPlayerEntity player = server == null ? null : server.getPlayerManager().getPlayer(playerId);
                if (player == null) {
                    directLinkFlowActive.remove(playerId);
                    linkFlowActive.remove(playerId);
                } else {
                    pollLink(player);
                }
            }
        }
        if (ticks >= nextPlayerPollTick) {
            int players = Math.max(1, minecraftServer.getPlayerManager().getCurrentPlayerCount());
            nextPlayerPollTick = ticks + Math.max(100L, settings().playerSyncIntervalSeconds * 20L / players);
            var list = minecraftServer.getPlayerManager().getPlayerList();
            if (!list.isEmpty()) {
                playerCursor = Math.floorMod(playerCursor, list.size());
                syncPlayer(list.get(playerCursor++), false);
            }
        }
    }

    private void pollChannel() {
        TwitchBridgeClient local = bridge;
        if (local == null) return;
        local.channelStatus().whenComplete((status, error) -> execute(() -> {
            if (error != null) {
                Chainacobblemon.LOGGER.debug("Could not refresh Chaina Twitch live state: {}", safeError(error));
                return;
            }
            updateChannelState(status.online(), false);
        }));
    }

    private void updateChannelState(boolean online, boolean forceAnnouncement) {
        boolean changed = !channelKnown || channelOnline != online;
        channelKnown = true;
        channelOnline = online;
        boolean bonusChanged = streamBonuses.onChannelState(online);
        if (server != null && (changed || forceAnnouncement || bonusChanged)) broadcastHudSnapshots();
        if ((!changed && !forceAnnouncement) || server == null) return;
        if (online && settings().announceOnline) {
            String url = "https://twitch.tv/" + settings().broadcasterLogin;
            MutableText prefix = Text.literal("● CHAINA ESTA EN DIRECTO · ")
                    .formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD);
            MutableText link = Text.literal("twitch.tv/" + settings().broadcasterLogin)
                    .styled(style -> style
                            .withColor(Formatting.AQUA)
                            .withUnderline(true)
                            .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url))
                            .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal("Clic para abrir el stream de Chaina"))));
            server.getPlayerManager().broadcast(prefix.append(link), false);
            if (streamBonuses.active()) {
                String jackpot = streamBonuses.jackpot() ? "§6§l🌟 DIRECTO LEGENDARIO · " : "§d§l✦ BONUS DEL DIRECTO · ";
                server.getPlayerManager().broadcast(Text.literal(jackpot + "§f" + streamBonuses.summary()), false);
            }
        } else if (!online && settings().announceOffline) {
            server.getPlayerManager().broadcast(Text.literal("§5Chaina termino el directo. ¡Gracias por acompañarla!"), false);
        }
    }

    private void sendHudSnapshot(ServerPlayerEntity player) {
        if (player == null) return;
        TwitchSnapshot snapshot = snapshot(player, "");
        snapshot.visible = false;
        snapshot.linkUrl = "";
        snapshot.linkCode = "";
        TwitchNetworking.send(player, snapshot);
    }

    private void broadcastHudSnapshots() {
        MinecraftServer local = server;
        if (local == null) return;
        for (ServerPlayerEntity player : local.getPlayerManager().getPlayerList()) sendHudSnapshot(player);
    }

    boolean channelKnownForIntegration() {
        return channelKnown;
    }

    boolean channelOnlineForIntegration() {
        return channelOnline;
    }

    String broadcasterForIntegration() {
        return settings().broadcasterLogin;
    }

    int tierForIntegration(ServerPlayerEntity player) {
        if (player == null) return 0;
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        return Math.clamp(profile.tier, 0, 3);
    }

    boolean vipForIntegration(ServerPlayerEntity player) {
        if (player == null) return false;
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        return profile.linked && profile.twitchRolesKnown && profile.twitchVip;
    }

    boolean moderatorForIntegration(ServerPlayerEntity player) {
        if (player == null) return false;
        TwitchProfile profile = store.getOrCreate(player.getUuid(), player.getGameProfile().getName());
        return profile.linked && profile.twitchRolesKnown && profile.twitchModerator;
    }

    com.andrewbristowx.chainacobblemon.config.ChainacobblemonConfig.TwitchSettings settingsForIntegration() {
        return settings();
    }

    StreamBonusService streamBonuses() {
        return streamBonuses;
    }

    public boolean rerollStreamBonusesForTesting() {
        boolean changed = streamBonuses.rerollForTesting(channelKnown && channelOnline);
        if (changed) broadcastHudSnapshots();
        return changed;
    }

    public String streamBonusStatusLine() {
        if (!channelKnown) return "Chaina: comprobando Twitch · bonus pendientes";
        if (!channelOnline) return "Chaina: OFFLINE · bonus inactivos";
        if (!streamBonuses.active()) return "Chaina: EN VIVO · bonus desactivados";
        return (streamBonuses.jackpot() ? "DIRECTO LEGENDARIO · " : "EN VIVO · ") + streamBonuses.summary();
    }

    TwitchBridgeClient bridgeForSupport() { return bridge; }

    public void startSupportEvents(java.util.function.Consumer<String> callback) {
        supportRewards.startSession(bridge, callback);
    }

    public String stopSupportEvents() { return supportRewards.stopSession(); }
    public String supportEventsStatus() { return supportRewards.statusLine(); }
    public String setSupportTarget(ServerPlayerEntity player) { return supportRewards.setTarget(player); }
    public java.util.List<String> supportRuleLines() { return supportRewards.rulesLines(); }
    public String addSupportRule(String eventType, int threshold, String destination, String action, String value, int count, double chance, String command) {
        return supportRewards.addRule(eventType, threshold, destination, action, value, count, chance, command);
    }
    public String deleteSupportRule(int id) { return supportRewards.deleteRule(id); }
    public String clearSupportRules() { return supportRewards.clearRules(); }
    public String testSupportEvent(String type, int amount, int tier, ServerPlayerEntity actor) {
        return supportRewards.simulate(type, amount, tier, actor);
    }

    private void rebuildBridge() {
        this.bridge = new TwitchBridgeClient(settings());
    }

    private boolean isDevelopmentMode() {
        return "development".equalsIgnoreCase(settings().mode);
    }

    private boolean isBridgeMode() {
        return "bridge".equalsIgnoreCase(settings().mode);
    }

    private com.andrewbristowx.chainacobblemon.config.ChainacobblemonConfig.TwitchSettings settings() {
        return configManager.get().twitch;
    }

    private void execute(Runnable runnable) {
        MinecraftServer local = server;
        if (local != null) local.execute(runnable);
    }

    private static String safeError(Throwable error) {
        Throwable value = error;
        while (value.getCause() != null) value = value.getCause();
        String message = value.getMessage();
        return message == null || message.isBlank() ? value.getClass().getSimpleName() : message;
    }
}
