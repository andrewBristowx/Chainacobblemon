package com.andrewbristowx.chainacobblemon.armor;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.registry.entry.RegistryEntry;
import org.apache.commons.lang3.mutable.MutableObject;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Chaina armor piece rendered through GeckoLib so the in-game silhouette can match the concept art much better
 * than vanilla armor layers.
 */
public final class ChainaGeoArmorItem extends ArmorItem implements ChainaGeoArmorPiece {
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final MutableObject<GeoRenderProvider> renderProviderHolder = new MutableObject<>();

    public ChainaGeoArmorItem(RegistryEntry<ArmorMaterial> material, Type type, Settings settings) {
        super(material, type, settings);
    }

    @Override
    public AnimatableInstanceCache chainaArmorGeoCache() {
        return geoCache;
    }

    @Override
    public MutableObject<GeoRenderProvider> chainaArmorRenderProviderHolder() {
        return renderProviderHolder;
    }
}
