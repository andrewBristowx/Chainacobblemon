package com.andrewbristowx.chainacobblemon.tower;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class ChallengeTowerCommands {
    private ChallengeTowerCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerAll(dispatcher));
    }

    private static void registerAll(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("chainacobblemon").requires(source -> source.hasPermissionLevel(4))
                .then(literal("tower")
                        .then(literal("test")
                                .then(literal("start").executes(ctx -> ChallengeTowerService.start(ctx.getSource().getPlayerOrThrow(), true) ? 1 : 0))
                                .then(literal("win").executes(ctx -> { ChallengeTowerService.forceWin(ctx.getSource().getPlayerOrThrow()); return 1; }))
                                .then(literal("lose").executes(ctx -> { ChallengeTowerService.forceLose(ctx.getSource().getPlayerOrThrow()); return 1; }))
                                .then(literal("complete").executes(ctx -> { ChallengeTowerService.forceComplete(ctx.getSource().getPlayerOrThrow(), false); return 1; }))
                                .then(literal("heal").executes(ctx -> { ChallengeTowerService.forceHeal(ctx.getSource().getPlayerOrThrow()); return 1; }))
                                .then(literal("cleanup").executes(ctx -> { ChallengeTowerService.forceCleanup(ctx.getSource().getPlayerOrThrow()); return 1; }))
                                .then(literal("celebrate").executes(ctx -> { ChallengeTowerService.forceCelebration(ctx.getSource().getPlayerOrThrow()); return 1; }))
                                .then(literal("roulette")
                                        .executes(ctx -> { ChallengeTowerService.forceRoulette(ctx.getSource().getPlayerOrThrow(), false); return 1; })
                                        .then(literal("jackpot").executes(ctx -> { ChallengeTowerService.forceRoulette(ctx.getSource().getPlayerOrThrow(), true); return 1; })))
                                .then(literal("lighting").executes(ctx -> { ChallengeTowerService.forceRebuildFloor(ctx.getSource().getPlayerOrThrow()); return 1; })))
                        .then(literal("floor")
                                .then(argument("numero", IntegerArgumentType.integer(1, 10))
                                        .executes(ctx -> ChallengeTowerService.jumpToFloor(ctx.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(ctx, "numero")) ? 1 : 0)))
                        .then(literal("boss").executes(ctx -> ChallengeTowerService.jumpToFloor(ctx.getSource().getPlayerOrThrow(), 10) ? 1 : 0))
                        .then(literal("buildmode").executes(ctx -> { ChallengeTowerService.toggleBuildMode(ctx.getSource().getPlayerOrThrow()); return 1; }))
                        .then(literal("status")
                                .executes(ctx -> status(ctx.getSource(), ctx.getSource().getPlayerOrThrow()))
                                .then(argument("player", EntityArgumentType.player())
                                        .executes(ctx -> status(ctx.getSource(), EntityArgumentType.getPlayer(ctx, "player")))))
                        .then(literal("reset")
                                .then(argument("player", EntityArgumentType.player())
                                        .executes(ctx -> { ChallengeTowerService.reset(EntityArgumentType.getPlayer(ctx, "player")); ctx.getSource().sendFeedback(() -> Text.literal("§aTorre reiniciada."), true); return 1; })))
                        .then(literal("cooldown")
                                .then(literal("clear")
                                        .then(argument("player", EntityArgumentType.player())
                                                .executes(ctx -> { ChallengeTowerService.clearCooldown(EntityArgumentType.getPlayer(ctx, "player")); ctx.getSource().sendFeedback(() -> Text.literal("§aCooldown eliminado."), true); return 1; }))))
                        .then(literal("unlock")
                                .then(argument("player", EntityArgumentType.player())
                                        .executes(ctx -> { ChallengeTowerService.setAdminUnlocked(EntityArgumentType.getPlayer(ctx, "player"), true); ctx.getSource().sendFeedback(() -> Text.literal("§aTorre desbloqueada para pruebas."), true); return 1; })))
                        .then(literal("lock")
                                .then(argument("player", EntityArgumentType.player())
                                        .executes(ctx -> { ChallengeTowerService.setAdminUnlocked(EntityArgumentType.getPlayer(ctx, "player"), false); ctx.getSource().sendFeedback(() -> Text.literal("§eOverride de desbloqueo retirado."), true); return 1; })))));
    }

    private static int status(ServerCommandSource source, ServerPlayerEntity player) {
        source.sendFeedback(() -> Text.literal(ChallengeTowerService.status(player)), false);
        return 1;
    }
}
