package com.andrewbristowx.chainacobblemon.challenge;

import com.andrewbristowx.chainacobblemon.npc.NpcNetworking;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.andrewbristowx.chainacobblemon.visual.VisualAssetService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.entity.EntityType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class ChallengeCommands {
    private static VisualAssetService assets;

    private ChallengeCommands() {
    }

    public static void register(VisualAssetService visualAssets) {
        assets = visualAssets;
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerAll(dispatcher));
    }

    private static void registerAll(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("chainacobblemon").requires(source -> source.hasPermissionLevel(4))
                .then(literal("desafios")
                        .then(literal("profesora")
                                .executes(context -> createProfessor(context.getSource())))
                        .then(literal("listar")
                                .executes(context -> list(context.getSource())))
                        .then(argument("region", StringArgumentType.word())
                                .suggests((context, builder) -> net.minecraft.command.CommandSource.suggestMatching(
                                        ChallengeCatalog.regions(), builder))
                                .then(argument("lider", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            String region = StringArgumentType.getString(context, "region");
                                            return net.minecraft.command.CommandSource.suggestMatching(
                                                    ChallengeCatalog.leaders(region), builder);
                                        })
                                        .executes(context -> createLeader(context.getSource(),
                                                StringArgumentType.getString(context, "region"),
                                                StringArgumentType.getString(context, "lider")))))));
    }

    private static int createLeader(ServerCommandSource source, String region, String leader) {
        ChallengeProfile profile = ChallengeCatalog.byRegionLeader(region, leader);
        if (profile == null) {
            source.sendError(Text.literal("No existe ese desafío. Regiones: kanto, johto, hoenn, sinnoh."));
            return 0;
        }
        if (NpcNetworking.findNpc(source.getServer(), profile.npcId()) != null) {
            source.sendError(Text.literal("Ya existe el NPC de desafío " + profile.displayName() + "."));
            return 0;
        }
        try {
            assets.ensureNpcFolder(profile.npcId());
        } catch (Exception exception) {
            source.sendError(Text.literal("No se pudo preparar la carpeta de skin: " + exception.getMessage()));
            return 0;
        }
        EntityType<ServiceNpcEntity> type = profile.slimModel()
                ? ModRegistries.CUSTOM_SLIM_NPC : ModRegistries.CUSTOM_NPC;
        ServiceNpcEntity npc = type.create(source.getWorld());
        if (npc == null) {
            source.sendError(Text.literal("No se pudo crear el NPC."));
            return 0;
        }
        place(source, npc);
        npc.setNpcId(profile.npcId());
        npc.setCustomName(Text.literal(profile.displayName()));
        npc.setCustomNameVisible(true);
        npc.setDialogue(String.join("\n\n", profile.introPages()));
        npc.setPokemonTeam(profile.team());
        npc.setBattleRewards(java.util.List.of());
        npc.setBattleRewardRepeatable(false);
        lock(npc);
        if (!source.getWorld().spawnEntity(npc)) {
            source.sendError(Text.literal("El mundo rechazó la creación del NPC."));
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§aDesafío creado: §f" + profile.displayName()
                + " §7[" + profile.regionName() + "]§a. Quedó fijo en tu posición."), true);
        source.sendFeedback(() -> Text.literal("§7ID interno: §f" + profile.npcId()
                + " §7· Skin: automática desde RCT/Cobbleverse si existe. Override: §f/chainacobblemon npc skin " + profile.npcId() + " ..."), false);
        return 1;
    }

    private static int createProfessor(ServerCommandSource source) {
        String id = ChallengeCatalog.PROFESSOR_NPC_ID;
        if (NpcNetworking.findNpc(source.getServer(), id) != null) {
            source.sendError(Text.literal("Ya existe la Guía Chaina cargada."));
            return 0;
        }
        try {
            assets.ensureNpcFolder(id);
        } catch (Exception exception) {
            source.sendError(Text.literal("No se pudo preparar la carpeta de skin: " + exception.getMessage()));
            return 0;
        }
        ServiceNpcEntity npc = ModRegistries.CUSTOM_SLIM_NPC.create(source.getWorld());
        if (npc == null) return 0;
        place(source, npc);
        npc.setNpcId(id);
        npc.setCustomName(Text.literal("Guía Chaina"));
        npc.setCustomNameVisible(true);
        npc.setDialogue("¡Hola! Soy la Guía Chaina. Abre conmigo tu ruta de desafíos, misiones y regiones.");
        npc.setPokemonTeam(java.util.List.of());
        npc.setBattleRewards(java.util.List.of());
        lock(npc);
        if (!source.getWorld().spawnEntity(npc)) return 0;
        source.sendFeedback(() -> Text.literal("§dGuía Chaina creada. §fColoca skin.png en su carpeta visual o usa /chainacobblemon npc skin."), true);
        return 1;
    }

    private static int list(ServerCommandSource source) {
        source.sendFeedback(() -> Text.literal("§dDesafíos regionales disponibles: §f" + ChallengeCatalog.all().size()
                + " §7(8 gimnasios + 4 Alto Mando + 1 Campeón por región)"), false);
        for (String region : ChallengeCatalog.regions()) {
            String leaders = String.join(", ", ChallengeCatalog.leaders(region));
            source.sendFeedback(() -> Text.literal("§7- §f" + title(region) + "§7: " + leaders), false);
        }
        source.sendFeedback(() -> Text.literal("§7Crear: §f/chainacobblemon desafios <region> <lider>"), false);
        source.sendFeedback(() -> Text.literal("§7Guía: §f/chainacobblemon desafios profesora"), false);
        return ChallengeCatalog.all().size();
    }

    private static void place(ServerCommandSource source, ServiceNpcEntity npc) {
        Vec3d pos = source.getPosition();
        float yaw = source.getEntity() == null ? 0.0f : source.getEntity().getYaw();
        npc.refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, 0.0f);
    }

    private static void lock(ServiceNpcEntity npc) {
        npc.setAiDisabled(true);
        npc.setInvulnerable(true);
        npc.setPersistent();
    }

    private static String title(String value) {
        if (value == null || value.isBlank()) return "";
        String lower = value.toLowerCase(Locale.ROOT);
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }
}
