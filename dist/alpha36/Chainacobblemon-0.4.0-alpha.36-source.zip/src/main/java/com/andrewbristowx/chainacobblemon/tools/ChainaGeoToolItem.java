package com.andrewbristowx.chainacobblemon.tools;

import org.apache.commons.lang3.mutable.MutableObject;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;

import java.util.function.Consumer;

/** Common-side GeckoLib item contract, safe for Loom split environment source sets. */
public interface ChainaGeoToolItem extends GeoItem {
    String chainaGeoModelId();
    AnimatableInstanceCache chainaGeoCache();
    MutableObject<GeoRenderProvider> chainaRenderProviderHolder();

    @Override
    default AnimatableInstanceCache getAnimatableInstanceCache() {
        return chainaGeoCache();
    }

    @Override
    default void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Static 3D equipment model. Minecraft still provides the normal hand swing/mining animation.
    }

    @Override
    default void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(chainaRenderProviderHolder().getValue());
    }
}
