package com.andrewbristowx.chainacobblemon.gacha.machine;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.gacha.GachaRollResult;
import com.andrewbristowx.chainacobblemon.gacha.GachaNetworking;
import com.andrewbristowx.chainacobblemon.gacha.GachaService;
import com.andrewbristowx.chainacobblemon.gacha.GachaTier;
import com.andrewbristowx.chainacobblemon.gacha.banner.BannerDefinition;
import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogEntry;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.Item;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;
import org.joml.Vector3f;

import java.util.Comparator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class GachaMachineBlockEntity extends BlockEntity implements GeoBlockEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.gacha_machine.idle");
    private static final RawAnimation ACTIVATE = RawAnimation.begin().thenPlay("animation.gacha_machine.activate");
    private static final RawAnimation ROLL = RawAnimation.begin().thenLoop("animation.gacha_machine.roll");
    private static final RawAnimation RESULT_COMMON = RawAnimation.begin().thenPlay("animation.gacha_machine.result_common");
    private static final RawAnimation RESULT_EPIC = RawAnimation.begin().thenPlay("animation.gacha_machine.result_epic");
    private static final RawAnimation RESULT_LEGENDARY = RawAnimation.begin().thenPlay("animation.gacha_machine.result_legendary");
    private static final RawAnimation ERROR = RawAnimation.begin().thenPlay("animation.gacha_machine.error");
    private static final DustParticleEffect CHAINA_PINK = new DustParticleEffect(new Vector3f(1.0F, 0.22F, 0.72F), 1.05F);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private String bannerId = "rayquaza_hoenn";
    private String featuredSpeciesId = "rayquaza";
    private String featuredPokemonName = "Rayquaza";
    private boolean bannerExplicitlyConfigured;
    private GachaMachineState machineState = GachaMachineState.IDLE;
    private GachaTier resultTier;
    private UUID activePlayerUuid;
    private UUID activeTransactionId;
    private int phaseTicks;
    private transient GachaService.PreparedPull preparedPull;
    private transient GachaMachineState lastAnimatedState;

    public GachaMachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistries.GACHA_MACHINE_BLOCK_ENTITY, pos, state);
        if (state.isOf(ModRegistries.STANDARD_GACHA_MACHINE)) {
            bannerId = "standard";
            featuredSpeciesId = "";
            featuredPokemonName = "";
        } else if (state.isOf(ModRegistries.CHAINA_GACHA_MACHINE)) {
            bannerId = "chaina_special";
        } else if (state.isOf(ModRegistries.TREASURE_GACHA_MACHINE)) {
            bannerId = com.andrewbristowx.chainacobblemon.gacha.treasure.TreasureGachaService.PROGRESS_ID;
            featuredSpeciesId = "";
            featuredPokemonName = "";
        }
    }

    public String getBannerId() {
        return bannerId;
    }

    public void setBannerId(String bannerId) {
        if (bannerId == null || bannerId.isBlank()) return;
        this.bannerId = bannerId.toLowerCase(Locale.ROOT);
        this.bannerExplicitlyConfigured = true;
        refreshFeaturedPokemon();
        markAndSync();
    }

    public String getFeaturedSpeciesId() { return featuredSpeciesId; }

    public String getFeaturedPokemonName() { return featuredPokemonName; }

    /** Client-only update used by the explicit seasonal-display S2C payload. */
    public void applyClientFeaturedPokemon(String speciesId, String name) {
        if (world == null || !world.isClient) return;
        this.featuredSpeciesId = normalizeSpeciesId(speciesId);
        this.featuredPokemonName = name == null ? "" : name;
    }

    public GachaMachineState getMachineState() {
        return machineState;
    }

    public GachaTier getResultTier() {
        return resultTier;
    }

    public boolean isBusy() {
        return machineState.isBusy();
    }

    public boolean isChainaThemed() {
        return getCachedState().isOf(ModRegistries.CHAINA_GACHA_MACHINE);
    }

    public boolean isTreasureThemed() {
        return getCachedState().isOf(ModRegistries.TREASURE_GACHA_MACHINE);
    }

    public GachaService.PrepareOutcome tryStartPull(ServerPlayerEntity player) {
        if (world == null || world.isClient) {
            return GachaService.PrepareOutcome.failure("La maquina solo puede activarse desde el servidor.");
        }
        if (isBusy()) {
            return GachaService.PrepareOutcome.failure("La maquina esta procesando otra tirada.");
        }

        if (isTreasureThemed()) {
            return GachaService.PrepareOutcome.failure("El Gasha de Tesoros usa su interfaz dedicada.");
        }
        BannerDefinition banner = Chainacobblemon.bannerManager().get(bannerId);
        if (banner == null || !banner.activeNow()) {
            setError();
            return GachaService.PrepareOutcome.failure("Banner no encontrado o desactivado: " + bannerId);
        }

        Item requiredTicket = requiresChainaTicket()
                ? ModRegistries.CHAINA_SPECIAL_BANNER_TICKET
                : ModRegistries.GACHA_TICKET;
        String virtualType = requiresChainaTicket()
                ? com.andrewbristowx.chainacobblemon.rewards.RewardWalletService.CHAINA
                : com.andrewbristowx.chainacobblemon.rewards.RewardWalletService.STANDARD;
        if (player.getInventory().count(requiredTicket) < 1
                && Chainacobblemon.rewardWalletService().balance(player, virtualType) < 1L) {
            return GachaService.PrepareOutcome.failure(
                    requiresChainaTicket()
                            ? "Necesitas 1x Ticket Especial de Chaina."
                            : "Necesitas 1x Gacha Ticket."
            );
        }

        GachaService.PrepareOutcome preparation = Chainacobblemon.gachaService().preparePull(player, bannerId, isChainaThemed() ? featuredSpeciesId : "");
        if (!preparation.success()) {
            setError();
            return preparation;
        }

        this.preparedPull = preparation.preparedPull();
        this.activePlayerUuid = player.getUuid();
        this.activeTransactionId = preparedPull.transactionId();
        this.resultTier = preparedPull.result().tier();
        this.machineState = GachaMachineState.ACTIVATING;
        this.phaseTicks = 10;
        emitPhaseEffects();
        markAndSync();
        return preparation;
    }

    public void forceReset() {
        cancelPreparedReservation();
        clearToIdle();
        markAndSync();
    }

    private void setError() {
        cancelPreparedReservation();
        this.machineState = GachaMachineState.ERROR;
        this.resultTier = null;
        this.activePlayerUuid = null;
        this.activeTransactionId = null;
        this.preparedPull = null;
        this.phaseTicks = 24;
        markAndSync();
    }

    private void clearToIdle() {
        this.machineState = GachaMachineState.IDLE;
        this.resultTier = null;
        this.activePlayerUuid = null;
        this.activeTransactionId = null;
        this.preparedPull = null;
        this.phaseTicks = 0;
    }

    private void cancelPreparedReservation() {
        if (activePlayerUuid != null && activeTransactionId != null) {
            Chainacobblemon.gachaService().cancelPreparedPull(activePlayerUuid, activeTransactionId);
        }
    }

    private BannerDefinition.Currency ticketCost() {
        BannerDefinition.Currency cost = new BannerDefinition.Currency();
        boolean chaina = requiresChainaTicket();
        String virtualType = chaina
                ? com.andrewbristowx.chainacobblemon.rewards.RewardWalletService.CHAINA
                : com.andrewbristowx.chainacobblemon.rewards.RewardWalletService.STANDARD;
        ServerPlayerEntity active = world instanceof ServerWorld serverWorld && activePlayerUuid != null
                ? serverWorld.getServer().getPlayerManager().getPlayer(activePlayerUuid) : null;
        if (active != null && Chainacobblemon.rewardWalletService().balance(active, virtualType) > 0L) {
            cost.type = virtualType;
            cost.itemId = "";
        } else {
            cost.type = "ITEM";
            cost.itemId = chaina ? "chainacobblemon:chaina_special_banner_ticket" : "chainacobblemon:gacha_ticket";
        }
        cost.amount = 1;
        cost.normalize();
        return cost;
    }

    private boolean isChainaBanner(String id) {
        String normalized = id == null ? "" : id.toLowerCase(Locale.ROOT);
        return normalized.startsWith("chaina_") || normalized.contains("chaina_special");
    }

    public boolean requiresChainaTicket() {
        return !isTreasureThemed() && (isChainaThemed() || isChainaBanner(bannerId));
    }

    private GachaService.PullOutcome commitPrepared(ServerWorld serverWorld) {
        if (preparedPull == null || activePlayerUuid == null || activeTransactionId == null) {
            return GachaService.PullOutcome.failure("La tirada preparada ya no esta disponible.");
        }

        ServerPlayerEntity player = serverWorld.getServer().getPlayerManager().getPlayer(activePlayerUuid);
        if (player == null) {
            cancelPreparedReservation();
            return GachaService.PullOutcome.failure("El jugador se desconecto antes de completar la tirada.");
        }

        GachaService.PullOutcome outcome = Chainacobblemon.gachaService()
                .commitPreparedPull(player, preparedPull, ticketCost());
        if (outcome.success()) {
            GachaRollResult result = outcome.result();
            StringBuilder message = new StringBuilder("GACHA: ")
                    .append(result.tier().name()).append(" -> ")
                    .append(result.pokemon().displayName()).append(" Nv.").append(result.level());
            if (result.shiny()) message.append(" SHINY");
            if (result.hasNatureBonus()) message.append(" | Naturaleza ").append(result.nature());
            if (result.hasPerfectIvBonus()) message.append(" | IVs perfectos mín.: ").append(result.minPerfectIvs());
            player.sendMessage(Text.literal(message.toString()), false);
        } else {
            player.sendMessage(Text.literal("Gacha: " + outcome.error()), false);
        }
        return outcome;
    }

    public static void tick(World world, BlockPos pos, BlockState state, GachaMachineBlockEntity machine) {
        if (world.isClient) return;
        if (world instanceof ServerWorld serverWorld) {
            long staggered = world.getTime() + Math.floorMod(pos.asLong(), 100L);
            machine.migrateLegacyDefaultBannerIfNeeded();
            if (machine.featuredSpeciesId == null || machine.featuredSpeciesId.isBlank()
                    || machine.featuredPokemonName == null || machine.featuredPokemonName.isBlank()
                    || staggered % 100L == 0L) {
                machine.refreshFeaturedPokemon();
            }
            // Block-entity update packets remain the persistence path, but an explicit lightweight
            // S2C refresh makes the floating seasonal display deterministic for clients that began
            // tracking the chunk after the last featured rotation.
            if (staggered % 40L == 0L) {
                GachaNetworking.syncSeasonalDisplay(serverWorld, machine);
            }
            if (staggered % 40L == 0L) {
                GachaMachineTextDisplayService.reconcile(serverWorld, machine);
            }
            machine.emitSeasonDisplayEffects(serverWorld, staggered);
        }
        if (machine.phaseTicks <= 0) return;

        machine.phaseTicks--;
        if (machine.phaseTicks > 0) return;

        switch (machine.machineState) {
            case ACTIVATING -> {
                machine.machineState = GachaMachineState.ROLLING;
                machine.phaseTicks = 60;
            }
            case ROLLING -> {
                if (!(world instanceof ServerWorld serverWorld)) {
                    machine.setError();
                    return;
                }

                GachaService.PullOutcome committed = machine.commitPrepared(serverWorld);
                if (!committed.success()) {
                    machine.setError();
                    return;
                }

                machine.preparedPull = null;
                machine.activeTransactionId = null;
                machine.resultTier = committed.result().tier();

                if (machine.resultTier.isAtLeast(GachaTier.LEGENDARY)) {
                    machine.machineState = GachaMachineState.REVEAL_LEGENDARY;
                    machine.phaseTicks = 42;
                } else if (machine.resultTier.isAtLeast(GachaTier.EPIC)) {
                    machine.machineState = GachaMachineState.REVEAL_EPIC;
                    machine.phaseTicks = 30;
                } else {
                    machine.machineState = GachaMachineState.REVEAL_COMMON;
                    machine.phaseTicks = 20;
                }
            }
            case REVEAL_COMMON, REVEAL_EPIC, REVEAL_LEGENDARY, ERROR -> machine.clearToIdle();
            case IDLE -> machine.phaseTicks = 0;
        }
        machine.emitPhaseEffects();
        machine.markAndSync();
    }

    private void emitPhaseEffects() {
        if (!(world instanceof ServerWorld serverWorld)) return;

        double x = pos.getX() + 0.5;
        double y = pos.getY() + 1.05;
        double z = pos.getZ() + 0.5;

        switch (machineState) {
            case ACTIVATING -> {
                serverWorld.playSound(null, pos, SoundEvents.BLOCK_BEACON_ACTIVATE,
                        SoundCategory.BLOCKS, 0.65f, 1.65f);
                serverWorld.spawnParticles(ParticleTypes.END_ROD, x, y, z,
                        5, 0.22, 0.25, 0.22, 0.015);
            }
            case ROLLING -> {
                serverWorld.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(),
                        SoundCategory.BLOCKS, 0.85f, 1.1f);
                serverWorld.spawnParticles(ParticleTypes.PORTAL, x, y + 0.15, z,
                        18, 0.38, 0.45, 0.38, 0.08);
            }
            case REVEAL_COMMON -> {
                serverWorld.playSound(null, pos, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                        SoundCategory.BLOCKS, 0.8f, 1.2f);
                serverWorld.spawnParticles(ParticleTypes.HAPPY_VILLAGER, x, y - 0.65, z,
                        10, 0.32, 0.18, 0.32, 0.04);
            }
            case REVEAL_EPIC -> {
                serverWorld.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
                        SoundCategory.BLOCKS, 0.85f, 1.25f);
                serverWorld.spawnParticles(ParticleTypes.END_ROD, x, y, z,
                        28, 0.48, 0.65, 0.48, 0.07);
            }
            case REVEAL_LEGENDARY -> {
                serverWorld.playSound(null, pos, SoundEvents.BLOCK_END_PORTAL_SPAWN,
                        SoundCategory.BLOCKS, 0.75f, 1.35f);
                serverWorld.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
                        SoundCategory.BLOCKS, 1.0f, 0.9f);
                serverWorld.spawnParticles(ParticleTypes.END_ROD, x, y + 0.2, z,
                        60, 0.62, 0.9, 0.62, 0.11);
            }
            case ERROR -> serverWorld.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(),
                    SoundCategory.BLOCKS, 0.8f, 0.65f);
            case IDLE -> {
            }
        }
    }

    private void markAndSync() {
        markDirty();
        if (world instanceof ServerWorld serverWorld) {
            serverWorld.getChunkManager().markForUpdate(pos);
            GachaNetworking.syncSeasonalDisplay(serverWorld, this);
        }
    }

    @Override
    public void markRemoved() {
        cancelPreparedReservation();
        if (world instanceof ServerWorld serverWorld) GachaMachineTextDisplayService.remove(serverWorld, pos);
        super.markRemoved();
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        nbt.putString("BannerId", bannerId);
        nbt.putBoolean("BannerExplicit", bannerExplicitlyConfigured);
        nbt.putString("FeaturedSpecies", featuredSpeciesId);
        nbt.putString("FeaturedName", featuredPokemonName);
        nbt.putString("MachineState", machineState.name());
        nbt.putInt("PhaseTicks", phaseTicks);
        if (resultTier != null) nbt.putString("ResultTier", resultTier.name());
        if (activePlayerUuid != null) nbt.putUuid("ActivePlayer", activePlayerUuid);
        if (activeTransactionId != null) nbt.putUuid("ActiveTransaction", activeTransactionId);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        if (nbt.contains("BannerId")) bannerId = nbt.getString("BannerId");
        bannerExplicitlyConfigured = nbt.contains("BannerExplicit") && nbt.getBoolean("BannerExplicit");
        featuredSpeciesId = nbt.contains("FeaturedSpecies") ? nbt.getString("FeaturedSpecies") : "";
        featuredPokemonName = nbt.contains("FeaturedName") ? nbt.getString("FeaturedName") : "";
        try {
            machineState = GachaMachineState.valueOf(nbt.getString("MachineState"));
        } catch (Exception ignored) {
            machineState = GachaMachineState.IDLE;
        }
        phaseTicks = Math.max(0, nbt.getInt("PhaseTicks"));
        resultTier = nbt.contains("ResultTier") ? GachaTier.parse(nbt.getString("ResultTier"), null) : null;
        activePlayerUuid = nbt.containsUuid("ActivePlayer") ? nbt.getUuid("ActivePlayer") : null;
        activeTransactionId = nbt.containsUuid("ActiveTransaction") ? nbt.getUuid("ActiveTransaction") : null;
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registryLookup) {
        return createNbt(registryLookup);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "machine", 2, this::animationController));
    }

    private PlayState animationController(AnimationState<GachaMachineBlockEntity> animationState) {
        if (lastAnimatedState != machineState) {
            animationState.getController().forceAnimationReset();
            lastAnimatedState = machineState;
        }

        RawAnimation animation = switch (machineState) {
            case IDLE -> IDLE;
            case ACTIVATING -> ACTIVATE;
            case ROLLING -> ROLL;
            case REVEAL_COMMON -> RESULT_COMMON;
            case REVEAL_EPIC -> RESULT_EPIC;
            case REVEAL_LEGENDARY -> RESULT_LEGENDARY;
            case ERROR -> ERROR;
        };
        return animationState.setAndContinue(animation);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    private void migrateLegacyDefaultBannerIfNeeded() {
        if (world == null || world.isClient || isTreasureThemed() || bannerExplicitlyConfigured) return;
        // Older builds created every machine with the Rayquaza banner by default. Keep the standard
        // machine on the standard pool, and migrate the Chaina machine to its own dedicated Chaina pool.
        if ("rayquaza_hoenn".equalsIgnoreCase(bannerId)) {
            if (isChainaThemed()) {
                bannerId = "chaina_special";
            } else {
                bannerId = "standard";
            }
            featuredSpeciesId = "";
            featuredPokemonName = "";
            markAndSync();
        }
    }

    private void refreshFeaturedPokemon() {
        if (world != null && world.isClient) return;
        if (isTreasureThemed()) {
            if (!featuredSpeciesId.isBlank() || !featuredPokemonName.isBlank()) {
                featuredSpeciesId = "";
                featuredPokemonName = "";
                markAndSync();
            }
            return;
        }
        BannerDefinition banner = Chainacobblemon.bannerManager().get(bannerId);
        PokemonCatalogEntry selected = null;
        String nextSpecies = "";
        String nextName = "";

        if (isChainaThemed()) {
            // CHAINA keeps the server-authoritative legendary selected for the current 12-hour rotation.
            selected = Chainacobblemon.featuredRotation().currentChainaLegendary();
        } else {
            // Alpha.8: use vanilla Eevee for the standard floating mascot. The custom Eevee Gatito remains
            // an independent species exclusive to the Chaina/event pools; this avoids coupling the world display
            // renderer to an addon species while preserving all custom Pokémon gameplay.
            selected = Chainacobblemon.pokemonCatalog().get("eevee");
        }

        if (selected != null) {
            nextSpecies = selected.speciesId();
            nextName = selected.displayName();
        }
        if (!nextSpecies.equals(featuredSpeciesId) || !nextName.equals(featuredPokemonName)) {
            featuredSpeciesId = nextSpecies;
            featuredPokemonName = nextName;
            markAndSync();
        }
    }

    private static String normalizeSpeciesId(String species) {
        if (species == null) return "";
        String normalized = species.strip().toLowerCase(Locale.ROOT);
        return normalized.startsWith("cobblemon:") ? normalized.substring("cobblemon:".length()) : normalized;
    }

    private void emitSeasonDisplayEffects(ServerWorld serverWorld, long staggeredTime) {
        if (isTreasureThemed()) {
            double x = pos.getX() + 0.5D, y = pos.getY() + 2.65D, z = pos.getZ() + 0.5D;
            if (staggeredTime % 10L == 0L) serverWorld.spawnParticles(CHAINA_PINK, x, y, z, 3, 0.4D, 0.35D, 0.4D, 0.02D);
            if (staggeredTime % 26L == 0L) serverWorld.spawnParticles(ParticleTypes.END_ROD, x, y + 0.15D, z, 2, 0.3D, 0.22D, 0.3D, 0.01D);
            return;
        }
        if (featuredSpeciesId == null || featuredSpeciesId.isBlank()) return;
        double x = pos.getX() + 0.5D;
        double y = pos.getY() + 2.65D;
        double z = pos.getZ() + 0.5D;
        if (isChainaThemed()) {
            if (staggeredTime % 10L == 0L) {
                serverWorld.spawnParticles(CHAINA_PINK, x, y, z, 2, 0.38D, 0.32D, 0.38D, 0.015D);
            }
            if (staggeredTime % 30L == 0L) {
                serverWorld.spawnParticles(ParticleTypes.HEART, x, y + 0.18D, z,
                        1, 0.28D, 0.18D, 0.28D, 0.02D);
            }
        } else if (staggeredTime % 16L == 0L) {
            serverWorld.spawnParticles(ParticleTypes.END_ROD, x, y, z,
                    1, 0.35D, 0.28D, 0.35D, 0.01D);
        }
    }

    private static String readableName(String species) {
        String[] words = species.replace('-', '_').split("_");
        StringBuilder name = new StringBuilder();
        for (String word : words) {
            if (word.isBlank()) continue;
            if (!name.isEmpty()) name.append(' ');
            name.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return name.toString();
    }
}
