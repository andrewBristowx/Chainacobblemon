package com.andrewbristowx.chainacobblemon.rewards;

import com.andrewbristowx.chainacobblemon.config.ChainacobblemonConfig;
import com.andrewbristowx.chainacobblemon.progress.JobAccessPolicy;
import com.andrewbristowx.chainacobblemon.progress.RankGroups;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Locale;
import java.util.Set;

/** Optional LuckPerms integration with safe operator, team, inherited-group and exact-name fallbacks. */
final class BattlePassAccessPolicy {
    private BattlePassAccessPolicy() { }

    static boolean hasPremium(ServerPlayerEntity player, ChainacobblemonConfig.BattlePassSettings settings) {
        if (player.hasPermissionLevel(2)) return true;
        String name = player.getGameProfile().getName().toLowerCase(Locale.ROOT);
        if (settings.premiumPlayerNames.contains(name)) return true;
        if (player.getScoreboardTeam() != null
                && settings.premiumGroups.contains(player.getScoreboardTeam().getName().toLowerCase(Locale.ROOT))) return true;

        Set<String> groups = JobAccessPolicy.groupsFor(player);
        for (String group : groups) {
            String normalized = RankGroups.normalize(group);
            if (settings.premiumGroups.contains(normalized) || RankGroups.PREMIUM.contains(normalized)) return true;
        }
        return JobAccessPolicy.hasPermission(player, settings.premiumPermission);
    }
}
