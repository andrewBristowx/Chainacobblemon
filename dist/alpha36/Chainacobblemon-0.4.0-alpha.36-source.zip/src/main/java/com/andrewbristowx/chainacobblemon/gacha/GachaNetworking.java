package com.andrewbristowx.chainacobblemon.gacha;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.gacha.banner.BannerDefinition;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineBlockEntity;
import com.andrewbristowx.chainacobblemon.gacha.treasure.TreasureGachaService;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.andrewbristowx.chainacobblemon.rewards.RewardWalletService;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Opens and executes the x1/x10 gacha UI while keeping every roll authoritative on the server. */
public final class GachaNetworking {
    private static final Gson GSON = new Gson();

    private GachaNetworking() { }

    public static void initializeServer() {
        PayloadTypeRegistry.playS2C().register(OpenGachaPayload.ID, OpenGachaPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SeasonalDisplayPayload.ID, SeasonalDisplayPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GachaActionPayload.ID, GachaActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(GachaActionPayload.ID,
                (payload, context) -> context.server().execute(() -> action(context.player(), payload)));
    }

    public static void open(ServerPlayerEntity player, GachaMachineBlockEntity machine, String message) {
        send(player, state(player, machine, message, List.of()));
    }

    private static void action(ServerPlayerEntity player, GachaActionPayload payload) {
        int count = payload.count();
        if (count != 1 && count != 10) return;
        BlockPos pos = BlockPos.fromLong(payload.blockPos());
        if (player.squaredDistanceTo(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 64.0D) {
            player.sendMessage(Text.literal("§cDebes permanecer cerca de la máquina gacha."), false);
            return;
        }
        if (!(player.getServerWorld().getBlockEntity(pos) instanceof GachaMachineBlockEntity machine)) {
            player.sendMessage(Text.literal("§cLa máquina gacha ya no está disponible."), false);
            return;
        }
        if (machine.isTreasureThemed()) {
            actionTreasure(player, machine, count);
            return;
        }
        BannerDefinition banner = Chainacobblemon.bannerManager().get(machine.getBannerId());
        if (banner == null || !banner.activeNow()) {
            open(player, machine, "§cEl banner está desactivado o ya terminó.");
            return;
        }
        ArrayList<ResultView> results = new ArrayList<>();
        String message = "";
        for (int index = 0; index < count; index++) {
            GachaService.PullOutcome outcome = Chainacobblemon.gachaService().pullWithCurrencyOverride(
                    player, banner.id, currency(player, machine),
                    machine.isChainaThemed() ? machine.getFeaturedSpeciesId() : "");
            if (!outcome.success()) {
                message = (results.isEmpty() ? "§c" : "§e") + outcome.error();
                break;
            }
            GachaRollResult result = outcome.result();
            results.add(new ResultView("POKEMON", result.pokemon().speciesId(), "", result.pokemon().displayName(),
                    result.tier().name(), result.level(), result.shiny(), 1));
        }
        if (!results.isEmpty()) message = "§a" + results.size() + " tirada" + (results.size() == 1 ? " completada." : "s completadas.");
        send(player, state(player, machine, message, results));
    }

    private static void actionTreasure(ServerPlayerEntity player, GachaMachineBlockEntity machine, int count) {
        ArrayList<ResultView> results = new ArrayList<>();
        String message = "";
        for (int index = 0; index < count; index++) {
            TreasureGachaService.PullOutcome outcome = Chainacobblemon.treasureGachaService().pull(player);
            if (!outcome.success()) {
                message = (results.isEmpty() ? "§c" : "§e") + outcome.error();
                break;
            }
            TreasureGachaService.TreasureResult result = outcome.result();
            results.add(new ResultView("ITEM", "", result.itemId(), result.displayName(),
                    result.tier().name(), 0, false, result.count()));
        }
        if (!results.isEmpty()) message = "§a" + results.size() + " tesoro" + (results.size() == 1 ? " obtenido." : "s obtenidos.");
        send(player, state(player, machine, message, results));
    }

    private static BannerDefinition.Currency currency(ServerPlayerEntity player, GachaMachineBlockEntity machine) {
        boolean chaina = machine.requiresChainaTicket();
        String walletType = chaina ? RewardWalletService.CHAINA : RewardWalletService.STANDARD;
        BannerDefinition.Currency cost = new BannerDefinition.Currency();
        if (Chainacobblemon.rewardWalletService().balance(player, walletType) > 0L) {
            cost.type = walletType;
            cost.itemId = "";
        } else {
            cost.type = "ITEM";
            cost.itemId = chaina ? "chainacobblemon:chaina_special_banner_ticket" : "chainacobblemon:gacha_ticket";
        }
        cost.amount = 1;
        cost.normalize();
        return cost;
    }

    public static void syncSeasonalDisplay(ServerWorld world, GachaMachineBlockEntity machine) {
        if (world == null || machine == null) return;
        SeasonalDisplayPayload payload = new SeasonalDisplayPayload(
                machine.getPos().asLong(),
                machine.getFeaturedSpeciesId() == null ? "" : machine.getFeaturedSpeciesId(),
                machine.getFeaturedPokemonName() == null ? "" : machine.getFeaturedPokemonName());
        double x = machine.getPos().getX() + 0.5D;
        double y = machine.getPos().getY() + 0.5D;
        double z = machine.getPos().getZ() + 0.5D;
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (player.squaredDistanceTo(x, y, z) > 96.0D * 96.0D) continue;
            if (ServerPlayNetworking.canSend(player, SeasonalDisplayPayload.ID)) {
                ServerPlayNetworking.send(player, payload);
            }
        }
    }

    private static GachaView state(ServerPlayerEntity player, GachaMachineBlockEntity machine,
                                   String message, List<ResultView> results) {
        if (machine.isTreasureThemed()) {
            GachaProgress progress = Chainacobblemon.treasureGachaService().progress(player);
            long tickets = player.getInventory().count(ModRegistries.TREASURE_GACHA_TICKET);
            return new GachaView(machine.getPos().asLong(), TreasureGachaService.PROGRESS_ID,
                    "Tesoros de Chaina", false, true, tickets,
                    progress.totalPulls, progress.pullsSinceEpicOrBetter, TreasureGachaService.NETHERITE_PITY,
                    progress.pullsSinceLegendaryOrBetter, TreasureGachaService.CHAINA_PITY,
                    message == null ? "" : message, results);
        }
        BannerDefinition banner = Chainacobblemon.bannerManager().get(machine.getBannerId());
        boolean chaina = machine.requiresChainaTicket();
        Item ticket = chaina ? ModRegistries.CHAINA_SPECIAL_BANNER_TICKET : ModRegistries.GACHA_TICKET;
        String wallet = chaina ? RewardWalletService.CHAINA : RewardWalletService.STANDARD;
        long tickets = player.getInventory().count(ticket) + Chainacobblemon.rewardWalletService().balance(player, wallet);
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        GachaProgress progress = data.gacha(machine.getBannerId());
        int epicMax = banner == null ? 0 : banner.pity.epicGuarantee;
        int legendaryMax = banner == null ? 0 : banner.pity.hardLegendaryGuarantee;
        String bannerName = banner == null ? machine.getBannerId() : banner.displayName;
        if (machine.isChainaThemed() && machine.getFeaturedPokemonName() != null
                && !machine.getFeaturedPokemonName().isBlank()) {
            bannerName = machine.getFeaturedPokemonName() + " · Legendario de Chaina";
        }
        return new GachaView(machine.getPos().asLong(), machine.getBannerId(),
                bannerName, chaina, false, tickets,
                progress.totalPulls, progress.pullsSinceEpicOrBetter, epicMax,
                progress.pullsSinceLegendaryOrBetter, legendaryMax,
                message == null ? "" : message, results);
    }

    private static void send(ServerPlayerEntity player, GachaView view) {
        if (ServerPlayNetworking.canSend(player, OpenGachaPayload.ID))
            ServerPlayNetworking.send(player, new OpenGachaPayload(GSON.toJson(view)));
    }

    public record GachaView(long blockPos, String bannerId, String bannerName, boolean chaina, boolean treasure,
                            long tickets, long totalPulls, int epicPity, int epicMaximum,
                            int legendaryPity, int legendaryMaximum, String message,
                            List<ResultView> results) { }

    public record ResultView(String rewardKind, String speciesId, String itemId, String name,
                             String tier, int level, boolean shiny, int count) { }

    public record OpenGachaPayload(String json) implements CustomPayload {
        public static final Id<OpenGachaPayload> ID = new Id<>(Identifier.of(Chainacobblemon.MOD_ID, "open_gacha"));
        public static final PacketCodec<RegistryByteBuf, OpenGachaPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, OpenGachaPayload::json, OpenGachaPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record SeasonalDisplayPayload(long blockPos, String speciesId, String name) implements CustomPayload {
        public static final Id<SeasonalDisplayPayload> ID = new Id<>(Identifier.of(Chainacobblemon.MOD_ID, "gacha_seasonal_display"));
        public static final PacketCodec<RegistryByteBuf, SeasonalDisplayPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_LONG, SeasonalDisplayPayload::blockPos,
                PacketCodecs.STRING, SeasonalDisplayPayload::speciesId,
                PacketCodecs.STRING, SeasonalDisplayPayload::name,
                SeasonalDisplayPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record GachaActionPayload(long blockPos, int count) implements CustomPayload {
        public static final Id<GachaActionPayload> ID = new Id<>(Identifier.of(Chainacobblemon.MOD_ID, "gacha_action"));
        public static final PacketCodec<RegistryByteBuf, GachaActionPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_LONG, GachaActionPayload::blockPos,
                PacketCodecs.VAR_INT, GachaActionPayload::count,
                GachaActionPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }
}
