package com.andrewbristowx.chainacobblemon.tools;

import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.TagKey;

/** A small step above Netherite without turning the Chaina set into creative-mode tools. */
public enum ChainaToolMaterial implements ToolMaterial {
    INSTANCE;

    @Override public int getDurability() { return 2460; }
    @Override public float getMiningSpeedMultiplier() { return 11.0F; }
    @Override public float getAttackDamage() { return 4.5F; }
    @Override public TagKey<Block> getInverseTag() { return ToolMaterials.NETHERITE.getInverseTag(); }
    @Override public int getEnchantability() { return 20; }
    @Override public Ingredient getRepairIngredient() { return ToolMaterials.NETHERITE.getRepairIngredient(); }
}
