package com.andrewbristowx.chainacobblemon.rewards.data;

/** Server-owned gacha credits. They are persisted with the player and never live only on the client. */
public final class RewardWallet {
    public long standardRolls;
    public long chainaRolls;

    public void normalize() {
        standardRolls = Math.max(0L, standardRolls);
        chainaRolls = Math.max(0L, chainaRolls);
    }
}
