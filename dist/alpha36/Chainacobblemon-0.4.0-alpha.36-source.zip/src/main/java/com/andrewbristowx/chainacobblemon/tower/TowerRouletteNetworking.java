package com.andrewbristowx.chainacobblemon.tower;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public final class TowerRouletteNetworking {
    private static final Gson GSON = new Gson();

    private TowerRouletteNetworking() { }

    public static void initializeServer() {
        PayloadTypeRegistry.playS2C().register(OpenTowerRoulettePayload.ID, OpenTowerRoulettePayload.CODEC);
    }

    public static void open(ServerPlayerEntity player, TowerRouletteSnapshot snapshot) {
        if (player != null && snapshot != null && ServerPlayNetworking.canSend(player, OpenTowerRoulettePayload.ID)) {
            ServerPlayNetworking.send(player, new OpenTowerRoulettePayload(GSON.toJson(snapshot)));
        }
    }

    public record OpenTowerRoulettePayload(String json) implements CustomPayload {
        public static final Id<OpenTowerRoulettePayload> ID = new Id<>(Identifier.of(Chainacobblemon.MOD_ID, "open_tower_roulette"));
        public static final PacketCodec<RegistryByteBuf, OpenTowerRoulettePayload> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, OpenTowerRoulettePayload::json, OpenTowerRoulettePayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }
}
