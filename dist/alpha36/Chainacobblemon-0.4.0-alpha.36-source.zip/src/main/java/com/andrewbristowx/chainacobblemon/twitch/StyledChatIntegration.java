package com.andrewbristowx.chainacobblemon.twitch;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** One-time, non-destructive Styled Chat setup for the Chaina rank presentation. */
public final class StyledChatIntegration {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private StyledChatIntegration() { }

    public static void serverStarted(MinecraftServer server, ConfigManager configManager) {
        if (!configManager.get().twitch.styledChatAutoConfigure) return;
        if (!FabricLoader.getInstance().isModLoaded("styledchat")) {
            Chainacobblemon.LOGGER.info("Styled Chat not detected; skipping automatic Chaina chat format");
            return;
        }

        try {
            Path configDir = FabricLoader.getInstance().getConfigDir();
            Path file = configDir.resolve("styled-chat.json");
            Path marker = configManager.configDirectory().resolve("styledchat-auto-installed.json");
            if (Files.exists(marker)) {
                server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), "styledchat reload");
                return;
            }
            if (Files.notExists(file)) {
                Chainacobblemon.LOGGER.warn("Styled Chat is loaded but {} does not exist yet; leaving it untouched", file);
                return;
            }

            Path backup = configDir.resolve("styled-chat.json.chaina-backup");
            if (Files.notExists(backup)) Files.copy(file, backup, StandardCopyOption.COPY_ATTRIBUTES);

            JsonObject root = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject defaults = object(root, "default");
            defaults.addProperty("display_name", "%chainacobblemon:styled_name%");
            JsonObject formats = object(defaults, "message_formats");
            formats.addProperty("chat", "${player} <dark_gray>»</dark_gray> ${message}");
            Files.writeString(file, GSON.toJson(root), StandardCharsets.UTF_8);

            JsonObject markerData = new JsonObject();
            markerData.addProperty("installed", true);
            markerData.addProperty("version", 1);
            markerData.addProperty("backup", backup.getFileName().toString());
            markerData.addProperty("note", "Remove this marker only if you want Chainacobblemon to apply the default Styled Chat format again.");
            Files.writeString(marker, GSON.toJson(markerData), StandardCharsets.UTF_8);

            server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), "styledchat reload");
            Chainacobblemon.LOGGER.info("Styled Chat configured for Chaina ranks; original saved as {}", backup);
        } catch (Throwable exception) {
            Chainacobblemon.LOGGER.warn("Could not auto-configure Styled Chat; existing chat configuration remains usable", exception);
        }
    }

    private static JsonObject object(JsonObject parent, String key) {
        if (parent.has(key) && parent.get(key).isJsonObject()) return parent.getAsJsonObject(key);
        JsonObject created = new JsonObject();
        parent.add(key, created);
        return created;
    }
}
