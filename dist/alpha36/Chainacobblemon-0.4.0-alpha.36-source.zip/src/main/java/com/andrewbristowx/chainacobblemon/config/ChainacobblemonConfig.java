package com.andrewbristowx.chainacobblemon.config;

public final class ChainacobblemonConfig {
    public int configVersion = 17;
    public boolean debugLogging = false;
    public boolean playerDataEnabled = true;
    public HubSettings hub = new HubSettings();
    public BalanceSettings balance = new BalanceSettings();
    public DailyRewardSettings dailyRewards = new DailyRewardSettings();
    public BattlePassSettings battlePass = new BattlePassSettings();
    public KitSettings kits = new KitSettings();
    public TwitchSettings twitch = new TwitchSettings();

    public void normalize() {
        int previousConfigVersion = configVersion;
        if (hub == null) {
            hub = new HubSettings();
        }
        hub.normalize();
        if (balance == null) balance = new BalanceSettings();
        balance.normalize();
        if (dailyRewards == null) dailyRewards = new DailyRewardSettings();
        dailyRewards.normalize();
        if (battlePass == null) battlePass = new BattlePassSettings();
        battlePass.normalize();
        if (kits == null) kits = new KitSettings();
        kits.normalize();
        if (twitch == null) twitch = new TwitchSettings();
        twitch.normalize();
        migrateLegacyRankGroups();
        if (previousConfigVersion < 10) migrateTreasureTicketRewards();
        if (previousConfigVersion < 17) migrateAlpha15RanksAndKits();
        configVersion = 17;
    }


    /** alpha.15 extends premium ranks and weekly kits without overwriting customized kit contents. */
    private void migrateAlpha15RanksAndKits() {
        battlePass.premiumGroups.addAll(java.util.List.of(
                "vip", "moderator", "admin", "owner", "chaina",
                twitch.tier1Group, twitch.tier2Group, twitch.tier3Group,
                twitch.vipTwitchGroup, twitch.moderatorTwitchGroup));

        java.util.LinkedHashMap<String, KitDefinition> existing = new java.util.LinkedHashMap<>();
        for (KitDefinition kit : kits.definitions) if (kit != null) existing.putIfAbsent(kit.id, kit);
        for (KitDefinition kit : KitSettings.alpha15DefaultKits()) existing.putIfAbsent(kit.id, kit);

        // Replace only the old shipped generic Premium kit. A server-owner customized entry is preserved.
        KitDefinition legacy = existing.get("premium");
        if (legacy != null && "Kit Premium".equals(legacy.displayName)
                && legacy.items != null && legacy.items.contains("chainacobblemon:chaina_special_banner_ticket*1")) {
            existing.remove("premium");
        }
        kits.definitions = new java.util.ArrayList<>(existing.values());
    }

    /** 0.5.0 adds the Tesoros de Chaina ticket without deleting customized daily rewards. */
    private void migrateTreasureTicketRewards() {
        boolean present = dailyRewards.rewards.stream().anyMatch(reward -> reward != null
                && "ITEM".equalsIgnoreCase(reward.type)
                && "chainacobblemon:treasure_gacha_ticket".equalsIgnoreCase(reward.value));
        if (!present) {
            dailyRewards.rewards.add(new DailyRewardEntry(
                    "treasure_ticket", "ITEM", "chainacobblemon:treasure_gacha_ticket", 1, 6));
        }
    }

    /** Corrects only shipped pre-alpha.67 defaults; custom permission nodes remain untouched. */
    private void migrateLegacyRankGroups() {
        java.util.LinkedHashSet<String> migrated = new java.util.LinkedHashSet<>();
        for (String group : battlePass.premiumGroups) {
            String key = group == null ? "" : group.strip().toLowerCase(java.util.Locale.ROOT);
            switch (key) {
                case "donador" -> migrated.add("vip");
                case "mod", "moderador" -> migrated.add("moderator");
                case "dueña", "duena" -> migrated.add("owner");
                default -> { if (!key.isBlank()) migrated.add(key); }
            }
        }
        if (migrated.isEmpty()) migrated.addAll(java.util.List.of("vip", "moderator", "admin", "owner"));
        battlePass.premiumGroups = migrated;
    }


    public static final class TwitchSettings {
        public boolean enabled = true;
        /** development = local simulator; bridge = signed ChainaBridge production mode. */
        public String mode = "bridge";
        public String broadcasterLogin = "chainavt";
        public String bridgeBaseUrl = "http://127.0.0.1:8765";
        /** Base64 X.509 Ed25519 public key. The bridge private key never enters Minecraft. */
        public String bridgePublicKey = "";
        public boolean requireSignedResponses = false;
        public int playerSyncIntervalSeconds = 300;
        public int channelPollSeconds = 60;
        public boolean announceOnline = true;
        public boolean announceOffline = true;
        /** Compact Twitch status indicator rendered at the top-center of the Minecraft HUD. */
        public boolean streamHudEnabled = true;
        /** Auto-create a Chaina style and placeholders when Styled Player List is installed. */
        public boolean styledPlayerListAutoConfigure = true;
        /** Download and render two Chaina Twitch emotes around the TAB title. */
        public boolean styledPlayerListTabEmotes = true;
        /** Configure Styled Chat once so rank colors/tags match the TAB. */
        public boolean styledChatAutoConfigure = true;
        /** Create and maintain Chainacobblemon-owned Twitch groups in LuckPerms. */
        public boolean luckPermsAutoConfigure = true;
        /** Hide the floating Twitch HUD when the same information is available in TAB. */
        public boolean hideStreamHudWhenTabIntegrated = true;
        /** Roll persistent random gameplay bonuses once per Chaina live session. */
        public boolean streamBonusesEnabled = true;
        public int streamBonusCount = 3;
        public double streamJackpotChance = 0.05D;
        /** Chance that a natural spawn is converted to the randomly featured elemental type. */
        public double streamTypeReplaceChance = 0.08D;
        /** Extra direct chance that a natural spawn becomes a legendary/mythical during the bonus. */
        public double streamLegendaryReplaceChance = 0.0008D;
        /** Chance that a common/uncommon natural spawn is promoted to Rare/Epic. */
        public double streamRareReplaceChance = 0.035D;
        /** Chance for a naturally spawned Pokemon to receive at least one IV of 31. */
        public double streamPerfectIvChance = 0.18D;
        /** Conditional chance for a second perfect IV after the first stream IV bonus triggers. */
        public double streamSecondPerfectIvChance = 0.04D;
        /** Optional LuckPerms inheritance groups; the primary group is never replaced. */
        public String linkedGroup = "twitch";
        public String tier1Group = "sub_chaina";
        public String tier2Group = "sub_chaina_plus";
        public String tier3Group = "sub_chaina_plus_plus";
        /** Secondary Twitch role groups observed from Chaina's authoritative chat badges. */
        public String vipTwitchGroup = "vip_chaina";
        public String moderatorTwitchGroup = "mod_chaina";

        public void normalize() {
            if (mode == null) mode = "bridge";
            mode = mode.strip().toLowerCase(java.util.Locale.ROOT);
            if (!java.util.Set.of("development", "bridge").contains(mode)) mode = "bridge";
            if (broadcasterLogin == null || broadcasterLogin.isBlank()) broadcasterLogin = "chainavt";
            broadcasterLogin = broadcasterLogin.strip().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_]", "");
            if (broadcasterLogin.isBlank()) broadcasterLogin = "chainavt";
            if (bridgeBaseUrl == null || bridgeBaseUrl.isBlank()) bridgeBaseUrl = "http://127.0.0.1:8765";
            bridgeBaseUrl = bridgeBaseUrl.strip();
            if (!bridgeBaseUrl.isBlank() && !(bridgeBaseUrl.startsWith("https://") || bridgeBaseUrl.startsWith("http://127.0.0.1") || bridgeBaseUrl.startsWith("http://localhost"))) bridgeBaseUrl = "http://127.0.0.1:8765";
            boolean loopbackBridge = bridgeBaseUrl.startsWith("http://127.0.0.1") || bridgeBaseUrl.startsWith("http://localhost");
            if (!loopbackBridge) requireSignedResponses = true;
            if (bridgePublicKey == null) bridgePublicKey = "";
            bridgePublicKey = bridgePublicKey.strip();
            playerSyncIntervalSeconds = Math.clamp(playerSyncIntervalSeconds, 30, 3600);
            channelPollSeconds = Math.clamp(channelPollSeconds, 15, 600);
            streamBonusCount = Math.clamp(streamBonusCount, 1, 5);
            streamJackpotChance = clamp01(streamJackpotChance, 0.05D, 0.25D);
            streamTypeReplaceChance = clamp01(streamTypeReplaceChance, 0.08D, 0.50D);
            streamLegendaryReplaceChance = clamp01(streamLegendaryReplaceChance, 0.0008D, 0.01D);
            streamRareReplaceChance = clamp01(streamRareReplaceChance, 0.035D, 0.25D);
            streamPerfectIvChance = clamp01(streamPerfectIvChance, 0.18D, 1.0D);
            streamSecondPerfectIvChance = clamp01(streamSecondPerfectIvChance, 0.04D, 1.0D);
            linkedGroup = normalizeGroup(linkedGroup, "twitch");
            tier1Group = normalizeGroup(tier1Group, "sub_chaina");
            tier2Group = normalizeGroup(tier2Group, "sub_chaina_plus");
            tier3Group = normalizeGroup(tier3Group, "sub_chaina_plus_plus");
            vipTwitchGroup = normalizeGroup(vipTwitchGroup, "vip_chaina");
            moderatorTwitchGroup = normalizeGroup(moderatorTwitchGroup, "mod_chaina");
        }

        private static double clamp01(double value, double fallback, double maximum) {
            if (!Double.isFinite(value)) return fallback;
            return Math.max(0.0D, Math.min(maximum, value));
        }

        private static String normalizeGroup(String value, String fallback) {
            if (value == null || value.isBlank()) return fallback;
            String normalized = value.strip().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
            return normalized.isBlank() ? fallback : normalized;
        }
    }

    public static final class KitSettings {
        public boolean enabled = true;
        public java.util.List<KitDefinition> definitions = defaultKits();

        public void normalize() {
            if (definitions == null) definitions = defaultKits();
            java.util.ArrayList<KitDefinition> safe = new java.util.ArrayList<>();
            java.util.HashSet<String> ids = new java.util.HashSet<>();
            for (KitDefinition kit : definitions) {
                if (kit == null) continue;
                kit.normalize();
                if (!kit.items.isEmpty() && ids.add(kit.id)) safe.add(kit);
            }
            definitions = safe.isEmpty() ? defaultKits() : safe;
        }

        private static java.util.List<KitDefinition> defaultKits() {
            return alpha15DefaultKits();
        }

        private static java.util.List<KitDefinition> alpha15DefaultKits() {
            return new java.util.ArrayList<>(java.util.List.of(
                    new KitDefinition("inicio", "Kit Inicial", "groups:*", 168,
                            java.util.List.of("minecraft:stone_pickaxe*1", "minecraft:stone_axe*1",
                                    "minecraft:bread*16", "cobblemon:poke_ball*16")),
                    new KitDefinition("sub1", "Kit SUB I", "groups:sub_chaina,sub_chaina_plus,sub_chaina_plus_plus", 168,
                            java.util.List.of("minecraft:diamond*2", "cobblemon:great_ball*16",
                                    "chainacobblemon:gacha_ticket*1")),
                    new KitDefinition("sub2", "Kit SUB II", "groups:sub_chaina_plus,sub_chaina_plus_plus", 168,
                            java.util.List.of("minecraft:diamond*3", "cobblemon:ultra_ball*12",
                                    "chainacobblemon:gacha_ticket*2")),
                    new KitDefinition("sub3", "Kit SUB III", "groups:sub_chaina_plus_plus", 168,
                            java.util.List.of("minecraft:diamond*5", "cobblemon:ultra_ball*16",
                                    "chainacobblemon:gacha_ticket*2", "chainacobblemon:chaina_special_banner_ticket*1")),
                    new KitDefinition("vip", "Kit VIP", "groups:vip,vip_chaina", 168,
                            java.util.List.of("minecraft:diamond*5", "cobblemon:ultra_ball*16",
                                    "chainacobblemon:gacha_ticket*3", "chainacobblemon:treasure_gacha_ticket*1")),
                    new KitDefinition("mod", "Kit MOD", "groups:moderator,mod,moderador,mod_chaina", 168,
                            java.util.List.of("minecraft:diamond*5", "cobblemon:ultra_ball*16",
                                    "chainacobblemon:gacha_ticket*3", "chainacobblemon:treasure_gacha_ticket*1"))
            ));
        }
    }

    public static final class KitDefinition {
        public String id;
        public String displayName;
        public String permission;
        /** 0 means one claim ever; otherwise cooldown in real hours. */
        public int cooldownHours;
        /** Entries use namespace:item*count. */
        public java.util.List<String> items;

        public KitDefinition() { }

        public KitDefinition(String id, String displayName, String permission, int cooldownHours,
                             java.util.List<String> items) {
            this.id = id;
            this.displayName = displayName;
            this.permission = permission;
            this.cooldownHours = cooldownHours;
            this.items = new java.util.ArrayList<>(items);
        }

        public void normalize() {
            if (id == null || id.isBlank()) id = "kit";
            id = id.strip().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
            if (displayName == null || displayName.isBlank()) displayName = id;
            if (permission == null || permission.isBlank()) permission = "chainacobblemon.kit." + id;
            permission = permission.strip().toLowerCase(java.util.Locale.ROOT);
            cooldownHours = Math.clamp(cooldownHours, 0, 24 * 365);
            if (items == null) items = new java.util.ArrayList<>();
            items = items.stream().filter(java.util.Objects::nonNull).map(String::strip)
                    .filter(value -> value.matches("[a-z0-9_.-]+:[a-z0-9_./-]+\\*[1-9][0-9]{0,5}"))
                    .distinct().limit(128)
                    .collect(java.util.stream.Collectors.toCollection(java.util.ArrayList::new));
        }
    }

    public static final class DailyRewardSettings {
        public boolean enabled = true;
        /** IANA time zone used to decide when a new real day starts. */
        public String timeZone = "America/Lima";
        public boolean openOnLogin = true;
        public java.util.List<DailyRewardEntry> rewards = defaultRewards();

        public void normalize() {
            if (timeZone == null || timeZone.isBlank()) timeZone = "America/Lima";
            try { java.time.ZoneId.of(timeZone); }
            catch (Exception ignored) { timeZone = "America/Lima"; }
            if (rewards == null) rewards = defaultRewards();
            java.util.ArrayList<DailyRewardEntry> safe = new java.util.ArrayList<>();
            java.util.HashSet<String> ids = new java.util.HashSet<>();
            for (DailyRewardEntry reward : rewards) {
                if (reward == null) continue;
                reward.normalize();
                if (reward.weight > 0 && ids.add(reward.id)) safe.add(reward);
            }
            rewards = safe.isEmpty() ? defaultRewards() : safe;
        }

        private static java.util.List<DailyRewardEntry> defaultRewards() {
            return new java.util.ArrayList<>(java.util.List.of(
                    new DailyRewardEntry("chaibells_250", "CHAIBELLS", "", 250, 28),
                    new DailyRewardEntry("diamonds_3", "ITEM", "minecraft:diamond", 3, 15),
                    new DailyRewardEntry("ultra_balls_4", "ITEM", "cobblemon:ultra_ball", 4, 18),
                    new DailyRewardEntry("rare_candy_2", "ITEM", "cobblemon:rare_candy", 2, 12),
                    new DailyRewardEntry("standard_roll", "STANDARD_ROLLS", "", 1, 12),
                    new DailyRewardEntry("chaina_roll", "CHAINA_ROLLS", "", 1, 5),
                    new DailyRewardEntry("treasure_ticket", "ITEM", "chainacobblemon:treasure_gacha_ticket", 1, 6),
                    new DailyRewardEntry("random_pokemon", "POKEMON", "standard", 1, 2)
            ));
        }
    }

    public static final class DailyRewardEntry {
        public String id;
        public String type;
        public String value;
        public int amount;
        public int weight;

        public DailyRewardEntry() { }

        public DailyRewardEntry(String id, String type, String value, int amount, int weight) {
            this.id = id;
            this.type = type;
            this.value = value;
            this.amount = amount;
            this.weight = weight;
        }

        public void normalize() {
            if (id == null || id.isBlank()) id = "reward";
            id = id.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
            if (type == null) type = "ITEM";
            type = type.toUpperCase(java.util.Locale.ROOT);
            if (!java.util.Set.of("ITEM", "CHAIBELLS", "STANDARD_ROLLS", "CHAINA_ROLLS", "POKEMON").contains(type))
                type = "ITEM";
            if (value == null) value = "";
            amount = Math.clamp(amount, 1, 1_000_000);
            weight = Math.clamp(weight, 0, 1_000_000);
        }
    }

    public static final class BattlePassSettings {
        public boolean enabled = true;
        public int baseXpPerLevel = 500;
        public int xpGrowthPerLevel = 75;
        public int maximumXpPerLevel = 5_000;
        public int activeRewardSeconds = 900;
        public int activeRewardXp = 20;
        public int questMinimumXp = 80;
        public int questMaximumXp = 400;
        public int commonCaptureXp = 8;
        public int uncommonCaptureXp = 12;
        public int rareCaptureXp = 25;
        public int epicCaptureXp = 45;
        public int legendaryCaptureXp = 120;
        public int mythicalCaptureXp = 180;
        public int newSpeciesBonusXp = 10;
        public int captureXpEventsPerMinute = 12;
        public int evolutionXp = 20;
        public int wildBattleXp = 12;
        public int trainerBattleXp = 30;
        public int newBiomeXp = 15;
        public int jobLevelXp = 40;
        /** Legitimate work grants one pass XP per this many scaled job XP. */
        public int jobActionXpPerPassXp = 8;
        /** Prevents automated farms from flooding the pass while preserving normal play. */
        public int jobActionPassXpPerMinute = 12;
        public int freeRewardEveryLevels = 4;
        public int freeChainaRolls = 1;
        public int premiumFirstLevelChainaRolls = 10;
        public int premiumRewardEveryLevels = 4;
        public int premiumChainaRolls = 2;
        public String premiumPermission = "chainacobblemon.battlepass.premium";
        public java.util.Set<String> premiumGroups = new java.util.LinkedHashSet<>(
                java.util.List.of("vip", "moderator", "admin", "owner", "chaina",
                        "sub_chaina", "sub_chaina_plus", "sub_chaina_plus_plus", "vip_chaina", "mod_chaina"));
        public java.util.Set<String> premiumPlayerNames = new java.util.LinkedHashSet<>();

        public void normalize() {
            baseXpPerLevel = Math.clamp(baseXpPerLevel, 50, 1_000_000);
            xpGrowthPerLevel = Math.clamp(xpGrowthPerLevel, 0, 100_000);
            maximumXpPerLevel = Math.clamp(maximumXpPerLevel, baseXpPerLevel, 10_000_000);
            activeRewardSeconds = Math.clamp(activeRewardSeconds, 60, 86_400);
            activeRewardXp = bounded(activeRewardXp);
            questMinimumXp = bounded(questMinimumXp);
            questMaximumXp = Math.clamp(questMaximumXp, questMinimumXp, 1_000_000);
            commonCaptureXp = bounded(commonCaptureXp);
            uncommonCaptureXp = bounded(uncommonCaptureXp);
            rareCaptureXp = bounded(rareCaptureXp);
            epicCaptureXp = bounded(epicCaptureXp);
            legendaryCaptureXp = bounded(legendaryCaptureXp);
            mythicalCaptureXp = bounded(mythicalCaptureXp);
            newSpeciesBonusXp = bounded(newSpeciesBonusXp);
            captureXpEventsPerMinute = Math.clamp(captureXpEventsPerMinute, 1, 10_000);
            evolutionXp = bounded(evolutionXp);
            wildBattleXp = bounded(wildBattleXp);
            trainerBattleXp = bounded(trainerBattleXp);
            newBiomeXp = bounded(newBiomeXp);
            jobLevelXp = bounded(jobLevelXp);
            jobActionXpPerPassXp = Math.clamp(jobActionXpPerPassXp, 1, 1_000);
            jobActionPassXpPerMinute = Math.clamp(jobActionPassXpPerMinute, 1, 10_000);
            freeRewardEveryLevels = Math.clamp(freeRewardEveryLevels, 1, 1_000);
            freeChainaRolls = Math.clamp(freeChainaRolls, 1, 1_000);
            premiumFirstLevelChainaRolls = Math.clamp(premiumFirstLevelChainaRolls, 1, 10_000);
            premiumRewardEveryLevels = Math.clamp(premiumRewardEveryLevels, 1, 1_000);
            premiumChainaRolls = Math.clamp(premiumChainaRolls, 1, 10_000);
            if (premiumPermission == null) premiumPermission = "chainacobblemon.battlepass.premium";
            if (premiumGroups == null) premiumGroups = new java.util.LinkedHashSet<>();
            if (premiumPlayerNames == null) premiumPlayerNames = new java.util.LinkedHashSet<>();
            premiumGroups = normalizeKeys(premiumGroups);
            premiumPlayerNames = normalizeKeys(premiumPlayerNames);
        }

        private static int bounded(int value) { return Math.clamp(value, 0, 1_000_000); }

        private static java.util.Set<String> normalizeKeys(java.util.Set<String> values) {
            java.util.LinkedHashSet<String> result = new java.util.LinkedHashSet<>();
            for (String value : values) if (value != null && !value.isBlank())
                result.add(value.strip().toLowerCase(java.util.Locale.ROOT));
            return result;
        }
    }



    public static final class BalanceSettings {
        public int activeRewardSeconds = 600;
        public long activeRewardCoins = 5L;
        public double directCoinMultiplier = 1.0D;
        public double jobCoinMultiplier = 1.0D;
        public double jobXpMultiplier = 1.0D;
        public double questCoinMultiplier = 1.0D;
        public double shopPriceMultiplier = 1.0D;

        public void normalize() {
            activeRewardSeconds = Math.clamp(activeRewardSeconds, 60, 86_400);
            activeRewardCoins = Math.clamp(activeRewardCoins, 0L, 1_000_000L);
            directCoinMultiplier = clampMultiplier(directCoinMultiplier);
            jobCoinMultiplier = clampMultiplier(jobCoinMultiplier);
            jobXpMultiplier = clampMultiplier(jobXpMultiplier);
            questCoinMultiplier = clampMultiplier(questCoinMultiplier);
            shopPriceMultiplier = clampMultiplier(shopPriceMultiplier);
        }

        private static double clampMultiplier(double value) {
            if (!Double.isFinite(value)) return 1.0D;
            return Math.clamp(value, 0.0D, 100.0D);
        }

        public long scaled(long base, double multiplier) {
            if (base <= 0L || multiplier <= 0.0D) return 0L;
            double scaled = base * multiplier;
            return scaled >= Long.MAX_VALUE ? Long.MAX_VALUE : Math.max(1L, Math.round(scaled));
        }
    }

    public static final class HubSettings {
        public boolean enabled = false;
        public String world = "minecraft:overworld";
        public double x = 0.5;
        public double y = 64.0;
        public double z = 0.5;
        public float yaw = 0.0f;
        public float pitch = 0.0f;
        public RegionCorner pos1;
        public RegionCorner pos2;

        public void normalize() {
            if (world == null || world.isBlank()) {
                world = "minecraft:overworld";
            }
            if (!Double.isFinite(x)) x = 0.5;
            if (!Double.isFinite(y)) y = 64.0;
            if (!Double.isFinite(z)) z = 0.5;
            if (!Float.isFinite(yaw)) yaw = 0.0f;
            if (!Float.isFinite(pitch)) pitch = 0.0f;
        }

        public boolean hasRegion() {
            return pos1 != null && pos2 != null;
        }

        public boolean contains(String worldId, int blockX, int blockY, int blockZ) {
            if (!enabled || !hasRegion() || !world.equals(worldId)) {
                return false;
            }
            return blockX >= Math.min(pos1.x, pos2.x) && blockX <= Math.max(pos1.x, pos2.x)
                    && blockY >= Math.min(pos1.y, pos2.y) && blockY <= Math.max(pos1.y, pos2.y)
                    && blockZ >= Math.min(pos1.z, pos2.z) && blockZ <= Math.max(pos1.z, pos2.z);
        }
    }

    public static final class RegionCorner {
        public int x;
        public int y;
        public int z;

        public RegionCorner() {
        }

        public RegionCorner(int x, int y, int z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }
}
