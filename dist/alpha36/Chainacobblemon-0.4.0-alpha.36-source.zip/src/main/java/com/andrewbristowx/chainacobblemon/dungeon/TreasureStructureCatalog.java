package com.andrewbristowx.chainacobblemon.dungeon;

import net.minecraft.util.Identifier;

import java.util.Locale;
import java.util.Set;

/** Whitelist/filter for structures that make good Treasure Hunt layouts. */
public final class TreasureStructureCatalog {
    private TreasureStructureCatalog() { }

    public static boolean supportedNamespace(String namespace) {
        if (namespace == null) return false;
        return Set.of(
                "dungeons_arise",
                "betterdungeons",
                "mr_dungeons_andtaverns",
                "dungeons_and_taverns",
                "dungeonsandtaverns",
                "mvs",
                "repurposed_structures"
        ).contains(namespace.toLowerCase(Locale.ROOT));
    }

    public static boolean eligibleForTreasure(Identifier id) {
        if (id == null || !supportedNamespace(id.getNamespace())) return false;
        String ns = id.getNamespace().toLowerCase(Locale.ROOT);
        String path = id.getPath().toLowerCase(Locale.ROOT);
        if (containsAny(path, "village", "well", "tavern", "house", "farm", "camp", "statue", "cart", "pond",
                "mineshaft", "ancient_city", "stronghold", "ocean", "ship", "floating", "end_", "nether_", "spider")) return false;

        if (ns.equals("dungeons_arise")) {
            return containsAny(path, "bandit", "illager", "coliseum", "infested", "temple", "tower", "fort");
        }
        if (ns.equals("betterdungeons")) {
            return containsAny(path, "undead", "catacomb", "fortress");
        }
        if (ns.contains("dungeons") && (ns.contains("tavern") || ns.contains("andtaverns"))) {
            return containsAny(path, "hideout", "bunker", "crypt", "jungle_ruin", "witch_villa", "manor", "citadel", "fort");
        }
        if (ns.equals("mvs")) {
            return containsAny(path, "cathedral", "cartographer_tower", "jungle_tower", "red_tower", "castle_ruin", "tower", "castle", "temple");
        }
        if (ns.equals("repurposed_structures")) {
            return containsAny(path, "fortress", "pyramid", "temple", "dungeon")
                    && !containsAny(path, "nether", "end", "ocean", "mineshaft", "ancient", "stronghold");
        }
        return false;
    }

    public static int stars(Identifier id) {
        if (id == null) return 1;
        String path = id.getPath().toLowerCase(Locale.ROOT);
        if (containsAny(path, "lone_citadel", "infested_temple", "cathedral", "manor", "mega", "palace")) return 5;
        if (containsAny(path, "illager_fort", "fortress", "castle", "citadel", "coliseum", "large")) return 4;
        if (containsAny(path, "temple", "tower", "crypt", "hideout", "bunker", "catacomb")) return 3;
        if (containsAny(path, "ruin", "dungeon", "villa")) return 2;
        return 1;
    }

    public static String ballItemForStars(int stars) {
        return switch (Math.max(1, Math.min(5, stars))) {
            case 1 -> "cobblemon:poke_ball";
            case 2 -> "cobblemon:great_ball";
            case 3 -> "cobblemon:ultra_ball";
            case 4 -> "cobblemon:luxury_ball";
            default -> "cobblemon:master_ball";
        };
    }

    public static String tierIdForStars(int stars) {
        return switch (Math.max(1, Math.min(5, stars))) {
            case 1 -> "common";
            case 2 -> "rare";
            case 3 -> "treasure";
            default -> "epic";
        };
    }

    public static int trainerCount(int stars) {
        return switch (Math.max(1, Math.min(5, stars))) {
            case 1 -> 2;
            case 2 -> 3;
            case 3 -> 4;
            case 4 -> 5;
            default -> 6;
        };
    }

    public static String starLabel(int stars) {
        return "★".repeat(Math.max(1, Math.min(5, stars)));
    }

    private static boolean containsAny(String value, String... tokens) {
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }
}
