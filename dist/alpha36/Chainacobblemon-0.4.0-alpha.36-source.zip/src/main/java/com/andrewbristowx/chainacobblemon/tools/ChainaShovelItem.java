package com.andrewbristowx.chainacobblemon.tools;

import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;


public final class ChainaShovelItem extends ShovelItem {
    public ChainaShovelItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }

    @Override
    public boolean postMine(ItemStack stack, World world, BlockState state, BlockPos pos, LivingEntity miner) {
        boolean result = super.postMine(stack, world, state, pos, miner);
        if (!ChainaToolActions.expanding() && world instanceof ServerWorld serverWorld
                && miner instanceof ServerPlayerEntity player && state.isIn(BlockTags.SHOVEL_MINEABLE)) {
            ChainaToolActions.minePlane(serverWorld, player, pos, BlockTags.SHOVEL_MINEABLE, this);
        }
        return result;
    }
}
