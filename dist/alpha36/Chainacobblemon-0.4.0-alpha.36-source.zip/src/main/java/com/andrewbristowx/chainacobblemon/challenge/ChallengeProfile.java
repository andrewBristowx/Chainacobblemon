package com.andrewbristowx.chainacobblemon.challenge;

import java.util.List;

public record ChallengeProfile(
        String regionId,
        String regionName,
        String leaderId,
        String displayName,
        String typeName,
        String badgeName,
        int order,
        String prerequisiteKey,
        boolean slimModel,
        List<String> team,
        List<String> introPages,
        List<String> victoryPages,
        List<String> rematchPages
) {
    public ChallengeProfile {
        team = List.copyOf(team == null ? List.of() : team);
        introPages = List.copyOf(introPages == null ? List.of() : introPages);
        victoryPages = List.copyOf(victoryPages == null ? List.of() : victoryPages);
        rematchPages = List.copyOf(rematchPages == null ? List.of() : rematchPages);
    }

    public String key() {
        return regionId + ":" + leaderId;
    }

    public String npcId() {
        return "challenge_" + regionId + "_" + leaderId;
    }

    public boolean isEliteFour() {
        return leaderId.startsWith("elite_");
    }

    public boolean isChampion() {
        return leaderId.startsWith("champion_");
    }

    public boolean isLeader() {
        return !isEliteFour() && !isChampion();
    }

    public String roleName() {
        if (isChampion()) return "Campeón";
        if (isEliteFour()) return "Alto Mando";
        return "Líder";
    }

    public String subtitle() {
        return roleName() + " de " + regionName + (typeName == null || typeName.isBlank() ? "" : " · Tipo " + typeName);
    }
}
