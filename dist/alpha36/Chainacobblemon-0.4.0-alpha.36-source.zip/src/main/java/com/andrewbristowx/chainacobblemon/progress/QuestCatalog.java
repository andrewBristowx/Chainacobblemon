package com.andrewbristowx.chainacobblemon.progress;

import java.util.List;

public final class QuestCatalog {
    private static final List<QuestDefinition> QUESTS = List.of(
            tutorial("mc_move", "M1", "Primeros pasos", "Aprende a moverte",
                    "Camina, salta y mira alrededor. No tengas prisa: el mundo puede explorarse a tu ritmo.",
                    "minecraft:move", 20, 40, 50, item("minecraft:bread", 8)),
            tutorial("mc_log", "M1", "Primeros pasos", "Consigue madera",
                    "Rompe cuatro troncos con la mano o con un hacha.",
                    "minecraft:log", 4, 60, 60, item("minecraft:torch", 8)),
            tutorial("mc_crafting_table", "M1", "Primeros pasos", "Fabrica una mesa de trabajo",
                    "Convierte troncos en tablones y usa cuatro tablones para crear una mesa de trabajo.",
                    "minecraft:craft:crafting_table", 1, 80, 70, item("minecraft:torch", 12)),
            tutorial("mc_pickaxe", "M1", "Primeros pasos", "Tu primer pico",
                    "Fabrica cualquier pico. Te permitirá obtener piedra y minerales.",
                    "minecraft:craft:pickaxe", 1, 100, 80, item("minecraft:coal", 8)),
            tutorial("mc_stone", "M2", "Un hogar seguro", "Recolecta piedra",
                    "Rompe dieciséis bloques de piedra o adoquín con un pico.",
                    "minecraft:stone", 16, 100, 90, item("cobblemon:potion", 3)),
            tutorial("mc_shelter", "M2", "Un hogar seguro", "Construye un refugio",
                    "Coloca veinte bloques para comenzar una casa donde pasar la noche.",
                    "minecraft:place", 20, 120, 100, item("minecraft:torch", 16)),
            tutorial("mc_furnace", "M2", "Un hogar seguro", "Fabrica un horno",
                    "Usa ocho bloques de adoquín para fabricar un horno.",
                    "minecraft:craft:furnace", 1, 150, 110, item("minecraft:iron_ingot", 3)),
            tutorial("mc_iron", "M3", "Minería y descanso", "Encuentra hierro",
                    "Rompe tres minerales de hierro; podrás fundirlos en tu horno.",
                    "minecraft:iron", 3, 180, 130, item("cobblemon:poke_ball", 5)),
            tutorial("mc_bed", "M3", "Minería y descanso", "Prepara una cama",
                    "Fabrica cualquier cama para poder saltarte la noche y fijar tu punto de aparición.",
                    "minecraft:craft:bed", 1, 180, 130, item("minecraft:golden_apple", 1)),
            tutorial("mc_diamond", "M4", "Nuevos horizontes", "Tu primer diamante",
                    "Explora las profundidades y rompe un mineral de diamante.",
                    "minecraft:diamond", 1, 300, 180, item("chainacobblemon:gacha_ticket", 1)),
            tutorial("mc_nether", "M4", "Nuevos horizontes", "Visita el Nether",
                    "Construye y enciende un portal, luego entra al Nether por primera vez.",
                    "minecraft:dimension:the_nether", 1, 500, 250, item("cobblemon:rare_candy", 2)),

            quest("starter", "1", "Tu aventura comienza", "Tu primera compañera",
                    "Elige a tu Pokémon inicial para comenzar tu aventura.", "starter", 1, 100,
                    item("cobblemon:poke_ball", 5)),
            quest("heal_team", "1", "Tu aventura comienza", "Una visita al Centro Pokémon",
                    "Cura a tu equipo por primera vez.", "heal", 1, 40,
                    item("cobblemon:potion", 3)),
            quest("craft_balls", "1", "Tu aventura comienza", "Tus primeras Poké Balls",
                    "Fabrica cinco Poké Balls en una mesa de crafteo.", "craft_pokeball", 5, 80),
            quest("first_capture", "1", "Tu aventura comienza", "Una nueva amistad",
                    "Captura tu primer Pokémon salvaje.", "capture", 1, 60),
            quest("first_victory", "1", "Tu aventura comienza", "Tu primera victoria",
                    "Gana un combate contra un Pokémon salvaje.", "wild_victory", 1, 60),
            quest("team_three", "1", "Tu aventura comienza", "Un pequeño equipo",
                    "Consigue tres Pokémon.", "owned_pokemon", 3, 80),
            quest("first_evolution", "1", "Tu aventura comienza", "Crecer juntos",
                    "Evoluciona un Pokémon por primera vez.", "evolution", 1, 120),

            quest("five_species", "2", "Camino de entrenador", "Conoce nuevas especies",
                    "Registra cinco especies diferentes.", "species", 5, 120),
            quest("level_fifteen", "2", "Camino de entrenador", "Cada vez más fuertes",
                    "Ten un Pokémon de nivel 15 o superior.", "pokemon_level", 15, 120),
            quest("three_wins", "2", "Camino de entrenador", "Racha de victorias",
                    "Gana tres combates Pokémon consecutivos.", "win_streak", 3, 150),
            quest("full_team", "2", "Camino de entrenador", "Equipo completo",
                    "Consigue un equipo de seis Pokémon.", "owned_pokemon", 6, 180),
            quest("explore_five", "2", "Camino de entrenador", "Conoce el mundo",
                    "Descubre cinco biomas diferentes.", "biomes", 5, 140),
            quest("job_level_three", "2", "Camino de entrenador", "Encuentra tu vocación",
                    "Alcanza nivel 3 en cualquier trabajo.", "job_level", 3, 180),

            leader("kanto", "brock", "Brock", "3K", 250),
            leader("kanto", "misty", "Misty", "3K", 275),
            leader("kanto", "lt_surge", "Lt. Surge", "3K", 300),
            leader("kanto", "erika", "Erika", "3K", 325),
            leader("kanto", "koga", "Koga", "3K", 350),
            leader("kanto", "sabrina", "Sabrina", "3K", 375),
            leader("kanto", "blaine", "Blaine", "3K", 400),
            leader("kanto", "giovanni", "Giovanni", "3K", 500),
            league("kanto", "elite_lorelei", "Lorelei", "3K-L", 600),
            league("kanto", "elite_bruno", "Bruno", "3K-L", 650),
            league("kanto", "elite_agatha", "Agatha", "3K-L", 700),
            league("kanto", "elite_lance", "Lance", "3K-L", 750),
            league("kanto", "champion_blue", "Blue", "3K-L", 1_000),

            leader("johto", "falkner", "Falkner", "3J", 525),
            leader("johto", "bugsy", "Bugsy", "3J", 550),
            leader("johto", "whitney", "Whitney", "3J", 575),
            leader("johto", "morty", "Morty", "3J", 600),
            leader("johto", "chuck", "Chuck", "3J", 625),
            leader("johto", "jasmine", "Jasmine", "3J", 650),
            leader("johto", "pryce", "Pryce", "3J", 675),
            leader("johto", "clair", "Clair", "3J", 750),
            league("johto", "elite_will", "Will", "3J-L", 800),
            league("johto", "elite_koga", "Koga", "3J-L", 825),
            league("johto", "elite_bruno", "Bruno", "3J-L", 850),
            league("johto", "elite_karen", "Karen", "3J-L", 900),
            league("johto", "champion_lance", "Lance", "3J-L", 1_100),

            leader("hoenn", "roxanne", "Roxanne", "3H", 775),
            leader("hoenn", "brawly", "Brawly", "3H", 800),
            leader("hoenn", "wattson", "Wattson", "3H", 825),
            leader("hoenn", "flannery", "Flannery", "3H", 850),
            leader("hoenn", "norman", "Norman", "3H", 875),
            leader("hoenn", "winona", "Winona", "3H", 900),
            leader("hoenn", "tate_liza", "Tate & Liza", "3H", 925),
            leader("hoenn", "juan", "Juan", "3H", 1_000),
            league("hoenn", "elite_sidney", "Sidney", "3H-L", 1_050),
            league("hoenn", "elite_phoebe", "Phoebe", "3H-L", 1_075),
            league("hoenn", "elite_glacia", "Glacia", "3H-L", 1_100),
            league("hoenn", "elite_drake", "Drake", "3H-L", 1_150),
            league("hoenn", "champion_steven", "Steven", "3H-L", 1_350),

            leader("sinnoh", "roark", "Roark", "3S", 1_025),
            leader("sinnoh", "gardenia", "Gardenia", "3S", 1_050),
            leader("sinnoh", "maylene", "Maylene", "3S", 1_075),
            leader("sinnoh", "crasher_wake", "Crasher Wake", "3S", 1_100),
            leader("sinnoh", "fantina", "Fantina", "3S", 1_125),
            leader("sinnoh", "byron", "Byron", "3S", 1_150),
            leader("sinnoh", "candice", "Candice", "3S", 1_175),
            leader("sinnoh", "volkner", "Volkner", "3S", 1_300),
            league("sinnoh", "elite_aaron", "Aaron", "3S-L", 1_350),
            league("sinnoh", "elite_bertha", "Bertha", "3S-L", 1_400),
            league("sinnoh", "elite_flint", "Flint", "3S-L", 1_450),
            league("sinnoh", "elite_lucian", "Lucian", "3S-L", 1_500),
            league("sinnoh", "champion_cynthia", "Cynthia", "3S-L", 1_800),

            adventureQuest("rocket_base", "AK", "Kanto · Estructuras", "La torre del Equipo Rocket",
                    "Encuentra y entra en la Torre/Base del Equipo Rocket de Cobbleverse.",
                    "structure_match:rocket,tower", 1, 500),
            adventureQuest("rocket_giovanni", "AK", "Kanto · Estructuras", "Cortar la cabeza de la serpiente",
                    "Derrota al Giovanni del Equipo Rocket durante la exploración regional.",
                    "advancement:chainacobblemon:integration/defeat_team_rocket_giovanni", 1, 750,
                    item("chainacobblemon:gacha_ticket", 1)),

            adventureQuest("kanto_league_arrival", "AK", "Kanto · Estructuras", "Liga Pokémon de Kanto",
                    "Encuentra y entra en la Liga Pokémon de Kanto durante tu exploración de Cobbleverse.",
                    "structure_match:kanto,league", 1, 450),
            adventureStructure("pokemon_mansion", "AK", "Kanto · Estructuras", "Mansión Pokémon", 400, "pokemon", "mansion"),
            adventureStructure("mew_shrine", "AK", "Kanto · Estructuras", "Santuario de Mew", 500, "mew", "shrine"),
            adventureStructure("resurrection_machine", "AK", "Kanto · Estructuras", "Máquina de Resurrección", 550, "resurrection"),

            adventureStructure("burned_tower", "AJ", "Johto · Estructuras", "Torre Quemada", 425, "burn", "tower"),
            adventureStructure("bell_tower", "AJ", "Johto · Estructuras", "Torre Campana", 450, "bell", "tower"),
            adventureStructure("whirl_island", "AJ", "Johto · Estructuras", "Islas Remolino", 450, "whirl", "island"),
            adventureStructure("ilex_shrine", "AJ", "Johto · Estructuras", "Santuario de Ilex/Celebi", 500, "shrine", "celebi"),
            // Keep the alpha.3 quest id for saved progress, but point it at Cobbleverse's actual Radio Tower concept.
            adventureStructure("johto_rocket_base", "AJ", "Johto · Estructuras", "Torre Radio del Team Rocket", 525, "radio", "tower"),
            adventureStructure("johto_league", "AJ", "Johto · Estructuras", "Liga Pokémon de Johto", 500, "johto", "league"),

            adventureStructure("team_magma_base", "AH", "Hoenn · Estructuras", "Base del Team Magma", 475, "magma", "base"),
            adventureStructure("team_aqua_base", "AH", "Hoenn · Estructuras", "Base del Team Aqua", 475, "aqua", "base"),
            adventureStructure("sky_pillar", "AH", "Hoenn · Estructuras", "Pilar Celeste", 525, "sky", "pillar"),
            adventureStructure("regi_temple", "AH", "Hoenn · Estructuras", "Templos Regi", 450, "regi"),
            adventureStructure("submerged_temple", "AH", "Hoenn · Estructuras", "Templo Sumergido de Kyogre", 525, "submerged", "temple"),
            adventureStructure("volcanic_island", "AH", "Hoenn · Estructuras", "Isla/Volcán de Groudon", 525, "groudon"),
            adventureStructure("secret_garden", "AH", "Hoenn · Estructuras", "Jardín Secreto", 450, "secret", "garden"),
            adventureStructure("wish_cave", "AH", "Hoenn · Estructuras", "Cueva de los Deseos", 500, "wish", "cave"),
            adventureStructure("deoxys_shrine", "AH", "Hoenn · Estructuras", "Santuario/Isla de Deoxys", 550, "deoxys"),
            adventureStructure("hoenn_league", "AH", "Hoenn · Estructuras", "Liga Pokémon de Hoenn", 550, "hoenn", "league"),

            adventureStructure("sinnoh_wind_plant", "AS", "Sinnoh · Team Galactic", "Central Eólica / Wind Plant", 500, "wind", "plant"),
            adventureStructure("sinnoh_eterna_building", "AS", "Sinnoh · Team Galactic", "Edificio de Eterna", 525, "eterna"),
            adventureStructure("sinnoh_galactic_hq", "AS", "Sinnoh · Team Galactic", "Cuartel General del Team Galactic", 600, "galactic", "hq"),
            adventureStructure("spear_pillar", "AS", "Sinnoh · Team Galactic", "Columna Lanza", 650, "spear", "pillar"),
            adventureStructure("lake_valor", "AS", "Sinnoh · Lagos y leyendas", "Lago Valor", 450, "valor", "lake"),
            adventureStructure("lake_acuity", "AS", "Sinnoh · Lagos y leyendas", "Lago Agudeza", 450, "acuity", "lake"),
            adventureStructure("lake_verity", "AS", "Sinnoh · Lagos y leyendas", "Lago Veraz", 450, "verity", "lake"),
            adventureStructure("stark_forge", "AS", "Sinnoh · Lagos y leyendas", "Forja Stark", 500, "stark"),
            adventureStructure("snowpoint_temple", "AS", "Sinnoh · Lagos y leyendas", "Templo Puntaneva", 500, "snowpoint", "temple"),
            adventureStructure("split_decision_temple", "AS", "Sinnoh · Lagos y leyendas", "Templo de la Decisión", 525, "decision", "temple"),
            adventureStructure("full_moon", "AS", "Sinnoh · Lagos y leyendas", "Altar de Luna Llena", 500, "full", "moon"),
            adventureStructure("new_moon", "AS", "Sinnoh · Lagos y leyendas", "Altar de Luna Nueva", 500, "new", "moon"),
            adventureStructure("flower_paradise", "AS", "Sinnoh · Lagos y leyendas", "Paraíso Floral", 500, "flower", "paradise"),
            adventureStructure("sinnoh_temple", "AS", "Sinnoh · Lagos y leyendas", "Templo Original de Sinnoh", 600, "original", "sinnoh"),
            adventureStructure("sinnoh_league", "AS", "Sinnoh · Liga", "Liga Pokémon de Sinnoh", 600, "sinnoh", "league"),


            altar("articuno", "Articuno", 500),
            captureLegendary("articuno", "Articuno", 900),
            altar("zapdos", "Zapdos", 500),
            captureLegendary("zapdos", "Zapdos", 900),
            altar("moltres", "Moltres", 500),
            adventureQuest("capture_altar_moltres", "7", "Altares legendarios", "Captura a Moltres",
                    "Después de invocarlo, captura un Moltres.",
                    "capture_species:cobblemon:moltres", 1, 900,
                    item("chainacobblemon:gacha_ticket", 1))
    );

    private QuestCatalog() {
    }

    public static List<QuestDefinition> all() {
        return QUESTS;
    }

    private static QuestDefinition quest(String id, String chapter, String chapterTitle, String title,
                                         String description, String type, long target, long coins,
                                         QuestDefinition.RewardItem... items) {
        return new QuestDefinition(id, QuestDefinition.PROGRESSION, chapter, chapterTitle, title,
                description, type, target, coins, passXp(target, coins), List.of(items));
    }

    private static QuestDefinition adventureQuest(String id, String chapter, String chapterTitle, String title,
                                                   String description, String type, long target, long coins,
                                                   QuestDefinition.RewardItem... items) {
        return new QuestDefinition(id, QuestDefinition.ADVENTURE, chapter, chapterTitle, title,
                description, type, target, coins, passXp(target, coins), List.of(items));
    }

    private static QuestDefinition tutorial(String id, String chapter, String chapterTitle, String title,
                                            String description, String type, long target, long coins, long passXp,
                                            QuestDefinition.RewardItem... items) {
        return new QuestDefinition(id, QuestDefinition.TUTORIAL, chapter, chapterTitle, title,
                description, type, target, coins, passXp, List.of(items));
    }

    private static long passXp(long target, long coins) {
        return Math.clamp(70L + Math.min(180L, Math.max(1L, target) * 8L) + Math.min(150L, coins / 8L), 80L, 400L);
    }

    private static QuestDefinition leader(String region, String id, String name, String chapter, long coins) {
        String questId = "kanto".equals(region) ? "defeat_" + id : "defeat_" + region + "_" + id;
        String regionName = switch (region) {
            case "johto" -> "Johto";
            case "hoenn" -> "Hoenn";
            case "sinnoh" -> "Sinnoh";
            default -> "Kanto";
        };
        return quest(questId, chapter, "Gimnasios de " + regionName, "Desafía a " + name,
                "Habla con " + name + " en la Zona de Desafíos o derrótalo durante tu exploración de Cobbleverse.",
                "regional_trainer:" + region + ":" + id, 1, coins);
    }

    private static QuestDefinition league(String region, String id, String name, String chapter, long coins) {
        String regionName = switch (region) {
            case "johto" -> "Johto";
            case "hoenn" -> "Hoenn";
            case "sinnoh" -> "Sinnoh";
            default -> "Kanto";
        };
        boolean champion = id.startsWith("champion_");
        String title = champion ? "Campeón: " + name : "Alto Mando: " + name;
        String questId = "kanto".equals(region) ? (champion ? "champion_blue" : id) : "defeat_" + region + "_" + id;
        return quest(questId, chapter, "Liga de " + regionName, title,
                "Habla con " + name + " en la Zona de Desafíos o derrótalo en la Liga natural de Cobbleverse.",
                "regional_trainer:" + region + ":" + id, 1, coins);
    }

    private static QuestDefinition adventureStructure(String id, String chapter, String chapterTitle,
                                                       String name, long coins, String... tokens) {
        return adventureQuest("visit_" + id, chapter, chapterTitle, "Explora " + name,
                "Encuentra y entra en " + name + " durante tu exploración de Cobbleverse.",
                "structure_match:" + String.join(",", tokens), 1, coins);
    }

    private static QuestDefinition structure(String id, String name, long coins) {
        return adventureQuest("visit_" + id, "6", "Estructuras especiales", "Explora " + name,
                "Entra en la estructura oficial de " + name + ".",
                "structure:cobbleverse:" + id, 1, coins);
    }

    private static QuestDefinition altar(String species, String name, long coins) {
        return adventureQuest("invoke_" + species, "7", "Altares legendarios", "Invoca a " + name,
                "Activa correctamente el altar de " + name + ".",
                "altar:lumymon:" + species + "_altar", 1, coins);
    }

    private static QuestDefinition captureLegendary(String species, String name, long coins) {
        return adventureQuest("capture_altar_" + species, "7", "Altares legendarios", "Captura a " + name,
                "Después de invocarlo, captura un " + name + ".",
                "capture_species:cobblemon:" + species, 1, coins);
    }

    private static QuestDefinition.RewardItem item(String id, int count) {
        return new QuestDefinition.RewardItem(id, count);
    }

}
