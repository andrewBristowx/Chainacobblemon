package com.andrewbristowx.chainacobblemon.registry;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.armor.ChainaArmorMaterial;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineBlock;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineBlockEntity;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineTopBlock;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.hologram.HologramEntity;
import com.andrewbristowx.chainacobblemon.visual.MediaDisplayEntity;
import com.andrewbristowx.chainacobblemon.tools.ChainaAxeItem;
import com.andrewbristowx.chainacobblemon.tools.ChainaHoeItem;
import com.andrewbristowx.chainacobblemon.tools.ChainaPickaxeItem;
import com.andrewbristowx.chainacobblemon.tools.ChainaShovelItem;
import com.andrewbristowx.chainacobblemon.tools.ChainaSwordItem;
import com.andrewbristowx.chainacobblemon.tools.ChainaToolMaterial;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.sound.SoundEvent;

public final class ModRegistries {

    public static final SoundEvent BADGE_RUSH = Registry.register(
            Registries.SOUND_EVENT, id("badge_rush"), SoundEvent.of(id("badge_rush")));
    public static final EntityType<ServiceNpcEntity> NURSE_NPC = registerNpc("nurse_npc");
    public static final EntityType<ServiceNpcEntity> SHOP_NPC = registerNpc("shop_npc");
    public static final EntityType<ServiceNpcEntity> CUSTOM_NPC = registerNpc("custom_npc");
    public static final EntityType<ServiceNpcEntity> CUSTOM_SLIM_NPC = registerNpc("custom_slim_npc");
    public static final EntityType<MediaDisplayEntity> MEDIA_DISPLAY = Registry.register(
            Registries.ENTITY_TYPE, id("media_display"),
            EntityType.Builder.<MediaDisplayEntity>create(MediaDisplayEntity::new, SpawnGroup.MISC)
                    .dimensions(0.1f, 0.1f)
                    .maxTrackingRange(32)
                    .trackingTickInterval(20)
                    .build(Chainacobblemon.MOD_ID + ":media_display"));
    public static final EntityType<HologramEntity> HOLOGRAM = Registry.register(
            Registries.ENTITY_TYPE, id("hologram"),
            EntityType.Builder.<HologramEntity>create(HologramEntity::new, SpawnGroup.MISC)
                    .dimensions(0.1F, 0.1F)
                    .maxTrackingRange(48)
                    .trackingTickInterval(10)
                    .build(Chainacobblemon.MOD_ID + ":hologram"));

    public static final Item GACHA_TICKET = registerItem(
            "gacha_ticket",
            new Item(new Item.Settings().maxCount(64))
    );

    public static final Item CHAINA_SPECIAL_BANNER_TICKET = registerItem(
            "chaina_special_banner_ticket",
            new Item(new Item.Settings().maxCount(64))
    );

    public static final Item TREASURE_GACHA_TICKET = registerItem(
            "treasure_gacha_ticket",
            new Item(new Item.Settings().maxCount(64))
    );
    /** Display-only symbols used by reward screens; the real ChaiBell balance stays server authoritative. */
    public static final Item CHAIBELL_ICON = registerItem("chaibell_icon", new Item(new Item.Settings().maxCount(1)));
    public static final Item RANDOM_POKEMON_ICON = registerItem("random_pokemon_icon", new Item(new Item.Settings().maxCount(1)));

    public static final Item CHAINA_SWORD = registerItem("chaina_sword", new ChainaSwordItem(
            ChainaToolMaterial.INSTANCE,
            new Item.Settings().attributeModifiers(
                    SwordItem.createAttributeModifiers(ChainaToolMaterial.INSTANCE, 3, -2.1F))));
    public static final Item CHAINA_PICKAXE = registerItem("chaina_pickaxe", new ChainaPickaxeItem(
            ChainaToolMaterial.INSTANCE,
            new Item.Settings().attributeModifiers(
                    MiningToolItem.createAttributeModifiers(ChainaToolMaterial.INSTANCE, 1.5F, -2.65F))));
    public static final Item CHAINA_AXE = registerItem("chaina_axe", new ChainaAxeItem(
            ChainaToolMaterial.INSTANCE,
            new Item.Settings().attributeModifiers(
                    MiningToolItem.createAttributeModifiers(ChainaToolMaterial.INSTANCE, 5.0F, -2.7F))));
    public static final Item CHAINA_SHOVEL = registerItem("chaina_shovel", new ChainaShovelItem(
            ChainaToolMaterial.INSTANCE,
            new Item.Settings().attributeModifiers(
                    MiningToolItem.createAttributeModifiers(ChainaToolMaterial.INSTANCE, 2.0F, -2.8F))));
    public static final Item CHAINA_HOE = registerItem("chaina_hoe", new ChainaHoeItem(
            ChainaToolMaterial.INSTANCE,
            new Item.Settings().attributeModifiers(
                    MiningToolItem.createAttributeModifiers(ChainaToolMaterial.INSTANCE, -3.5F, -1.5F))));

    public static final Item CHAINA_HELMET = registerItem("chaina_helmet", new ArmorItem(
            ChainaArmorMaterial.INSTANCE, ArmorItem.Type.HELMET,
            new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(ChainaArmorMaterial.DURABILITY_MULTIPLIER)).component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)).fireproof()));
    public static final Item CHAINA_CHESTPLATE = registerItem("chaina_chestplate", new ArmorItem(
            ChainaArmorMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE,
            new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(ChainaArmorMaterial.DURABILITY_MULTIPLIER)).component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)).fireproof()));
    public static final Item CHAINA_LEGGINGS = registerItem("chaina_leggings", new ArmorItem(
            ChainaArmorMaterial.INSTANCE, ArmorItem.Type.LEGGINGS,
            new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(ChainaArmorMaterial.DURABILITY_MULTIPLIER)).component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)).fireproof()));
    public static final Item CHAINA_BOOTS = registerItem("chaina_boots", new ArmorItem(
            ChainaArmorMaterial.INSTANCE, ArmorItem.Type.BOOTS,
            new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(ChainaArmorMaterial.DURABILITY_MULTIPLIER)).component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)).fireproof()));

    public static final GachaMachineBlock STANDARD_GACHA_MACHINE = registerBlockWithItem(
            "standard_gacha_machine",
            new GachaMachineBlock(AbstractBlock.Settings.create()
                    .strength(3.5f)
                    .luminance(state -> 5)
                    .nonOpaque())
    );

    public static final GachaMachineBlock CHAINA_GACHA_MACHINE = registerBlockWithItem(
            "chaina_gacha_machine",
            new GachaMachineBlock(AbstractBlock.Settings.create()
                    .strength(3.5f)
                    .luminance(state -> 7)
                    .nonOpaque())
    );

    public static final GachaMachineBlock TREASURE_GACHA_MACHINE = registerBlockWithItem(
            "treasure_gacha_machine",
            new GachaMachineBlock(AbstractBlock.Settings.create()
                    .strength(3.5f)
                    .luminance(state -> 8)
                    .nonOpaque())
    );

    public static final GachaMachineTopBlock GACHA_MACHINE_TOP = registerBlock(
            "gacha_machine_top",
            new GachaMachineTopBlock(AbstractBlock.Settings.create()
                    .strength(3.5f)
                    .nonOpaque())
    );

    public static final BlockEntityType<GachaMachineBlockEntity> GACHA_MACHINE_BLOCK_ENTITY = Registry.register(
            Registries.BLOCK_ENTITY_TYPE,
            id("standard_gacha_machine"),
            FabricBlockEntityTypeBuilder.create(
                    GachaMachineBlockEntity::new,
                    STANDARD_GACHA_MACHINE,
                    CHAINA_GACHA_MACHINE,
                    TREASURE_GACHA_MACHINE
            ).build()
    );

    private ModRegistries() {
    }

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(NURSE_NPC, ServiceNpcEntity.createMobAttributes());
        FabricDefaultAttributeRegistry.register(SHOP_NPC, ServiceNpcEntity.createMobAttributes());
        FabricDefaultAttributeRegistry.register(CUSTOM_NPC, ServiceNpcEntity.createMobAttributes());
        FabricDefaultAttributeRegistry.register(CUSTOM_SLIM_NPC, ServiceNpcEntity.createMobAttributes());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(STANDARD_GACHA_MACHINE);
            entries.add(CHAINA_GACHA_MACHINE);
            entries.add(TREASURE_GACHA_MACHINE);
            entries.add(GACHA_TICKET);
            entries.add(CHAINA_SPECIAL_BANNER_TICKET);
            entries.add(TREASURE_GACHA_TICKET);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(CHAINA_PICKAXE);
            entries.add(CHAINA_AXE);
            entries.add(CHAINA_SHOVEL);
            entries.add(CHAINA_HOE);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(CHAINA_SWORD);
            entries.add(CHAINA_HELMET);
            entries.add(CHAINA_CHESTPLATE);
            entries.add(CHAINA_LEGGINGS);
            entries.add(CHAINA_BOOTS);
        });
        Chainacobblemon.LOGGER.info("Chainacobblemon registries initialized: gasha, herramientas/armadura Chaina, NPCs, displays y hologramas");
    }

    private static Identifier id(String path) {
        return Identifier.of(Chainacobblemon.MOD_ID, path);
    }

    private static Item registerItem(String path, Item item) {
        return Registry.register(Registries.ITEM, id(path), item);
    }

    private static <T extends Block> T registerBlock(String path, T block) {
        return Registry.register(Registries.BLOCK, id(path), block);
    }

    private static <T extends Block> T registerBlockWithItem(String path, T block) {
        registerBlock(path, block);
        Registry.register(Registries.ITEM, id(path), new BlockItem(block, new Item.Settings()));
        return block;
    }

private static EntityType<ServiceNpcEntity> registerNpc(String path) {
        return Registry.register(Registries.ENTITY_TYPE, id(path),
                EntityType.Builder.create(ServiceNpcEntity::new, SpawnGroup.MISC)
                        .dimensions(0.6f, 1.8f)
                        .eyeHeight(1.62f)
                        .maxTrackingRange(10)
                        .trackingTickInterval(2)
                        .build(Chainacobblemon.MOD_ID + ":" + path));
    }
}
