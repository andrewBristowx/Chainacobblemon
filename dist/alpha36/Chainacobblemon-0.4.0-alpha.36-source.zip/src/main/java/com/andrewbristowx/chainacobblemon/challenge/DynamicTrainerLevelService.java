package com.andrewbristowx.chainacobblemon.challenge;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Scales Chainacobblemon's persistent regional challenge teams upward to the current player instead of
 * forcing the player into a lower regional level curve. It never lowers the authored team and never
 * exceeds the player's current RCT level cap when that cap is available.
 */
public final class DynamicTrainerLevelService {
    private static final Pattern LEVEL = Pattern.compile("(?i)\\blevel=(\\d+)");

    private DynamicTrainerLevelService() {}

    public record ScalingResult(List<String> team, int authoredMax, int targetMax, boolean scaled) {}

    public static ScalingResult scale(ServerPlayerEntity player, ChallengeProfile profile) {
        if (profile == null) return new ScalingResult(List.of(), 0, 0, false);
        List<String> source = profile.team();
        int authoredMax = maxLevel(source);
        if (player == null || authoredMax <= 0) return new ScalingResult(source, authoredMax, authoredMax, false);

        RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
        int highest = cap.highestPartyLevel();
        if (highest <= authoredMax) return new ScalingResult(source, authoredMax, authoredMax, false);

        int roleBonus = profile.isChampion() ? 2 : profile.isEliteFour() ? 1 : 0;
        int target = Math.min(100, highest + roleBonus);
        if (cap.available() && cap.cap() > 0) target = Math.min(target, cap.cap());
        target = Math.max(authoredMax, target);
        if (target <= authoredMax) return new ScalingResult(source, authoredMax, authoredMax, false);

        int delta = target - authoredMax;
        List<String> scaled = new ArrayList<>(source.size());
        for (String spec : source) scaled.add(shiftLevel(spec, delta, target));
        return new ScalingResult(List.copyOf(scaled), authoredMax, target, true);
    }

    public static int targetLevel(ServerPlayerEntity player, ChallengeProfile profile) {
        return scale(player, profile).targetMax();
    }

    private static int maxLevel(List<String> team) {
        int max = 0;
        for (String spec : team) {
            Matcher matcher = LEVEL.matcher(spec == null ? "" : spec);
            if (matcher.find()) max = Math.max(max, Integer.parseInt(matcher.group(1)));
        }
        return max;
    }

    private static String shiftLevel(String spec, int delta, int targetMax) {
        if (spec == null) return "";
        Matcher matcher = LEVEL.matcher(spec);
        if (!matcher.find()) return spec;
        int original = Integer.parseInt(matcher.group(1));
        int scaled = Math.min(targetMax, Math.min(100, original + delta));
        return matcher.replaceFirst("level=" + scaled);
    }
}
