package com.andrewbristowx.chainacobblemon.mixin;

import com.andrewbristowx.chainacobblemon.npc.RctWorldTrainerService;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Captures Radical's automatic/forced TrainerMob battle start so Chaina can show its dialogue first. */
@Pseudo
@Mixin(targets = "com.gitlab.srcmc.rctmod.world.entities.TrainerMob", remap = false)
abstract class RctTrainerMobMixin {
    @Inject(method = "startBattleWith", at = @At("HEAD"), cancellable = true, remap = false)
    private void chainacobblemon$dialogueBeforeNativeBattle(@Coerce Object player, CallbackInfo callback) {
        if (player instanceof ServerPlayerEntity serverPlayer
                && RctWorldTrainerService.interceptStart(this, serverPlayer)) {
            callback.cancel();
        }
    }
}
