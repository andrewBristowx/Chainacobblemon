package com.andrewbristowx.chainacobblemon.tools;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;


import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ChainaHoeItem extends HoeItem {
    private static final long WINDOW_MILLIS = 5L * 60L * 1_000L;
    private static final int MAX_MINERALS_PER_WINDOW = 4;
    private static final Map<UUID, RewardWindow> REWARD_WINDOWS = new HashMap<>();

    public ChainaHoeItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        BlockState before = context.getWorld().getBlockState(context.getBlockPos());
        ActionResult result = super.useOnBlock(context);
        if (!(context.getWorld() instanceof ServerWorld world)
                || !(context.getPlayer() instanceof ServerPlayerEntity player)
                || !result.isAccepted()) return result;
        BlockState after = world.getBlockState(context.getBlockPos());
        if (!before.isOf(Blocks.FARMLAND) && after.isOf(Blocks.FARMLAND)
                && world.getRandom().nextFloat() < 0.16F && consumeRewardSlot(player.getUuid())) {
            ItemStack reward = new ItemStack(randomMineral(world));
            if (!player.giveItemStack(reward)) player.dropItem(reward, false);
            world.spawnParticles(ParticleTypes.HAPPY_VILLAGER,
                    context.getBlockPos().getX() + 0.5, context.getBlockPos().getY() + 1.05,
                    context.getBlockPos().getZ() + 0.5, 7, 0.25, 0.12, 0.25, 0.02);
            world.playSound(null, context.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                    SoundCategory.PLAYERS, 0.55F, 1.45F);
        }
        return result;
    }

    private static boolean consumeRewardSlot(UUID player) {
        long now = System.currentTimeMillis();
        RewardWindow window = REWARD_WINDOWS.computeIfAbsent(player, ignored -> new RewardWindow(now, 0));
        if (now - window.startedAt >= WINDOW_MILLIS) {
            window.startedAt = now;
            window.rewards = 0;
        }
        if (window.rewards >= MAX_MINERALS_PER_WINDOW) return false;
        window.rewards++;
        return true;
    }

    private static Item randomMineral(ServerWorld world) {
        int roll = world.getRandom().nextInt(1_000);
        if (roll < 260) return Items.COAL;
        if (roll < 480) return Items.RAW_COPPER;
        if (roll < 680) return Items.RAW_IRON;
        if (roll < 800) return Items.REDSTONE;
        if (roll < 880) return Items.LAPIS_LAZULI;
        if (roll < 940) return Items.RAW_GOLD;
        if (roll < 975) return Items.EMERALD;
        return Items.DIAMOND;
    }

    private static final class RewardWindow {
        private long startedAt;
        private int rewards;
        private RewardWindow(long startedAt, int rewards) {
            this.startedAt = startedAt;
            this.rewards = rewards;
        }
    }
}
