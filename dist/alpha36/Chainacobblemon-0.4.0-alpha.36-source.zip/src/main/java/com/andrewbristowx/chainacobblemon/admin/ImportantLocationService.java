package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

/**
 * World-specific route planner for the 69 official regional locations audited by Chaina.
 *
 * Registered structures are located progressively. A regional label may match more than one STRUCTURE
 * registry id, so alpha.27 tries every candidate in every loaded server dimension before widening the search radius.
 * a real location as missing merely because the audit's first textual match was not the worldgen entry
 * This avoids treating a real location as missing merely because it lives outside the Overworld or because the audit
 * first matched a different worldgen entry used by the current Cobbleverse datapacks.
 *
 * Datapack/template-only assets cannot be located generically through Minecraft's STRUCTURE registry.
 * They remain visible as explicit pending entries and can be marked at their real world position.
 */
public final class ImportantLocationService {
    public static final int EXPECTED_TOTAL = 69;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int[] SEARCH_RADII_CHUNKS = {4096, 6144, 8192, 12288};
    private static final int LOCATE_INTERVAL_TICKS = 20;
    private static final int DEFAULT_PADDING = 1024;

    private static ConfigManager configManager;
    private static long loadedSeed = Long.MIN_VALUE;
    private static SavedState saved = new SavedState();
    private static PlanJob job;
    private static int tickCounter;
    private static boolean initialized;

    private ImportantLocationService() {}

    public static synchronized void initialize(ConfigManager config) {
        configManager = config;
        if (initialized) return;
        initialized = true;
        ServerTickEvents.END_SERVER_TICK.register(ImportantLocationService::tick);
    }

    public record LocationView(String key, String region, int order, String label, String structureId,
                               String dimensionId, boolean registered, boolean located, boolean assetOnly,
                               int x, int y, int z) {}

    public record DimensionBoundsView(String dimensionId, int located, int minX, int maxX, int minZ, int maxZ,
                                      int centerX, int centerZ, int width, int length, int padding) {}

    public record RegionView(String id, String name, int located, int total, List<LocationView> locations) {}

    public record MapSnapshot(List<RegionView> regions, int located, int total, int registered,
                              int assetOnly, boolean planning, int planDone, int planTotal,
                              boolean hasBounds, int minX, int maxX, int minZ, int maxZ,
                              int centerX, int centerZ, int width, int length, int padding,
                              List<DimensionBoundsView> dimensionBounds) {
        public boolean complete() {
            return total > 0 && located == total;
        }
    }

    private record Definition(String key, String regionId, String regionName, int order, String label,
                              List<Identifier> registeredIds, String bestAssetId) {
        boolean registered() {
            return registeredIds != null && !registeredIds.isEmpty();
        }

        Identifier primaryRegisteredId() {
            return registered() ? registeredIds.getFirst() : null;
        }
    }

    private static final class SavedState {
        long seed;
        int padding = DEFAULT_PADDING;
        Map<String, SavedLocation> locations = new LinkedHashMap<>();
    }

    private static final class SavedLocation {
        String structureId = "";
        String dimensionId = "";
        int x;
        int y;
        int z;
        boolean located;
        boolean manuallyMarked;
        int searchAttempts;
        int lastSearchRadiusChunks;
        boolean searchExhausted;
    }

    private static final class AttemptState {
        final Definition definition;
        int radiusIndex;
        int candidateIndex;
        int dimensionIndex;

        AttemptState(Definition definition) {
            this.definition = definition;
        }

        Identifier candidate() {
            return definition.registeredIds().get(candidateIndex);
        }

        int radiusChunks() {
            return SEARCH_RADII_CHUNKS[radiusIndex];
        }

        RegistryKey<World> dimension(List<RegistryKey<World>> dimensions) {
            return dimensions.get(dimensionIndex);
        }

        boolean advance(int dimensionCount) {
            dimensionIndex++;
            if (dimensionIndex < dimensionCount) return true;
            dimensionIndex = 0;
            candidateIndex++;
            if (candidateIndex < definition.registeredIds().size()) return true;
            candidateIndex = 0;
            radiusIndex++;
            return radiusIndex < SEARCH_RADII_CHUNKS.length;
        }
    }

    private static final class PlanJob {
        final Queue<AttemptState> pending = new ArrayDeque<>();
        final int total;
        final UUID requester;
        final List<RegistryKey<World>> dimensions;
        int done;
        int attempts;
        int found;
        int exhausted;

        PlanJob(List<Definition> definitions, UUID requester, List<RegistryKey<World>> dimensions) {
            for (Definition definition : definitions) pending.add(new AttemptState(definition));
            this.total = definitions.size();
            this.requester = requester;
            this.dimensions = List.copyOf(dimensions);
        }
    }

    public static synchronized int startPlan(ServerCommandSource source, boolean refresh) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        if (job != null) {
            source.sendFeedback(() -> Text.literal("§eYa hay un plan de ubicaciones ejecutándose: " + job.done + "/" + job.total + "."), false);
            return 0;
        }

        List<Definition> definitions = definitions(server);
        if (refresh) {
            for (Definition definition : definitions) {
                if (!definition.registered()) continue;
                SavedLocation existing = saved.locations.get(definition.key());
                if (existing != null && !existing.manuallyMarked) {
                    existing.located = false;
                    existing.dimensionId = "";
                    existing.searchAttempts = 0;
                    existing.lastSearchRadiusChunks = 0;
                    existing.searchExhausted = false;
                }
            }
            save(server);
        }

        List<Definition> pending = new ArrayList<>();
        for (Definition definition : definitions) {
            if (!definition.registered()) continue;
            SavedLocation existing = saved.locations.get(definition.key());
            if (existing == null || !existing.located) pending.add(definition);
        }

        UUID requester = source.getEntity() instanceof ServerPlayerEntity player ? player.getUuid() : null;
        List<RegistryKey<World>> dimensions = loadedDimensions(server);
        job = new PlanJob(pending, requester, dimensions);
        tickCounter = LOCATE_INTERVAL_TICKS;
        int assetOnly = (int) definitions.stream().filter(d -> !d.registered()).count();
        int alreadyLocated = (int) definitions.stream().filter(d -> {
            SavedLocation location = saved.locations.get(d.key());
            return location != null && location.located;
        }).count();
        source.sendFeedback(() -> Text.literal("§dChaina · Plan de 69 ubicaciones iniciado. §f" + alreadyLocated
                + "§7 ya guardadas; §f" + pending.size() + "§7 registradas pendientes; §f" + assetOnly
                + "§7 son assets/plantillas."), false);
        source.sendFeedback(() -> Text.literal("§8Las pendientes probarán todos sus IDs en §f" + dimensions.size()
                + "§8 dimensiones cargadas y radios de " + SEARCH_RADII_CHUNKS[0] * 16 + " a "
                + SEARCH_RADII_CHUNKS[SEARCH_RADII_CHUNKS.length - 1] * 16
                + " bloques desde el spawn de cada dimensión. Solo se considera mapa final al llegar a 69/69."), false);
        source.sendFeedback(() -> Text.literal("§8Dimensiones: §7" + dimensions.stream()
                .map(key -> key.getValue().toString()).reduce((a, b) -> a + " | " + b).orElse("ninguna")), false);
        if (pending.isEmpty()) finishPlan(server);
        return 1;
    }

    public static synchronized int reportStatus(ServerCommandSource source) {
        MapSnapshot snapshot = snapshot(source.getServer());
        source.sendFeedback(() -> Text.literal("§d§lUbicaciones importantes · §f" + snapshot.located() + "/" + snapshot.total()), false);
        for (RegionView region : snapshot.regions()) {
            source.sendFeedback(() -> Text.literal("§f" + region.name() + ": §a" + region.located() + "§7/§f" + region.total()), false);
        }
        if (snapshot.planning()) {
            source.sendFeedback(() -> Text.literal("§ePlan en curso: §f" + snapshot.planDone() + "/" + snapshot.planTotal()), false);
        }
        if (snapshot.complete() && snapshot.hasBounds()) {
            source.sendFeedback(() -> Text.literal("§a§lÁREAS FINALES 69/69 §7· una región de pregeneración por dimensión:"), false);
            for (DimensionBoundsView bounds : snapshot.dimensionBounds()) {
                source.sendFeedback(() -> Text.literal("§a✓ §f" + bounds.dimensionId() + " §7· margen " + bounds.padding()
                        + " · §f" + bounds.width() + " × " + bounds.length() + " bloques §7| centro §fX "
                        + bounds.centerX() + " Z " + bounds.centerZ()), false);
            }
            source.sendFeedback(() -> Text.literal("§bPruebas rápidas: §f/chainacobblemon admin structures generate §7pregenera solo alrededor de las ubicaciones."), false);
            source.sendFeedback(() -> Text.literal("§dMapa final completo: §f/chainacobblemon worldborder calcular §7calcula el borde hasta la estructura Overworld más lejana y prepara la pregeneración total."), false);
        } else if (snapshot.hasBounds()) {
            int missing = snapshot.total() - snapshot.located();
            source.sendFeedback(() -> Text.literal("§6Áreas provisionales en §f" + snapshot.dimensionBounds().size()
                    + "§6 dimensiones. §cNO usar todavía para Chunky; faltan " + missing + " ubicaciones."), false);
        }
        int unresolvedAsset = snapshot.assetOnly() - countLocatedAssetOnly(source.getServer());
        if (unresolvedAsset > 0) {
            source.sendFeedback(() -> Text.literal("§eQuedan " + unresolvedAsset
                    + " ubicaciones de plantilla sin ID STRUCTURE. Usa §f/chainacobblemon admin structures mapmissing§e para ver cuáles son."), false);
        }
        if (!snapshot.complete()) {
            source.sendFeedback(() -> Text.literal("§7Pendientes totales: §f" + (snapshot.total() - snapshot.located())
                    + "§7. El plan no está completo hasta 69/69."), false);
        }
        return snapshot.complete() ? 1 : 0;
    }

    public static synchronized int reportMissing(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        List<Definition> definitions = definitions(server);
        int missing = 0;
        for (Definition definition : definitions) {
            SavedLocation location = saved.locations.get(definition.key());
            if (location == null || !location.located) missing++;
        }
        if (missing == 0) {
            source.sendFeedback(() -> Text.literal("§a§lMapa completo: 69/69 ubicaciones tienen coordenadas."), false);
            return 1;
        }

        int finalMissing = missing;
        source.sendFeedback(() -> Text.literal("§d§lUbicaciones pendientes · §f" + finalMissing + "/" + EXPECTED_TOTAL), false);
        for (Definition definition : definitions) {
            SavedLocation location = saved.locations.get(definition.key());
            if (location != null && location.located) continue;
            if (!definition.registered()) {
                String asset = definition.bestAssetId() == null || definition.bestAssetId().isBlank()
                        ? "asset sin ID STRUCTURE" : definition.bestAssetId();
                source.sendFeedback(() -> Text.literal("§6[PLANTILLA] §f" + definition.regionName() + " #" + definition.order()
                        + " · " + definition.label() + " §8→ §7" + asset), false);
                source.sendFeedback(() -> Text.literal("  §8Cuando estés físicamente allí: §7/chainacobblemon admin structures mapmark "
                        + definition.regionId() + " " + definition.order()), false);
            } else {
                String ids = definition.registeredIds().stream().map(Identifier::toString).limit(4)
                        .reduce((a, b) -> a + " | " + b).orElse("?");
                String searchInfo = location != null && location.searchExhausted
                        ? " §c· búsqueda agotada hasta " + (location.lastSearchRadiusChunks * 16) + " bloques"
                        : "";
                source.sendFeedback(() -> Text.literal("§c[NO LOCALIZADA] §f" + definition.regionName() + " #" + definition.order()
                        + " · " + definition.label() + searchInfo), false);
                source.sendFeedback(() -> Text.literal("  §8IDs candidatos: §7" + ids), false);
            }
        }
        return 0;
    }

    public static synchronized int markCurrent(ServerCommandSource source, String rawRegion, int order) {
        ServerPlayerEntity player;
        try {
            player = source.getPlayerOrThrow();
        } catch (Exception exception) {
            source.sendFeedback(() -> Text.literal("§cEste comando debe ejecutarlo un jugador situado en la ubicación."), false);
            return 0;
        }
        String region = normalizeRegion(rawRegion);
        Definition target = definitions(source.getServer()).stream()
                .filter(d -> d.regionId().equals(region) && d.order() == order)
                .findFirst().orElse(null);
        if (target == null) {
            source.sendFeedback(() -> Text.literal("§cNo existe " + rawRegion + " #" + order + " en la ruta de 69 ubicaciones."), false);
            return 0;
        }
        ensureLoaded(source.getServer());
        SavedLocation location = saved.locations.computeIfAbsent(target.key(), ignored -> new SavedLocation());
        BlockPos pos = player.getBlockPos();
        Identifier primary = target.primaryRegisteredId();
        location.structureId = primary != null ? primary.toString() : target.bestAssetId();
        location.dimensionId = player.getWorld().getRegistryKey().getValue().toString();
        location.x = pos.getX();
        location.y = pos.getY();
        location.z = pos.getZ();
        location.located = true;
        location.manuallyMarked = true;
        location.searchExhausted = false;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aUbicación guardada: §f" + target.regionName() + " #" + target.order()
                + " · " + target.label() + " §7→ §f" + location.dimensionId + " · X " + pos.getX()
                + " Y " + pos.getY() + " Z " + pos.getZ()), false);
        MapSnapshot snapshot = snapshot(source.getServer());
        if (snapshot.complete()) {
            source.sendFeedback(() -> Text.literal("§a§l¡69/69! §aEl mapa ya tiene coordenadas para todas las ubicaciones. Usa mapstatus para ver el área final."), false);
        }
        return 1;
    }

    /**
     * Replaces one official route coordinate after RegionalLayoutService has physically placed and verified it.
     * Generated layout positions are treated as authoritative/manual marks so a later mapplan refresh cannot
     * silently send the campaign back to a distant natural copy.
     */
    public static synchronized boolean recordGeneratedLocation(MinecraftServer server, String key, String structureId,
                                                               RegistryKey<World> worldKey, BlockPos pos) {
        if (server == null || key == null || pos == null || worldKey == null) return false;
        ensureLoaded(server);
        boolean known = definitions(server).stream().anyMatch(definition -> definition.key().equals(key));
        if (!known) return false;
        SavedLocation location = saved.locations.computeIfAbsent(key, ignored -> new SavedLocation());
        location.structureId = structureId == null ? "" : structureId;
        location.dimensionId = worldKey.getValue().toString();
        location.x = pos.getX();
        location.y = pos.getY();
        location.z = pos.getZ();
        location.located = true;
        location.manuallyMarked = true;
        location.searchExhausted = false;
        save(server);
        return true;
    }

    public static synchronized int clearPlan(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        saved.locations.clear();
        job = null;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§eSe borraron las coordenadas guardadas de las 69 ubicaciones. No se modificó el mundo."), false);
        return 1;
    }

    public static synchronized MapSnapshot snapshot(MinecraftServer server) {
        ensureLoaded(server);
        List<Definition> definitions = definitions(server);
        Map<String, List<LocationView>> grouped = new LinkedHashMap<>();
        Map<String, String> regionNames = new LinkedHashMap<>();
        Map<String, int[]> rawBounds = new LinkedHashMap<>();
        Map<String, Integer> dimensionCounts = new LinkedHashMap<>();
        int located = 0;
        int registered = 0;
        int assetOnly = 0;
        for (Definition definition : definitions) {
            SavedLocation entry = saved.locations.get(definition.key());
            boolean found = entry != null && entry.located;
            String dimensionId = found && entry.dimensionId != null && !entry.dimensionId.isBlank()
                    ? entry.dimensionId : found ? World.OVERWORLD.getValue().toString() : "";
            if (found) {
                located++;
                int[] bounds = rawBounds.computeIfAbsent(dimensionId, ignored -> new int[]{
                        Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE});
                bounds[0] = Math.min(bounds[0], entry.x);
                bounds[1] = Math.max(bounds[1], entry.x);
                bounds[2] = Math.min(bounds[2], entry.z);
                bounds[3] = Math.max(bounds[3], entry.z);
                dimensionCounts.merge(dimensionId, 1, Integer::sum);
            }
            if (definition.registered()) registered++; else assetOnly++;
            Identifier primary = definition.primaryRegisteredId();
            String structureId = entry != null && entry.structureId != null && !entry.structureId.isBlank()
                    ? entry.structureId
                    : primary != null ? primary.toString() : definition.bestAssetId();
            LocationView view = new LocationView(definition.key(), definition.regionId(), definition.order(), definition.label(),
                    structureId == null ? "" : structureId, dimensionId, definition.registered(), found,
                    !definition.registered(), found ? entry.x : 0, found ? entry.y : 0, found ? entry.z : 0);
            grouped.computeIfAbsent(definition.regionId(), ignored -> new ArrayList<>()).add(view);
            regionNames.put(definition.regionId(), definition.regionName());
        }
        List<RegionView> regions = new ArrayList<>();
        for (Map.Entry<String, List<LocationView>> entry : grouped.entrySet()) {
            int count = (int) entry.getValue().stream().filter(LocationView::located).count();
            regions.add(new RegionView(entry.getKey(), regionNames.getOrDefault(entry.getKey(), entry.getKey()), count,
                    entry.getValue().size(), List.copyOf(entry.getValue())));
        }
        int padding = Math.max(0, saved.padding);
        List<DimensionBoundsView> dimensionBounds = new ArrayList<>();
        for (Map.Entry<String, int[]> entry : rawBounds.entrySet()) {
            int[] bounds = entry.getValue();
            int minX = bounds[0] - padding;
            int maxX = bounds[1] + padding;
            int minZ = bounds[2] - padding;
            int maxZ = bounds[3] + padding;
            int centerX = minX + (maxX - minX) / 2;
            int centerZ = minZ + (maxZ - minZ) / 2;
            dimensionBounds.add(new DimensionBoundsView(entry.getKey(), dimensionCounts.getOrDefault(entry.getKey(), 0),
                    minX, maxX, minZ, maxZ, centerX, centerZ, maxX - minX + 1, maxZ - minZ + 1, padding));
        }
        DimensionBoundsView primary = dimensionBounds.stream()
                .filter(bounds -> bounds.dimensionId().equals(World.OVERWORLD.getValue().toString()))
                .findFirst().orElse(dimensionBounds.isEmpty() ? null : dimensionBounds.getFirst());
        boolean hasBounds = primary != null;
        return new MapSnapshot(List.copyOf(regions), located, definitions.size(), registered, assetOnly,
                job != null, job == null ? 0 : job.done, job == null ? 0 : job.total,
                hasBounds, primary == null ? 0 : primary.minX(), primary == null ? 0 : primary.maxX(),
                primary == null ? 0 : primary.minZ(), primary == null ? 0 : primary.maxZ(),
                primary == null ? 0 : primary.centerX(), primary == null ? 0 : primary.centerZ(),
                primary == null ? 0 : primary.width(), primary == null ? 0 : primary.length(), padding,
                List.copyOf(dimensionBounds));
    }

    private static void tick(MinecraftServer server) {
        synchronized (ImportantLocationService.class) {
            if (job == null) return;
            if (++tickCounter < LOCATE_INTERVAL_TICKS) return;
            tickCounter = 0;
            AttemptState attempt = job.pending.poll();
            if (attempt == null) {
                finishPlan(server);
                return;
            }

            Definition definition = attempt.definition;
            Identifier candidate = attempt.candidate();
            int radius = attempt.radiusChunks();
            RegistryKey<World> dimension = attempt.dimension(job.dimensions);
            boolean found = locateOne(server, definition, candidate, dimension, radius);
            job.attempts++;
            if (found) {
                job.done++;
                job.found++;
                notifyRequester(server, "§a✓ §f" + definition.regionName() + " · " + definition.label()
                        + " §7(" + candidate + " · " + dimension.getValue() + ")");
            } else if (attempt.advance(job.dimensions.size())) {
                job.pending.add(attempt);
                notifyRequester(server, "§eBuscando §f" + definition.label() + " §8· siguiente dimensión/candidato/radio");
            } else {
                SavedLocation location = saved.locations.computeIfAbsent(definition.key(), ignored -> new SavedLocation());
                location.located = false;
                location.searchExhausted = true;
                location.lastSearchRadiusChunks = SEARCH_RADII_CHUNKS[SEARCH_RADII_CHUNKS.length - 1];
                job.done++;
                job.exhausted++;
                save(server);
                notifyRequester(server, "§c✗ §f" + definition.regionName() + " · " + definition.label()
                        + " §7(no encontrada hasta " + (location.lastSearchRadiusChunks * 16) + " bloques)");
            }
            if (job.pending.isEmpty()) finishPlan(server);
        }
    }

    private static boolean locateOne(MinecraftServer server, Definition definition, Identifier candidateId,
                                     RegistryKey<World> worldKey, int radiusChunks) {
        ServerWorld world = server.getWorld(worldKey);
        if (world == null) return false;
        try {
            Registry<Structure> registry = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
            Optional<RegistryEntry.Reference<Structure>> optional = registry.getEntry(candidateId);
            SavedLocation location = saved.locations.computeIfAbsent(definition.key(), ignored -> new SavedLocation());
            location.searchAttempts++;
            location.lastSearchRadiusChunks = radiusChunks;
            location.searchExhausted = false;
            if (optional.isEmpty()) return false;
            RegistryEntryList<Structure> list = RegistryEntryList.of(List.of(optional.get()));
            Pair<BlockPos, RegistryEntry<Structure>> found = world.getChunkManager().getChunkGenerator()
                    .locateStructure(world, list, world.getSpawnPos(), radiusChunks, false);
            if (found == null) return false;
            BlockPos pos = found.getFirst();
            location.structureId = candidateId.toString();
            location.dimensionId = worldKey.getValue().toString();
            location.x = pos.getX();
            location.y = pos.getY();
            location.z = pos.getZ();
            location.located = true;
            location.manuallyMarked = false;
            location.searchExhausted = false;
            save(server);
            return true;
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not locate important structure {} ({}) in {} radius {} chunks",
                    definition.label(), candidateId, worldKey.getValue(), radiusChunks, exception);
            return false;
        }
    }

    private static List<RegistryKey<World>> loadedDimensions(MinecraftServer server) {
        List<RegistryKey<World>> dimensions = new ArrayList<>();
        for (ServerWorld world : server.getWorlds()) dimensions.add(world.getRegistryKey());
        dimensions.sort((a, b) -> dimensionPriority(a) - dimensionPriority(b));
        return dimensions;
    }

    private static int dimensionPriority(RegistryKey<World> key) {
        if (key.equals(World.OVERWORLD)) return 0;
        if (key.equals(World.NETHER)) return 1;
        if (key.equals(World.END)) return 2;
        return 10;
    }

    private static void finishPlan(MinecraftServer server) {
        PlanJob finished = job;
        job = null;
        save(server);
        MapSnapshot snapshot = snapshot(server);
        if (finished != null && finished.requester != null) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(finished.requester);
            if (player != null) {
                if (snapshot.complete()) {
                    player.sendMessage(Text.literal("§a§lPLAN COMPLETO: 69/69 §aubicaciones con coordenadas."), false);
                    if (snapshot.hasBounds()) {
                        player.sendMessage(Text.literal("§aPregeneración final repartida en §f" + snapshot.dimensionBounds().size()
                                + "§a dimensiones. Usa §fmapstatus §apara ver cada área."), false);
                    }
                } else {
                    int missing = snapshot.total() - snapshot.located();
                    player.sendMessage(Text.literal("§eRonda de búsqueda terminada: §f" + snapshot.located() + "/" + snapshot.total()
                            + "§e con coordenadas. §cFaltan " + missing + "; el mapa TODAVÍA NO está terminado."), false);
                    player.sendMessage(Text.literal("§7Encontradas en esta ronda: §a" + finished.found + " §7| agotadas: §c"
                            + finished.exhausted + " §7| intentos: §f" + finished.attempts), false);
                    player.sendMessage(Text.literal("§7Usa §f/chainacobblemon admin structures mapmissing §7para ver exactamente las pendientes."), false);
                    if (snapshot.hasBounds()) {
                        player.sendMessage(Text.literal("§6Hay áreas provisionales en §f" + snapshot.dimensionBounds().size()
                                + "§6 dimensiones §c(NO usar aún para Chunky)"), false);
                    }
                }
            }
        }
    }

    private static void notifyRequester(MinecraftServer server, String message) {
        if (job == null || job.requester == null) return;
        ServerPlayerEntity player = server.getPlayerManager().getPlayer(job.requester);
        if (player != null) player.sendMessage(Text.literal(message), true);
    }

    private static int countLocatedAssetOnly(MinecraftServer server) {
        int count = 0;
        for (Definition definition : definitions(server)) {
            if (definition.registered()) continue;
            SavedLocation location = saved.locations.get(definition.key());
            if (location != null && location.located) count++;
        }
        return count;
    }

    private static List<Definition> definitions(MinecraftServer server) {
        RegionalStructureAuditService.AuditResult audit = RegionalStructureAuditService.audit(server);
        List<Definition> result = new ArrayList<>();
        for (Map.Entry<String, List<String>> expectedRegion : RegionalStructureAuditService.expectedLabels().entrySet()) {
            String regionName = expectedRegion.getKey();
            String regionId = normalizeRegion(regionName);
            RegionalStructureAuditService.RegionResult region = audit.regions().get(regionName);
            for (int index = 0; index < expectedRegion.getValue().size(); index++) {
                String label = expectedRegion.getValue().get(index);
                List<String> matches = region == null ? List.of() : region.matches().getOrDefault(label, List.of());
                Set<Identifier> registered = new LinkedHashSet<>();
                String bestAsset = "";
                for (String display : matches) {
                    String raw = stripSource(display);
                    if (display.startsWith("[REGISTRY] ")) {
                        Identifier parsed = Identifier.tryParse(raw);
                        if (parsed != null) registered.add(parsed);
                    } else if (bestAsset.isBlank() && !raw.isBlank()) {
                        bestAsset = raw;
                    }
                }
                // Older audit outputs may only expose the registry candidate as the first generic match.
                if (registered.isEmpty()) {
                    for (String display : matches) {
                        String raw = stripSource(display);
                        Identifier parsed = Identifier.tryParse(raw);
                        if (parsed != null && display.toUpperCase(Locale.ROOT).contains("REGISTRY")) registered.add(parsed);
                    }
                }
                if (bestAsset.isBlank() && registered.isEmpty() && !matches.isEmpty()) bestAsset = stripSource(matches.getFirst());
                result.add(new Definition(regionId + ":" + (index + 1), regionId, regionName, index + 1,
                        label, List.copyOf(registered), bestAsset));
            }
        }
        return List.copyOf(result);
    }

    private static String stripSource(String display) {
        if (display == null) return "";
        int end = display.indexOf("] ");
        return end >= 0 ? display.substring(end + 2).trim() : display.trim();
    }

    private static String normalizeRegion(String region) {
        if (region == null) return "";
        return region.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
    }

    private static void ensureLoaded(MinecraftServer server) {
        if (configManager == null || server == null || server.getOverworld() == null) return;
        long seed = server.getOverworld().getSeed();
        if (loadedSeed == seed) return;
        loadedSeed = seed;
        saved = new SavedState();
        saved.seed = seed;
        Path file = stateFile(seed);
        if (!Files.exists(file)) return;
        try {
            SavedState loaded = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), SavedState.class);
            if (loaded != null && loaded.seed == seed) {
                if (loaded.locations == null) loaded.locations = new LinkedHashMap<>();
                if (loaded.padding <= 0) loaded.padding = DEFAULT_PADDING;
                saved = loaded;
            }
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.warn("Could not read important-location plan {}", file, exception);
        }
    }

    private static void save(MinecraftServer server) {
        if (configManager == null || server == null) return;
        ensureLoaded(server);
        Path file = stateFile(saved.seed);
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(temp, GSON.toJson(saved), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            Chainacobblemon.LOGGER.warn("Could not save important-location plan {}", file, exception);
        }
    }

    private static Path stateFile(long seed) {
        return configManager.configDirectory().resolve("important-locations-" + Long.toUnsignedString(seed) + ".json");
    }
}
