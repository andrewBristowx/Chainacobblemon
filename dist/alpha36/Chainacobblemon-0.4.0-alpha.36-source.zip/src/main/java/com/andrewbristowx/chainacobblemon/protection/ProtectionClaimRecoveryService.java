package com.andrewbristowx.chainacobblemon.protection;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Repairs the protection/Flan edge case where a broken core can leave its claim behind. */
public final class ProtectionClaimRecoveryService {
    private static final Map<Key, Capture> BEFORE = new HashMap<>();
    private static final Map<UUID, Retry> RETRIES = new HashMap<>();
    private static long ticks;
    private static boolean initialized;

    private ProtectionClaimRecoveryService() { }

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof ServerWorld serverWorld && protection(state) && blockEntity != null) {
                UUID claim = claimId(blockEntity);
                if (claim != null) BEFORE.put(new Key(serverWorld.getRegistryKey().getValue().toString(), pos.asLong()),
                        new Capture(claim, ticks));
            }
            return true; // EmiProtecciones remains authoritative for break permissions.
        });
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof ServerWorld serverWorld) || !protection(state)) return;
            Capture capture = BEFORE.remove(new Key(serverWorld.getRegistryKey().getValue().toString(), pos.asLong()));
            if (capture != null) RETRIES.put(capture.claimId(), new Retry(serverWorld, capture.claimId(), ticks + 2L, 0));
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
    }

    private static void tick() {
        ticks++;
        BEFORE.entrySet().removeIf(entry -> ticks - entry.getValue().capturedTick() > 100L);
        Iterator<Map.Entry<UUID, Retry>> iterator = RETRIES.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Retry> entry = iterator.next();
            Retry retry = entry.getValue();
            if (ticks < retry.nextTick()) continue;
            boolean remains = removeAndCheck(retry.world(), retry.claimId());
            if (!remains) {
                iterator.remove();
                continue;
            }
            int attempt = retry.attempt() + 1;
            if (attempt >= 4) {
                Chainacobblemon.LOGGER.warn("Protection claim {} still exists after safe removal retries; use /chainacobblemon protection cleanuporphans", retry.claimId());
                iterator.remove();
            } else {
                long delay = attempt == 1 ? 20L : attempt == 2 ? 60L : 120L;
                entry.setValue(new Retry(retry.world(), retry.claimId(), ticks + delay, attempt));
            }
        }
    }

    static boolean removeAndCheck(ServerWorld world, UUID claimId) {
        try {
            Class<?> bridge = Class.forName("com.emiprotecciones.FlanBridge");
            bridge.getMethod("removeClaim", ServerWorld.class, UUID.class).invoke(null, world, claimId);
            Method claim = bridge.getDeclaredMethod("claim", ServerWorld.class, UUID.class);
            claim.setAccessible(true);
            return claim.invoke(null, world, claimId) != null;
        } catch (ClassNotFoundException ignored) {
            return false;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not verify Flan protection claim {}", claimId, exception);
            return true;
        }
    }

    private static boolean protection(BlockState state) {
        if (state == null) return false;
        Identifier id = Registries.BLOCK.getId(state.getBlock());
        return id != null && "chainacobblemon".equals(id.getNamespace()) && id.getPath().startsWith("protection_core");
    }

    private static UUID claimId(BlockEntity blockEntity) {
        try {
            Object value = blockEntity.getClass().getMethod("getFlanClaimId").invoke(blockEntity);
            return value instanceof UUID id ? id : null;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }

    private record Key(String world, long pos) { }
    private record Capture(UUID claimId, long capturedTick) { }
    private record Retry(ServerWorld world, UUID claimId, long nextTick, int attempt) { }
}
