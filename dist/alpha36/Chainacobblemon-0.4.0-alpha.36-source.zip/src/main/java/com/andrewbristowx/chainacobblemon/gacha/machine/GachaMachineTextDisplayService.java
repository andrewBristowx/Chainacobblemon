package com.andrewbristowx.chainacobblemon.gacha.machine;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.DisplayEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import java.util.ArrayList;
import java.util.List;
final class GachaMachineTextDisplayService {
    private static final String TAG_PREFIX = "chainacobblemon:gacha-label:";
    private static final double LABEL_Y = 3.92D;
    private GachaMachineTextDisplayService() {}
    static void reconcile(ServerWorld world, GachaMachineBlockEntity machine) {
        if (world == null || machine == null) return;
        String tag = tag(machine.getPos()); Text expected = label(machine);
        String expectedJson = Text.Serialization.toJsonString(expected, world.getRegistryManager());
        Box search = new Box(machine.getPos()).expand(1.4D,0.0D,1.4D).offset(0.0D,3.0D,0.0D).stretch(0.0D,2.4D,0.0D);
        List<DisplayEntity.TextDisplayEntity> owned=new ArrayList<>(), unowned=new ArrayList<>(); boolean legacyTitleFound=false;
        for (DisplayEntity.TextDisplayEntity display : world.getEntitiesByType(EntityType.TEXT_DISPLAY, search, entity -> true)) {
            if (display.getCommandTags().contains(tag)) { owned.add(display); continue; }
            if (isProtectedHologram(display)) continue; unowned.add(display); if (isLegacyGachaLabel(display)) legacyTitleFound=true;
        }
        if (legacyTitleFound) for (DisplayEntity.TextDisplayEntity display : unowned) display.discard();
        DisplayEntity.TextDisplayEntity current=owned.isEmpty()?null:owned.getFirst();
        for(int i=1;i<owned.size();i++) owned.get(i).discard();
        if(current!=null && matchesText(current,expectedJson)) return; if(current!=null) current.discard();
        spawn(world,machine.getPos(),tag,expected);
    }
    static void remove(ServerWorld world, BlockPos pos) {
        if(world==null||pos==null)return; String tag=tag(pos);
        Box search=new Box(pos).expand(1.4D,0.0D,1.4D).offset(0.0D,3.0D,0.0D).stretch(0.0D,2.4D,0.0D);
        for(DisplayEntity.TextDisplayEntity d:world.getEntitiesByType(EntityType.TEXT_DISPLAY,search,e->e.getCommandTags().contains(tag))) d.discard();
    }
    private static Text label(GachaMachineBlockEntity machine) {
        if (machine.isTreasureThemed()) {
            return Text.literal("✦ TESOROS DE CHAINA ✦").setStyle(Style.EMPTY.withColor(0xFFA6E4))
                    .append(Text.literal("\nEquipamiento exclusivo").setStyle(Style.EMPTY.withColor(0xFFD8B45A)));
        }
        int c=machine.isChainaThemed()?0xFFA6E4:0x8DEBFF; String title=machine.isChainaThemed()?"✦ LEGENDARIO DE CHAINA ✦":"✦ GASHA NORMAL ✦";
        MutableText text=Text.literal(title).setStyle(Style.EMPTY.withColor(c));
        if(machine.isChainaThemed()){ String name=machine.getFeaturedPokemonName(); if(name==null||name.isBlank()) name="Sincronizando…"; text.append(Text.literal("\n"+name).setStyle(Style.EMPTY.withColor(0xFFFFFF))); }
        return text;
    }
    private static void spawn(ServerWorld world, BlockPos pos, String tag, Text text) {
        DisplayEntity.TextDisplayEntity d=EntityType.TEXT_DISPLAY.create(world); if(d==null)return;
        double x=pos.getX()+0.5D,y=pos.getY()+LABEL_Y,z=pos.getZ()+0.5D; d.refreshPositionAndAngles(x,y,z,0,0); d.setNoGravity(true); d.setInvulnerable(true); d.setSilent(true); d.ignoreCameraFrustum=true;
        NbtCompound n=new NbtCompound(); d.writeNbt(n); n.putString("text",Text.Serialization.toJsonString(text,world.getRegistryManager())); n.putString("billboard","center"); n.putFloat("view_range",4.0F); n.putFloat("width",3.0F); n.putFloat("height",1.0F); n.putInt("line_width",220); n.putByte("text_opacity",(byte)0xFF); n.putByte("shadow",(byte)1); n.putByte("see_through",(byte)1); n.putByte("default_background",(byte)0); n.putInt("background",0);
        NbtCompound b=new NbtCompound(); b.putInt("block",15); b.putInt("sky",15); n.put("brightness",b); d.readNbt(n); d.refreshPositionAndAngles(x,y,z,0,0); d.ignoreCameraFrustum=true; d.addCommandTag(tag); d.setCustomName(Text.literal("Chainacobblemon gacha label")); d.setCustomNameVisible(false); world.spawnEntity(d);
    }
    private static boolean matchesText(DisplayEntity.TextDisplayEntity d,String expected){NbtCompound n=new NbtCompound();d.writeNbt(n);return expected.equals(n.getString("text"));}
    private static boolean isProtectedHologram(DisplayEntity.TextDisplayEntity d){for(String t:d.getCommandTags())if(t.startsWith("chainacobblemon:hologram:"))return true;return false;}
    private static boolean isLegacyGachaLabel(DisplayEntity.TextDisplayEntity d){if(isProtectedHologram(d))return false;for(String t:d.getCommandTags())if(t.startsWith(TAG_PREFIX))return false;NbtCompound n=new NbtCompound();d.writeNbt(n);String s=n.getString("text").toLowerCase(java.util.Locale.ROOT);return s.contains("pokémon de temporada")||s.contains("pokemon de temporada")||s.contains("legendario de chaina")||s.contains("gasha normal");}
    private static String tag(BlockPos p){return TAG_PREFIX+p.getX()+":"+p.getY()+":"+p.getZ();}
}
