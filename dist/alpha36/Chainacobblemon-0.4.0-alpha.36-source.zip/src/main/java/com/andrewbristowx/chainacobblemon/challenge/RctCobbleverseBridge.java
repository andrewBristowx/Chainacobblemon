package com.andrewbristowx.chainacobblemon.challenge;

import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Optional bridge to the RCT instance that Cobbleverse already uses.
 * Everything is reflective on purpose: Chainacobblemon keeps the exact pinned runtime
 * dependency, but a missing/renamed helper must never crash the server.
 */
public final class RctCobbleverseBridge {
    private RctCobbleverseBridge() {}

    public record LevelCapStatus(int cap, int highestPartyLevel, boolean available) {
        public boolean allowed() {
            return !available || cap <= 0 || highestPartyLevel <= cap;
        }
    }

    public record NativeTrainer(String trainerId, Object trainer) {}

    public static LevelCapStatus levelCap(ServerPlayerEntity player) {
        int highest = highestPartyLevel(player);
        try {
            Class<?> stateClass = Class.forName("com.gitlab.srcmc.rctmod.api.data.sync.PlayerState");
            Object state = null;
            for (Method method : stateClass.getMethods()) {
                if (!method.getName().equals("get") || method.getParameterCount() != 1 || !Modifier.isStatic(method.getModifiers())) continue;
                Class<?> parameter = method.getParameterTypes()[0];
                if (!parameter.isAssignableFrom(player.getClass())) continue;
                state = method.invoke(null, player);
                if (state != null) break;
            }
            if (state == null) return new LevelCapStatus(-1, highest, false);
            for (String getter : List.of("getLevelCap", "levelCap")) {
                try {
                    Object value = state.getClass().getMethod(getter).invoke(state);
                    if (value instanceof Number number) return new LevelCapStatus(number.intValue(), highest, true);
                } catch (NoSuchMethodException ignored) {
                }
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("RCT level-cap bridge unavailable: {}", exception.toString());
        }
        return new LevelCapStatus(-1, highest, false);
    }


    /**
     * Mirrors a first Chaina victory into RCT without replacing RCT's own progression model.
     * The native trainer id is resolved from the live RCT registry, then RCT's public admin commands
     * advance the player's series and defeat statistic. The matching vanilla advancement is granted
     * as the visible record used by the reverse Chaina <- RCT synchronizer.
     */
    public static boolean syncChainaVictoryToRct(ServerPlayerEntity player, ChallengeProfile profile) {
        if (player == null || profile == null || player.getServer() == null) return false;
        String trainerId = resolveNativeTrainerId(player.getServer(), profile);
        if (trainerId == null || trainerId.isBlank()) return false;
        try {
            String playerName = player.getGameProfile().getName();
            var source = player.getCommandSource().withLevel(4).withSilent();
            player.getServer().getCommandManager().executeWithPrefix(source,
                    "rctmod player add progress " + playerName + " after " + trainerId);
            Identifier advancementId = Identifier.tryParse(ChallengeCatalog.naturalAdvancementPath(profile));
            boolean alreadyAdvanced = false;
            if (advancementId != null) {
                AdvancementEntry advancement = player.getServer().getAdvancementLoader().get(advancementId);
                alreadyAdvanced = advancement != null && player.getAdvancementTracker().getProgress(advancement).isDone();
            }
            // Only synthesize the first defeat when RCT has not already recorded the visible milestone.
            if (!alreadyAdvanced) {
                player.getServer().getCommandManager().executeWithPrefix(source,
                        "rctmod player set defeats " + trainerId + " " + playerName + " 1");
                if (advancementId != null && player.getServer().getAdvancementLoader().get(advancementId) != null) {
                    player.getServer().getCommandManager().executeWithPrefix(source,
                            "advancement grant " + playerName + " only " + advancementId);
                }
            }
            return true;
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not mirror Chaina victory {} into RCT trainer {}", profile.key(), trainerId, exception);
            return false;
        }
    }

    public static String resolveNativeTrainerId(MinecraftServer server, ChallengeProfile profile) {
        if (server == null || profile == null) return null;
        try {
            Class<?> rctApiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
            Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
            Object rct = rctApiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
            if (rct == null) return null;
            Object registry = rct.getClass().getMethod("getTrainerRegistry").invoke(rct);
            return resolveTrainerId(registry, trainerNpcClass, profile);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not resolve native RCT trainer id for {}: {}", profile.key(), exception.toString());
            return null;
        }
    }

    public static NativeTrainer attachNativeTrainer(MinecraftServer server, ChallengeProfile profile, ServiceNpcEntity entity) {
        if (server == null || profile == null || entity == null) return null;
        try {
            Class<?> rctApiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
            Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
            Object rct = rctApiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
            if (rct == null) return null;
            Object registry = rct.getClass().getMethod("getTrainerRegistry").invoke(rct);
            String trainerId = resolveTrainerId(registry, trainerNpcClass, profile);
            if (trainerId == null) return null;
            Object trainer = registry.getClass().getMethod("getById", String.class, Class.class)
                    .invoke(registry, trainerId, trainerNpcClass);
            if (trainer == null) return null;
            trainer.getClass().getMethod("setEntity", net.minecraft.entity.LivingEntity.class).invoke(trainer, entity);
            return new NativeTrainer(trainerId, trainer);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not attach native RCT/Cobbleverse trainer for {}: {}", profile.key(), exception.toString());
            return null;
        }
    }

    private static String resolveTrainerId(Object registry, Class<?> trainerNpcClass, ChallengeProfile profile)
            throws ReflectiveOperationException {
        for (String candidate : directCandidates(profile)) {
            try {
                Object trainer = registry.getClass().getMethod("getById", String.class, Class.class)
                        .invoke(registry, candidate, trainerNpcClass);
                if (trainer != null) return candidate;
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // Some registry implementations throw for unknown ids; continue with aliases/discovery.
            }
        }
        Set<String> ids = discoverIds(registry);
        if (ids.isEmpty()) return null;
        List<String> searchTokens = searchTokens(profile);
        String leaderToken = searchTokens.getFirst();
        String region = profile.regionId();
        String best = null;
        int bestScore = Integer.MIN_VALUE;
        for (String id : ids) {
            String normalized = id.toLowerCase(Locale.ROOT);
            String matchedToken = null;
            for (String token : searchTokens) {
                if (normalized.contains(token)) { matchedToken = token; break; }
            }
            if (matchedToken == null) continue;
            int score = matchedToken.equals(leaderToken) ? 20 : 10;
            if (normalized.startsWith(region + "_")) score += 80;
            if (normalized.contains("_" + region + "_")) score += 40;
            if (profile.isLeader() && normalized.contains("leader")) score += 40;
            if (profile.isEliteFour() && (normalized.contains("league") || normalized.contains("elite") || normalized.contains("e4"))) score += 50;
            if (profile.isChampion() && normalized.contains("champ")) score += 60;
            if (normalized.equals(region + "_" + leaderToken)) score += 120;
            score -= Math.min(40, normalized.length() / 4);
            if (score > bestScore) {
                bestScore = score;
                best = id;
            }
        }
        return best;
    }

    private static List<String> directCandidates(ChallengeProfile profile) {
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        for (String alias : searchTokens(profile)) {
            String compact = alias.replace("_", "");
            ids.add(profile.regionId() + "_" + alias);
            ids.add(profile.regionId() + "_" + compact);
            if (profile.isLeader()) {
                ids.add("leader_" + alias);
                ids.add("leader_" + compact);
                ids.add(profile.regionId() + "_leader_" + alias);
            } else if (profile.isEliteFour()) {
                ids.add(profile.regionId() + "_league_" + alias);
                ids.add(profile.regionId() + "_elite_" + alias);
                ids.add("elite_" + alias);
                ids.add("e4_" + alias);
            } else if (profile.isChampion()) {
                ids.add(profile.regionId() + "_champion_" + alias);
                ids.add("champion_" + alias);
                ids.add("champ_" + alias);
            }
        }
        // Legacy RCT ids can carry a short generated suffix. Discovery below handles those.
        return List.copyOf(ids);
    }

    private static Set<String> discoverIds(Object registry) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        for (String methodName : List.of("getIds", "ids", "getKeys", "keySet", "getAll", "getRegistry", "entries")) {
            try {
                Method method = registry.getClass().getMethod(methodName);
                if (method.getParameterCount() != 0) continue;
                collectStrings(method.invoke(registry), result);
            } catch (ReflectiveOperationException | RuntimeException ignored) {
            }
        }
        return result;
    }

    private static void collectStrings(Object value, Set<String> output) {
        if (value == null) return;
        if (value instanceof Map<?, ?> map) {
            for (Object key : map.keySet()) if (key != null) output.add(String.valueOf(key));
            return;
        }
        if (value instanceof Collection<?> collection) {
            for (Object entry : collection) collectEntry(entry, output);
            return;
        }
        if (value instanceof Iterable<?> iterable) {
            for (Object entry : iterable) collectEntry(entry, output);
        }
    }

    private static void collectEntry(Object entry, Set<String> output) {
        if (entry == null) return;
        if (entry instanceof String text) output.add(text);
        else if (entry instanceof Map.Entry<?, ?> pair && pair.getKey() != null) output.add(String.valueOf(pair.getKey()));
        else {
            for (String getter : List.of("getId", "id")) {
                try {
                    Object id = entry.getClass().getMethod(getter).invoke(entry);
                    if (id != null) output.add(String.valueOf(id));
                    return;
                } catch (ReflectiveOperationException ignored) {
                }
            }
        }
    }

    private static int highestPartyLevel(ServerPlayerEntity player) {
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                int highest = 0;
                for (Pokemon pokemon : party) if (pokemon != null) highest = Math.max(highest, pokemon.getLevel());
                return highest;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not inspect Cobblemon party for RCT cap: {}", exception.toString());
        }
        return 0;
    }

    public static List<String> searchTokens(ChallengeProfile profile) {
        String canonical = baseToken(profile.leaderId());
        LinkedHashSet<String> result = new LinkedHashSet<>();
        result.add(canonical);
        String key = profile.regionId() + ":" + canonical;
        String alias = switch (key) {
            case "johto:falkner" -> "valerio";
            case "johto:bugsy" -> "raffaello";
            case "johto:whitney" -> "chiara";
            case "johto:morty" -> "angelo";
            case "johto:chuck" -> "furio";
            case "johto:pryce" -> "alfredo";
            case "johto:clair" -> "sandra";
            case "johto:will" -> "pino";
            case "hoenn:roxanne" -> "petra";
            case "hoenn:brawly" -> "rudi";
            case "hoenn:wattson" -> "walter";
            case "hoenn:flannery" -> "fiammetta";
            case "hoenn:winona" -> "alice";
            case "hoenn:tate_liza" -> "tell";
            case "hoenn:juan" -> "adriano";
            case "hoenn:sidney" -> "fosco";
            case "hoenn:phoebe" -> "ester";
            case "hoenn:glacia" -> "frida";
            case "hoenn:steven" -> "rocco";
            case "sinnoh:roark" -> "pedro";
            case "sinnoh:maylene" -> "marzia";
            case "sinnoh:crasher_wake" -> "omar";
            case "sinnoh:fantina" -> "fannie";
            case "sinnoh:byron" -> "ferruccio";
            case "sinnoh:candice" -> "bianca";
            case "sinnoh:volkner" -> "corrado";
            case "sinnoh:bertha" -> "terrie";
            case "sinnoh:flint" -> "vulcano";
            case "sinnoh:lucian" -> "luciano";
            case "sinnoh:cynthia" -> "camilla";
            default -> "";
        };
        if (!alias.isBlank()) result.add(alias);
        if ("hoenn:tate_liza".equals(key)) result.add("pat");
        return List.copyOf(result);
    }

    public static String baseToken(String leaderId) {
        if (leaderId == null) return "";
        return leaderId.toLowerCase(Locale.ROOT)
                .replaceFirst("^elite_", "")
                .replaceFirst("^champion_", "");
    }
}
