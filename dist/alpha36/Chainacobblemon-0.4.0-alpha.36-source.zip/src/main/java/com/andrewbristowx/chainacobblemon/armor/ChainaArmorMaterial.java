package com.andrewbristowx.chainacobblemon.armor;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Map;

/** Vanilla-shaped Chaina armor, intentionally a modest tier above netherite. */
public final class ChainaArmorMaterial {
    public static final int DURABILITY_MULTIPLIER = 45;
    public static final RegistryEntry<ArmorMaterial> INSTANCE = register();

    private ChainaArmorMaterial() { }

    private static RegistryEntry<ArmorMaterial> register() {
        ArmorMaterial material = new ArmorMaterial(
                Map.of(
                        ArmorItem.Type.HELMET, 4,
                        ArmorItem.Type.CHESTPLATE, 9,
                        ArmorItem.Type.LEGGINGS, 7,
                        ArmorItem.Type.BOOTS, 4,
                        ArmorItem.Type.BODY, 14
                ),
                20,
                SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE,
                () -> Ingredient.ofItems(Items.NETHERITE_INGOT),
                List.of(new ArmorMaterial.Layer(Identifier.of(Chainacobblemon.MOD_ID, "chaina"))),
                4.0F,
                0.15F
        );
        Registry.register(Registries.ARMOR_MATERIAL, Identifier.of(Chainacobblemon.MOD_ID, "chaina"), material);
        return Registries.ARMOR_MATERIAL.getEntry(material);
    }
}
