package com.andrewbristowx.chainacobblemon.twitch;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.Set;

/** Shared rank presentation used by Styled Player List and Styled Chat. */
public final class RankDisplayService {
    private static final int CHAINA = 0xFF4FAF;
    private static final int CHAINA_NAME = 0xFFB5E4;
    private static final int ADMIN = 0xE53935;
    private static final int ADMIN_NAME = 0xFF8A80;
    private static final int MOD = 0xFF6F61;
    private static final int MOD_NAME = 0xFFB3AA;
    private static final int VIP = 0xFFD35C;
    private static final int VIP_NAME = 0xFFE8A3;
    private static final int PLAYER = 0xA7A0B6;
    private static final int PLAYER_NAME = 0xF0EDF5;
    private static final int SUB_1 = 0xC985FF;
    private static final int SUB_2 = 0xFF77C9;
    private static final int SUB_3 = 0xFFD166;
    private static final int TWITCH_VIP = 0xFF69C9;
    private static final int TWITCH_MOD = 0xFF8A80;

    private RankDisplayService() { }

    public static Text styledName(ServerPlayerEntity player, TwitchService twitch) {
        if (player == null) return Text.literal("Jugador").setStyle(Style.EMPTY.withColor(PLAYER_NAME));
        Set<String> groups = LuckPermsBootstrap.inheritedGroups(player);
        int tier = twitch == null ? 0 : twitch.tierForIntegration(player);
        if (tier <= 0) tier = tierFromGroups(groups, twitch);
        boolean twitchMod = twitch != null && twitch.moderatorForIntegration(player);
        boolean twitchVip = twitch != null && twitch.vipForIntegration(player);
        if (twitch != null) {
            var settings = twitch.settingsForIntegration();
            if (!twitchMod) twitchMod = groups.contains(normalize(settings.moderatorTwitchGroup));
            if (!twitchVip) twitchVip = groups.contains(normalize(settings.vipTwitchGroup));
        }

        Primary primary = primary(player, groups, tier, twitchMod, twitchVip);
        MutableText out = Text.empty();
        out.append(tag(primary.label, primary.color));
        out.append(Text.literal(" "));
        out.append(Text.literal(player.getGameProfile().getName()).setStyle(Style.EMPTY.withColor(primary.nameColor)));

        // Keep Twitch roles as secondary badges for staff/admins; avoid duplicate [MOD] ◆MOD / [VIP] ◆VIP.
        if (twitchMod && !"MOD".equals(primary.label)) {
            out.append(Text.literal(" "));
            out.append(compactRole("◆MOD", TWITCH_MOD));
        } else if (twitchVip && !"VIP".equals(primary.label)) {
            out.append(Text.literal(" "));
            out.append(compactRole("◆VIP", TWITCH_VIP));
        }
        if (tier > 0 && !primary.label.startsWith("SUB ")) {
            out.append(Text.literal(" "));
            out.append(tag("SUB " + roman(tier), subColor(tier)));
        }
        return out;
    }

    private static Text tag(String label, int color) {
        return Text.literal("[" + label + "]").setStyle(Style.EMPTY.withColor(color).withBold(true));
    }

    private static Text compactRole(String label, int color) {
        return Text.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true));
    }

    private static Primary primary(ServerPlayerEntity player, Set<String> groups, int tier, boolean twitchMod, boolean twitchVip) {
        if (hasAny(groups, "chaina")) return new Primary("CHAINA", CHAINA, CHAINA_NAME);
        if (player.hasPermissionLevel(4) || hasAny(groups, "owner", "admin", "administrator"))
            return new Primary("ADMIN", ADMIN, ADMIN_NAME);
        if (twitchMod || hasAny(groups, "mod", "moderador", "moderator", "mod_chaina"))
            return new Primary("MOD", MOD, MOD_NAME);
        if (twitchVip || hasAny(groups, "vip", "vip_chaina")) return new Primary("VIP", VIP, VIP_NAME);
        if (tier >= 3) return new Primary("SUB III", SUB_3, 0xFFE5A3);
        if (tier == 2) return new Primary("SUB II", SUB_2, 0xFFB7DF);
        if (tier == 1) return new Primary("SUB I", SUB_1, 0xE8C4FF);
        return new Primary("JUGADOR", PLAYER, PLAYER_NAME);
    }

    private static int tierFromGroups(Set<String> groups, TwitchService twitch) {
        if (twitch == null) return 0;
        var settings = twitch.settingsForIntegration();
        if (groups.contains(normalize(settings.tier3Group))) return 3;
        if (groups.contains(normalize(settings.tier2Group))) return 2;
        if (groups.contains(normalize(settings.tier1Group))) return 1;
        return 0;
    }

    private static boolean hasAny(Set<String> groups, String... names) {
        for (String name : names) if (groups.contains(normalize(name))) return true;
        return false;
    }

    private static String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).replace(' ', '_');
    }

    private static String roman(int tier) { return tier >= 3 ? "III" : tier == 2 ? "II" : "I"; }
    private static int subColor(int tier) { return tier >= 3 ? SUB_3 : tier == 2 ? SUB_2 : SUB_1; }
    private record Primary(String label, int color, int nameColor) { }
}
