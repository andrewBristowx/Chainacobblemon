package com.andrewbristowx.chainacobblemon.tools;

import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;

public final class ChainaSwordItem extends SwordItem {

    public ChainaSwordItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }
}
