package com.andrewbristowx.chainacobblemon.events;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.gacha.GachaTier;
import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogEntry;
import com.cobblemon.mod.common.pokemon.Pokemon;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Locale;

/** Shared scoring used by Fishing and Safari events. */
public final class PokemonEventMetrics {
    private PokemonEventMetrics() { }

    public static Result score(Pokemon pokemon, boolean fishing) {
        if (pokemon == null) return new Result("Pokémon", "unknown", 0, 0, 1.0D, "M", 0.0D, false, "", false, 0L);
        String speciesId = pokemon.getSpecies().showdownId().toLowerCase(Locale.ROOT);
        PokemonCatalogEntry entry = Chainacobblemon.pokemonCatalog().get(speciesId);
        String display = entry == null ? pokemon.getSpecies().getName() : entry.displayName();
        int ivs = ivTotal(pokemon);
        double scale = number(invoke(pokemon, "getScaleModifier"), 1.0D);
        if (scale <= 0.0D) scale = 1.0D;
        String size = string(invoke(pokemon, "getSizeCategory"), sizeLabel(scale));
        Object species = pokemon.getSpecies();
        double baseWeight = number(invoke(species, "getWeight"), 0.0D);
        double weight = Math.max(0.0D, baseWeight * scale * scale * scale);
        boolean shiny = bool(invoke(pokemon, "getShiny"), bool(invoke(pokemon, "isShiny"), false));
        Object ability = invoke(pokemon, "getAbility");
        String abilityName = abilityName(ability);
        boolean hidden = hiddenAbility(ability);

        int rarity = rarityPoints(entry == null ? GachaTier.COMMON : entry.tier());
        int ivPoints = ivs;
        int sizePoints = exceptionalSizePoints(scale);
        int abilityPoints = hidden ? 150 : 0;
        int shinyPoints = shiny ? 750 : 0;
        int fishingBonus = fishing ? Math.max(0, (int)Math.round(Math.abs(scale - 1.0D) * 220.0D)) : 0;
        long total = Math.max(1L, rarity + ivPoints + sizePoints + abilityPoints + shinyPoints + fishingBonus);
        return new Result(display, speciesId, ivs, 186, scale, size, weight, shiny, abilityName, hidden, total);
    }

    private static int rarityPoints(GachaTier tier) {
        if (tier == null) return 100;
        return switch (tier) {
            case COMMON -> 100;
            case UNCOMMON -> 175;
            case RARE -> 275;
            case EPIC -> 400;
            case LEGENDARY -> 500;
            case MYTHICAL, SPECIAL -> 525;
        };
    }

    private static int exceptionalSizePoints(double scale) {
        double delta = Math.abs(scale - 1.0D);
        if (delta < 0.025D) return 15;
        return Math.min(250, 25 + (int)Math.round(delta * 900.0D));
    }

    private static String sizeLabel(double scale) {
        if (scale < 0.80D) return "XXS";
        if (scale < 0.90D) return "XS";
        if (scale < 0.98D) return "S";
        if (scale <= 1.02D) return "M";
        if (scale <= 1.10D) return "L";
        if (scale <= 1.20D) return "XL";
        return "XXL";
    }

    private static int ivTotal(Pokemon pokemon) {
        try {
            Object ivs = pokemon.getIvs();
            if (ivs instanceof Map<?, ?> map) {
                int total = 0;
                for (Object value : map.values()) if (value instanceof Number number) total += number.intValue();
                if (total > 0) return Math.min(186, total);
            }
            if (ivs instanceof Iterable<?> iterable) {
                int total = 0;
                for (Object value : iterable) {
                    if (value instanceof Map.Entry<?, ?> entry && entry.getValue() instanceof Number number) total += number.intValue();
                    else if (value instanceof Number number) total += number.intValue();
                }
                if (total > 0) return Math.min(186, total);
            }
            for (String name : new String[]{"getValues", "asMap", "toMap"}) {
                Object value = invoke(ivs, name);
                if (value instanceof Map<?, ?> map) {
                    int total = 0;
                    for (Object iv : map.values()) if (iv instanceof Number number) total += number.intValue();
                    if (total > 0) return Math.min(186, total);
                }
            }
        } catch (Throwable ignored) { }
        return 0;
    }

    private static String abilityName(Object ability) {
        if (ability == null) return "";
        Object template = invoke(ability, "getTemplate");
        if (template != null) {
            String value = string(invoke(template, "getName"), "");
            if (!value.isBlank()) return value;
            value = string(invoke(template, "getDisplayName"), "");
            if (!value.isBlank()) return value;
        }
        return string(ability, "");
    }

    private static boolean hiddenAbility(Object ability) {
        if (ability == null) return false;
        Object template = invoke(ability, "getTemplate");
        for (Object target : new Object[]{ability, template}) {
            if (target == null) continue;
            for (String method : new String[]{"getHidden", "isHidden", "getIsHidden"}) {
                Object value = invoke(target, method);
                if (value instanceof Boolean bool) return bool;
            }
        }
        return false;
    }

    private static Object invoke(Object target, String name) {
        if (target == null) return null;
        try {
            Method method = target.getClass().getMethod(name);
            method.setAccessible(true);
            return method.invoke(target);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static double number(Object value, double fallback) {
        return value instanceof Number number ? number.doubleValue() : fallback;
    }

    private static boolean bool(Object value, boolean fallback) {
        return value instanceof Boolean bool ? bool : fallback;
    }

    private static String string(Object value, String fallback) {
        if (value == null) return fallback;
        String text = String.valueOf(value);
        return text.isBlank() ? fallback : text;
    }

    public record Result(String displayName, String speciesId, int ivTotal, int ivMaximum, double scale,
                         String sizeCategory, double weight, boolean shiny, String ability,
                         boolean hiddenAbility, long score) {
        public String compactDetail() {
            StringBuilder text = new StringBuilder();
            text.append(displayName).append(" · ").append(sizeCategory);
            if (weight > 0.0D) text.append(String.format(Locale.ROOT, " · %.1f kg", weight));
            text.append(" · IV ").append(ivTotal).append('/').append(ivMaximum);
            if (hiddenAbility) text.append(" · Habilidad oculta");
            if (shiny) text.append(" · ✨ SHINY");
            return text.toString();
        }
    }
}
