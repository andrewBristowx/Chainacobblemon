package com.andrewbristowx.chainacobblemon.events;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.tower.ChallengeTowerService;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Central reward policy shared by every Chaina Event. */
public final class EventRewardService {
    private EventRewardService() { }

    public static void rewardPlace(ServerPlayerEntity player, ChainaEventType type, int place, boolean activeParticipant) {
        if (player == null || type == null) return;
        long xp;
        long coins;
        if (place == 1) { xp = 750L; coins = 2_500L; }
        else if (place == 2) { xp = 450L; coins = 1_500L; }
        else if (place == 3) { xp = 250L; coins = 750L; }
        else if (activeParticipant) { xp = 75L; coins = 150L; }
        else return;

        Chainacobblemon.battlePassService().addXp(player, xp, "chaina_event:" + type.id + ":place_" + place);
        Chainacobblemon.progressionService().adminGive(player, coins, "chaina_event_" + type.id);
        player.sendMessage(Text.literal("§d✦ Evento Chaina · §f+" + xp + " XP del Pase §7· §6+" + coins + " ChaiBells"), false);
        if (place == 1) {
            ChallengeTowerService.openExternalRoulette(player,
                    "✦ RULETA DEL CAMPEÓN ✦",
                    type.displayName + " · 1.º puesto",
                    true);
        }
    }
}
