package com.andrewbristowx.chainacobblemon.events;

import com.andrewbristowx.chainacobblemon.events.treasure.TreasureHuntService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class EventCommands {
    private EventCommands() { }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerAll(dispatcher));
    }

    private static void registerAll(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("chainacobblemon")
                .then(literal("event")
                        .then(literal("join").executes(ctx -> ChainaEventManager.join(ctx.getSource().getPlayerOrThrow()) ? 1 : 0))
                        .then(literal("leave").executes(ctx -> { ChainaEventManager.leave(ctx.getSource().getPlayerOrThrow()); return 1; }))
                        .then(literal("status").executes(ctx -> { ctx.getSource().sendFeedback(() -> Text.literal(ChainaEventManager.status()), false); return 1; }))
                        .then(literal("start").requires(src -> src.hasPermissionLevel(4))
                                .then(argument("tipo", StringArgumentType.word()).executes(ctx -> {
                                    ChainaEventType type = ChainaEventType.parse(StringArgumentType.getString(ctx, "tipo"));
                                    if (type == null) { ctx.getSource().sendError(Text.literal("Tipo: fishing, safari, beauty, mining o treasure")); return 0; }
                                    return ChainaEventManager.start(ctx.getSource().getServer(), type, ctx.getSource().getPlayer(), false) ? 1 : 0;
                                })))
                        .then(literal("stop").requires(src -> src.hasPermissionLevel(4)).executes(ctx -> { ChainaEventManager.stop(ctx.getSource().getServer(), "detenido por admin"); return 1; }))
                        .then(literal("test").requires(src -> src.hasPermissionLevel(4))
                                .then(literal("fishing").executes(ctx -> test(ctx, ChainaEventType.FISHING)))
                                .then(literal("safari").executes(ctx -> test(ctx, ChainaEventType.SAFARI)))
                                .then(literal("beauty").executes(ctx -> test(ctx, ChainaEventType.BEAUTY)))
                                .then(literal("mining").executes(ctx -> test(ctx, ChainaEventType.MINING)))
                                .then(literal("treasure")
                                        .executes(ctx -> test(ctx, ChainaEventType.TREASURE))
                                        .then(argument("tier", IntegerArgumentType.integer(1, 5)).executes(ctx -> {
                                            TreasureHuntService.forceNextTier(IntegerArgumentType.getInteger(ctx, "tier"));
                                            return test(ctx, ChainaEventType.TREASURE);
                                        }))))
                        .then(literal("treasure").requires(src -> src.hasPermissionLevel(4))
                                .then(literal("scan").executes(ctx -> {
                                    ctx.getSource().sendFeedback(() -> Text.literal(TreasureHuntService.scanSummary(ctx.getSource().getServer().getOverworld())), false); return 1;
                                }))
                                .then(literal("templates").executes(ctx -> {
                                    ctx.getSource().sendFeedback(() -> Text.literal(TreasureHuntService.scanSummary(ctx.getSource().getServer().getOverworld())), false); return 1;
                                }))
                                .then(literal("tier").then(argument("numero", IntegerArgumentType.integer(1, 5)).executes(ctx -> {
                                    int tier = IntegerArgumentType.getInteger(ctx, "numero");
                                    TreasureHuntService.forceNextTier(tier);
                                    ctx.getSource().sendFeedback(() -> Text.literal("§aLa próxima Cacería usará tier " + tier + "."), false);
                                    return 1;
                                })))
                                .then(literal("spawn").then(argument("tier", IntegerArgumentType.integer(1, 5)).executes(ctx -> {
                                    int tier = IntegerArgumentType.getInteger(ctx, "tier");
                                    return TreasureHuntService.spawnSpecific(ctx.getSource().getServer(), ctx.getSource().getPlayerOrThrow(), Integer.toString(tier), false) ? 1 : 0;
                                })))
                                .then(literal("tp")
                                        .executes(ctx -> TreasureHuntService.teleportAdmin(ctx.getSource().getPlayerOrThrow(), "entrance", 0) ? 1 : 0)
                                        .then(literal("entrance").executes(ctx -> TreasureHuntService.teleportAdmin(ctx.getSource().getPlayerOrThrow(), "entrance", 0) ? 1 : 0))
                                        .then(literal("final").executes(ctx -> TreasureHuntService.teleportAdmin(ctx.getSource().getPlayerOrThrow(), "final", 0) ? 1 : 0))
                                        .then(literal("room").then(argument("numero", IntegerArgumentType.integer(1, 10)).executes(ctx ->
                                                TreasureHuntService.teleportAdmin(ctx.getSource().getPlayerOrThrow(), "room", IntegerArgumentType.getInteger(ctx,"numero")) ? 1 : 0))))
                                .then(literal("debug").executes(ctx -> { ctx.getSource().sendFeedback(() -> Text.literal(TreasureHuntService.debugSummary()), false); return 1; }))
                                .then(literal("cleanup").executes(ctx -> {
                                    TreasureHuntService.cleanup(ctx.getSource().getServer(), true);
                                    ctx.getSource().sendFeedback(() -> Text.literal("§aLaberintos, NPCs, Pokémon temporales y Poké Balls de Cacería limpiados."), false);
                                    return 1;
                                }))
                                .then(literal("buildmode").executes(ctx -> { TreasureHuntService.toggleBuildMode(ctx.getSource().getPlayerOrThrow()); return 1; }))))) ;
    }

    private static int test(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx, ChainaEventType type) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        return ChainaEventManager.start(ctx.getSource().getServer(), type, ctx.getSource().getPlayerOrThrow(), true) ? 1 : 0;
    }
}
