package com.andrewbristowx.chainacobblemon.twitch;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.Heightmap;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Converts durable ChainaBridge support events into configurable Minecraft rewards/effects.
 * Rules and pending deliveries are persisted. Twitch credentials never enter the mod.
 */
final class TwitchSupportRewardService {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final long POLL_INTERVAL_TICKS = 40L;
    private static final long DELIVERY_INTERVAL_TICKS = 15L * 20L;
    private static final int MAX_PENDING = 1000;

    private final Path stateFile;
    private final TwitchProfileStore profiles;
    private volatile State state = new State();
    private volatile MinecraftServer server;
    private long nextPollTick;
    private long nextDeliveryTick;
    private boolean pollInFlight;
    private WaterDropChallenge waterDrop;

    TwitchSupportRewardService(ConfigManager configManager, TwitchProfileStore profiles) {
        this.stateFile = configManager.configDirectory().resolve("twitch").resolve("support-rewards.json");
        this.profiles = profiles;
    }

    void initialize() {
        load();
        seedDefaultsIfNeeded();
        save();
    }

    void serverStarted(MinecraftServer server) {
        this.server = server;
        this.nextPollTick = 20L;
        this.nextDeliveryTick = 40L;
    }

    void serverStopping() {
        save();
        server = null;
        waterDrop = null;
    }

    void playerJoined(ServerPlayerEntity player) {
        if (player == null) return;
        resolvePendingForProfile(player.getUuid());
        if (state.targetUuid != null && state.targetUuid.equals(player.getUuid().toString()) && !state.pending.isEmpty()) {
            player.sendMessage(Text.literal("✦ TWITCH · Hay " + pendingFor(player.getUuid()) + " efecto(s) del directo esperando para ti.")
                    .formatted(Formatting.LIGHT_PURPLE), false);
        }
    }

    void onProfileSynced(UUID playerId) {
        resolvePendingForProfile(playerId);
    }

    void tick(MinecraftServer minecraftServer, long ticks, TwitchBridgeClient bridge) {
        if (server == null) server = minecraftServer;
        tickWaterDrop();
        if (bridge != null && bridge.configured() && ticks >= nextPollTick && !pollInFlight) {
            nextPollTick = ticks + POLL_INTERVAL_TICKS;
            pollInFlight = true;
            long after = state.lastSequence;
            bridge.supportEvents(after, 200).whenComplete((batch, error) -> minecraftServer.execute(() -> {
                pollInFlight = false;
                if (error != null) {
                    Chainacobblemon.LOGGER.debug("Could not poll Twitch support events: {}", safe(error));
                    return;
                }
                if (batch == null) return;
                boolean changed = false;
                for (TwitchBridgeClient.SupportEvent event : batch.events()) {
                    if (event.sequence() <= state.lastSequence) continue;
                    state.lastSequence = event.sequence();
                    changed = true;
                    if (state.active && event.timestamp() >= state.sessionStartedAtEpochSeconds) {
                        processEvent(event, false);
                    }
                }
                if (batch.latestSequence() > state.lastSequence && !state.active) {
                    state.lastSequence = batch.latestSequence();
                    changed = true;
                }
                if (changed) save();
            }));
        }
        if (ticks >= nextDeliveryTick) {
            nextDeliveryTick = ticks + DELIVERY_INTERVAL_TICKS;
            deliverOnePending();
        }
    }

    void startSession(TwitchBridgeClient bridge, java.util.function.Consumer<String> callback) {
        if (bridge == null || !bridge.configured()) {
            callback.accept("ChainaBridge no está configurado.");
            return;
        }
        if (state.active) {
            callback.accept("Los eventos Twitch ya están activos.");
            return;
        }
        bridge.supportEvents(state.lastSequence, 0).whenComplete((batch, error) -> execute(() -> {
            if (error != null || batch == null) {
                callback.accept("No se pudo fijar el inicio: " + safe(error));
                return;
            }
            state.lastSequence = Math.max(state.lastSequence, batch.latestSequence());
            state.active = true;
            state.sessionStartedAtEpochSeconds = Instant.now().getEpochSecond();
            state.giftSubTotals.clear();
            state.giftHighestThresholdFired.clear();
            save();
            callback.accept("Eventos Twitch ACTIVOS desde ahora · secuencia base " + state.lastSequence + ".");
        }));
    }

    String stopSession() {
        if (!state.active) return "Los eventos Twitch ya estaban detenidos.";
        state.active = false;
        state.sessionStartedAtEpochSeconds = 0L;
        state.giftSubTotals.clear();
        state.giftHighestThresholdFired.clear();
        save();
        return "Eventos Twitch DETENIDOS. Las recompensas ya pendientes se conservan.";
    }

    String setTarget(ServerPlayerEntity player) {
        if (player == null) return "Jugador objetivo inválido.";
        state.targetUuid = player.getUuidAsString();
        state.targetName = player.getGameProfile().getName();
        save();
        return "Objetivo de los efectos CHAINA: " + state.targetName + ".";
    }

    String statusLine() {
        return (state.active ? "ACTIVOS" : "DETENIDOS")
                + " · objetivo=" + (state.targetName == null || state.targetName.isBlank() ? "sin configurar" : state.targetName)
                + " · reglas=" + state.rules.size()
                + " · pendientes=" + state.pending.size()
                + " · último_evento=" + state.lastSequence;
    }

    List<String> rulesLines() {
        if (state.rules.isEmpty()) return List.of("No hay recompensas configuradas.");
        List<String> lines = new ArrayList<>();
        for (Rule rule : state.rules) {
            lines.add("#" + rule.id + " · " + rule.eventType + ">=" + rule.threshold + " · " + rule.destination
                    + " · " + describeAction(rule));
        }
        return lines;
    }

    String addRule(String eventType, int threshold, String destination, String action,
                   String value, int count, double chance, String command) {
        String type = normalizeEventType(eventType);
        String dest = normalizeDestination(destination);
        String act = action == null ? "" : action.toLowerCase(Locale.ROOT);
        if (type.isBlank() || dest.isBlank()) return "Tipo de evento/destino inválido.";
        Rule rule = new Rule();
        rule.id = state.nextRuleId++;
        rule.eventType = type;
        rule.threshold = Math.max(1, threshold);
        rule.destination = dest;
        rule.action = act;
        rule.value = value == null ? "" : value.toLowerCase(Locale.ROOT);
        rule.count = Math.max(0, count);
        rule.chance = Math.max(0.0D, Math.min(100.0D, chance));
        rule.command = command == null ? "" : stripSlash(command.strip());
        if (!validRule(rule)) return "Esa recompensa no es válida.";
        state.rules.add(rule);
        save();
        return "Recompensa creada #" + rule.id + " · " + describeAction(rule) + ".";
    }

    String deleteRule(int id) {
        boolean removed = state.rules.removeIf(rule -> rule.id == id);
        if (!removed) return "No existe la recompensa #" + id + ".";
        save();
        return "Recompensa #" + id + " eliminada.";
    }

    String clearRules() {
        int count = state.rules.size();
        state.rules.clear();
        save();
        return "Se eliminaron " + count + " recompensa(s) personalizadas.";
    }

    String simulate(String type, int amount, int tier, ServerPlayerEntity actor) {
        String userId = actor == null ? "test-twitch-user" : "test-" + actor.getUuid();
        String login = actor == null ? "tester" : actor.getGameProfile().getName().toLowerCase(Locale.ROOT);
        String mcUuid = actor == null ? "" : actor.getUuidAsString();
        TwitchBridgeClient.SupportEvent event = new TwitchBridgeClient.SupportEvent(
                Long.MAX_VALUE - ThreadLocalRandom.current().nextInt(1_000_000), "test-" + UUID.randomUUID(),
                normalizeEventType(type), Math.max(1, amount), Math.max(0, Math.min(3, tier)),
                userId, login, false, Instant.now().getEpochSecond(), "TEST", mcUuid);
        int before = state.pending.size();
        processEvent(event, true);
        int added = state.pending.size() - before;
        deliverOnePending();
        return "TEST " + type + "=" + amount + " · " + added + " efecto(s) encolado(s).";
    }

    private void processEvent(TwitchBridgeClient.SupportEvent event, boolean test) {
        String type = normalizeEventType(event.type());
        if (type.isBlank()) return;
        int matchedThreshold;
        if ("giftsubs".equals(type)) {
            String key = event.anonymous() ? "anonymous" : (!event.twitchUserId().isBlank() ? event.twitchUserId() : event.twitchLogin());
            int total = state.giftSubTotals.merge(key, Math.max(0, event.amount()), Integer::sum);
            int previous = state.giftHighestThresholdFired.getOrDefault(key, 0);
            matchedThreshold = highestThreshold(type, total);
            if (matchedThreshold <= previous) return;
            state.giftHighestThresholdFired.put(key, matchedThreshold);
        } else if ("sub".equals(type)) {
            matchedThreshold = highestThreshold(type, Math.max(1, event.tier()));
        } else {
            matchedThreshold = highestThreshold(type, event.amount());
        }
        if (matchedThreshold <= 0) return;

        for (Rule rule : state.rules) {
            if (!rule.eventType.equals(type) || rule.threshold != matchedThreshold) continue;
            queue(rule, event, test);
        }
        save();
    }

    private int highestThreshold(String type, int value) {
        int best = 0;
        for (Rule rule : state.rules) {
            if (rule.eventType.equals(type) && rule.threshold <= value) best = Math.max(best, rule.threshold);
        }
        return best;
    }

    private void queue(Rule rule, TwitchBridgeClient.SupportEvent event, boolean test) {
        if (state.pending.size() >= MAX_PENDING) {
            Chainacobblemon.LOGGER.warn("Twitch support pending queue full; dropping rule {}", rule.id);
            return;
        }
        Pending pending = new Pending();
        pending.id = UUID.randomUUID().toString();
        pending.ruleId = rule.id;
        pending.destination = rule.destination;
        pending.action = rule.action;
        pending.value = rule.value;
        pending.count = rule.count;
        pending.chance = rule.chance;
        pending.command = rule.command;
        pending.twitchUserId = event.twitchUserId();
        pending.twitchLogin = event.twitchLogin();
        pending.eventAmount = event.amount();
        pending.tier = event.tier();
        pending.createdAt = Instant.now().getEpochSecond();
        pending.test = test;
        if ("chaina".equals(rule.destination)) {
            pending.targetUuid = state.targetUuid == null ? "" : state.targetUuid;
        } else if (!event.minecraftUuid().isBlank()) {
            pending.targetUuid = event.minecraftUuid();
        }
        state.pending.add(pending);
        announceQueued(pending, event);
    }

    private void announceQueued(Pending pending, TwitchBridgeClient.SupportEvent event) {
        MinecraftServer local = server;
        if (local == null) return;
        String actor = event.anonymous() || event.twitchLogin().isBlank() ? "Anónimo" : "@" + event.twitchLogin();
        String source = switch (event.type()) {
            case "bits" -> event.amount() + " Bits";
            case "giftsubs" -> event.amount() + " Gift Sub(s)";
            case "sub" -> "SUB Tier " + Math.max(1, event.tier());
            default -> event.type();
        };
        local.getPlayerManager().broadcast(Text.literal("✦ TWITCH · " + actor + " · " + source + " → " + describePending(pending))
                .formatted(Formatting.LIGHT_PURPLE), false);
    }

    private void deliverOnePending() {
        MinecraftServer local = server;
        if (local == null || state.pending.isEmpty()) return;
        for (int i = 0; i < state.pending.size(); i++) {
            Pending pending = state.pending.get(i);
            resolvePendingTarget(pending);
            UUID targetId = parseUuid(pending.targetUuid);
            if (targetId == null) continue;
            ServerPlayerEntity target = local.getPlayerManager().getPlayer(targetId);
            if (target == null) continue;
            if (("shuffle".equals(pending.action) || "waterdrop".equals(pending.action)) && playerBusy(target)) continue;
            boolean done = executePending(target, pending);
            if (done) {
                state.pending.remove(i);
                save();
            }
            return;
        }
    }

    private void resolvePendingTarget(Pending pending) {
        if (parseUuid(pending.targetUuid) != null) return;
        if ("chaina".equals(pending.destination)) {
            pending.targetUuid = state.targetUuid == null ? "" : state.targetUuid;
            return;
        }
        if (pending.twitchUserId == null || pending.twitchUserId.isBlank()) return;
        UUID id = profiles.findMinecraftUuidByTwitchUserId(pending.twitchUserId);
        if (id != null) pending.targetUuid = id.toString();
    }

    private void resolvePendingForProfile(UUID playerId) {
        TwitchProfile profile = profiles.get(playerId);
        if (profile == null || !profile.linked || profile.twitchUserId == null || profile.twitchUserId.isBlank()) return;
        boolean changed = false;
        for (Pending pending : state.pending) {
            if ("donador".equals(pending.destination) && (pending.targetUuid == null || pending.targetUuid.isBlank())
                    && profile.twitchUserId.equals(pending.twitchUserId)) {
                pending.targetUuid = playerId.toString();
                changed = true;
            }
        }
        if (changed) save();
    }

    private boolean executePending(ServerPlayerEntity target, Pending pending) {
        try {
            return switch (pending.action) {
                case "command" -> executeCommand(target, pending);
                case "tickets" -> giveTickets(target, pending.value, pending.count);
                case "pokemon" -> giveRandomPokemon(target, pending.chance);
                case "shuffle" -> shuffleInventory(target);
                case "waterdrop" -> startWaterDrop(target);
                default -> true;
            };
        } catch (Exception error) {
            Chainacobblemon.LOGGER.warn("Could not execute Twitch support reward {}", pending.id, error);
            return false;
        }
    }

    private boolean executeCommand(ServerPlayerEntity target, Pending pending) {
        MinecraftServer local = server;
        if (local == null || pending.command == null || pending.command.isBlank()) return true;
        String command = pending.command
                .replace("{player}", target.getGameProfile().getName())
                .replace("{target}", target.getGameProfile().getName())
                .replace("{uuid}", target.getUuidAsString())
                .replace("{twitch}", pending.twitchLogin == null ? "" : pending.twitchLogin)
                .replace("{amount}", Integer.toString(pending.eventAmount))
                .replace("{tier}", Integer.toString(pending.tier));
        local.getCommandManager().executeWithPrefix(local.getCommandSource().withSilent(), stripSlash(command));
        target.sendMessage(Text.literal("✦ TWITCH · Recompensa personalizada ejecutada.").formatted(Formatting.LIGHT_PURPLE), false);
        return true;
    }

    private boolean giveTickets(ServerPlayerEntity player, String type, int count) {
        Item item = switch (type == null ? "" : type) {
            case "chaina" -> ModRegistries.CHAINA_SPECIAL_BANNER_TICKET;
            case "tesoro", "treasure" -> ModRegistries.TREASURE_GACHA_TICKET;
            default -> ModRegistries.GACHA_TICKET;
        };
        give(player, item, Math.max(1, count));
        player.sendMessage(Text.literal("✦ TWITCH · Recibiste " + Math.max(1, count) + " ticket(s) " + type + ".")
                .formatted(Formatting.LIGHT_PURPLE), false);
        return true;
    }

    private boolean giveRandomPokemon(ServerPlayerEntity player, double shinyChancePercent) {
        MinecraftServer local = player.getServer();
        if (local == null) return false;
        boolean shiny = ThreadLocalRandom.current().nextDouble(100.0D) < shinyChancePercent;
        String command = "givepokemonother " + player.getGameProfile().getName() + " random level="
                + ThreadLocalRandom.current().nextInt(15, 51) + (shiny ? " shiny=true" : "");
        local.getCommandManager().executeWithPrefix(local.getCommandSource().withSilent(), command);
        player.sendMessage(Text.literal("✦ TWITCH · ¡Un Pokémon aleatorio ha llegado!" + (shiny ? " ✨ SHINY" : ""))
                .formatted(shiny ? Formatting.GOLD : Formatting.LIGHT_PURPLE), false);
        return true;
    }

    private boolean shuffleInventory(ServerPlayerEntity player) {
        List<ItemStack> stacks = new ArrayList<>(36);
        for (int slot = 0; slot < 36; slot++) stacks.add(player.getInventory().getStack(slot).copy());
        Collections.shuffle(stacks, ThreadLocalRandom.current());
        for (int slot = 0; slot < 36; slot++) player.getInventory().setStack(slot, stacks.get(slot));
        player.getInventory().markDirty();
        player.sendMessage(Text.literal("✦ TWITCH CAOS · ¡Tu inventario fue revuelto!").formatted(Formatting.RED, Formatting.BOLD), false);
        return true;
    }

    private boolean startWaterDrop(ServerPlayerEntity player) {
        if (waterDrop != null) return false;
        ServerWorld world = player.getServerWorld();
        int x = player.getBlockX();
        int z = player.getBlockZ();
        int groundY = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        int topYInclusive = world.getBottomY() + world.getHeight() - 1;
        if (groundY < world.getBottomY() + 2 || groundY > topYInclusive - 55) return false;
        int launchY = Math.min(topYInclusive - 5, groundY + 48);
        player.teleport(world, x + 0.5D, launchY, z + 0.5D, player.getYaw(), player.getPitch());
        player.fallDistance = 0.0F;
        waterDrop = new WaterDropChallenge(player.getUuid(), groundY, 0, 0L);
        player.sendMessage(Text.literal("✦ TWITCH CAOS · WATER DROP · Prepárate para caer…").formatted(Formatting.AQUA, Formatting.BOLD), false);
        return true;
    }

    private void tickWaterDrop() {
        WaterDropChallenge challenge = waterDrop;
        MinecraftServer local = server;
        if (challenge == null || local == null) return;
        ServerPlayerEntity player = local.getPlayerManager().getPlayer(challenge.playerId());
        if (player == null || !player.isAlive()) { waterDrop = null; return; }
        if (challenge.phase() == 0) {
            player.fallDistance = 0.0F;
            if (player.getY() <= challenge.groundY() + 9.0D && player.getVelocity().y < -0.1D) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 24, 4, false, true, true));
                player.fallDistance = 0.0F;
                waterDrop = new WaterDropChallenge(player.getUuid(), challenge.groundY(), 1, local.getTicks() + 30L);
                player.sendMessage(Text.literal("✦ TWITCH · ¡LEVITACIÓN! Enseguida viene la caída real…").formatted(Formatting.YELLOW), false);
            }
        } else if (challenge.phase() == 1 && local.getTicks() >= challenge.releaseTick()) {
            player.removeStatusEffect(StatusEffects.LEVITATION);
            player.fallDistance = 0.0F;
            giveWaterBucketHotbar(player);
            waterDrop = new WaterDropChallenge(player.getUuid(), challenge.groundY(), 2, local.getTicks() + 20L * 20L);
            player.sendMessage(Text.literal("✦ TWITCH · ¡CUBO DE AGUA! Haz el water drop.").formatted(Formatting.AQUA, Formatting.BOLD), false);
        } else if (challenge.phase() == 2 && (player.isOnGround() || local.getTicks() >= challenge.releaseTick())) {
            waterDrop = null;
        }
    }

    private void giveWaterBucketHotbar(ServerPlayerEntity player) {
        int slot = ThreadLocalRandom.current().nextInt(9);
        ItemStack previous = player.getInventory().getStack(slot).copy();
        player.getInventory().setStack(slot, new ItemStack(Items.WATER_BUCKET));
        if (!previous.isEmpty()) {
            if (!player.getInventory().insertStack(previous)) player.dropItem(previous, false);
        }
        player.getInventory().selectedSlot = slot;
        player.getInventory().markDirty();
    }

    private boolean playerBusy(ServerPlayerEntity player) {
        // Cobblemon 1.7.3 is compiled against Mojmap while this Fabric project uses Yarn.
        // Calling BattleRegistry directly from Java therefore leaks ServerPlayer's Mojmap
        // signature into compilation. Resolve the stable Cobblemon class/method reflectively
        // and pass the runtime player object instead; this also avoids a hard failure if the
        // battle implementation changes in a later Cobblemon build.
        try {
            Class<?> registryClass = Class.forName("com.cobblemon.mod.common.battles.BattleRegistry");
            Object instance = registryClass.getField("INSTANCE").get(null);
            for (java.lang.reflect.Method method : registryClass.getMethods()) {
                if (!"getBattleByParticipatingPlayer".equals(method.getName()) || method.getParameterCount() != 1) continue;
                return method.invoke(instance, player) != null;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private void give(ServerPlayerEntity player, Item item, int amount) {
        int remaining = Math.max(1, amount);
        while (remaining > 0) {
            int count = Math.min(item.getMaxCount(), remaining);
            ItemStack stack = new ItemStack(item, count);
            player.getInventory().insertStack(stack);
            if (!stack.isEmpty()) player.dropItem(stack, false);
            remaining -= count;
        }
        player.getInventory().markDirty();
    }

    private int pendingFor(UUID playerId) {
        int count = 0;
        for (Pending pending : state.pending) if (playerId.toString().equals(pending.targetUuid)) count++;
        return count;
    }

    private void seedDefaultsIfNeeded() {
        if (!state.rules.isEmpty() || state.defaultsSeeded) return;
        state.defaultsSeeded = true;
        addRule("bits", 100, "chaina", "pokemon", "", 1, 0.0D, "");
        addRule("bits", 1000, "chaina", "pokemon", "", 1, 10.0D, "");
        addRule("giftsubs", 5, "chaina", "tickets", "chaina", 10, 0.0D, "");
    }

    private boolean validRule(Rule rule) {
        if (rule.threshold <= 0) return false;
        return switch (rule.action) {
            case "command" -> rule.command != null && !rule.command.isBlank();
            case "tickets" -> rule.count > 0 && List.of("normal", "chaina", "tesoro", "treasure").contains(rule.value);
            case "pokemon" -> rule.chance >= 0.0D && rule.chance <= 100.0D;
            case "shuffle", "waterdrop" -> true;
            default -> false;
        };
    }

    private static String normalizeEventType(String value) {
        if (value == null) return "";
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "bits" -> "bits";
            case "sub", "subs" -> "sub";
            case "giftsub", "giftsubs", "gift_subs" -> "giftsubs";
            default -> "";
        };
    }

    private static String normalizeDestination(String value) {
        if (value == null) return "";
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "chaina" -> "chaina";
            case "donador", "donor" -> "donador";
            default -> "";
        };
    }

    private static String describeAction(Rule rule) {
        return switch (rule.action) {
            case "command" -> "comando /" + rule.command;
            case "tickets" -> rule.count + " ticket(s) " + rule.value;
            case "pokemon" -> "Pokémon aleatorio · shiny " + formatChance(rule.chance) + "%";
            case "shuffle" -> "revolver inventario";
            case "waterdrop" -> "Water Drop";
            default -> rule.action;
        };
    }

    private static String describePending(Pending pending) {
        return switch (pending.action) {
            case "command" -> "recompensa personalizada";
            case "tickets" -> pending.count + " tickets " + pending.value;
            case "pokemon" -> "Pokémon aleatorio" + (pending.chance > 0 ? " (shiny " + formatChance(pending.chance) + "%)" : "");
            case "shuffle" -> "CAOS: inventario revuelto";
            case "waterdrop" -> "CAOS: Water Drop";
            default -> pending.action;
        };
    }

    private static String formatChance(double value) {
        return value == Math.rint(value) ? Integer.toString((int) value) : String.format(Locale.ROOT, "%.2f", value);
    }

    private void load() {
        try {
            Files.createDirectories(stateFile.getParent());
            if (Files.notExists(stateFile)) return;
            try (Reader reader = Files.newBufferedReader(stateFile, StandardCharsets.UTF_8)) {
                State loaded = GSON.fromJson(reader, State.class);
                if (loaded != null) state = loaded;
            }
        } catch (Exception error) {
            Chainacobblemon.LOGGER.warn("Could not load Twitch support rewards; starting with defaults", error);
            state = new State();
        }
        normalizeState();
    }

    synchronized void save() {
        normalizeState();
        try {
            Files.createDirectories(stateFile.getParent());
            Path temp = stateFile.resolveSibling(stateFile.getFileName() + ".tmp");
            try (Writer writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) { GSON.toJson(state, writer); }
            try {
                Files.move(temp, stateFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temp, stateFile, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception error) {
            Chainacobblemon.LOGGER.warn("Could not save Twitch support rewards", error);
        }
    }

    private void normalizeState() {
        if (state.rules == null) state.rules = new ArrayList<>();
        if (state.pending == null) state.pending = new ArrayList<>();
        if (state.giftSubTotals == null) state.giftSubTotals = new LinkedHashMap<>();
        if (state.giftHighestThresholdFired == null) state.giftHighestThresholdFired = new LinkedHashMap<>();
        int maxId = 0;
        for (Rule rule : state.rules) maxId = Math.max(maxId, rule.id);
        state.nextRuleId = Math.max(Math.max(1, state.nextRuleId), maxId + 1);
    }

    private void execute(Runnable runnable) {
        MinecraftServer local = server;
        if (local != null) local.execute(runnable); else runnable.run();
    }

    private static UUID parseUuid(String value) {
        try { return value == null || value.isBlank() ? null : UUID.fromString(value); }
        catch (IllegalArgumentException ignored) { return null; }
    }

    private static String stripSlash(String value) {
        String result = value == null ? "" : value.strip();
        while (result.startsWith("/")) result = result.substring(1);
        return result;
    }

    private static String safe(Throwable error) {
        if (error == null) return "desconocido";
        Throwable value = error;
        while (value.getCause() != null) value = value.getCause();
        String message = value.getMessage();
        return message == null || message.isBlank() ? value.getClass().getSimpleName() : message;
    }

    private static final class State {
        boolean active;
        long sessionStartedAtEpochSeconds;
        long lastSequence;
        String targetUuid = "";
        String targetName = "";
        int nextRuleId = 1;
        boolean defaultsSeeded;
        List<Rule> rules = new ArrayList<>();
        List<Pending> pending = new ArrayList<>();
        Map<String, Integer> giftSubTotals = new LinkedHashMap<>();
        Map<String, Integer> giftHighestThresholdFired = new LinkedHashMap<>();
    }

    private static final class Rule {
        int id;
        String eventType = "";
        int threshold;
        String destination = "chaina";
        String action = "";
        String value = "";
        int count;
        double chance;
        String command = "";
    }

    private static final class Pending {
        String id = "";
        int ruleId;
        String destination = "";
        String targetUuid = "";
        String twitchUserId = "";
        String twitchLogin = "";
        String action = "";
        String value = "";
        int count;
        double chance;
        String command = "";
        int eventAmount;
        int tier;
        long createdAt;
        boolean test;
    }

    private record WaterDropChallenge(UUID playerId, int groundY, int phase, long releaseTick) { }
}
