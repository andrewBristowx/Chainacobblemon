package com.andrewbristowx.chainacobblemon.challenge;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.npc.NpcBattleService;
import com.andrewbristowx.chainacobblemon.npc.NpcNetworking;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.progress.network.ProgressionNetworking;
import com.andrewbristowx.chainacobblemon.tower.ChallengeTowerService;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class ChallengeService {
    private static final String PROFESSOR_TITLE = "Profesora Pokémon";

    private ChallengeService() {
    }

    public static boolean isChallengeNpc(ServiceNpcEntity npc) {
        return npc != null && ChallengeCatalog.byNpcId(npc.npcId()) != null;
    }

    public static boolean isProfessor(ServiceNpcEntity npc) {
        return npc != null && ChallengeCatalog.PROFESSOR_NPC_ID.equalsIgnoreCase(npc.npcId());
    }

    public static NpcNetworking.DialogueState dialogueState(ServerPlayerEntity player, ServiceNpcEntity npc) {
        ChallengeProfile profile = ChallengeCatalog.byNpcId(npc.npcId());
        if (profile == null) {
            if (isProfessor(npc)) return professorState(player, false);
            return null;
        }
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        boolean defeated = data.defeatedTrainers.contains(profile.key());
        boolean unlocked = profile.prerequisiteKey().isBlank() || data.defeatedTrainers.contains(profile.prerequisiteKey());
        List<String> pages;
        if (!unlocked) {
            ChallengeProfile required = ChallengeCatalog.byKey(profile.prerequisiteKey());
            String requirement = required == null ? profile.prerequisiteKey() : required.displayName();
            pages = List.of(
                    "Este desafío todavía está bloqueado para ti.",
                    "Primero derrota a " + requirement + ". Después vuelve y podremos combatir."
            );
        } else if (defeated) {
            pages = profile.rematchPages();
        } else {
            pages = profile.introPages();
        }
        List<NpcNetworking.DialogueChoice> choices = new ArrayList<>();
        if (unlocked) {
            choices.add(new NpcNetworking.DialogueChoice("battle", defeated ? "⚔ Revancha" : "⚔ Desafiar",
                    "Inicia un combate con la IA de RCT."));
        }
        choices.add(new NpcNetworking.DialogueChoice("missions", "📖 Misiones", "Abre tu progreso Pokémon."));
        choices.add(new NpcNetworking.DialogueChoice("close", "Salir", "Cierra el diálogo."));
        RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
        DynamicTrainerLevelService.ScalingResult scaling = DynamicTrainerLevelService.scale(player, profile);
        String adaptive = scaling.scaled() ? " · Equipo adaptativo ~Nv." + scaling.targetMax() : "";
        String reward = rewardDescription(profile, defeated) + adaptive
                + (cap.available() && cap.cap() > 0 ? " · Límite Cobbleverse: " + cap.cap() : "");
        return new NpcNetworking.DialogueState(
                npc.npcId(), profile.displayName(), profile.subtitle(), pages, choices,
                reward, false, defeated, defeated, !unlocked
        );
    }

    public static boolean handleDialogueAction(ServerPlayerEntity player, ServiceNpcEntity npc, String rawAction) {
        String action = rawAction == null ? "" : rawAction.trim().toLowerCase(Locale.ROOT);
        if (isProfessor(npc)) {
            return switch (action) {
                case "missions" -> {
                    ProgressionNetworking.open(player, "progression");
                    yield true;
                }
                case "gyms_info" -> {
                    NpcNetworking.sendDialogue(player, professorState(player, true));
                    yield true;
                }
                case "tower" -> ChallengeTowerService.start(player, false);
                case "tower_info" -> {
                    NpcNetworking.sendDialogue(player, professorTowerState(player));
                    yield true;
                }
                case "close" -> true;
                default -> false;
            };
        }
        ChallengeProfile profile = ChallengeCatalog.byNpcId(npc.npcId());
        if (profile == null) return false;
        return switch (action) {
            case "battle" -> {
                if (!canChallenge(player, profile, true)) yield true;
                yield NpcBattleService.start(player, npc);
            }
            case "missions" -> {
                ProgressionNetworking.open(player, "progression");
                yield true;
            }
            case "close" -> true;
            default -> false;
        };
    }

    public static boolean canChallenge(ServerPlayerEntity player, ChallengeProfile profile, boolean message) {
        if (profile == null) return false;
        if (profile.prerequisiteKey().isBlank()) return true;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        if (data.defeatedTrainers.contains(profile.prerequisiteKey())) return true;
        if (message) {
            ChallengeProfile required = ChallengeCatalog.byKey(profile.prerequisiteKey());
            player.sendMessage(Text.literal("§ePrimero debes derrotar a §f"
                    + (required == null ? profile.prerequisiteKey() : required.displayName()) + "§e."), false);
        }
        return false;
    }

    public static void onVictory(ServerPlayerEntity player, ServiceNpcEntity npc) {
        ChallengeProfile profile = ChallengeCatalog.byNpcId(npc.npcId());
        if (profile == null) return;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        boolean firstVictory = data.defeatedTrainers.add(profile.key());
        Chainacobblemon.progressionService().recordRegionalTrainerVictory(player, profile.key());
        if (firstVictory) {
            if (!profile.badgeName().isBlank()) grantBadge(player, profile);
            boolean rctSynced = RctCobbleverseBridge.syncChainaVictoryToRct(player, profile);
            Chainacobblemon.playerDataManager().saveNow(player.getUuid());
            player.sendMessage(Text.literal("§d✦ Desafío completado: §f" + profile.displayName()
                    + " §7(" + profile.regionName() + ")" + (rctSynced ? " §a· progreso Radical sincronizado" : "")), false);
        }
        NpcNetworking.sendDialogue(player, victoryState(profile, firstVictory));
    }

    public static boolean hasDefeated(ServerPlayerEntity player, String trainerKey) {
        if (player == null || trainerKey == null) return false;
        return Chainacobblemon.playerDataManager().getOrLoad(player.getUuid()).defeatedTrainers.contains(trainerKey);
    }

    private static NpcNetworking.DialogueState victoryState(ChallengeProfile profile, boolean firstVictory) {
        List<String> pages = profile.victoryPages().isEmpty()
                ? List.of("Buen combate. Has ganado.") : profile.victoryPages();
        List<NpcNetworking.DialogueChoice> choices = List.of(
                new NpcNetworking.DialogueChoice("missions", "📖 Ver progreso", "Abre las misiones Pokémon."),
                new NpcNetworking.DialogueChoice("close", "Continuar", "Vuelve al mundo.")
        );
        String reward = firstVictory
                ? firstVictoryReward(profile)
                : (profile.isLeader() ? "Revancha completada · la medalla solo se entrega una vez"
                : "Revancha completada · progreso regional ya registrado");
        return new NpcNetworking.DialogueState(profile.npcId(), profile.displayName(), profile.subtitle(), pages,
                choices, reward, false, true, true, false);
    }


    private static String rewardDescription(ChallengeProfile profile, boolean defeated) {
        if (profile.isLeader()) {
            return profile.badgeName() + (defeated ? " · ya registrada" : " · primera victoria")
                    + " · ChaiBells/XP desde la misión regional";
        }
        if (profile.isChampion()) {
            return (defeated ? "Campeón regional · ya derrotado" : "Título regional · primera victoria")
                    + " · ChaiBells/XP desde la misión de Liga";
        }
        return (defeated ? "Alto Mando · ya derrotado" : "Progreso del Alto Mando · primera victoria")
                + " · ChaiBells/XP desde la misión de Liga";
    }

    private static String firstVictoryReward(ChallengeProfile profile) {
        if (profile.isLeader()) return profile.badgeName() + " · victoria registrada";
        if (profile.isChampion()) return "Campeón de " + profile.regionName() + " · victoria registrada";
        return "Alto Mando de " + profile.regionName() + " · victoria registrada";
    }

    private static NpcNetworking.DialogueState professorState(ServerPlayerEntity player, boolean details) {
        List<String> pages = details ? List.of(
                "Los líderes del spawn son desafíos persistentes: no dependen de que su gimnasio se genere en el mundo.",
                "Si prefieres explorar, puedes seguir buscando los gimnasios naturales de Cobbleverse. Tus victorias pueden alimentar el mismo progreso regional.",
                "Los circuitos incluidos aquí son Kanto, Johto, Hoenn y Sinnoh: 8 líderes, 4 miembros del Alto Mando y 1 Campeón por región.",
                "Cuando completes las cuatro regiones desbloquearás la Torre Desafío: diez combates consecutivos en una dimensión propia, con rivales adaptados a tu equipo."
        ) : List.of(
                "¡Hola! Soy la Profesora Chaina. Voy a ayudarte a organizar tu aventura sin quitarte la libertad de explorar.",
                "En el spawn puedes encontrar líderes regionales permanentes, pero también puedes recorrer el mundo y descubrir gimnasios y estructuras en el orden que quieras.",
                ChallengeTowerService.unlocked(player)
                        ? "Ya has completado las cuatro regiones. La Torre Desafío está disponible como tu prueba endgame."
                        : "Al completar Kanto, Johto, Hoenn y Sinnoh desbloquearás mi Torre Desafío."
        );
        List<NpcNetworking.DialogueChoice> choices = new ArrayList<>();
        choices.add(new NpcNetworking.DialogueChoice("missions", "📖 Ver misiones", "Abre el Diario de aventuras."));
        choices.add(new NpcNetworking.DialogueChoice("gyms_info", "🏅 Cómo funcionan", "Explica los desafíos regionales."));
        choices.add(new NpcNetworking.DialogueChoice("tower_info", "🏰 Torre Desafío", ChallengeTowerService.professorSummary(player)));
        if (ChallengeTowerService.unlocked(player) && ChallengeTowerService.cooldownRemaining(player) <= 0L) {
            choices.add(new NpcNetworking.DialogueChoice("tower", "⚔ Entrar a la Torre", "Inicia un intento desde el Piso 1."));
        }
        choices.add(new NpcNetworking.DialogueChoice("close", "Salir", "Cierra el diálogo."));
        return new NpcNetworking.DialogueState(ChallengeCatalog.PROFESSOR_NPC_ID, "Profesora Chaina", PROFESSOR_TITLE,
                pages, choices, "Regiones + Torre Desafío · " + ChallengeTowerService.professorSummary(player), false, false, false, false);
    }

    private static NpcNetworking.DialogueState professorTowerState(ServerPlayerEntity player) {
        boolean unlocked = ChallengeTowerService.unlocked(player);
        List<String> pages = unlocked ? List.of(
                "La Torre Desafío tiene 10 pisos. Si ganas un combate subirás al siguiente; si pierdes, regresarás al mundo normal y podrás intentarlo otra vez de inmediato.",
                "Tras los pisos 3 y 6 la dificultad sube. El décimo piso presenta al Maestro de la Torre con una batalla especial.",
                "Los rivales usan equipos aleatorios y su nivel se calcula desde tus tres Pokémon de mayor nivel. Completar los 10 pisos entrega 10 tiradas de cada gasha.",
                ChallengeTowerService.cooldownRemaining(player) > 0L
                        ? "Ya reclamaste el premio de este ciclo. Podrás volver a competir en " + ChallengeTowerService.cooldownText(player) + "."
                        : "La Torre está lista. Si la completas, el premio volverá a estar disponible dentro de 4 días."
        ) : List.of(
                "La Torre Desafío es mi prueba final para entrenadores que ya dominaron las cuatro regiones.",
                "Completa Kanto, Johto, Hoenn y Sinnoh para desbloquearla. Tus misiones de exploración no necesitan esperar: puedes descubrir estructuras en cualquier orden."
        );
        List<NpcNetworking.DialogueChoice> choices = new ArrayList<>();
        if (unlocked && ChallengeTowerService.cooldownRemaining(player) <= 0L) {
            choices.add(new NpcNetworking.DialogueChoice("tower", "⚔ Entrar ahora", "Teletransporte al Piso 1."));
        }
        choices.add(new NpcNetworking.DialogueChoice("missions", "📖 Ver misiones", "Abre el Diario."));
        choices.add(new NpcNetworking.DialogueChoice("close", "Volver", "Cierra el diálogo."));
        return new NpcNetworking.DialogueState(ChallengeCatalog.PROFESSOR_NPC_ID, "Profesora Chaina", "Torre Desafío",
                pages, choices, ChallengeTowerService.professorSummary(player), false, false, false, !unlocked);
    }

    private static void grantBadge(ServerPlayerEntity player, ChallengeProfile profile) {
        Item badge = findBadge(profile.badgeName());
        if (badge == null) {
            player.sendMessage(Text.literal("§eLa victoria quedó registrada, pero no encontré el objeto §f"
                    + profile.badgeName() + "§e en el registro. No se perderá tu progreso."), false);
            Chainacobblemon.LOGGER.warn("Cobbleverse badge item not found for {} ({})", profile.key(), profile.badgeName());
            return;
        }
        ItemStack stack = new ItemStack(badge, 1);
        if (!player.getInventory().insertStack(stack)) player.dropItem(stack, false);
        player.sendMessage(Text.literal("§6🏅 Obtuviste: §f" + profile.badgeName()), false);
    }

    private static Item findBadge(String badgeName) {
        String slug = badgeName == null ? "" : badgeName.toLowerCase(Locale.ROOT)
                .replace("badge", "")
                .replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
        if (slug.isBlank()) return null;
        return Registries.ITEM.getIds().stream()
                .filter(id -> id.getPath().contains("badge") && id.getPath().contains(slug))
                .sorted(Comparator.comparingInt(ChallengeService::badgePriority))
                .map(Registries.ITEM::get)
                .filter(item -> item != net.minecraft.item.Items.AIR)
                .findFirst().orElse(null);
    }

    private static int badgePriority(Identifier id) {
        String namespace = id.getNamespace();
        String path = id.getPath();
        int score = 100;
        if (namespace.contains("cobbleverse")) score -= 50;
        if (path.endsWith("_badge")) score -= 20;
        if (path.startsWith("badge_")) score -= 10;
        if (path.contains("box")) score += 200;
        return score;
    }
}
