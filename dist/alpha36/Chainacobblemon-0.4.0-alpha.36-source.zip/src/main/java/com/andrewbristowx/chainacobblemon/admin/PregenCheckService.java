package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Final-map readiness check. It is deliberately read-only and never generates/locates chunks. */
public final class PregenCheckService {
    private PregenCheckService() {}

    public record Result(boolean ready, List<String> blockers, List<String> notes) {}

    public static Result check(ServerCommandSource source) {
        List<String> blockers = new ArrayList<>();
        List<String> notes = new ArrayList<>();

        FabricLoader loader = FabricLoader.getInstance();
        requireMod(loader, blockers, "cobblemon", "Cobblemon");
        requireMod(loader, blockers, "fabric-api", "Fabric API");
        if (!loader.isModLoaded("rctmod")) notes.add("RCT no fue detectado por mod id 'rctmod'; el escalado seguirá usando el fallback de Chainacobblemon si corresponde.");

        RegionalStructureAuditService.AuditResult structures = RegionalStructureAuditService.audit(source.getServer());
        if (!structures.ready()) {
            for (RegionalStructureAuditService.RegionResult region : structures.regions().values()) {
                if (!region.complete()) blockers.add(region.region() + ": faltan " + String.join(", ", region.missing()));
            }
        }
        if (structures.assetOnlyMatches() > 0) {
            notes.add(structures.assetOnlyMatches() + " grupos regionales se detectan por assets/plantillas del datapack y no por un ID equivalente en STRUCTURE; esto es válido para contenido colocado por lógica de Cobbleverse.");
        }
        notes.add("La Máquina de Resurrección de Cobblemon se excluye correctamente del worldgen: es un multibloque construible, no una estructura regional generada.");
        notes.add("El gimnasio doble de Hoenn se valida con la nomenclatura Cobbleverse Tell & Pat (checkpoint canónico hoenn_tell; alias hoenn_pat).");
        notes.add("El reset alpha.9 conserva la serie y el límite de nivel RCT; el escalado de desafíos nunca reduce el límite de nivel.");
        notes.add("Los mods de dungeons y la campaña de Chaina se validan por separado antes del mapa final.");
        return new Result(blockers.isEmpty(), List.copyOf(blockers), List.copyOf(notes));
    }

    public static int report(ServerCommandSource source) {
        Result result = check(source);
        source.sendFeedback(() -> Text.literal("§d§lChainacobblemon · PreGen Check " + Chainacobblemon.VERSION), false);
        if (result.ready()) {
            source.sendFeedback(() -> Text.literal("§aBASE REGIONAL LISTA. §7No hay bloqueos de Chainacobblemon para preparar el mapa final."), false);
        } else {
            source.sendFeedback(() -> Text.literal("§cNO PREGENERES TODAVÍA. §7Se encontraron bloqueos:"), false);
            for (String blocker : result.blockers()) {
                source.sendFeedback(() -> Text.literal("  §c✘ §f" + blocker), false);
            }
        }
        for (String note : result.notes()) {
            source.sendFeedback(() -> Text.literal("  §7• " + note), false);
        }
        source.sendFeedback(() -> Text.literal("§8Este comando no ejecuta /locate, no genera chunks y no modifica el límite de nivel."), false);
        return result.ready() ? 1 : 0;
    }

    private static void requireMod(FabricLoader loader, List<String> blockers, String id, String name) {
        if (!loader.isModLoaded(id)) blockers.add(name + " (mod id " + id + ") no está cargado.");
    }
}
