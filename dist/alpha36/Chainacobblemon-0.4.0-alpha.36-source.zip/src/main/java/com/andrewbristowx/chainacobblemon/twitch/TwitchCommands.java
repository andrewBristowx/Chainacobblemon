package com.andrewbristowx.chainacobblemon.twitch;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class TwitchCommands {
    private TwitchCommands() { }

    public static void register(TwitchService service) {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> registerCommands(dispatcher, service));
    }

    private static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, TwitchService service) {
        dispatcher.register(literal("twitch")
                .executes(context -> openAdminSelfOrExplain(context.getSource(), service))
                // This is intentionally the only normal-player Twitch command. It is invoked by the private chat prompt.
                .then(literal("vincular_directo").executes(context -> playerAction(context.getSource(), service, "link_direct")))
                .then(literal("admin")
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes(context -> openAdminSelf(context.getSource(), service))
                        .then(argument("jugador", EntityArgumentType.player())
                                .executes(context -> openAdminTarget(context.getSource(), service,
                                        EntityArgumentType.getPlayer(context, "jugador"))))));

        LiteralArgumentBuilder<ServerCommandSource> test = literal("test")
                .requires(source -> source.hasPermissionLevel(2))
                .then(literal("online").executes(context -> testChannel(context.getSource(), service, true)))
                .then(literal("offline").executes(context -> testChannel(context.getSource(), service, false)))
                .then(literal("nosub").executes(context -> testTier(context.getSource(), service, 0)))
                .then(literal("sub")
                        .then(literal("1").executes(context -> testTier(context.getSource(), service, 1)))
                        .then(literal("2").executes(context -> testTier(context.getSource(), service, 2)))
                        .then(literal("3").executes(context -> testTier(context.getSource(), service, 3))));

        dispatcher.register(literal("chaina")
                .then(literal("twitch")
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes(context -> openAdminSelf(context.getSource(), service))
                        .then(literal("status").executes(context -> {
                            ServerPlayerEntity player = context.getSource().getPlayer();
                            if (player == null) return 0;
                            context.getSource().sendFeedback(() -> Text.literal(service.statusLine(player)), false);
                            return 1;
                        }))
                        .then(literal("admin")
                                .then(argument("jugador", EntityArgumentType.player())
                                        .executes(context -> openAdminTarget(context.getSource(), service,
                                                EntityArgumentType.getPlayer(context, "jugador")))))
                        .then(literal("bonus")
                                .executes(context -> streamBonusStatus(context.getSource(), service))
                                .then(literal("reroll").executes(context -> rerollStreamBonus(context.getSource(), service))))
                        .then(supportEvents(service))
                        .then(test)));
    }


    private static LiteralArgumentBuilder<ServerCommandSource> supportEvents(TwitchService service) {
        LiteralArgumentBuilder<ServerCommandSource> rewards = literal("recompensa")
                .then(literal("listar").executes(context -> listSupportRules(context.getSource(), service)))
                .then(literal("borrar")
                        .then(argument("id", IntegerArgumentType.integer(1))
                                .executes(context -> feedback(context.getSource(), service.deleteSupportRule(IntegerArgumentType.getInteger(context, "id"))))))
                .then(literal("borrar_todas").executes(context -> feedback(context.getSource(), service.clearSupportRules())));

        rewards.then(ruleEventNode(service, "bits", "cantidad", 1, 1_000_000));
        rewards.then(ruleEventNode(service, "giftsubs", "cantidad", 1, 1000));
        rewards.then(ruleEventNode(service, "sub", "tier", 1, 3));

        return literal("eventos")
                .executes(context -> feedback(context.getSource(), service.supportEventsStatus()))
                .then(literal("iniciar").executes(context -> startSupportEvents(context.getSource(), service)))
                .then(literal("detener").executes(context -> feedback(context.getSource(), service.stopSupportEvents())))
                .then(literal("estado").executes(context -> feedback(context.getSource(), service.supportEventsStatus())))
                .then(literal("objetivo")
                        .then(argument("jugador", EntityArgumentType.player())
                                .executes(context -> feedback(context.getSource(), service.setSupportTarget(EntityArgumentType.getPlayer(context, "jugador"))))))
                .then(rewards)
                .then(literal("test")
                        .then(literal("bits")
                                .then(argument("cantidad", IntegerArgumentType.integer(1, 1_000_000))
                                        .executes(context -> testSupport(context.getSource(), service, "bits", IntegerArgumentType.getInteger(context, "cantidad"), 0))))
                        .then(literal("giftsubs")
                                .then(argument("cantidad", IntegerArgumentType.integer(1, 1000))
                                        .executes(context -> testSupport(context.getSource(), service, "giftsubs", IntegerArgumentType.getInteger(context, "cantidad"), 0))))
                        .then(literal("sub")
                                .then(argument("tier", IntegerArgumentType.integer(1, 3))
                                        .executes(context -> testSupport(context.getSource(), service, "sub", 1, IntegerArgumentType.getInteger(context, "tier"))))));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> ruleEventNode(TwitchService service, String type,
                                                                              String amountArg, int min, int max) {
        LiteralArgumentBuilder<ServerCommandSource> event = literal(type);
        var amount = argument(amountArg, IntegerArgumentType.integer(min, max));
        amount.then(ruleDestinationNode(service, type, amountArg, "chaina"));
        amount.then(ruleDestinationNode(service, type, amountArg, "donador"));
        event.then(amount);
        return event;
    }

    private static LiteralArgumentBuilder<ServerCommandSource> ruleDestinationNode(TwitchService service, String type,
                                                                                    String amountArg, String destination) {
        LiteralArgumentBuilder<ServerCommandSource> target = literal(destination);
        target.then(literal("revolver")
                .executes(context -> addRule(context, service, type, amountArg, destination,
                        "shuffle", "", 0, 0.0D, "")));
        target.then(literal("waterdrop")
                .executes(context -> addRule(context, service, type, amountArg, destination,
                        "waterdrop", "", 0, 0.0D, "")));
        target.then(literal("pokemon")
                .executes(context -> addRule(context, service, type, amountArg, destination,
                        "pokemon", "", 1, 0.0D, ""))
                .then(argument("shiny_porcentaje", IntegerArgumentType.integer(0, 100))
                        .executes(context -> addRule(context, service, type, amountArg, destination,
                                "pokemon", "", 1, IntegerArgumentType.getInteger(context, "shiny_porcentaje"), ""))));
        target.then(literal("tickets")
                .then(literal("normal")
                        .then(argument("cantidad_tickets", IntegerArgumentType.integer(1, 640))
                                .executes(context -> addRule(context, service, type, amountArg, destination,
                                        "tickets", "normal", IntegerArgumentType.getInteger(context, "cantidad_tickets"), 0.0D, ""))))
                .then(literal("chaina")
                        .then(argument("cantidad_tickets", IntegerArgumentType.integer(1, 640))
                                .executes(context -> addRule(context, service, type, amountArg, destination,
                                        "tickets", "chaina", IntegerArgumentType.getInteger(context, "cantidad_tickets"), 0.0D, ""))))
                .then(literal("tesoro")
                        .then(argument("cantidad_tickets", IntegerArgumentType.integer(1, 640))
                                .executes(context -> addRule(context, service, type, amountArg, destination,
                                        "tickets", "tesoro", IntegerArgumentType.getInteger(context, "cantidad_tickets"), 0.0D, "")))));
        target.then(literal("comando")
                .then(argument("comando", StringArgumentType.greedyString())
                        .executes(context -> addRule(context, service, type, amountArg, destination,
                                "command", "", 0, 0.0D, StringArgumentType.getString(context, "comando")))));
        return target;
    }

    private static int addRule(CommandContext<ServerCommandSource> context, TwitchService service, String type, String amountArg,
                               String destination, String action, String value, int count, double chance, String command) {
        int threshold = IntegerArgumentType.getInteger(context, amountArg);
        return feedback(context.getSource(), service.addSupportRule(type, threshold, destination, action, value, count, chance, command));
    }

    private static int startSupportEvents(ServerCommandSource source, TwitchService service) {
        service.startSupportEvents(message -> source.getServer().execute(() -> source.sendFeedback(() -> Text.literal("§d✦ TWITCH §f" + message), false)));
        source.sendFeedback(() -> Text.literal("§d✦ TWITCH §7Sincronizando el punto de inicio con ChainaBridge…"), false);
        return 1;
    }

    private static int listSupportRules(ServerCommandSource source, TwitchService service) {
        source.sendFeedback(() -> Text.literal("§d✦ RECOMPENSAS TWITCH"), false);
        for (String line : service.supportRuleLines()) source.sendFeedback(() -> Text.literal("§7" + line), false);
        return 1;
    }

    private static int testSupport(ServerCommandSource source, TwitchService service, String type, int amount, int tier) {
        return feedback(source, service.testSupportEvent(type, amount, tier, source.getPlayer()));
    }

    private static int feedback(ServerCommandSource source, String message) {
        source.sendFeedback(() -> Text.literal("§d✦ TWITCH §f" + message), false);
        return 1;
    }

    private static int openAdminSelfOrExplain(ServerCommandSource source, TwitchService service) {
        if (!source.hasPermissionLevel(2)) {
            source.sendFeedback(() -> Text.literal("§d✦ CHAINA × TWITCH §7La vinculación se gestiona desde el aviso privado del chat."), false);
            return 1;
        }
        return openAdminSelf(source, service);
    }

    private static int openAdminSelf(ServerCommandSource source, TwitchService service) {
        ServerPlayerEntity admin = source.getPlayer();
        if (admin == null) {
            source.sendFeedback(() -> Text.literal("Este panel debe abrirse como jugador administrador."), false);
            return 0;
        }
        service.openAdmin(admin, admin, "Panel administrativo Twitch.");
        return 1;
    }

    private static int openAdminTarget(ServerCommandSource source, TwitchService service, ServerPlayerEntity target) {
        ServerPlayerEntity admin = source.getPlayer();
        if (admin == null) {
            source.sendFeedback(() -> Text.literal("Este panel debe abrirse como jugador administrador."), false);
            return 0;
        }
        service.openAdmin(admin, target, "Estado de " + target.getGameProfile().getName());
        return 1;
    }

    private static int playerAction(ServerCommandSource source, TwitchService service, String action) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendFeedback(() -> Text.literal("Este comando Twitch debe ejecutarse como jugador."), false);
            return 0;
        }
        service.handleAction(player, action);
        return 1;
    }

    private static int testTier(ServerCommandSource source, TwitchService service, int tier) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;
        boolean ok = service.debugSetTier(player, tier);
        if (!ok) source.sendFeedback(() -> Text.literal("§cLos comandos test solo funcionan con twitch.mode=development."), false);
        return ok ? 1 : 0;
    }

    private static int testChannel(ServerCommandSource source, TwitchService service, boolean online) {
        boolean ok = service.debugSetChannel(online);
        if (!ok) source.sendFeedback(() -> Text.literal("§cLos comandos test solo funcionan con twitch.mode=development."), false);
        return ok ? 1 : 0;
    }
    private static int streamBonusStatus(ServerCommandSource source, TwitchService service) {
        source.sendFeedback(() -> Text.literal("§d✦ BONUS STREAM §f" + service.streamBonusStatusLine()), false);
        return 1;
    }

    private static int rerollStreamBonus(ServerCommandSource source, TwitchService service) {
        boolean ok = service.rerollStreamBonusesForTesting();
        if (!ok) {
            source.sendFeedback(() -> Text.literal("§cSolo se pueden volver a sortear los bonus mientras Chaina está EN VIVO y el sistema está activo."), false);
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§d✦ Nuevos bonus del directo: §f" + service.streamBonusStatusLine()), false);
        return 1;
    }

}
