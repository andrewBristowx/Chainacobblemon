package com.andrewbristowx.chainacobblemon.events;

import java.util.ArrayList;
import java.util.List;

/** Compact server-authoritative sidebar state for Chaina Events. */
public final class EventHudSnapshot {
    public boolean visible;
    public String eventId = "";
    public String title = "";
    public String subtitle = "";
    public String timer = "";
    public String footer = "";
    public String accent = "pink";
    public List<Entry> entries = new ArrayList<>();

    public static final class Entry {
        public int rank;
        public String player = "";
        public String value = "";
        public String detail = "";
        public boolean self;

        public Entry() { }

        public Entry(int rank, String player, String value, String detail, boolean self) {
            this.rank = rank;
            this.player = player;
            this.value = value;
            this.detail = detail;
            this.self = self;
        }
    }
}
