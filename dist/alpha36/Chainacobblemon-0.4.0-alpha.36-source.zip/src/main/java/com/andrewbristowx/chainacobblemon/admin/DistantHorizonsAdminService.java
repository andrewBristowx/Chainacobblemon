package com.andrewbristowx.chainacobblemon.admin;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

/**
 * Soft command bridge for Distant Horizons 2.3+ server support.
 *
 * <p>It deliberately does not disable Distant Generation after pregen: DH requires that toggle enabled on the server
 * in order to serve generated LODs to clients. Instead CHAINA permanently switches the generator to PRE_EXISTING_ONLY
 * and clamps DH's server generation bounds to the same square as the Minecraft world border. That prevents DH from
 * creating vanilla chunks outside the finalized map while preserving LOD delivery.</p>
 */
public final class DistantHorizonsAdminService {
    private DistantHorizonsAdminService() {}

    public static int prepare(ServerCommandSource source) {
        if (!available()) {
            source.sendFeedback(() -> Text.literal("§cDistant Horizons no está instalado en el servidor. §7Para LODs server-side usa DH 2.3+ y la misma build recomendada en cliente/servidor."), false);
            return 0;
        }
        if (source.getPlayer() == null) {
            source.sendFeedback(() -> Text.literal("§eEjecuta este comando dentro del juego como OP. Algunas builds DH 2.3.x no aceptan /dh pregen desde consola."), false);
            return 0;
        }
        FullWorldPregenService.BorderPlan plan = FullWorldPregenService.appliedPlan(source.getServer());
        if (plan == null) {
            source.sendFeedback(() -> Text.literal("§cPrimero aplica el world border final de CHAINA."), false);
            return 0;
        }

        boolean mode = execute(source, "dh config generation.mode PRE_EXISTING_ONLY");
        boolean x = execute(source, "dh config generation.bounds.x " + plan.centerX());
        boolean z = execute(source, "dh config generation.bounds.z " + plan.centerZ());
        boolean radius = execute(source, "dh config generation.bounds.radius " + plan.radiusBlocks());

        if (!(mode && x && z && radius)) {
            source.sendFeedback(() -> Text.literal("§cDH no aceptó una o más claves de configuración. §7Comprueba tu versión con /dh config. "
                    + "Objetivo: generation.mode=PRE_EXISTING_ONLY y bounds X/Z/radius iguales al world border."), false);
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§a§lDISTANT HORIZONS PREPARADO PARA CHAINA"), false);
        source.sendFeedback(() -> Text.literal("§7Modo: §fPRE_EXISTING_ONLY §7· límites: centro §fX " + plan.centerX() + " Z "
                + plan.centerZ() + " §7· radio §f" + plan.radiusBlocks() + " bloques."), false);
        source.sendFeedback(() -> Text.literal("§8No desactivamos Distant Generation: DH necesita ese sistema activo para entregar LODs a los clientes. "
                + "PRE_EXISTING_ONLY + el límite cuadrado evita crear terreno nuevo."), false);
        return 1;
    }

    public static int start(ServerCommandSource source) {
        if (!available()) {
            source.sendFeedback(() -> Text.literal("§cDistant Horizons no está instalado en el servidor."), false);
            return 0;
        }
        if (source.getPlayer() == null) {
            source.sendFeedback(() -> Text.literal("§eEjecuta este comando dentro del juego como OP."), false);
            return 0;
        }
        if (!FullWorldPregenService.isFinishedAndBorderValid(source.getServer())) {
            source.sendFeedback(() -> Text.literal("§cPrimero termina la pregeneración completa del Overworld con Chunky."), false);
            return 0;
        }
        FullWorldPregenService.BorderPlan plan = FullWorldPregenService.appliedPlan(source.getServer());
        if (plan == null) return 0;

        // Re-apply the safety settings immediately before DH starts.
        if (prepare(source) == 0) return 0;
        int radiusChunks = plan.distantHorizonsRadiusChunks();
        boolean ok = execute(source, "dh pregen start overworld " + plan.centerX() + " " + plan.centerZ() + " " + radiusChunks);
        if (!ok) {
            source.sendFeedback(() -> Text.literal("§cDH rechazó el pregen. §7Prueba /dh pregen status y revisa que tu build sea 2.3+."), false);
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§dDH pregen iniciado: §fsolo chunks ya existentes§d. Radio de escaneo §f"
                + radiusChunks + " chunks§d (incluye las esquinas del borde cuadrado)."), false);
        return 1;
    }

    public static int status(ServerCommandSource source) {
        if (!available()) {
            source.sendFeedback(() -> Text.literal("§cDistant Horizons no está instalado en el servidor."), false);
            return 0;
        }
        return execute(source, "dh pregen status") ? 1 : 0;
    }

    public static int stop(ServerCommandSource source) {
        if (!available()) {
            source.sendFeedback(() -> Text.literal("§cDistant Horizons no está instalado en el servidor."), false);
            return 0;
        }
        boolean ok = execute(source, "dh pregen stop");
        if (ok) source.sendFeedback(() -> Text.literal("§eDH pregen detenido. §7El modo PRE_EXISTING_ONLY y los límites del mapa permanecen."), false);
        return ok ? 1 : 0;
    }

    private static boolean available() {
        return FabricLoader.getInstance().isModLoaded("distanthorizons");
    }

    private static boolean execute(ServerCommandSource source, String command) {
        try {
            source.getServer().getCommandManager().executeWithPrefix(source, command);
            return true;
        } catch (RuntimeException exception) {
            return false;
        }
    }
}
