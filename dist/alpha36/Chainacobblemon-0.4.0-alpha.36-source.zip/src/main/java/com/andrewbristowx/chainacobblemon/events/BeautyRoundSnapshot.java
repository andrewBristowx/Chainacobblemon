package com.andrewbristowx.chainacobblemon.events;

import java.util.ArrayList;
import java.util.List;

public final class BeautyRoundSnapshot {
    public int round;
    public int lives = 3;
    public boolean eliminated;
    public long revealUntilEpochMillis;
    public long responseUntilEpochMillis;
    public String message = "";
    public List<String> sequence = new ArrayList<>();
    public List<String> options = new ArrayList<>();
}
