package com.andrewbristowx.chainacobblemon.events;

import java.util.Locale;

public enum ChainaEventType {
    FISHING("fishing", "🎣 Concurso de Pesca Chaina", 10 * 60, 8),
    SAFARI("safari", "🌿 Safari Chaina", 15 * 60, 8),
    BEAUTY("beauty", "✨ Exhibición Chaina", 12 * 60, 7),
    MINING("mining", "⛏ Fiebre Minera Chaina", 10 * 60, 7),
    TREASURE("treasure", "🗺 Cacería del Tesoro Chaina", 25 * 60, 3);

    public final String id;
    public final String displayName;
    public final int defaultDurationSeconds;
    public final int autoWeight;

    ChainaEventType(String id, String displayName, int defaultDurationSeconds, int autoWeight) {
        this.id = id;
        this.displayName = displayName;
        this.defaultDurationSeconds = defaultDurationSeconds;
        this.autoWeight = autoWeight;
    }

    public static ChainaEventType parse(String value) {
        if (value == null) return null;
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        for (ChainaEventType type : values()) {
            if (type.id.equals(normalized) || type.name().toLowerCase(Locale.ROOT).equals(normalized)) return type;
        }
        return switch (normalized) {
            case "pesca" -> FISHING;
            case "zafari", "safari" -> SAFARI;
            case "belleza", "exhibicion", "exhibición" -> BEAUTY;
            case "mineria", "minería", "mina" -> MINING;
            case "tesoro", "caceria", "cacería" -> TREASURE;
            default -> null;
        };
    }
}
