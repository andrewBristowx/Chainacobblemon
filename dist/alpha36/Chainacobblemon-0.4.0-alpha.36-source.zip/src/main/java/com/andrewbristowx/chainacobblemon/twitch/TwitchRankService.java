package com.andrewbristowx.chainacobblemon.twitch;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ChainacobblemonConfig;
import net.minecraft.server.network.ServerPlayerEntity;

import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Optional LuckPerms rank overlay. Never changes the player's primary group. */
final class TwitchRankService {
    private TwitchRankService() { }

    static void sync(ServerPlayerEntity player, TwitchProfile profile, ChainacobblemonConfig.TwitchSettings settings) {
        if (player == null || profile == null || settings == null) return;
        Set<String> managed = new LinkedHashSet<>();
        add(managed, settings.linkedGroup);
        add(managed, settings.tier1Group);
        add(managed, settings.tier2Group);
        add(managed, settings.tier3Group);
        add(managed, settings.vipTwitchGroup);
        add(managed, settings.moderatorTwitchGroup);

        Set<String> desired = desiredGroups(profile, settings);
        try {
            Class<?> provider = Class.forName("net.luckperms.api.LuckPermsProvider");
            Object luckPerms = provider.getMethod("get").invoke(null);
            Class<?> luckPermsApi = Class.forName("net.luckperms.api.LuckPerms");
            Object userManager = luckPermsApi.getMethod("getUserManager").invoke(luckPerms);
            Class<?> userManagerApi = Class.forName("net.luckperms.api.model.user.UserManager");
            Object user = userManagerApi.getMethod("getUser", UUID.class).invoke(userManager, player.getUuid());
            if (user == null) return;

            Class<?> permissionHolderApi = Class.forName("net.luckperms.api.model.PermissionHolder");
            Object data = permissionHolderApi.getMethod("data").invoke(user);
            Class<?> inheritanceNode = Class.forName("net.luckperms.api.node.types.InheritanceNode");
            Method builder = inheritanceNode.getMethod("builder", String.class);
            Class<?> nodeBuilderApi = Class.forName("net.luckperms.api.node.NodeBuilder");
            Class<?> nodeApi = Class.forName("net.luckperms.api.node.Node");
            Class<?> nodeMapApi = Class.forName("net.luckperms.api.model.data.NodeMap");
            Method remove = nodeMapApi.getMethod("remove", nodeApi);
            Method addNode = nodeMapApi.getMethod("add", nodeApi);

            for (String group : managed) {
                Object nodeBuilder = builder.invoke(null, group);
                Object node = nodeBuilderApi.getMethod("build").invoke(nodeBuilder);
                remove.invoke(data, node);
            }
            for (String group : desired) {
                Object nodeBuilder = builder.invoke(null, group);
                Object node = nodeBuilderApi.getMethod("build").invoke(nodeBuilder);
                addNode.invoke(data, node);
            }
            userManagerApi.getMethod("saveUser", Class.forName("net.luckperms.api.model.user.User")).invoke(userManager, user);
            LuckPermsBootstrap.invalidate(player.getUuid());
        } catch (ClassNotFoundException ignored) {
            // Singleplayer/default Fabric mode: internal Twitch state remains active without LuckPerms.
        } catch (Throwable exception) {
            Chainacobblemon.LOGGER.warn("Could not synchronize optional Twitch LuckPerms groups for {}",
                    player.getGameProfile().getName(), exception);
        }
    }

    static String label(TwitchProfile profile) {
        if (profile == null || !profile.linked) return "Sin vincular";
        return switch (profile.tier) {
            case 3 -> "SUB CHAINA III";
            case 2 -> "SUB CHAINA II";
            case 1 -> "SUB CHAINA I";
            default -> "TWITCH";
        };
    }

    static String roleLabel(TwitchProfile profile) {
        if (profile == null || !profile.linked || !profile.twitchRolesKnown) return "";
        if (profile.twitchModerator) return "MOD TWITCH";
        if (profile.twitchVip) return "VIP TWITCH";
        return "";
    }

    private static Set<String> desiredGroups(TwitchProfile profile, ChainacobblemonConfig.TwitchSettings settings) {
        LinkedHashSet<String> desired = new LinkedHashSet<>();
        if (!profile.linked) return desired;
        String subscription = switch (profile.tier) {
            case 3 -> settings.tier3Group;
            case 2 -> settings.tier2Group;
            case 1 -> settings.tier1Group;
            default -> settings.linkedGroup;
        };
        add(desired, subscription);
        if (profile.twitchVip) add(desired, settings.vipTwitchGroup);
        if (profile.twitchModerator) add(desired, settings.moderatorTwitchGroup);
        return desired;
    }

    private static void add(Set<String> groups, String value) {
        if (value == null || value.isBlank()) return;
        groups.add(value.strip().toLowerCase(Locale.ROOT));
    }
}
