package com.andrewbristowx.chainacobblemon.rewards;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.andrewbristowx.chainacobblemon.config.ChainacobblemonConfig;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.data.PlayerDataManager;
import com.andrewbristowx.chainacobblemon.gacha.GachaTier;
import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogEntry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Infinite, server-authoritative two-track progression pass. */
public final class BattlePassService {
    public static final int PAGE_SIZE = 8;
    private final PlayerDataManager dataManager;
    private final ConfigManager configManager;
    private final Map<UUID, CaptureWindow> captureWindows = new ConcurrentHashMap<>();
    private final Map<UUID, JobXpWindow> jobXpWindows = new ConcurrentHashMap<>();
    private final Path auditFile = FabricLoader.getInstance().getConfigDir()
            .resolve(Chainacobblemon.MOD_ID).resolve("battle-pass-audit.log");

    public BattlePassService(PlayerDataManager dataManager, ConfigManager configManager) {
        this.dataManager = dataManager;
        this.configManager = configManager;
    }

    public void playerLeft(UUID playerId) {
        captureWindows.remove(playerId);
        jobXpWindows.remove(playerId);
    }

    /** Converts alpha.64's invisible stored rolls into the physical tickets players expected to receive. */
    public synchronized void playerJoined(ServerPlayerEntity player) {
        if (player == null) return;
        PlayerData data = dataManager.getOrLoad(player.getUuid());
        long chaina = Math.max(0L, data.rewardWallet.chainaRolls);
        long standard = Math.max(0L, data.rewardWallet.standardRolls);
        if (chaina <= 0L && standard <= 0L) return;
        data.rewardWallet.chainaRolls = 0L;
        data.rewardWallet.standardRolls = 0L;
        if (!dataManager.saveNowChecked(player.getUuid())) {
            data.rewardWallet.chainaRolls = chaina;
            data.rewardWallet.standardRolls = standard;
            return;
        }
        deliverItem(player, "chainacobblemon:chaina_special_banner_ticket", chaina);
        deliverItem(player, "chainacobblemon:gacha_ticket", standard);
        audit(player.getUuid(), "legacy_roll_materialized", "chaina=" + chaina + ":standard=" + standard);
        player.sendMessage(Text.literal("§d✦ Tus tiradas guardadas ahora son tickets físicos: §f"
                + chaina + " de Chaina §7y §f" + standard + " estándar."), false);
    }

    public void onActiveSecond(ServerPlayerEntity player) {
        ChainacobblemonConfig.BattlePassSettings settings = settings();
        if (!settings.enabled || settings.activeRewardXp <= 0) return;
        PlayerData data = dataManager.getOrLoad(player.getUuid());
        data.battlePass.activeSecondsBank++;
        if (data.battlePass.activeSecondsBank < settings.activeRewardSeconds) return;
        data.battlePass.activeSecondsBank -= settings.activeRewardSeconds;
        addXp(player, settings.activeRewardXp, "active_time");
    }

    public void onCapture(ServerPlayerEntity player, PokemonCatalogEntry entry, boolean newSpecies) {
        if (entry == null || !captureRateAllows(player.getUuid())) return;
        ChainacobblemonConfig.BattlePassSettings value = settings();
        int xp = switch (entry.tier()) {
            case COMMON -> value.commonCaptureXp;
            case UNCOMMON -> value.uncommonCaptureXp;
            case RARE -> value.rareCaptureXp;
            case EPIC -> value.epicCaptureXp;
            case LEGENDARY -> value.legendaryCaptureXp;
            case MYTHICAL, SPECIAL -> value.mythicalCaptureXp;
        };
        if (newSpecies) xp = Math.addExact(xp, value.newSpeciesBonusXp);
        addXp(player, xp, "capture:" + entry.tier().name().toLowerCase(java.util.Locale.ROOT));
    }

    public void onEvolution(ServerPlayerEntity player) { addXp(player, settings().evolutionXp, "evolution"); }
    public void onBattleVictory(ServerPlayerEntity player, boolean wild) {
        addXp(player, wild ? settings().wildBattleXp : settings().trainerBattleXp, wild ? "wild_battle" : "trainer_battle");
    }
    public void onNewBiome(ServerPlayerEntity player) { addXp(player, settings().newBiomeXp, "new_biome"); }
    public void onJobLevel(ServerPlayerEntity player, int levels) {
        addXp(player, (long) settings().jobLevelXp * Math.max(1, levels), "job_level");
    }

    /** Balanced passive pass XP for normal job actions, independent of the larger job-level bonus. */
    public synchronized void onJobAction(ServerPlayerEntity player, long scaledJobXp) {
        if (player == null || scaledJobXp <= 0L || !settings().enabled) return;
        ChainacobblemonConfig.BattlePassSettings value = settings();
        PlayerData data = dataManager.getOrLoad(player.getUuid());
        long bank = saturatingAdd(data.battlePass.jobXpBank, scaledJobXp);
        long available = bank / value.jobActionXpPerPassXp;
        if (available <= 0L) {
            data.battlePass.jobXpBank = bank;
            return;
        }
        long minute = System.currentTimeMillis() / 60_000L;
        JobXpWindow window = jobXpWindows.computeIfAbsent(player.getUuid(), ignored -> new JobXpWindow());
        if (window.minute != minute) { window.minute = minute; window.granted = 0; }
        long allowance = Math.max(0L, (long) value.jobActionPassXpPerMinute - window.granted);
        long grant = Math.min(available, allowance);
        if (grant <= 0L) {
            data.battlePass.jobXpBank = Math.min(bank, (long) value.jobActionXpPerPassXp * 4L);
            return;
        }
        long oldBank = data.battlePass.jobXpBank;
        data.battlePass.jobXpBank = bank - grant * value.jobActionXpPerPassXp;
        long credited = addXp(player, grant, "job_action");
        if (credited > 0L) window.granted += credited;
        else data.battlePass.jobXpBank = oldBank;
    }
    public void onQuestClaim(ServerPlayerEntity player, long passXp) {
        addXp(player, Math.max(0L, passXp), "quest_claim");
    }

    public synchronized long addXp(ServerPlayerEntity player, long requested, String reason) {
        if (player == null || requested <= 0L || !settings().enabled) return 0L;
        PlayerData data = dataManager.getOrLoad(player.getUuid());
        long before = data.battlePass.experience;
        int oldLevel = levelFor(before);
        long amount = Math.min(requested, Long.MAX_VALUE - before);
        data.battlePass.experience = before + amount;
        if (!dataManager.saveNowChecked(player.getUuid())) {
            data.battlePass.experience = before;
            return 0L;
        }
        int newLevel = levelFor(data.battlePass.experience);
        audit(player.getUuid(), "xp", amount + ":" + reason + ":level=" + newLevel);
        if (newLevel > oldLevel) {
            player.sendMessage(Text.literal("§d✦ Pase de Chaina: alcanzaste el nivel §f" + newLevel
                    + "§d. Abre /pase para reclamar."), false);
        }
        return amount;
    }

    public synchronized boolean claim(ServerPlayerEntity player, boolean premiumTrack, int level) {
        if (player == null || level < 1 || level > levelFor(dataManager.getOrLoad(player.getUuid()).battlePass.experience)) return false;
        ChainacobblemonConfig.BattlePassSettings settings = settings();
        if (premiumTrack && !BattlePassAccessPolicy.hasPremium(player, settings)) return false;
        BattlePassReward reward = rewardFor(level, premiumTrack, settings);
        if (reward == null || reward.amount() <= 0) return false;
        PlayerData data = dataManager.getOrLoad(player.getUuid());
        java.util.Set<Integer> claimed = premiumTrack ? data.battlePass.claimedPremium : data.battlePass.claimedFree;
        if (!claimed.add(level)) return false;
        if (!dataManager.saveNowChecked(player.getUuid())) {
            claimed.remove(level);
            return false;
        }
        if (!grant(player, reward, premiumTrack, level)) {
            claimed.remove(level);
            dataManager.saveNowChecked(player.getUuid());
            return false;
        }
        String track = premiumTrack ? "premium" : "free";
        audit(player.getUuid(), "claim", track + ":level=" + level + ":" + reward.type() + "=" + reward.amount());
        player.sendMessage(Text.literal("§dPase de Chaina: §f" + reward.amount() + "× " + reward.label()
                + " §7(" + track + " nivel " + level + ")"), false);
        return true;
    }

    public BattlePassSnapshot snapshot(ServerPlayerEntity player, int requestedPage, String message) {
        PlayerData data = dataManager.getOrLoad(player.getUuid());
        int level = levelFor(data.battlePass.experience);
        int currentPage = Math.max(0, (level - 1) / PAGE_SIZE);
        int page = requestedPage < 0 ? currentPage : Math.max(0, requestedPage);
        BattlePassSnapshot snapshot = new BattlePassSnapshot();
        snapshot.playerName = player.getGameProfile().getName();
        snapshot.experience = data.battlePass.experience;
        snapshot.level = level;
        snapshot.levelStartXp = totalXpForLevel(level);
        snapshot.nextLevelXp = totalXpForLevel(level + 1);
        snapshot.premium = BattlePassAccessPolicy.hasPremium(player, settings());
        snapshot.page = page;
        snapshot.standardRolls = data.rewardWallet.standardRolls;
        snapshot.chainaRolls = data.rewardWallet.chainaRolls;
        snapshot.message = message == null ? "" : message;
        int first = page * PAGE_SIZE + 1;
        for (int displayed = 0; displayed < PAGE_SIZE; displayed++) {
            int target = first + displayed;
            snapshot.free.add(slot(target, level, false, true, data, settings()));
            snapshot.premiumTrack.add(slot(target, level, true, snapshot.premium, data, settings()));
        }
        return snapshot;
    }

    private BattlePassSnapshot.RewardSlot slot(int target, int current, boolean premium, boolean trackAvailable, PlayerData data,
                                                ChainacobblemonConfig.BattlePassSettings settings) {
        BattlePassSnapshot.RewardSlot slot = new BattlePassSnapshot.RewardSlot();
        slot.level = target;
        BattlePassReward reward = rewardFor(target, premium, settings);
        slot.amount = reward.amount();
        slot.type = reward.type();
        slot.itemId = reward.itemId();
        slot.label = reward.label();
        slot.unlocked = current >= target;
        slot.claimed = (premium ? data.battlePass.claimedPremium : data.battlePass.claimedFree).contains(target);
        slot.claimable = slot.unlocked && !slot.claimed && trackAvailable;
        return slot;
    }

    public int levelFor(long experience) {
        if (experience <= 0L) return 1;
        int low = 1;
        int high = 2;
        while (high < 1_000_000_000 && totalXpForLevel(high) <= experience) high = Math.min(1_000_000_000, high * 2);
        while (low + 1 < high) {
            int middle = low + (high - low) / 2;
            if (totalXpForLevel(middle) <= experience) low = middle;
            else high = middle;
        }
        return low;
    }

    public long totalXpForLevel(int level) {
        if (level <= 1) return 0L;
        ChainacobblemonConfig.BattlePassSettings value = settings();
        long transitions = (long) level - 1L;
        long growingTransitions = value.xpGrowthPerLevel == 0 ? 0L
                : Math.min(transitions, Math.max(0L, ((long) value.maximumXpPerLevel - value.baseXpPerLevel
                + value.xpGrowthPerLevel - 1L) / value.xpGrowthPerLevel));
        long total = saturatingAdd(saturatingMultiply(growingTransitions, value.baseXpPerLevel),
                saturatingMultiply(value.xpGrowthPerLevel,
                        growingTransitions * Math.max(0L, growingTransitions - 1L) / 2L));
        long cappedTransitions = transitions - growingTransitions;
        long capped = saturatingMultiply(cappedTransitions, value.maximumXpPerLevel);
        return saturatingAdd(total, capped);
    }

    private BattlePassReward rewardFor(int level, boolean premium, ChainacobblemonConfig.BattlePassSettings value) {
        if (premium) {
            if (level == 1) return BattlePassReward.item("chainacobblemon:chaina_special_banner_ticket",
                    value.premiumFirstLevelChainaRolls, "Tickets de Chaina");
            if (level % value.premiumRewardEveryLevels == 0)
                return BattlePassReward.item("chainacobblemon:chaina_special_banner_ticket", value.premiumChainaRolls,
                        "Tickets de Chaina");
            return switch (Math.floorMod(level, 6)) {
                case 0 -> BattlePassReward.coins(650);
                case 1 -> BattlePassReward.item("cobblemon:rare_candy", 2, "Caramelos Raros");
                case 2 -> BattlePassReward.item("minecraft:diamond", 2, "Diamantes");
                case 3 -> BattlePassReward.item("chainacobblemon:gacha_ticket", 2, "Tiradas normales");
                case 4 -> BattlePassReward.item("cobblemon:ultra_ball", 4, "Ultra Balls");
                default -> BattlePassReward.item("chainacobblemon:treasure_gacha_ticket", 2, "Tickets de Tesoros de Chaina");
            };
        }
        if (level % value.freeRewardEveryLevels == 0)
            return BattlePassReward.item("chainacobblemon:chaina_special_banner_ticket", value.freeChainaRolls,
                    "Tirada de Chaina");
        return switch (Math.floorMod(level, 6)) {
            case 0 -> BattlePassReward.coins(200);
            case 1 -> BattlePassReward.item("cobblemon:poke_ball", 8, "Poké Balls");
            case 2 -> BattlePassReward.item("minecraft:iron_ingot", 6, "Lingotes de hierro");
            case 3 -> BattlePassReward.item("chainacobblemon:gacha_ticket", 1, "Tirada normal");
            case 4 -> BattlePassReward.item("cobblemon:great_ball", 4, "Great Balls");
            default -> BattlePassReward.item("chainacobblemon:treasure_gacha_ticket", 1, "Ticket de Tesoros de Chaina");
        };
    }

    private boolean grant(ServerPlayerEntity player, BattlePassReward reward, boolean premium, int level) {
        if (BattlePassReward.CHAIBELLS.equals(reward.type())) {
            return Chainacobblemon.progressionService().refund(player, reward.amount(),
                    "battle_pass:" + (premium ? "premium" : "free") + ":" + level) == reward.amount();
        }
        return deliverItem(player, reward.itemId(), reward.amount());
    }

    private boolean deliverItem(ServerPlayerEntity player, String itemId, long amount) {
        Identifier id = Identifier.tryParse(itemId);
        if (id == null || !Registries.ITEM.containsId(id)) return false;
        Item item = Registries.ITEM.get(id);
        if (item == Items.AIR) return false;
        long remaining = Math.max(0L, amount);
        while (remaining > 0L) {
            int count = (int) Math.min(item.getMaxCount(), remaining);
            ItemStack stack = new ItemStack(item, count);
            player.getInventory().insertStack(stack);
            if (!stack.isEmpty()) player.dropItem(stack, false);
            remaining -= count;
        }
        player.getInventory().markDirty();
        return true;
    }

    private boolean captureRateAllows(UUID playerId) {
        long minute = System.currentTimeMillis() / 60_000L;
        CaptureWindow window = captureWindows.computeIfAbsent(playerId, ignored -> new CaptureWindow());
        synchronized (window) {
            if (window.minute != minute) { window.minute = minute; window.events = 0; }
            if (window.events >= settings().captureXpEventsPerMinute) return false;
            window.events++;
            return true;
        }
    }

    private long saturatingMultiply(long left, long right) {
        try { return Math.multiplyExact(left, right); }
        catch (ArithmeticException overflow) { return Long.MAX_VALUE; }
    }

    private long saturatingAdd(long left, long right) {
        return left > Long.MAX_VALUE - right ? Long.MAX_VALUE : left + right;
    }

    private ChainacobblemonConfig.BattlePassSettings settings() { return configManager.get().battlePass; }

    private void audit(UUID playerId, String action, String detail) {
        try {
            Files.createDirectories(auditFile.getParent());
            Files.writeString(auditFile, System.currentTimeMillis() + "\t" + playerId + "\t" + action + "\t" + detail
                            + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not write battle pass audit", exception);
        }
    }

    private static final class CaptureWindow { long minute; int events; }
    private static final class JobXpWindow { long minute; long granted; }
}
