package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Chunky-backed selective pregenerator for the campaign locations.
 *
 * Chaina no longer asks ServerWorld#getChunk directly. Each static campaign location is split into small
 * 256x256-block tiles and Chunky is allowed to process exactly one tile at a time. This keeps Chunky's own
 * asynchronous generation, existing-chunk checks and task persistence while Chaina owns the high-level queue.
 *
 * The integration is deliberately soft/reflection based: Chunky is recommended, not a hard classpath dependency.
 * If Chunky is missing or exposes an incompatible API, the command refuses to start instead of crashing the server.
 */
public final class SelectivePregenService {
    public static final int ZONE_RADIUS_BLOCKS = 1024;
    public static final int TILE_SIZE_BLOCKS = 256;
    public static final int TILE_RADIUS_BLOCKS = TILE_SIZE_BLOCKS / 2;
    public static final int TILES_PER_AXIS = (ZONE_RADIUS_BLOCKS * 2) / TILE_SIZE_BLOCKS;
    public static final int TILES_PER_ZONE = TILES_PER_AXIS * TILES_PER_AXIS;

    private static final double DEFAULT_DISK_CAP_GIB = 146.0;
    private static final double MIN_FREE_GIB = 30.0;
    private static final double DISK_SLOW_GIB = 35.0;
    private static final double DISK_WARN_GIB = 45.0;
    private static final long GIB = 1024L * 1024L * 1024L;

    // TPS guard. MSPT is measured from Fabric START_SERVER_TICK -> END_SERVER_TICK.
    private static final double PAUSE_MSPT = 45.0;
    private static final double RESUME_MSPT = 32.0;
    private static final int OVERLOAD_TICKS = 20;
    private static final int RECOVERY_TICKS = 100;
    private static final int DISK_RESCAN_TICKS = 2400; // ~2 minutes at 20 TPS.

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final ExecutorService DISK_EXECUTOR = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "Chaina-Chunky-Disk-Scanner");
        thread.setDaemon(true);
        return thread;
    });

    private static ConfigManager configManager;
    private static boolean initialized;
    private static long loadedSeed = Long.MIN_VALUE;
    private static State state = new State();
    private static List<Zone> zones = List.of();
    private static List<Tile> tiles = List.of();
    private static boolean planInitialized;
    private static UUID requester;

    private static long tickStartNs;
    private static double smoothedMspt;
    private static int overloadTicks;
    private static int recoveryTicks;
    private static int cooldownTicks;
    private static int diskTickCounter;

    private static volatile long measuredDirectoryBytes = -1L;
    private static volatile boolean diskScanRunning;
    private static volatile String diskScanError = "";
    private static boolean warning45Sent;
    private static boolean warning35Sent;

    private SelectivePregenService() {}

    public static synchronized void initialize(ConfigManager config) {
        configManager = config;
        if (initialized) return;
        initialized = true;
        ServerTickEvents.START_SERVER_TICK.register(server -> tickStartNs = System.nanoTime());
        ServerTickEvents.END_SERVER_TICK.register(SelectivePregenService::tick);
    }

    private record Zone(String key, String region, int order, String label, String dimensionId, int x, int y, int z) {}
    private record Tile(String key, String zoneKey, String region, int order, String label, String dimensionId,
                        int centerX, int centerZ, int tileNumber, int distanceSq) {}
    private record DiskSnapshot(boolean ready, double usedGiB, double freeGiB) {}

    private static final class State {
        long seed;
        boolean running;
        boolean pausedForDisk;
        boolean pausedForTps;
        boolean pausedManually;
        double diskCapacityGiB = DEFAULT_DISK_CAP_GIB;
        Set<String> completedTiles = new LinkedHashSet<>();
        String currentTileKey = "";
        boolean taskWasStarted;
        boolean taskNeedsResume;
        long completedTileCount;
        String lastError = "";
    }

    public static synchronized int startOrResume(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
        rebuildPlan(map);
        if (!map.complete()) {
            source.sendFeedback(() -> Text.literal("§cNo se puede pregenerar: el plan de ubicaciones está en §f"
                    + map.located() + "/" + map.total() + "§c. Completa primero 69/69."), false);
            return 0;
        }
        ChunkyBridge.Probe probe = ChunkyBridge.probe();
        if (!probe.available()) {
            source.sendFeedback(() -> Text.literal("§cChunky no está disponible. §7Instala Chunky para Fabric 1.21.1 SOLO en el servidor y reinicia. §8Detalle: " + probe.message()), false);
            return 0;
        }
        if (tiles.isEmpty()) {
            source.sendFeedback(() -> Text.literal("§cNo hay ubicaciones estáticas para pregenerar."), false);
            return 0;
        }
        if (completedTileCount() >= tiles.size()) {
            source.sendFeedback(() -> Text.literal("§aLa campaña ya está preparada con Chunky: §f" + tiles.size() + "/" + tiles.size()
                    + "§a lotes completados. Las 2 ubicaciones dinámicas quedan fuera de la pregeneración masiva."), false);
            return 1;
        }

        requester = source.getEntity() instanceof ServerPlayerEntity player ? player.getUuid() : null;
        state.running = true;
        state.pausedForDisk = false;
        state.pausedManually = false;
        state.lastError = "";
        warning45Sent = false;
        warning35Sent = false;
        if (currentTile() == null) selectNextTile();
        requestDiskScan(true);
        save(server);

        source.sendFeedback(() -> Text.literal("§d§lPregeneración segura Chaina + Chunky iniciada"), false);
        source.sendFeedback(() -> Text.literal("§7Motor: §bChunky API v" + probe.apiVersion()
                + " §7· zonas estáticas: §f" + zones.size() + " §7· lotes: §f" + tiles.size()), false);
        source.sendFeedback(() -> Text.literal("§7Cada lote mide §f" + TILE_SIZE_BLOCKS + "×" + TILE_SIZE_BLOCKS
                + " bloques §7(~16×16 chunks). Solo hay §f1 tarea de Chunky§7 activa a la vez."), false);
        source.sendFeedback(() -> Text.literal("§7Protecciones: pausa por carga a §f~" + (int) PAUSE_MSPT
                + " MSPT§7, reanuda al estabilizarse; reserva dura de disco §c30 GiB libres§7."), false);
        source.sendFeedback(() -> Text.literal("§8Chaina ya NO llama world.getChunk() para esta tarea."), false);
        return 1;
    }

    public static synchronized int resume(ServerCommandSource source) {
        return startOrResume(source);
    }

    public static synchronized int pause(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        Tile tile = currentTile();
        if (!state.running && !state.pausedForTps) {
            source.sendFeedback(() -> Text.literal("§eLa pregeneración ya está pausada."), false);
            return 0;
        }
        if (tile != null && state.taskWasStarted) {
            tryPauseChunky(tile);
            state.taskNeedsResume = true;
        }
        state.running = false;
        state.pausedManually = true;
        state.pausedForTps = false;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§ePregeneración pausada. §7Chunky guardará el lote activo; usa §f/chainacobblemon admin structures generate resume§7."), false);
        return 1;
    }

    public static synchronized int reportStatus(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
        rebuildPlan(map);
        DiskSnapshot disk = diskSnapshot();
        ChunkyBridge.Probe probe = ChunkyBridge.probe();
        Tile tile = currentTile();
        int done = completedTileCount();

        source.sendFeedback(() -> Text.literal("§d§lPregeneración campaña · Chunky §f" + done + "/" + tiles.size() + " lotes"), false);
        source.sendFeedback(() -> Text.literal("§7Mapa: " + (map.complete() ? "§a69/69" : "§c" + map.located() + "/" + map.total())
                + " §7· Chunky: " + (probe.available() ? "§aOK API v" + probe.apiVersion() : "§cNO DISPONIBLE")), false);
        String status = state.running
                ? state.pausedForTps ? "§6ESPERANDO RECUPERACIÓN TPS" : "§aEN CURSO"
                : state.pausedForDisk ? "§cPAUSADA POR DISCO"
                : state.pausedManually ? "§ePAUSADA MANUALMENTE" : "§ePAUSADA";
        source.sendFeedback(() -> Text.literal("§7Estado: " + status + " §7· MSPT suavizado: §f" + format(smoothedMspt)), false);
        if (tile != null) {
            boolean chunkyRunning = probe.available() && ChunkyBridge.isRunning(tile.dimensionId());
            source.sendFeedback(() -> Text.literal("§7Actual: §f" + tile.region() + " #" + tile.order() + " · " + tile.label()
                    + " §7· lote §f" + tile.tileNumber() + "/" + TILES_PER_ZONE + " §7· " + tile.dimensionId()), false);
            source.sendFeedback(() -> Text.literal("§7Centro lote: §fX " + tile.centerX() + " Z " + tile.centerZ()
                    + " §7· tarea Chunky: " + (chunkyRunning ? "§aACTIVA" : state.taskNeedsResume ? "§eGUARDADA/PAUSANDO" : "§7esperando")), false);
        }
        if (disk.ready()) {
            source.sendFeedback(() -> Text.literal("§7Disco Chaina: usado §f" + format(disk.usedGiB()) + " GiB§7 / límite §f"
                    + format(state.diskCapacityGiB) + " GiB§7 · libre seguro §f" + format(disk.freeGiB()) + " GiB §7(reserva §c30 GiB§7)"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§7Disco: §emedición en curso..."), false);
        }
        source.sendFeedback(() -> Text.literal("§7Zonas estáticas: §f" + zones.size() + " §7· 2 destinos dinámicos no se pregeneran masivamente."), false);
        if (!state.lastError.isBlank()) source.sendFeedback(() -> Text.literal("§cÚltimo error: §f" + state.lastError), false);
        return map.complete() && probe.available() ? 1 : 0;
    }

    public static synchronized int setDiskCapacity(ServerCommandSource source, int gib) {
        ensureLoaded(source.getServer());
        state.diskCapacityGiB = gib;
        requestDiskScan(true);
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aCapacidad lógica configurada: §f" + gib + " GiB§a. La reserva mínima sigue siendo §f30 GiB§a."), false);
        return 1;
    }

    public static synchronized int reset(ServerCommandSource source, boolean confirm) {
        ensureLoaded(source.getServer());
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eEsto reinicia SOLO la cola/progreso de Chaina+Chunky; no borra chunks ya generados. "
                    + "Ejecuta §f/chainacobblemon admin structures generate reset confirm§e."), false);
            return 0;
        }
        Tile tile = currentTile();
        if (tile != null && ChunkyBridge.probe().available() && ChunkyBridge.isRunning(tile.dimensionId())) {
            ChunkyBridge.cancelTask(tile.dimensionId());
        }
        double cap = state.diskCapacityGiB > 0 ? state.diskCapacityGiB : DEFAULT_DISK_CAP_GIB;
        state = new State();
        state.seed = source.getServer().getOverworld().getSeed();
        state.diskCapacityGiB = cap;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aCola Chaina reiniciada. §7Los chunks ya creados permanecen y Chunky los saltará al volver a pasar."), false);
        return 1;
    }

    private static void tick(MinecraftServer server) {
        synchronized (SelectivePregenService.class) {
            recordTickDuration();
            if (!state.running) return;
            ensureLoaded(server);
            if (!planInitialized) {
                // A persisted queue may resume after a server restart. Build its immutable plan once,
                // never on every tick: the regional audit is intentionally too expensive for the tick loop.
                ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
                rebuildPlan(map);
            }
            if (tiles.isEmpty()) {
                pauseWithError(server, "No hay lotes estáticos disponibles.");
                return;
            }
            ChunkyBridge.Probe probe = ChunkyBridge.probe();
            if (!probe.available()) {
                pauseWithError(server, "Chunky dejó de estar disponible: " + probe.message());
                return;
            }

            if (++diskTickCounter >= DISK_RESCAN_TICKS) {
                diskTickCounter = 0;
                requestDiskScan(false);
            }
            DiskSnapshot disk = diskSnapshot();
            if (!disk.ready()) {
                requestDiskScan(false);
                return;
            }
            if (disk.freeGiB() <= MIN_FREE_GIB) {
                Tile tile = currentTile();
                if (tile != null && state.taskWasStarted) {
                    tryPauseChunky(tile);
                    state.taskNeedsResume = true;
                }
                state.running = false;
                state.pausedForDisk = true;
                state.pausedForTps = false;
                state.lastError = "Reserva de disco alcanzada: " + format(disk.freeGiB()) + " GiB libres.";
                save(server);
                notifyRequester(server, "§c§lPREGENERACIÓN PAUSADA POR DISCO §7· quedan §f" + format(disk.freeGiB())
                        + " GiB libres§7. El límite duro es 30 GiB.");
                return;
            }
            if (disk.freeGiB() <= DISK_WARN_GIB && !warning45Sent) {
                warning45Sent = true;
                notifyRequester(server, "§6Aviso: quedan §f" + format(disk.freeGiB()) + " GiB libres§6. Chaina dejará más descanso entre lotes.");
            }
            if (disk.freeGiB() <= DISK_SLOW_GIB && !warning35Sent) {
                warning35Sent = true;
                notifyRequester(server, "§cDisco bajo: §f" + format(disk.freeGiB()) + " GiB libres§c. Cola muy ralentizada; se detendrá a 30 GiB.");
            }

            if (cooldownTicks > 0) {
                cooldownTicks--;
                return;
            }

            Tile tile = currentTile();
            if (tile == null) {
                if (!selectNextTile()) {
                    finish(server);
                    return;
                }
                tile = currentTile();
                if (tile == null) return;
            }

            // If Chaina paused this Chunky task (TPS/manual/restart), wait until Chunky has fully saved/stopped it,
            // then continue the saved task. If no resumable task exists, restart the same tiny tile safely.
            if (state.taskNeedsResume) {
                if (ChunkyBridge.isRunning(tile.dimensionId())) return;
                if (state.pausedForTps) {
                    if (recoveryTicks < RECOVERY_TICKS) return;
                    state.pausedForTps = false;
                }
                boolean resumed = ChunkyBridge.continueTask(tile.dimensionId());
                if (!resumed) resumed = ChunkyBridge.startTask(tile);
                if (!resumed) {
                    pauseWithError(server, "Chunky no pudo reanudar/iniciar el lote " + tile.key());
                    return;
                }
                state.taskNeedsResume = false;
                state.taskWasStarted = true;
                save(server);
                notifyRequester(server, "§aChunky reanudado §7· " + shortTile(tile));
                return;
            }

            if (state.taskWasStarted) {
                if (ChunkyBridge.isRunning(tile.dimensionId())) {
                    if (overloadTicks >= OVERLOAD_TICKS) {
                        if (ChunkyBridge.pauseTask(tile.dimensionId())) {
                            state.taskNeedsResume = true;
                            state.pausedForTps = true;
                            overloadTicks = 0;
                            recoveryTicks = 0;
                            save(server);
                            notifyRequester(server, "§6Chunky pausado automáticamente por carga §7· MSPT ~§f" + format(smoothedMspt)
                                    + "§7. Se reanudará cuando el servidor se estabilice.");
                        }
                    }
                    return;
                }
                // It was active and we did not request a pause: Chunky completed this tile naturally.
                completeTile(server, tile, disk.freeGiB());
                return;
            }

            // Do not launch a new tile while the server is already close to its 50ms tick budget.
            if (smoothedMspt >= PAUSE_MSPT || overloadTicks > 0) return;
            if (ChunkyBridge.isRunning(tile.dimensionId())) {
                pauseWithError(server, "Ya existe otra tarea Chunky activa en " + tile.dimensionId()
                        + ". Páusala/cancélala antes de continuar la cola de Chaina.");
                return;
            }
            if (!ChunkyBridge.startTask(tile)) {
                pauseWithError(server, "Chunky rechazó el lote " + tile.key() + ". Revisa /chunky progress.");
                return;
            }
            state.taskWasStarted = true;
            save(server);
        }
    }

    private static void recordTickDuration() {
        if (tickStartNs <= 0L) return;
        double ms = (System.nanoTime() - tickStartNs) / 1_000_000.0;
        smoothedMspt = smoothedMspt <= 0.0 ? ms : smoothedMspt * 0.92 + ms * 0.08;
        if (smoothedMspt >= PAUSE_MSPT) {
            overloadTicks++;
            recoveryTicks = 0;
        } else if (smoothedMspt <= RESUME_MSPT) {
            recoveryTicks++;
            overloadTicks = 0;
        } else {
            overloadTicks = Math.max(0, overloadTicks - 1);
            recoveryTicks = Math.max(0, recoveryTicks - 1);
        }
    }

    private static void completeTile(MinecraftServer server, Tile tile, double freeGiB) {
        state.completedTiles.add(tile.key());
        state.completedTileCount = completedTileCount();
        state.currentTileKey = "";
        state.taskWasStarted = false;
        state.taskNeedsResume = false;
        state.pausedForTps = false;
        save(server);
        int done = completedTileCount();
        if (done == tiles.size() || done % 8 == 0) {
            notifyRequester(server, "§aChunky campaña §f" + done + "/" + tiles.size() + " lotes §7· último: " + shortTile(tile));
        }
        cooldownTicks = freeGiB <= DISK_SLOW_GIB ? 100 : freeGiB <= DISK_WARN_GIB ? 40 : 10;
        if (!selectNextTile()) finish(server);
    }

    private static boolean selectNextTile() {
        for (Tile tile : tiles) {
            if (state.completedTiles.contains(tile.key())) continue;
            state.currentTileKey = tile.key();
            state.taskWasStarted = false;
            state.taskNeedsResume = false;
            return true;
        }
        state.currentTileKey = "";
        return false;
    }

    private static void finish(MinecraftServer server) {
        state.running = false;
        state.pausedForDisk = false;
        state.pausedForTps = false;
        state.pausedManually = false;
        state.currentTileKey = "";
        state.taskWasStarted = false;
        state.taskNeedsResume = false;
        state.lastError = "";
        save(server);
        notifyRequester(server, "§a§lMAPA DE CAMPAÑA PREGENERADO CON CHUNKY §7· §f" + zones.size()
                + "§a zonas estáticas / §f" + tiles.size() + "§a lotes + §f2/2§a destinos dinámicos verificados.");
        Chainacobblemon.LOGGER.info("Chunky selective campaign pregeneration finished: {} zones / {} tiles", zones.size(), tiles.size());
    }

    private static void pauseWithError(MinecraftServer server, String error) {
        Tile tile = currentTile();
        if (tile != null && state.taskWasStarted && ChunkyBridge.probe().available() && ChunkyBridge.isRunning(tile.dimensionId())) {
            tryPauseChunky(tile);
            state.taskNeedsResume = true;
        }
        state.running = false;
        state.lastError = error;
        save(server);
        notifyRequester(server, "§cPregeneración pausada: §f" + error);
    }

    private static void tryPauseChunky(Tile tile) {
        try {
            if (ChunkyBridge.isRunning(tile.dimensionId())) ChunkyBridge.pauseTask(tile.dimensionId());
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not pause Chunky task in {}", tile.dimensionId(), exception);
        }
    }

    private static String shortTile(Tile tile) {
        return tile.region() + " #" + tile.order() + " · lote " + tile.tileNumber() + "/" + TILES_PER_ZONE;
    }

    private static Tile currentTile() {
        if (state.currentTileKey == null || state.currentTileKey.isBlank()) return null;
        for (Tile tile : tiles) if (tile.key().equals(state.currentTileKey)) return tile;
        return null;
    }

    private static int completedTileCount() {
        if (state.completedTiles == null || state.completedTiles.isEmpty()) return 0;
        int count = 0;
        for (Tile tile : tiles) if (state.completedTiles.contains(tile.key())) count++;
        return count;
    }

    private static void rebuildPlan(ImportantLocationService.MapSnapshot snapshot) {
        List<Zone> z = new ArrayList<>();
        for (ImportantLocationService.RegionView region : snapshot.regions()) {
            for (ImportantLocationService.LocationView location : region.locations()) {
                // registered=false is how the two template/instance destinations are represented; they remain dynamic.
                if (!location.registered() || !location.located() || location.dimensionId().isBlank()) continue;
                z.add(new Zone(location.key(), region.name(), location.order(), location.label(), location.dimensionId(),
                        location.x(), location.y(), location.z()));
            }
        }
        z.sort(Comparator.comparingInt((Zone zone) -> regionPriority(zone.region())).thenComparingInt(Zone::order));
        zones = List.copyOf(z);

        List<Tile> planned = new ArrayList<>(zones.size() * TILES_PER_ZONE);
        for (Zone zone : zones) {
            List<Tile> local = new ArrayList<>(TILES_PER_ZONE);
            int n = 0;
            for (int gx = 0; gx < TILES_PER_AXIS; gx++) {
                int ox = -ZONE_RADIUS_BLOCKS + TILE_RADIUS_BLOCKS + gx * TILE_SIZE_BLOCKS;
                for (int gz = 0; gz < TILES_PER_AXIS; gz++) {
                    int oz = -ZONE_RADIUS_BLOCKS + TILE_RADIUS_BLOCKS + gz * TILE_SIZE_BLOCKS;
                    n++;
                    String key = zone.key() + "@" + gx + "," + gz;
                    local.add(new Tile(key, zone.key(), zone.region(), zone.order(), zone.label(), zone.dimensionId(),
                            zone.x() + ox, zone.z() + oz, n, ox * ox + oz * oz));
                }
            }
            local.sort(Comparator.comparingInt(Tile::distanceSq).thenComparingInt(Tile::centerX).thenComparingInt(Tile::centerZ));
            // Renumber after center-out sorting so status is intuitive.
            for (int i = 0; i < local.size(); i++) {
                Tile t = local.get(i);
                planned.add(new Tile(t.key(), t.zoneKey(), t.region(), t.order(), t.label(), t.dimensionId(),
                        t.centerX(), t.centerZ(), i + 1, t.distanceSq()));
            }
        }
        tiles = List.copyOf(planned);
        if (state.completedTiles == null) state.completedTiles = new LinkedHashSet<>();
        Set<String> valid = new LinkedHashSet<>();
        for (Tile tile : tiles) valid.add(tile.key());
        state.completedTiles.retainAll(valid);
        if (currentTile() == null && state.currentTileKey != null && !state.currentTileKey.isBlank()) {
            state.currentTileKey = "";
            state.taskWasStarted = false;
            state.taskNeedsResume = false;
        }
        planInitialized = true;
    }

    private static int regionPriority(String region) {
        if (region == null) return 99;
        return switch (region.toLowerCase(Locale.ROOT)) {
            case "kanto" -> 0;
            case "johto" -> 1;
            case "hoenn" -> 2;
            case "sinnoh" -> 3;
            default -> 10;
        };
    }

    private static void notifyRequester(MinecraftServer server, String message) {
        if (requester != null) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(requester);
            if (player != null) {
                player.sendMessage(Text.literal(message), false);
                return;
            }
        }
        Chainacobblemon.LOGGER.info(message.replaceAll("§.", ""));
    }

    private static void requestDiskScan(boolean force) {
        if (diskScanRunning) return;
        diskScanRunning = true;
        Path gameDir = FabricLoader.getInstance().getGameDir();
        CompletableFuture.supplyAsync(() -> directorySize(gameDir), DISK_EXECUTOR).whenComplete((size, error) -> {
            if (error != null) {
                diskScanError = error.getClass().getSimpleName() + ": " + error.getMessage();
            } else {
                measuredDirectoryBytes = Math.max(0L, size);
                diskScanError = "";
            }
            diskScanRunning = false;
        });
    }

    private static long directorySize(Path root) {
        try (var stream = Files.walk(root)) {
            return stream.filter(Files::isRegularFile).mapToLong(path -> {
                try {
                    return Files.size(path);
                } catch (IOException ignored) {
                    return 0L;
                }
            }).sum();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private static DiskSnapshot diskSnapshot() {
        if (measuredDirectoryBytes < 0) return new DiskSnapshot(false, 0.0, 0.0);
        double used = measuredDirectoryBytes / (double) GIB;
        double logicalFree = Math.max(0.0, state.diskCapacityGiB - used);
        double physicalFree = Double.MAX_VALUE;
        try {
            FileStore store = Files.getFileStore(FabricLoader.getInstance().getGameDir());
            physicalFree = store.getUsableSpace() / (double) GIB;
        } catch (IOException exception) {
            if (diskScanError.isBlank()) diskScanError = exception.getClass().getSimpleName();
        }
        return new DiskSnapshot(true, used, Math.min(logicalFree, physicalFree));
    }

    private static void ensureLoaded(MinecraftServer server) {
        if (configManager == null || server == null || server.getOverworld() == null) return;
        long seed = server.getOverworld().getSeed();
        if (loadedSeed == seed) return;
        loadedSeed = seed;
        planInitialized = false;
        zones = List.of();
        tiles = List.of();
        state = new State();
        state.seed = seed;
        Path file = stateFile(seed);
        if (Files.exists(file)) {
            try {
                State loaded = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), State.class);
                if (loaded != null && loaded.seed == seed) {
                    if (loaded.completedTiles == null) loaded.completedTiles = new LinkedHashSet<>();
                    if (loaded.diskCapacityGiB <= 0) loaded.diskCapacityGiB = DEFAULT_DISK_CAP_GIB;
                    // Never auto-resume world generation after a restart.
                    loaded.running = false;
                    loaded.pausedManually = true;
                    if (loaded.taskWasStarted && loaded.currentTileKey != null && !loaded.currentTileKey.isBlank()) {
                        loaded.taskNeedsResume = true;
                    }
                    state = loaded;
                }
            } catch (Exception exception) {
                Chainacobblemon.LOGGER.warn("Could not read Chunky pregeneration state {}", file, exception);
            }
        }
        requester = null;
        smoothedMspt = 0.0;
        overloadTicks = 0;
        recoveryTicks = 0;
        cooldownTicks = 0;
        measuredDirectoryBytes = -1L;
        requestDiskScan(true);
    }

    private static void save(MinecraftServer server) {
        if (configManager == null || server == null) return;
        Path file = stateFile(state.seed);
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(temp, GSON.toJson(state), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            Chainacobblemon.LOGGER.warn("Could not save Chunky pregeneration state {}", file, exception);
        }
    }

    private static Path stateFile(long seed) {
        // V2 is intentionally separate from alpha.28's direct-world.getChunk progress file.
        return configManager.configDirectory().resolve("campaign-chunky-pregen-v2-" + Long.toUnsignedString(seed) + ".json");
    }

    private static String format(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    /** Reflection-only bridge so Chainacobblemon still loads cleanly when Chunky is not installed. */
    private static final class ChunkyBridge {
        private static Object api;
        private static Method version;
        private static Method isRunning;
        private static Method startTask;
        private static Method pauseTask;
        private static Method continueTask;
        private static Method cancelTask;
        private static String error = "";
        private static boolean attempted;

        record Probe(boolean available, int apiVersion, String message) {}

        static synchronized Probe probe() {
            if (!FabricLoader.getInstance().isModLoaded("chunky")) {
                return new Probe(false, -1, "mod 'chunky' no instalado");
            }
            if (!attempted) bind();
            if (api == null) return new Probe(false, -1, error.isBlank() ? "API no encontrada" : error);
            try {
                int v = ((Number) version.invoke(api)).intValue();
                if (v != 0) return new Probe(false, v, "API Chunky no soportada (esperada 0, encontrada " + v + ")");
                return new Probe(true, v, "OK");
            } catch (ReflectiveOperationException exception) {
                return new Probe(false, -1, rootMessage(exception));
            }
        }

        private static void bind() {
            attempted = true;
            try {
                Class<?> provider = Class.forName("org.popcraft.chunky.ChunkyProvider");
                Object chunky = provider.getMethod("get").invoke(null);
                api = chunky.getClass().getMethod("getApi").invoke(chunky);
                Class<?> apiClass = Class.forName("org.popcraft.chunky.api.ChunkyAPI");
                version = apiClass.getMethod("version");
                isRunning = apiClass.getMethod("isRunning", String.class);
                startTask = apiClass.getMethod("startTask", String.class, String.class,
                        double.class, double.class, double.class, double.class, String.class);
                pauseTask = apiClass.getMethod("pauseTask", String.class);
                continueTask = apiClass.getMethod("continueTask", String.class);
                cancelTask = apiClass.getMethod("cancelTask", String.class);
                error = "";
            } catch (ReflectiveOperationException | RuntimeException exception) {
                api = null;
                error = rootMessage(exception);
                Chainacobblemon.LOGGER.warn("Chunky soft integration unavailable: {}", error);
            }
        }

        static boolean isRunning(String world) {
            return invokeBool(isRunning, world);
        }

        static boolean startTask(Tile tile) {
            if (!probe().available()) return false;
            try {
                // A 128-block square radius = 256x256 blocks (~16x16 chunks). Concentric prioritizes the tile center.
                return (Boolean) startTask.invoke(api, tile.dimensionId(), "square",
                        (double) tile.centerX(), (double) tile.centerZ(),
                        (double) TILE_RADIUS_BLOCKS, (double) TILE_RADIUS_BLOCKS, "concentric");
            } catch (ReflectiveOperationException exception) {
                error = rootMessage(exception);
                Chainacobblemon.LOGGER.error("Chunky startTask failed for {}", tile.key(), exception);
                return false;
            }
        }

        static boolean pauseTask(String world) { return invokeBool(pauseTask, world); }
        static boolean continueTask(String world) { return invokeBool(continueTask, world); }
        static boolean cancelTask(String world) { return invokeBool(cancelTask, world); }

        private static boolean invokeBool(Method method, String world) {
            if (!probe().available() || method == null) return false;
            try {
                return (Boolean) method.invoke(api, world);
            } catch (ReflectiveOperationException exception) {
                error = rootMessage(exception);
                Chainacobblemon.LOGGER.error("Chunky API call failed in {}", world, exception);
                return false;
            }
        }

        private static String rootMessage(Throwable throwable) {
            Throwable current = throwable;
            if (current instanceof InvocationTargetException ite && ite.getCause() != null) current = ite.getCause();
            String msg = current.getMessage();
            return current.getClass().getSimpleName() + (msg == null || msg.isBlank() ? "" : ": " + msg);
        }
    }
}
