package com.andrewbristowx.chainacobblemon.tower;

import java.util.ArrayList;
import java.util.List;

/** Serializable client view for the repeat-clear Tower reward roulette. */
public final class TowerRouletteSnapshot {
    public List<RewardView> previews = new ArrayList<>();
    public RewardView selected;
    public boolean jackpot;
    public long closeAfterMillis = 8_000L;
    public String title = "";
    public String subtitle = "";
    public String settledMessage = "";

    public static final class RewardView {
        public String type = "ITEM";
        public String value = "";
        public String label = "Premio";
        public int amount = 1;
        public String speciesId = "";

        public RewardView() { }

        public RewardView(String type, String value, String label, int amount, String speciesId) {
            this.type = type;
            this.value = value;
            this.label = label;
            this.amount = amount;
            this.speciesId = speciesId;
        }
    }
}
