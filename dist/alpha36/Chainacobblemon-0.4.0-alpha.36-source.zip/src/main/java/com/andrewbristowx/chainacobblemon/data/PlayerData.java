package com.andrewbristowx.chainacobblemon.data;

import com.andrewbristowx.chainacobblemon.gacha.GachaProgress;
import com.andrewbristowx.chainacobblemon.progress.data.EconomyProgress;
import com.andrewbristowx.chainacobblemon.progress.data.JobProgress;
import com.andrewbristowx.chainacobblemon.progress.data.QuestProgress;
import com.andrewbristowx.chainacobblemon.rewards.data.BattlePassProgress;
import com.andrewbristowx.chainacobblemon.rewards.data.DailyRewardProgress;
import com.andrewbristowx.chainacobblemon.rewards.data.RewardWallet;
import com.andrewbristowx.chainacobblemon.tower.TowerProgress;
import com.andrewbristowx.chainacobblemon.events.data.EventProgress;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class PlayerData {
    public int dataVersion = 13;
    public UUID playerId;
    public long firstSeenEpochMillis;
    public long lastSeenEpochMillis;
    public long debugCounter;
    public Map<String, GachaProgress> gachaProgress = new HashMap<>();
    public EconomyProgress economy = new EconomyProgress();
    public JobProgress jobs = new JobProgress();
    public QuestProgress quests = new QuestProgress();
    public RewardWallet rewardWallet = new RewardWallet();
    public DailyRewardProgress dailyReward = new DailyRewardProgress();
    public BattlePassProgress battlePass = new BattlePassProgress();
    public Set<String> claimedNpcRewards = new HashSet<>();
    public boolean megaEvolutionUnlocked;
    public Set<String> defeatedTrainers = new HashSet<>();
    public Set<String> defeatedDungeonTrainers = new HashSet<>();
    public Set<String> clearedDungeons = new HashSet<>();
    public Map<String, Long> kitClaims = new HashMap<>();
    public TowerProgress tower = new TowerProgress();
    public EventProgress events = new EventProgress();
    public Set<String> claimedDungeonLoot = new HashSet<>();

    public static PlayerData create(UUID playerId) {
        long now = System.currentTimeMillis();
        PlayerData data = new PlayerData();
        data.playerId = playerId;
        data.firstSeenEpochMillis = now;
        data.lastSeenEpochMillis = now;
        data.normalize();
        return data;
    }

    public void normalize() {
        if (gachaProgress == null) gachaProgress = new HashMap<>();
        if (economy == null) economy = new EconomyProgress();
        if (jobs == null) jobs = new JobProgress();
        if (quests == null) quests = new QuestProgress();
        if (rewardWallet == null) rewardWallet = new RewardWallet();
        if (dailyReward == null) dailyReward = new DailyRewardProgress();
        if (battlePass == null) battlePass = new BattlePassProgress();
        if (claimedNpcRewards == null) claimedNpcRewards = new HashSet<>();
        if (defeatedTrainers == null) defeatedTrainers = new HashSet<>();
        if (defeatedDungeonTrainers == null) defeatedDungeonTrainers = new HashSet<>();
        if (clearedDungeons == null) clearedDungeons = new HashSet<>();
        if (kitClaims == null) kitClaims = new HashMap<>();
        if (tower == null) tower = new TowerProgress();
        if (events == null) events = new EventProgress();
        if (claimedDungeonLoot == null) claimedDungeonLoot = new HashSet<>();
        economy.normalize();
        jobs.normalize();
        quests.normalize();
        rewardWallet.normalize();
        dailyReward.normalize();
        battlePass.normalize();
        tower.normalize();
        events.normalize();
        dataVersion = 13;
    }

    public GachaProgress gacha(String bannerId) {
        normalize();
        return gachaProgress.computeIfAbsent(bannerId, ignored -> new GachaProgress());
    }

    public void touch() {
        lastSeenEpochMillis = System.currentTimeMillis();
    }
}
