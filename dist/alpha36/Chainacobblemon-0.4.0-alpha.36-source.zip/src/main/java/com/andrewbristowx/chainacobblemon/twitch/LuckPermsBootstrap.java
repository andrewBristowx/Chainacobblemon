package com.andrewbristowx.chainacobblemon.twitch;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Optional LuckPerms bootstrap. Uses reflection so Chainacobblemon keeps working
 * in integrated singleplayer worlds and servers where LuckPerms is not installed.
 */
public final class LuckPermsBootstrap {
    private static final long GROUP_CACHE_MS = 2_000L;
    private static final ConcurrentHashMap<UUID, CachedGroups> GROUP_CACHE = new ConcurrentHashMap<>();
    private static volatile Object luckPerms;
    private static volatile boolean available;

    private LuckPermsBootstrap() { }

    public static void serverStarted(MinecraftServer server, ConfigManager configManager) {
        GROUP_CACHE.clear();
        available = false;
        luckPerms = null;
        if (!configManager.get().twitch.luckPermsAutoConfigure) return;
        if (!FabricLoader.getInstance().isModLoaded("luckperms")) {
            Chainacobblemon.LOGGER.info("LuckPerms not detected; Chaina ranks will use internal Twitch state only");
            return;
        }

        try {
            Class<?> provider = Class.forName("net.luckperms.api.LuckPermsProvider");
            Object api = provider.getMethod("get").invoke(null);
            luckPerms = api;
            available = true;

            var settings = configManager.get().twitch;
            List<CompletableFuture<?>> futures = new ArrayList<>();
            futures.add(ensureGroup(api, settings.linkedGroup, null,
                    List.of("chainacobblemon.twitch.linked")));
            futures.add(ensureGroup(api, settings.tier1Group, settings.linkedGroup,
                    List.of("chainacobblemon.twitch.sub", "chainacobblemon.twitch.sub.1")));
            futures.add(ensureGroup(api, settings.tier2Group, settings.tier1Group,
                    List.of("chainacobblemon.twitch.sub.2")));
            futures.add(ensureGroup(api, settings.tier3Group, settings.tier2Group,
                    List.of("chainacobblemon.twitch.sub.3")));
            futures.add(ensureGroup(api, settings.vipTwitchGroup, null,
                    List.of("chainacobblemon.twitch.vip")));
            futures.add(ensureGroup(api, settings.moderatorTwitchGroup, null,
                    List.of("chainacobblemon.twitch.mod")));

            CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new)).whenComplete((ignored, error) -> {
                if (error != null) {
                    Chainacobblemon.LOGGER.warn("LuckPerms Chaina group bootstrap finished with an error", error);
                } else {
                    Chainacobblemon.LOGGER.info("LuckPerms ready: Twitch groups {} -> {} -> {} -> {} + roles {} / {}",
                            settings.linkedGroup, settings.tier1Group, settings.tier2Group, settings.tier3Group,
                            settings.vipTwitchGroup, settings.moderatorTwitchGroup);
                }
                GROUP_CACHE.clear();
            });
        } catch (Throwable exception) {
            available = false;
            luckPerms = null;
            Chainacobblemon.LOGGER.warn("Could not initialize optional LuckPerms integration", exception);
        }
    }

    public static boolean available() {
        return available && luckPerms != null;
    }

    public static Set<String> inheritedGroups(ServerPlayerEntity player) {
        if (player == null || !available()) return Set.of();
        long now = System.currentTimeMillis();
        CachedGroups cached = GROUP_CACHE.get(player.getUuid());
        if (cached != null && now - cached.loadedAt < GROUP_CACHE_MS) return cached.groups;

        Set<String> groups = queryGroups(player);
        GROUP_CACHE.put(player.getUuid(), new CachedGroups(now, groups));
        return groups;
    }

    public static void invalidate(UUID playerId) {
        if (playerId != null) GROUP_CACHE.remove(playerId);
    }

    private static CompletableFuture<?> ensureGroup(Object api, String rawName, String rawParent, List<String> permissions) throws Exception {
        String name = normalizeGroup(rawName);
        String parent = normalizeGroup(rawParent);
        Class<?> luckPermsApi = Class.forName("net.luckperms.api.LuckPerms");
        Object groupManager = luckPermsApi.getMethod("getGroupManager").invoke(api);
        Class<?> groupManagerApi = Class.forName("net.luckperms.api.model.group.GroupManager");
        Method modifyGroup = groupManagerApi.getMethod("modifyGroup", String.class, Consumer.class);
        Consumer<Object> action = group -> {
            try {
                Class<?> permissionHolderApi = Class.forName("net.luckperms.api.model.PermissionHolder");
                Object data = permissionHolderApi.getMethod("data").invoke(group);
                if (!parent.isBlank() && !parent.equals(name)) {
                    addNode(data, "net.luckperms.api.node.types.InheritanceNode", parent);
                }
                for (String permission : permissions) {
                    if (permission != null && !permission.isBlank()) {
                        addNode(data, "net.luckperms.api.node.types.PermissionNode", permission);
                    }
                }
            } catch (Throwable exception) {
                throw new RuntimeException(exception);
            }
        };
        Object result = modifyGroup.invoke(groupManager, name, action);
        return result instanceof CompletableFuture<?> future ? future : CompletableFuture.completedFuture(null);
    }

    private static void addNode(Object data, String nodeClassName, String value) throws Exception {
        Class<?> nodeClass = Class.forName(nodeClassName);
        Object builder = nodeClass.getMethod("builder", String.class).invoke(null, value);
        Class<?> nodeBuilderApi = Class.forName("net.luckperms.api.node.NodeBuilder");
        Object node = nodeBuilderApi.getMethod("build").invoke(builder);
        Class<?> nodeApi = Class.forName("net.luckperms.api.node.Node");
        Class<?> nodeMapApi = Class.forName("net.luckperms.api.model.data.NodeMap");
        nodeMapApi.getMethod("add", nodeApi).invoke(data, node);
    }

    private static Set<String> queryGroups(ServerPlayerEntity player) {
        Object api = luckPerms;
        if (api == null) return Set.of();
        try {
            Class<?> luckPermsApi = Class.forName("net.luckperms.api.LuckPerms");
            Object userManager = luckPermsApi.getMethod("getUserManager").invoke(api);
            Class<?> userManagerApi = Class.forName("net.luckperms.api.model.user.UserManager");
            Object user = userManagerApi.getMethod("getUser", UUID.class).invoke(userManager, player.getUuid());
            if (user == null) return Set.of();
            Class<?> queryOptions = Class.forName("net.luckperms.api.query.QueryOptions");
            Object options = queryOptions.getMethod("nonContextual").invoke(null);
            Class<?> permissionHolderApi = Class.forName("net.luckperms.api.model.PermissionHolder");
            Object inherited = permissionHolderApi.getMethod("getInheritedGroups", queryOptions).invoke(user, options);
            if (!(inherited instanceof Collection<?> collection)) return Set.of();
            LinkedHashSet<String> names = new LinkedHashSet<>();
            for (Object group : collection) {
                Class<?> groupApi = Class.forName("net.luckperms.api.model.group.Group");
                Object rawName = groupApi.getMethod("getName").invoke(group);
                if (rawName != null) names.add(rawName.toString().toLowerCase(Locale.ROOT));
            }
            return Collections.unmodifiableSet(names);
        } catch (Throwable exception) {
            Chainacobblemon.LOGGER.debug("Could not read LuckPerms groups for {}", player.getGameProfile().getName(), exception);
            return Set.of();
        }
    }

    private static String normalizeGroup(String value) {
        if (value == null) return "";
        return value.strip().toLowerCase(Locale.ROOT).replace(' ', '_');
    }

    private record CachedGroups(long loadedAt, Set<String> groups) { }
}
