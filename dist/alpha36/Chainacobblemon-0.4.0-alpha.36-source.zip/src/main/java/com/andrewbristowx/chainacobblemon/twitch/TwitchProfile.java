package com.andrewbristowx.chainacobblemon.twitch;

import java.time.Instant;
import java.util.UUID;

/** Persisted non-sensitive Twitch state. OAuth tokens deliberately never live here. */
public final class TwitchProfile {
    public UUID minecraftUuid;
    public String minecraftName = "";
    public boolean linked;
    public String twitchUserId = "";
    public String twitchLogin = "";
    public int tier;
    /** Twitch role data is non-sensitive and is learned by ChainaBridge from chat badges. */
    public boolean twitchVip;
    public boolean twitchModerator;
    public boolean twitchRolesKnown;
    public long twitchRolesObservedAtEpochSeconds;
    public long lastSyncEpochSeconds;

    public TwitchProfile() { }

    public TwitchProfile(UUID playerId, String playerName) {
        this.minecraftUuid = playerId;
        this.minecraftName = playerName == null ? "" : playerName;
    }

    public void normalize(UUID fallbackId, String fallbackName) {
        if (minecraftUuid == null) minecraftUuid = fallbackId;
        if (minecraftName == null || minecraftName.isBlank()) minecraftName = fallbackName == null ? "" : fallbackName;
        if (twitchUserId == null) twitchUserId = "";
        if (twitchLogin == null) twitchLogin = "";
        tier = Math.clamp(tier, 0, 3);
        if (!linked) {
            twitchUserId = "";
            twitchLogin = "";
            tier = 0;
            twitchVip = false;
            twitchModerator = false;
            twitchRolesKnown = false;
            twitchRolesObservedAtEpochSeconds = 0L;
        }
        if (!twitchRolesKnown) {
            twitchVip = false;
            twitchModerator = false;
            twitchRolesObservedAtEpochSeconds = 0L;
        }
        if (twitchRolesObservedAtEpochSeconds < 0L) twitchRolesObservedAtEpochSeconds = 0L;
        if (lastSyncEpochSeconds < 0L) lastSyncEpochSeconds = 0L;
    }

    public void touch() {
        lastSyncEpochSeconds = Instant.now().getEpochSecond();
    }
}
