package com.andrewbristowx.chainacobblemon.command;

import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.data.PlayerDataManager;
import com.andrewbristowx.chainacobblemon.gacha.GachaProgress;
import com.andrewbristowx.chainacobblemon.gacha.GachaRollResult;
import com.andrewbristowx.chainacobblemon.gacha.GachaService;
import com.andrewbristowx.chainacobblemon.gacha.GachaTier;
import com.andrewbristowx.chainacobblemon.gacha.banner.BannerDefinition;
import com.andrewbristowx.chainacobblemon.gacha.banner.BannerManager;
import com.andrewbristowx.chainacobblemon.gacha.banner.FeaturedRotationService;
import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogEntry;
import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Map;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class GachaCommands {
    private GachaCommands() {
    }

    public static void register(
            PokemonCatalogService catalog,
            BannerManager banners,
            GachaService gacha,
            PlayerDataManager playerData
    ) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                register(dispatcher, catalog, banners, gacha, playerData, com.andrewbristowx.chainacobblemon.Chainacobblemon.featuredRotation()));
    }

    private static void register(
            CommandDispatcher<ServerCommandSource> dispatcher,
            PokemonCatalogService catalog,
            BannerManager banners,
            GachaService gacha,
            PlayerDataManager playerData,
            FeaturedRotationService featuredRotation
    ) {
        dispatcher.register(literal("chainacobblemon")
                .then(literal("gacha")
                        .then(literal("catalog")
                                .executes(context -> {
                                    Map<GachaTier, Long> counts = catalog.tierCounts();
                                    context.getSource().sendFeedback(() -> Text.literal(
                                            "Catalogo Chainacobblemon: " + catalog.size() + " Pokemon | " + formatCountsLong(counts)), false);
                                    return catalog.size();
                                }))
                        .then(literal("inspect")
                                .then(argument("pokemon", StringArgumentType.word())
                                        .executes(context -> {
                                            String id = StringArgumentType.getString(context, "pokemon");
                                            PokemonCatalogEntry entry = catalog.get(id);
                                            if (entry == null) {
                                                context.getSource().sendError(Text.literal("Pokemon no encontrado en el catalogo: " + id));
                                                return 0;
                                            }
                                            context.getSource().sendFeedback(() -> Text.literal(
                                                    entry.displayName() + " | tier=" + entry.tier().name()
                                                            + " | gen=" + entry.generation()
                                                            + " | region=" + entry.region()
                                                            + " | tipos=" + entry.types()
                                                            + " | catchRate=" + entry.catchRate()
                                                            + " | BST=" + entry.baseStatTotal()
                                                            + " | labels=" + entry.labels()), false);
                                            return 1;
                                        })))
                        .then(literal("banners")
                                .executes(context -> {
                                    String names = banners.all().stream()
                                            .map(banner -> banner.id + (banner.enabled ? "" : " [OFF]"))
                                            .reduce((a, b) -> a + ", " + b).orElse("ninguno");
                                    context.getSource().sendFeedback(() -> Text.literal("Banners: " + names), false);
                                    return banners.size();
                                }))
                        .then(literal("info")
                                .then(argument("banner", StringArgumentType.word())
                                        .executes(context -> {
                                            String id = StringArgumentType.getString(context, "banner");
                                            BannerDefinition banner = banners.get(id);
                                            if (banner == null) {
                                                context.getSource().sendError(Text.literal("Banner no encontrado: " + id));
                                                return 0;
                                            }
                                            Map<GachaTier, Integer> counts = gacha.poolCounts(id);
                                            String generations = banner.generations.isEmpty() ? "todas" : banner.generations.toString();
                                            String featured = banner.featuredSpecies.isEmpty() ? "ninguno" : banner.featuredSpecies.toString();
                                            context.getSource().sendFeedback(() -> Text.literal(
                                                    banner.displayName + " | generaciones=" + generations
                                                            + " | destacados=" + featured
                                                            + " | pool: " + formatCounts(counts)), false);
                                            return 1;
                                        })))
                        .then(literal("pity")
                                .then(argument("banner", StringArgumentType.word())
                                        .executes(context -> {
                                            ServerPlayerEntity player = context.getSource().getPlayer();
                                            if (player == null) {
                                                context.getSource().sendError(Text.literal("Este comando debe ejecutarse como jugador."));
                                                return 0;
                                            }
                                            String id = StringArgumentType.getString(context, "banner");
                                            BannerDefinition banner = banners.get(id);
                                            if (banner == null) {
                                                context.getSource().sendError(Text.literal("Banner no encontrado: " + id));
                                                return 0;
                                            }
                                            PlayerData data = playerData.getOrLoad(player.getUuid());
                                            GachaProgress progress = data.gacha(banner.id);
                                            context.getSource().sendFeedback(() -> Text.literal(
                                                    "Pity " + banner.displayName + ": total=" + progress.totalPulls
                                                            + " | epico=" + progress.pullsSinceEpicOrBetter + "/" + banner.pity.epicGuarantee
                                                            + " | legendario=" + progress.pullsSinceLegendaryOrBetter + "/" + banner.pity.hardLegendaryGuarantee), false);
                                            return 1;
                                        })))
                        .then(literal("simulate")
                                .requires(source -> source.hasPermissionLevel(4))
                                .then(argument("banner", StringArgumentType.word())
                                        .executes(context -> {
                                            String id = StringArgumentType.getString(context, "banner");
                                            GachaRollResult result = gacha.simulate(id);
                                            if (result == null) {
                                                context.getSource().sendError(Text.literal("No se pudo simular el banner " + id));
                                                return 0;
                                            }
                                            context.getSource().sendFeedback(() -> Text.literal("SIMULACION: " + describe(result)), false);
                                            return 1;
                                        })))
                        .then(literal("pull")
                                .requires(source -> source.hasPermissionLevel(4))
                                .then(argument("banner", StringArgumentType.word())
                                        .executes(context -> {
                                            ServerPlayerEntity player = context.getSource().getPlayer();
                                            if (player == null) {
                                                context.getSource().sendError(Text.literal("Este comando debe ejecutarse como jugador."));
                                                return 0;
                                            }
                                            String id = StringArgumentType.getString(context, "banner");
                                            GachaService.PullOutcome outcome = gacha.pull(player, id);
                                            if (!outcome.success()) {
                                                context.getSource().sendError(Text.literal("Gacha: " + outcome.error()));
                                                return 0;
                                            }
                                            GachaRollResult result = outcome.result();
                                            context.getSource().sendFeedback(() -> Text.literal("GACHA: " + describe(result)), false);
                                            return 1;
                                        })))
                        .then(literal("featured")
                                .requires(source -> source.hasPermissionLevel(4))
                                .then(literal("chaina")
                                        .then(literal("current").executes(context -> {
                                            PokemonCatalogEntry forced = featuredRotation.forcedChainaLegendary();
                                            PokemonCatalogEntry current = featuredRotation.currentChainaLegendary();
                                            String suffix = forced != null ? " | forzado=" + forced.displayName() : "";
                                            context.getSource().sendFeedback(() -> Text.literal(current == null ? "No hay legendario actual de Chaina todavía." : "Legendario actual de Chaina: " + current.displayName() + suffix), false);
                                            return current == null ? 0 : 1;
                                        }))
                                        .then(literal("force").then(argument("pokemon", StringArgumentType.word()).executes(context -> {
                                            String id = StringArgumentType.getString(context, "pokemon");
                                            PokemonCatalogEntry entry = featuredRotation.forceChainaLegendary(id);
                                            if (entry == null) { context.getSource().sendError(Text.literal("Debes indicar un Pokemon legendario válido del catálogo: " + id)); return 0; }
                                            context.getSource().sendFeedback(() -> Text.literal("Legendario de Chaina forzado a: " + entry.displayName() + " (los gashas se actualizarán en pocos segundos)."), true);
                                            return 1;
                                        })))
                                        .then(literal("clear").executes(context -> {
                                            PokemonCatalogEntry current = featuredRotation.clearForcedChainaLegendary();
                                            context.getSource().sendFeedback(() -> Text.literal(current == null ? "Se limpió el forzado del legendario de Chaina." : "Se limpió el forzado del legendario de Chaina. Ahora rota: " + current.displayName()), true);
                                            return 1;
                                        }))))
                        .then(literal("reload")
                                .requires(source -> source.hasPermissionLevel(4))
                                .executes(context -> {
                                    boolean bannerOk = banners.reload();
                                    catalog.rebuild();
                                    context.getSource().sendFeedback(() -> Text.literal(
                                            bannerOk
                                                    ? "Gacha recargado: " + banners.size() + " banners, " + catalog.size() + " Pokemon."
                                                    : "Fallo al recargar banners; se conservaron los ultimos validos. Catalogo reconstruido."), false);
                                    return bannerOk ? 1 : 0;
                                }))));
    }

    private static String describe(GachaRollResult result) {
        StringBuilder text = new StringBuilder()
                .append(result.tier().name()).append(" -> ")
                .append(result.pokemon().displayName()).append(" Nv.").append(result.level());
        if (result.shiny()) text.append(" SHINY");
        if (result.hasNatureBonus()) text.append(" | naturaleza=").append(result.nature());
        if (result.hasPerfectIvBonus()) text.append(" | minPerfectIvs=").append(result.minPerfectIvs());
        if (result.legendaryPityTriggered()) text.append(" [HARD PITY]");
        else if (result.epicPityTriggered()) text.append(" [PITY]");
        return text.toString();
    }

    private static String formatCounts(Map<GachaTier, Integer> counts) {
        StringBuilder text = new StringBuilder();
        for (GachaTier tier : GachaTier.values()) {
            int count = counts.getOrDefault(tier, 0);
            if (count <= 0) continue;
            if (!text.isEmpty()) text.append(" | ");
            text.append(tier.name()).append('=').append(count);
        }
        return text.toString();
    }

    private static String formatCountsLong(Map<GachaTier, Long> counts) {
        StringBuilder text = new StringBuilder();
        for (GachaTier tier : GachaTier.values()) {
            long count = counts.getOrDefault(tier, 0L);
            if (count <= 0) continue;
            if (!text.isEmpty()) text.append(" | ");
            text.append(tier.name()).append('=').append(count);
        }
        return text.toString();
    }
}
