package com.andrewbristowx.chainacobblemon.protection;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.Collection;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** Administrative recovery for claims orphaned by versions before alpha.15. */
public final class ProtectionRecoveryCommands {
    private ProtectionRecoveryCommands() { }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("chainacobblemon").requires(source -> source.hasPermissionLevel(4))
                .then(literal("protection")
                        .then(literal("cleanuporphans")
                                .executes(ctx -> cleanup(ctx.getSource(), 160))
                                .then(argument("radius", IntegerArgumentType.integer(16, 512))
                                        .executes(ctx -> cleanup(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius")))))));
    }

    private static int cleanup(ServerCommandSource source, int radius) {
        ServerPlayerEntity player;
        try { player = source.getPlayerOrThrow(); }
        catch (Exception exception) { source.sendError(Text.literal("Ejecuta este comando como jugador dentro de la zona.")); return 0; }
        if (!(player.getWorld() instanceof ServerWorld world)) return 0;
        try {
            Class<?> storageClass = Class.forName("io.github.flemmli97.flan.claim.ClaimStorage");
            Object storage = storageClass.getMethod("get", ServerWorld.class).invoke(null, world);
            Object raw = storageClass.getMethod("getNearbyClaims", ServerWorld.class, BlockPos.class, int.class, int.class)
                    .invoke(storage, world, player.getBlockPos(), radius, radius);
            if (!(raw instanceof Collection<?> claims)) {
                source.sendError(Text.literal("Flan no devolvió una colección de claims."));
                return 0;
            }
            int inspected = 0, removed = 0;
            for (Object claim : claims) {
                String name = String.valueOf(claim.getClass().getMethod("getClaimName").invoke(claim));
                if (name == null || !name.toLowerCase(java.util.Locale.ROOT).startsWith("protecci")) continue;
                inspected++;
                Object box = claim.getClass().getMethod("getDimensions").invoke(claim);
                int minX = (int) box.getClass().getMethod("minX").invoke(box);
                int maxX = (int) box.getClass().getMethod("maxX").invoke(box);
                int minZ = (int) box.getClass().getMethod("minZ").invoke(box);
                int maxZ = (int) box.getClass().getMethod("maxZ").invoke(box);
                int centerX = (minX + maxX) / 2;
                int centerZ = (minZ + maxZ) / 2;
                if (coreExists(world, centerX, centerZ)) continue;
                UUID id = (UUID) claim.getClass().getMethod("getClaimID").invoke(claim);
                if (id != null && !ProtectionClaimRecoveryService.removeAndCheck(world, id)) removed++;
            }
            int finalInspected = inspected, finalRemoved = removed;
            source.sendFeedback(() -> Text.literal("§aProtecciones: §f" + finalRemoved + " claim(s) huérfano(s) eliminado(s) §7de " + finalInspected + " revisados."), true);
            return removed;
        } catch (ClassNotFoundException missing) {
            source.sendError(Text.literal("Flan no está cargado."));
            return 0;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.error("Protection orphan cleanup failed", exception);
            source.sendError(Text.literal("No se pudieron limpiar claims huérfanos; revisa latest.log."));
            return 0;
        }
    }

    private static boolean coreExists(ServerWorld world, int x, int z) {
        int bottom = world.getBottomY();
        int top = bottom + world.getHeight();
        BlockPos.Mutable pos = new BlockPos.Mutable(x, bottom, z);
        for (int y = bottom; y < top; y++) {
            pos.setY(y);
            Identifier id = Registries.BLOCK.getId(world.getBlockState(pos).getBlock());
            if (id != null && "chainacobblemon".equals(id.getNamespace()) && id.getPath().startsWith("protection_core")) return true;
        }
        return false;
    }
}
