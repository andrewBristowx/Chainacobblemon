package com.andrewbristowx.chainacobblemon.twitch;

/** Client-facing Twitch state. Contains no OAuth tokens or secrets. */
public final class TwitchSnapshot {
    public boolean visible = true;
    /** True when the snapshot is an administrator view of another player. */
    public boolean adminView;
    public String targetUuid = "";
    public String targetName = "";
    public boolean enabled;
    public String mode = "development";
    public String broadcaster = "chainavt";
    public boolean channelOnline;
    public boolean channelKnown;
    public boolean streamHudEnabled = true;
    public boolean styledPlayerListIntegrated;
    public boolean streamBonusesActive;
    public boolean streamJackpot;
    public String streamSessionId = "";
    public java.util.List<String> streamBonuses = new java.util.ArrayList<>();
    public boolean linked;
    public String twitchLogin = "";
    /** 0 = no sub, 1/2/3 = Twitch subscription tier. */
    public int tier;
    public String rankLabel = "Sin vincular";
    public String lastSync = "Nunca";
    public String message = "";
    public String linkUrl = "";
    public String linkCode = "";
}
