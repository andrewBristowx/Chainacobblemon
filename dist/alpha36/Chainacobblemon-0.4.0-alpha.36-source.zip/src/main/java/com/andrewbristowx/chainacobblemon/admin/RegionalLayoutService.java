package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureStart;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.text.Text;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Builds CHAINA's regional campaign inside a controlled Overworld area instead of accepting whatever
 * extreme coordinates /locate happens to return. Planning is deterministic for the world seed and is
 * deliberately incremental so terrain checks do not freeze the main server thread.
 *
 * <p>Registered worldgen structures are placed through vanilla's {@code /place structure}; template-only
 * Cobbleverse assets are placed through the server {@link StructureTemplate} manager. Existing official
 * coordinates are not replaced until a placement succeeds, so a failed asset cannot silently destroy the
 * working 69-location map.</p>
 */
public final class RegionalLayoutService {
    public static final int DEFAULT_TARGET_RADIUS_BLOCKS = 9000;
    public static final int HARD_MAX_RADIUS_BLOCKS = 10000;
    public static final int DEFAULT_MIN_SEPARATION_BLOCKS = 512;

    private static final int MIN_TARGET_RADIUS_BLOCKS = 5000;
    private static final int MAX_CONFIGURED_RADIUS_BLOCKS = 12000;
    private static final int MAX_CANDIDATES = 14;
    private static final int PLAN_INTERVAL_TICKS = 4;
    private static final int PLACE_INTERVAL_TICKS = 80;
    private static final int SPAWN_CLEARANCE_BLOCKS = 1000;
    private static final double GOLDEN_ANGLE = Math.PI * (3.0 - Math.sqrt(5.0));

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ConfigManager configManager;
    private static boolean initialized;
    private static long loadedSeed = Long.MIN_VALUE;
    private static SavedState saved = new SavedState();
    private static PlanJob planJob;
    private static PlaceJob placeJob;
    private static int tickCounter;

    private RegionalLayoutService() {}

    private enum PlacementMode { REGISTERED, TEMPLATE, UNSUPPORTED }
    private enum TerrainPreference { LAND, WATER, MOUNTAIN }

    private record PlacementAsset(String id, PlacementMode mode) {}
    private record PlannedPoint(int x, int y, int z, double score, TerrainPreference terrain) {}
    private record PlanItem(String key, String regionId, String regionName, int order, String label,
                            PlacementAsset asset, int sequence, int total) {}

    private static final class LayoutEntry {
        String key = "";
        String regionId = "";
        String regionName = "";
        int order;
        String label = "";
        String structureId = "";
        String placementMode = "";
        String terrain = "";
        int x;
        int y;
        int z;
        double score;
        boolean planned;
        boolean placed;
        boolean failed;
        String lastError = "";
    }

    private static final class SavedState {
        long seed;
        int targetRadiusBlocks = DEFAULT_TARGET_RADIUS_BLOCKS;
        int minSeparationBlocks = DEFAULT_MIN_SEPARATION_BLOCKS;
        boolean planComplete;
        boolean generationComplete;
        Map<String, LayoutEntry> entries = new LinkedHashMap<>();
    }

    private static final class PlanJob {
        final List<PlanItem> items;
        final UUID requester;
        int itemIndex;
        int candidateIndex;
        PlannedPoint best;

        PlanJob(List<PlanItem> items, UUID requester) {
            this.items = items;
            this.requester = requester;
        }
    }

    private static final class PlaceJob {
        final List<LayoutEntry> entries;
        final UUID requester;
        int index;
        int placed;
        int failed;

        PlaceJob(List<LayoutEntry> entries, UUID requester) {
            this.entries = entries;
            this.requester = requester;
        }
    }

    public record LayoutSnapshot(int total, int planned, int placed, int failed, int unsupported,
                                 boolean planning, boolean generating, boolean planComplete,
                                 boolean generationComplete, int targetRadiusBlocks, int minSeparationBlocks) {}

    public static synchronized void initialize(ConfigManager config) {
        configManager = config;
        if (initialized) return;
        initialized = true;
        ServerTickEvents.END_SERVER_TICK.register(RegionalLayoutService::tick);
    }

    public static synchronized int analyze(ServerCommandSource source, int requestedRadius) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
        int radius = clampRadius(requestedRadius);
        int borderRadius = alignUp(radius + FullWorldPregenService.DEFAULT_MARGIN_BLOCKS,
                FullWorldPregenService.REGION_ALIGNMENT_BLOCKS);
        long chunksAxis = (borderRadius * 2L) / 16L;
        long chunks = chunksAxis * chunksAxis;

        source.sendFeedback(() -> Text.literal("§d§lCHAINA · REGIONAL LAYOUT CONTROLADO"), false);
        source.sendFeedback(() -> Text.literal("§7Mapa actual: §f" + map.located() + "/" + map.total()
                + (map.complete() ? " §aCOMPLETO" : " §cINCOMPLETO")), false);
        source.sendFeedback(() -> Text.literal("§7Radio objetivo de estructuras: §f" + radius
                + " bloques §7· separación mínima: §f" + saved.minSeparationBlocks + " bloques."), false);
        source.sendFeedback(() -> Text.literal("§7Borde final esperado con margen de 1024: §a~" + borderRadius
                + " de radio §7(§f" + (borderRadius * 2) + " × " + (borderRadius * 2) + "§7)."), false);
        source.sendFeedback(() -> Text.literal("§7Pregeneración aproximada posterior: §f" + chunksAxis + " × "
                + chunksAxis + " = " + formatLong(chunks) + " chunks§7."), false);
        source.sendFeedback(() -> Text.literal("§8Kanto se prioriza cerca; Johto/Hoenn/Sinnoh se abren progresivamente hacia el exterior."), false);
        source.sendFeedback(() -> Text.literal("§8Antes de generar se comprueba superficie, pendiente, agua y distancia entre ubicaciones. Las coordenadas antiguas no se sustituyen hasta colocar cada estructura con éxito."), false);
        if (!map.complete()) {
            source.sendFeedback(() -> Text.literal("§cPrimero completa las 69/69 ubicaciones; se usan para conocer el ID real de cada asset del modpack."), false);
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§bSiguiente: §f/chainacobblemon regionlayout planificar " + radius + " confirm"), false);
        return 1;
    }

    public static synchronized int startPlan(ServerCommandSource source, int requestedRadius, boolean confirm) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        if (planJob != null || placeJob != null) {
            source.sendFeedback(() -> Text.literal("§eYa hay una tarea de Regional Layout en ejecución."), false);
            return 0;
        }
        ImportantLocationService.MapSnapshot map = ImportantLocationService.snapshot(server);
        if (!map.complete()) {
            source.sendFeedback(() -> Text.literal("§cRegional Layout requiere el mapa 69/69 para conservar la identidad exacta de cada estructura."), false);
            return 0;
        }
        int radius = clampRadius(requestedRadius);
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eEsto buscará nuevas posiciones dentro de " + radius
                    + " bloques del spawn. §aNo coloca estructuras todavía§e. Repite con §fconfirm§e."), false);
            return 1;
        }

        List<PlanItem> items = buildItems(server, map);
        if (items.size() != map.total()) {
            source.sendFeedback(() -> Text.literal("§cNo pude construir los " + map.total() + " elementos del layout; encontrados: " + items.size() + "."), false);
            return 0;
        }

        saved = new SavedState();
        saved.seed = server.getOverworld().getSeed();
        saved.targetRadiusBlocks = radius;
        saved.minSeparationBlocks = DEFAULT_MIN_SEPARATION_BLOCKS;
        saved.entries = new LinkedHashMap<>();
        saved.planComplete = false;
        saved.generationComplete = false;
        UUID requester = source.getEntity() == null ? null : source.getEntity().getUuid();
        planJob = new PlanJob(items, requester);
        tickCounter = PLAN_INTERVAL_TICKS;
        save(server);
        source.sendFeedback(() -> Text.literal("§dPlanificación regional iniciada: §f" + items.size()
                + "§d ubicaciones dentro de un radio objetivo de §f" + radius + "§d."), false);
        source.sendFeedback(() -> Text.literal("§8Se prueba un candidato cada pocos ticks para no congelar el servidor. Usa /chainacobblemon regionlayout estado."), false);
        return 1;
    }

    public static synchronized int status(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        LayoutSnapshot snapshot = snapshot(source.getServer());
        source.sendFeedback(() -> Text.literal("§d§lCHAINA · REGIONAL LAYOUT"), false);
        source.sendFeedback(() -> Text.literal("§7Plan: §f" + snapshot.planned() + "/" + snapshot.total()
                + (snapshot.planComplete() ? " §aCOMPLETO" : snapshot.planning() ? " §ePLANIFICANDO" : " §7")), false);
        source.sendFeedback(() -> Text.literal("§7Colocadas: §a" + snapshot.placed() + " §7· fallidas: §c"
                + snapshot.failed() + " §7· no colocables automáticamente: §e" + snapshot.unsupported()), false);
        source.sendFeedback(() -> Text.literal("§7Radio objetivo: §f" + snapshot.targetRadiusBlocks()
                + " §7· separación: §f" + snapshot.minSeparationBlocks()), false);
        if (snapshot.generating()) {
            source.sendFeedback(() -> Text.literal("§eGeneración física en progreso. No inicies Chunky ni apliques el borde final todavía."), false);
        } else if (snapshot.generationComplete()) {
            source.sendFeedback(() -> Text.literal("§aRegional Layout terminado. Ya puedes recalcular el WorldBorder."), false);
            source.sendFeedback(() -> Text.literal("§b/chainacobblemon worldborder calcular"), false);
        } else if (snapshot.planComplete()) {
            source.sendFeedback(() -> Text.literal("§bSiguiente: §f/chainacobblemon regionlayout generar confirm"), false);
        }
        return snapshot.generationComplete() ? 1 : 0;
    }

    public static synchronized int startGeneration(ServerCommandSource source, boolean confirm) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        if (planJob != null || placeJob != null) {
            source.sendFeedback(() -> Text.literal("§eYa hay una tarea de Regional Layout en ejecución."), false);
            return 0;
        }
        if (!saved.planComplete || saved.entries.isEmpty()) {
            source.sendFeedback(() -> Text.literal("§cPrimero ejecuta /chainacobblemon regionlayout planificar ... confirm y espera a que termine."), false);
            return 0;
        }
        long planned = saved.entries.values().stream().filter(entry -> entry.planned).count();
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eSe colocarán físicamente §f" + planned
                    + "§e estructuras dentro del Overworld. Las ubicaciones oficiales solo cambian después de cada colocación exitosa."), false);
            source.sendFeedback(() -> Text.literal("§cHaz backup antes de esta fase. §eRepite añadiendo §fconfirm§e."), false);
            return 1;
        }

        for (LayoutEntry entry : saved.entries.values()) {
            entry.placed = false;
            entry.failed = false;
            entry.lastError = "";
        }
        saved.generationComplete = false;
        List<LayoutEntry> queue = saved.entries.values().stream()
                .filter(entry -> entry.planned)
                .sorted(Comparator.comparing((LayoutEntry entry) -> regionRank(entry.regionId)).thenComparingInt(entry -> entry.order))
                .toList();
        UUID requester = source.getEntity() == null ? null : source.getEntity().getUuid();
        placeJob = new PlaceJob(new ArrayList<>(queue), requester);
        tickCounter = PLACE_INTERVAL_TICKS;
        save(server);
        source.sendFeedback(() -> Text.literal("§dGeneración regional iniciada: §f" + queue.size()
                + "§d estructuras. Se procesa una cada ~4 s para limitar picos de CPU."), false);
        return 1;
    }

    public static synchronized int cancel(ServerCommandSource source) {
        boolean had = planJob != null || placeJob != null;
        planJob = null;
        placeJob = null;
        tickCounter = 0;
        source.sendFeedback(() -> Text.literal(had
                ? "§eTarea Regional Layout detenida. Las estructuras ya colocadas no se borraron."
                : "§7No había una tarea Regional Layout activa."), false);
        return had ? 1 : 0;
    }

    public static synchronized int resetPlan(ServerCommandSource source, boolean confirm) {
        ensureLoaded(source.getServer());
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eEsto borra SOLO el plan guardado de Regional Layout. §cNo borra estructuras ya colocadas. §eAñade §fconfirm§e."), false);
            return 1;
        }
        planJob = null;
        placeJob = null;
        saved = new SavedState();
        saved.seed = source.getServer().getOverworld().getSeed();
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aPlan Regional Layout reiniciado. El mundo no fue modificado."), false);
        return 1;
    }

    public static synchronized LayoutSnapshot snapshot(MinecraftServer server) {
        ensureLoaded(server);
        int total = ImportantLocationService.snapshot(server).total();
        int planned = 0;
        int placed = 0;
        int failed = 0;
        int unsupported = 0;
        for (LayoutEntry entry : saved.entries.values()) {
            if (entry.planned) planned++;
            if (entry.placed) placed++;
            if (entry.failed) failed++;
            if (PlacementMode.UNSUPPORTED.name().equals(entry.placementMode)) unsupported++;
        }
        return new LayoutSnapshot(total, planned, placed, failed, unsupported,
                planJob != null, placeJob != null, saved.planComplete, saved.generationComplete,
                saved.targetRadiusBlocks, saved.minSeparationBlocks);
    }

    public static synchronized boolean blocksFinalBorder(MinecraftServer server) {
        ensureLoaded(server);
        return (!saved.entries.isEmpty() && (!saved.generationComplete || placeJob != null || planJob != null));
    }

    private static void tick(MinecraftServer server) {
        synchronized (RegionalLayoutService.class) {
            if (planJob != null) tickPlan(server);
            else if (placeJob != null) tickPlacement(server);
        }
    }

    private static void tickPlan(MinecraftServer server) {
        if (++tickCounter < PLAN_INTERVAL_TICKS) return;
        tickCounter = 0;
        if (planJob.itemIndex >= planJob.items.size()) {
            finishPlan(server);
            return;
        }

        PlanItem item = planJob.items.get(planJob.itemIndex);
        if (item.asset.mode == PlacementMode.UNSUPPORTED) {
            LayoutEntry entry = entryFor(item);
            entry.planned = false;
            entry.failed = true;
            entry.lastError = "No existe un STRUCTURE registrado ni una plantilla NBT colocable para este asset.";
            saved.entries.put(item.key, entry);
            notifyRequester(server, "§c✗ §f" + item.regionName + " · " + item.label + " §7(asset no colocable automáticamente)");
            planJob.itemIndex++;
            planJob.candidateIndex = 0;
            planJob.best = null;
            save(server);
            return;
        }

        PlannedPoint candidate = evaluateCandidate(server.getOverworld(), item, planJob.candidateIndex);
        if (candidate != null && (planJob.best == null || candidate.score < planJob.best.score)) {
            planJob.best = candidate;
        }
        planJob.candidateIndex++;

        if (planJob.candidateIndex < MAX_CANDIDATES) return;

        PlannedPoint chosen = planJob.best;
        if (chosen == null) {
            chosen = emergencyCandidate(server.getOverworld(), item);
        }
        LayoutEntry entry = entryFor(item);
        if (chosen == null) {
            entry.planned = false;
            entry.failed = true;
            entry.lastError = "No se encontró terreno seguro dentro del radio objetivo.";
            notifyRequester(server, "§c✗ §f" + item.regionName + " · " + item.label + " §7(sin terreno seguro)");
        } else {
            entry.x = chosen.x;
            entry.y = chosen.y;
            entry.z = chosen.z;
            entry.score = chosen.score;
            entry.terrain = chosen.terrain.name();
            entry.planned = true;
            entry.failed = false;
            entry.lastError = "";
            notifyRequester(server, "§a✓ §f" + item.regionName + " · " + item.label + " §7→ X "
                    + chosen.x + " Y " + chosen.y + " Z " + chosen.z);
        }
        saved.entries.put(item.key, entry);
        planJob.itemIndex++;
        planJob.candidateIndex = 0;
        planJob.best = null;
        save(server);
        if (planJob.itemIndex >= planJob.items.size()) finishPlan(server);
    }

    private static void finishPlan(MinecraftServer server) {
        PlanJob finished = planJob;
        planJob = null;
        int planned = (int) saved.entries.values().stream().filter(entry -> entry.planned).count();
        int unsupported = (int) saved.entries.values().stream()
                .filter(entry -> PlacementMode.UNSUPPORTED.name().equals(entry.placementMode)).count();
        saved.planComplete = planned == ImportantLocationService.EXPECTED_TOTAL;
        saved.generationComplete = false;
        save(server);
        if (finished != null) {
            notify(server, finished.requester, "§dRegional Layout: §f" + planned + "/" + ImportantLocationService.EXPECTED_TOTAL
                    + "§d posiciones planificadas." + (unsupported > 0 ? " §eNo colocables automáticamente: " + unsupported : ""));
            if (saved.planComplete) {
                notify(server, finished.requester, "§aPlan completo. Usa §f/chainacobblemon regionlayout generar confirm§a después de hacer backup.");
            } else {
                notify(server, finished.requester, "§cEl plan no está listo para generación total. Revisa /chainacobblemon regionlayout estado.");
            }
        }
    }

    private static void tickPlacement(MinecraftServer server) {
        if (++tickCounter < PLACE_INTERVAL_TICKS) return;
        tickCounter = 0;
        if (placeJob.index >= placeJob.entries.size()) {
            finishPlacement(server);
            return;
        }

        LayoutEntry entry = placeJob.entries.get(placeJob.index++);
        PlacementMode mode;
        try {
            mode = PlacementMode.valueOf(entry.placementMode);
        } catch (Exception ignored) {
            mode = PlacementMode.UNSUPPORTED;
        }
        String error = "";
        boolean success = false;
        try {
            if (mode == PlacementMode.REGISTERED) success = placeRegistered(server, entry);
            else if (mode == PlacementMode.TEMPLATE) success = placeTemplate(server, entry);
            else error = "Asset no colocable automáticamente.";
        } catch (Exception exception) {
            error = exception.getClass().getSimpleName() + ": " + (exception.getMessage() == null ? "sin detalle" : exception.getMessage());
            Chainacobblemon.LOGGER.warn("Regional layout placement failed for {} ({})", entry.label, entry.structureId, exception);
        }

        if (success) {
            entry.placed = true;
            entry.failed = false;
            entry.lastError = "";
            ImportantLocationService.recordGeneratedLocation(server, entry.key, entry.structureId,
                    World.OVERWORLD, new BlockPos(entry.x, entry.y, entry.z));
            placeJob.placed++;
            notifyRequester(server, "§a✓ Generada §f" + entry.regionName + " · " + entry.label
                    + " §7(" + entry.placementMode.toLowerCase(Locale.ROOT) + ")");
        } else {
            entry.placed = false;
            entry.failed = true;
            if (!error.isBlank()) entry.lastError = error;
            if (entry.lastError.isBlank()) entry.lastError = "La colocación no pudo verificarse.";
            placeJob.failed++;
            notifyRequester(server, "§c✗ Falló §f" + entry.regionName + " · " + entry.label + " §7→ " + entry.lastError);
        }
        saved.entries.put(entry.key, entry);
        save(server);
        if (placeJob.index >= placeJob.entries.size()) finishPlacement(server);
    }

    private static void finishPlacement(MinecraftServer server) {
        PlaceJob finished = placeJob;
        placeJob = null;
        int placed = (int) saved.entries.values().stream().filter(entry -> entry.placed).count();
        int failed = (int) saved.entries.values().stream().filter(entry -> entry.failed).count();
        saved.generationComplete = placed == ImportantLocationService.EXPECTED_TOTAL && failed == 0;
        save(server);
        if (finished != null) {
            notify(server, finished.requester, "§dRegional Layout terminado: §a" + placed + " colocadas §7· §c" + failed + " fallidas§7.");
            if (saved.generationComplete) {
                notify(server, finished.requester, "§a69/69 reubicadas dentro del mapa controlado. Ejecuta §f/chainacobblemon worldborder calcular§a.");
            } else {
                notify(server, finished.requester, "§eNo se modificaron las coordenadas oficiales de las estructuras que fallaron. Revisa el log antes de fijar el borde.");
            }
        }
    }

    private static boolean placeRegistered(MinecraftServer server, LayoutEntry entry) {
        ServerWorld world = server.getOverworld();
        Identifier id = Identifier.tryParse(entry.structureId);
        if (id == null) {
            entry.lastError = "ID STRUCTURE inválido.";
            return false;
        }
        Registry<Structure> registry = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
        Optional<RegistryEntry.Reference<Structure>> registered = registry.getEntry(id);
        if (registered.isEmpty()) {
            entry.lastError = "El ID ya no existe en RegistryKeys.STRUCTURE.";
            return false;
        }

        String command = "place structure " + id + " " + entry.x + " " + entry.y + " " + entry.z;
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withLevel(4).withSilent(), command);

        Structure expected = registered.get().value();
        ChunkPos center = new ChunkPos(entry.x >> 4, entry.z >> 4);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                List<StructureStart> starts = world.getStructureAccessor().getStructureStarts(
                        new ChunkPos(center.x + dx, center.z + dz), structure -> structure == expected);
                if (starts.stream().anyMatch(start -> start != null && start.hasChildren())) return true;
            }
        }
        entry.lastError = "/place structure terminó pero no apareció un StructureStart verificable cerca del punto.";
        return false;
    }

    private static boolean placeTemplate(MinecraftServer server, LayoutEntry entry) {
        ServerWorld world = server.getOverworld();
        Identifier id = Identifier.tryParse(entry.structureId);
        if (id == null) {
            entry.lastError = "ID de plantilla inválido.";
            return false;
        }
        Optional<StructureTemplate> optional = world.getStructureTemplateManager().getTemplate(id);
        if (optional.isEmpty()) {
            entry.lastError = "Plantilla NBT no encontrada por StructureTemplateManager.";
            return false;
        }
        StructureTemplate template = optional.get();
        int rotationIndex = Math.floorMod(entry.key.hashCode(), BlockRotation.values().length);
        BlockRotation rotation = BlockRotation.values()[rotationIndex];
        StructurePlacementData data = new StructurePlacementData()
                .setRotation(rotation)
                .setIgnoreEntities(false)
                .setInitializeMobs(true);
        BlockPos origin = new BlockPos(entry.x, entry.y, entry.z);
        boolean placed = template.place(world, origin, origin, data,
                Random.create(server.getOverworld().getSeed() ^ entry.key.hashCode()), 3);
        if (!placed) entry.lastError = "StructureTemplate.place devolvió false.";
        return placed;
    }

    private static PlannedPoint evaluateCandidate(ServerWorld world, PlanItem item, int attempt) {
        int[] ring = ringFor(item.regionId, saved.targetRadiusBlocks);
        long mixed = mix64(world.getSeed() ^ item.key.hashCode() * 0x9E3779B97F4A7C15L ^ (attempt * 0xC2B2AE3D27D4EB4FL));
        double unit = ((mixed >>> 11) & ((1L << 53) - 1)) / (double) (1L << 53);
        double angle = Math.floorMod(item.sequence * 17 + attempt * 29 + item.key.hashCode(), 4096) * GOLDEN_ANGLE;
        double radius = ring[0] + (ring[1] - ring[0]) * (0.18 + 0.82 * unit);
        int spawnX = world.getSpawnPos().getX();
        int spawnZ = world.getSpawnPos().getZ();
        int x = alignChunkCenter(spawnX + (int) Math.round(Math.cos(angle) * radius));
        int z = alignChunkCenter(spawnZ + (int) Math.round(Math.sin(angle) * radius));
        int edge = Math.max(Math.abs(x - spawnX), Math.abs(z - spawnZ));
        if (edge < SPAWN_CLEARANCE_BLOCKS || edge > HARD_MAX_RADIUS_BLOCKS) return null;
        if (!farEnough(x, z, saved.minSeparationBlocks)) return null;

        TerrainPreference preference = terrainPreference(item.label);
        TerrainSample terrain = sampleTerrain(world, x, z);
        if (terrain == null) return null;
        double score = terrain.score(preference);
        if (score >= 100000.0) return null;
        score += Math.abs(radius - ((ring[0] + ring[1]) / 2.0)) / 64.0;
        return new PlannedPoint(x, terrain.y, z, score, preference);
    }

    private static PlannedPoint emergencyCandidate(ServerWorld world, PlanItem item) {
        int[] ring = ringFor(item.regionId, saved.targetRadiusBlocks);
        for (int attempt = MAX_CANDIDATES; attempt < MAX_CANDIDATES + 24; attempt++) {
            long mixed = mix64(world.getSeed() + item.key.hashCode() * 31L + attempt * 101L);
            double angle = ((mixed & 0xffffL) / 65535.0) * Math.PI * 2.0;
            double radius = ring[0] + (((mixed >>> 16) & 0xffffL) / 65535.0) * (ring[1] - ring[0]);
            int x = alignChunkCenter(world.getSpawnPos().getX() + (int) (Math.cos(angle) * radius));
            int z = alignChunkCenter(world.getSpawnPos().getZ() + (int) (Math.sin(angle) * radius));
            if (!farEnough(x, z, Math.max(320, saved.minSeparationBlocks - 128))) continue;
            TerrainSample terrain = sampleTerrain(world, x, z);
            if (terrain == null) continue;
            return new PlannedPoint(x, terrain.y, z, 9999.0 + terrain.roughness, terrainPreference(item.label));
        }
        return null;
    }

    private record TerrainSample(int y, int roughness, int waterSamples, int solidSamples) {
        double score(TerrainPreference preference) {
            return switch (preference) {
                case LAND -> waterSamples >= 2 || solidSamples < 4 || roughness > 14
                        ? 100000.0 : roughness * 12.0 + waterSamples * 300.0;
                case WATER -> waterSamples < 3
                        ? 100000.0 : roughness * 5.0 + (5 - waterSamples) * 40.0;
                case MOUNTAIN -> waterSamples >= 2 || y < 90 || roughness > 28
                        ? 100000.0 : roughness * 4.0 + Math.max(0, 120 - y) * 3.0;
            };
        }
    }

    private static TerrainSample sampleTerrain(ServerWorld world, int x, int z) {
        int[][] offsets = {{0, 0}, {32, 0}, {-32, 0}, {0, 32}, {0, -32}};
        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;
        int centerY = 0;
        int water = 0;
        int solid = 0;
        for (int i = 0; i < offsets.length; i++) {
            int sx = x + offsets[i][0];
            int sz = z + offsets[i][1];
            int y = world.getTopY(Heightmap.Type.WORLD_SURFACE, sx, sz);
            if (i == 0) centerY = y;
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            BlockPos below = new BlockPos(sx, Math.max(world.getBottomY(), y - 1), sz);
            BlockState state = world.getBlockState(below);
            if (!state.getFluidState().isEmpty()) water++;
            if (state.isSolidBlock(world, below)) solid++;
        }
        if (centerY <= world.getBottomY() + 2) return null;
        return new TerrainSample(centerY, maxY - minY, water, solid);
    }

    private static boolean farEnough(int x, int z, int separation) {
        long minSquared = (long) separation * separation;
        for (LayoutEntry entry : saved.entries.values()) {
            if (!entry.planned) continue;
            long dx = (long) x - entry.x;
            long dz = (long) z - entry.z;
            if (dx * dx + dz * dz < minSquared) return false;
        }
        return true;
    }

    private static List<PlanItem> buildItems(MinecraftServer server, ImportantLocationService.MapSnapshot map) {
        List<PlanItem> items = new ArrayList<>();
        RegionalStructureAuditService.AuditResult audit = RegionalStructureAuditService.audit(server);
        int sequence = 0;
        for (ImportantLocationService.RegionView region : map.regions()) {
            List<ImportantLocationService.LocationView> locations = new ArrayList<>(region.locations());
            locations.sort(Comparator.comparingInt(ImportantLocationService.LocationView::order));
            for (ImportantLocationService.LocationView location : locations) {
                PlacementAsset asset = resolveAsset(server, audit, region.name(), location);
                items.add(new PlanItem(location.key(), region.id(), region.name(), location.order(), location.label(),
                        asset, sequence++, map.total()));
            }
        }
        items.sort(Comparator.comparingInt((PlanItem item) -> regionRank(item.regionId)).thenComparingInt(item -> item.order));
        return items;
    }

    private static PlacementAsset resolveAsset(MinecraftServer server, RegionalStructureAuditService.AuditResult audit,
                                                String regionName, ImportantLocationService.LocationView location) {
        ServerWorld world = server.getOverworld();
        Registry<Structure> registry = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
        Identifier current = Identifier.tryParse(location.structureId());
        if (current != null && registry.getEntry(current).isPresent()) {
            return new PlacementAsset(current.toString(), PlacementMode.REGISTERED);
        }

        RegionalStructureAuditService.RegionResult region = audit.regions().get(regionName);
        List<String> matches = region == null ? List.of() : region.matches().getOrDefault(location.label(), List.of());
        for (String display : matches) {
            if (!display.startsWith("[REGISTRY] ")) continue;
            Identifier id = Identifier.tryParse(stripSource(display));
            if (id != null && registry.getEntry(id).isPresent()) return new PlacementAsset(id.toString(), PlacementMode.REGISTERED);
        }
        for (String display : matches) {
            if (!display.startsWith("[TEMPLATE] ")) continue;
            Identifier id = Identifier.tryParse(stripSource(display));
            if (id != null && world.getStructureTemplateManager().getTemplate(id).isPresent()) {
                return new PlacementAsset(id.toString(), PlacementMode.TEMPLATE);
            }
        }
        if (current != null && world.getStructureTemplateManager().getTemplate(current).isPresent()) {
            return new PlacementAsset(current.toString(), PlacementMode.TEMPLATE);
        }
        return new PlacementAsset(location.structureId(), PlacementMode.UNSUPPORTED);
    }

    private static LayoutEntry entryFor(PlanItem item) {
        LayoutEntry entry = new LayoutEntry();
        entry.key = item.key;
        entry.regionId = item.regionId;
        entry.regionName = item.regionName;
        entry.order = item.order;
        entry.label = item.label;
        entry.structureId = item.asset.id;
        entry.placementMode = item.asset.mode.name();
        return entry;
    }

    private static TerrainPreference terrainPreference(String label) {
        String text = label.toLowerCase(Locale.ROOT);
        if (text.contains("lake ") || text.startsWith("lake") || text.contains("isla") || text.contains("islas")
                || text.contains("sumergido") || text.contains("remolino") || text.contains("fullmoon")
                || text.contains("newmoon") || text.contains("whirl")) {
            return TerrainPreference.WATER;
        }
        if (text.contains("mountain") || text.contains("montaña") || text.contains("pilar")
                || text.contains("snowpoint") || text.contains("stark") || text.contains("volcánica")) {
            return TerrainPreference.MOUNTAIN;
        }
        return TerrainPreference.LAND;
    }

    private static int[] ringFor(String regionId, int targetRadius) {
        double scale = targetRadius / (double) DEFAULT_TARGET_RADIUS_BLOCKS;
        int min;
        int max;
        switch (regionRank(regionId)) {
            case 0 -> { min = 1600; max = 4200; }
            case 1 -> { min = 3300; max = 6000; }
            case 2 -> { min = 5000; max = 7700; }
            default -> { min = 6500; max = DEFAULT_TARGET_RADIUS_BLOCKS; }
        }
        min = (int) Math.round(min * scale);
        max = (int) Math.round(max * scale);
        max = Math.min(targetRadius, max);
        min = Math.min(max - 256, min);
        return new int[]{Math.max(SPAWN_CLEARANCE_BLOCKS, min), Math.max(SPAWN_CLEARANCE_BLOCKS + 256, max)};
    }

    private static int regionRank(String regionId) {
        return switch (regionId) {
            case "kanto" -> 0;
            case "johto" -> 1;
            case "hoenn" -> 2;
            case "sinnoh" -> 3;
            default -> 4;
        };
    }

    private static int clampRadius(int requested) {
        return Math.max(MIN_TARGET_RADIUS_BLOCKS, Math.min(MAX_CONFIGURED_RADIUS_BLOCKS, requested));
    }

    private static int alignChunkCenter(int value) {
        return Math.floorDiv(value, 16) * 16 + 8;
    }

    private static int alignUp(int value, int alignment) {
        return Math.floorDiv(value + alignment - 1, alignment) * alignment;
    }

    private static long mix64(long z) {
        z = (z ^ (z >>> 33)) * 0xff51afd7ed558ccdL;
        z = (z ^ (z >>> 33)) * 0xc4ceb9fe1a85ec53L;
        return z ^ (z >>> 33);
    }

    private static String stripSource(String display) {
        if (display == null) return "";
        int end = display.indexOf("] ");
        return end >= 0 ? display.substring(end + 2).trim() : display.trim();
    }

    private static String formatLong(long value) {
        return String.format(Locale.ROOT, "%,d", value);
    }

    private static void notifyRequester(MinecraftServer server, String message) {
        if (planJob != null) notify(server, planJob.requester, message);
        else if (placeJob != null) notify(server, placeJob.requester, message);
    }

    private static void notify(MinecraftServer server, UUID requester, String message) {
        if (requester == null) return;
        var player = server.getPlayerManager().getPlayer(requester);
        if (player != null) player.sendMessage(Text.literal(message), false);
    }

    private static void ensureLoaded(MinecraftServer server) {
        if (configManager == null || server == null || server.getOverworld() == null) return;
        long seed = server.getOverworld().getSeed();
        if (loadedSeed == seed) return;
        loadedSeed = seed;
        saved = new SavedState();
        saved.seed = seed;
        Path file = stateFile(seed);
        if (!Files.exists(file)) return;
        try {
            SavedState loaded = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), SavedState.class);
            if (loaded != null && loaded.seed == seed) {
                if (loaded.entries == null) loaded.entries = new LinkedHashMap<>();
                if (loaded.targetRadiusBlocks <= 0) loaded.targetRadiusBlocks = DEFAULT_TARGET_RADIUS_BLOCKS;
                if (loaded.minSeparationBlocks <= 0) loaded.minSeparationBlocks = DEFAULT_MIN_SEPARATION_BLOCKS;
                saved = loaded;
            }
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.warn("Could not read regional layout state {}", file, exception);
        }
    }

    private static void save(MinecraftServer server) {
        if (configManager == null || server == null) return;
        ensureLoaded(server);
        Path file = stateFile(saved.seed);
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(temp, GSON.toJson(saved), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            Chainacobblemon.LOGGER.warn("Could not save regional layout state {}", file, exception);
        }
    }

    private static Path stateFile(long seed) {
        return configManager.configDirectory().resolve("regional-layout-" + Long.toUnsignedString(seed) + ".json");
    }
}
