package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeCatalog;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeProfile;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.andrewbristowx.chainacobblemon.data.PlayerDataManager;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * One-shot destructive reset for test accounts before the final server/map opens.
 *
 * This deliberately resets player-owned progression only. It does NOT touch worlds, structures,
 * NPC placement, server configuration or world-global region unlock state used for pregeneration.
 */
public final class PlayerResetService {
    private PlayerResetService() {}

    public record ResetResult(boolean chainacobblemon, boolean cobblemon, boolean rct, int resetTrainerDefeats) {
        public boolean success() { return chainacobblemon && cobblemon; }
    }

    public record ResetAllResult(int onlinePlayers, int onlineSuccessful, int offlineChainacobblemonProfilesRemoved,
                                 int cobblemonFailures, int rctPartialOrUnavailable) {
        public boolean success() { return onlineSuccessful == onlinePlayers && cobblemonFailures == 0; }
    }

    public static ResetResult reset(ServerPlayerEntity player, PlayerDataManager dataManager) {
        if (player == null || dataManager == null) return new ResetResult(false, false, false, 0);
        MinecraftServer server = player.getServer();
        if (server == null) return new ResetResult(false, false, false, 0);

        // Drop transient runtime state first so nothing can immediately write old progress back.
        Chainacobblemon.progressionService().playerLeft(player.getUuid());
        Chainacobblemon.battlePassService().playerLeft(player.getUuid());
        Chainacobblemon.dailyRewardService().playerLeft(player.getUuid());

        boolean cobblemon = resetCobblemon(server, player);
        RctReset rct = resetRct(server, player);
        boolean chainacobblemon = dataManager.resetPlayer(player.getUuid());

        // Rebuild the online runtime state from the newly created player profile.
        if (chainacobblemon) {
            Chainacobblemon.progressionService().playerJoined(player);
            Chainacobblemon.battlePassService().playerJoined(player);
            Chainacobblemon.dailyRewardService().playerJoined(player);
        }
        return new ResetResult(chainacobblemon, cobblemon, rct.success, rct.defeatsReset);
    }


    public static ResetAllResult resetAllOnlineAndOfflineChainacobblemon(MinecraftServer server, PlayerDataManager dataManager) {
        if (server == null || dataManager == null) return new ResetAllResult(0, 0, 0, 0, 0);
        Set<UUID> onlineIds = new LinkedHashSet<>();
        int online = 0;
        int success = 0;
        int cobblemonFailures = 0;
        int rctPartial = 0;
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            online++;
            onlineIds.add(player.getUuid());
            ResetResult result = reset(player, dataManager);
            if (result.success()) success++;
            if (!result.cobblemon()) cobblemonFailures++;
            if (!result.rct()) rctPartial++;
            player.sendMessage(net.minecraft.text.Text.literal("§dTu progreso de pruebas fue reiniciado por el reinicio global. §aTu límite de nivel/serie RCT no se redujo."), false);
        }
        int offlineRemoved = dataManager.deleteProfilesExcept(onlineIds);
        return new ResetAllResult(online, success, offlineRemoved, cobblemonFailures, rctPartial);
    }

    private static boolean resetCobblemon(MinecraftServer server, ServerPlayerEntity player) {
        String target = player.getGameProfile().getName();
        try {
            if (run(server, "pokemonrestartother " + target)) return true;
            // Mapping/modpack command changes should not leave half a wipe: use the two canonical
            // targetable commands as a safe fallback.
            boolean party = run(server, "clearparty " + target);
            boolean pc = run(server, "clearpc " + target);
            return party || pc;
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.error("Cobblemon reset failed for {}", target, exception);
            return false;
        }
    }

    private static RctReset resetRct(MinecraftServer server, ServerPlayerEntity player) {
        String target = player.getGameProfile().getName();
        int successes = 0;
        int defeatsReset = 0;
        try {
            // Alpha.7 intentionally preserves the player's active RCT series and level cap.
            // We only clear battle-completion markers that are safe to reset without forcing a
            // regional series transition (which Cobbleverse can use to lower the level cap).
            if (run(server, "advancement revoke " + target + " from rctmod:trainers/defeat_any")) successes++;

            Set<String> trainerIds = new LinkedHashSet<>();
            for (ChallengeProfile profile : ChallengeCatalog.all()) {
                String trainerId = RctCobbleverseBridge.resolveNativeTrainerId(server, profile);
                if (trainerId != null && !trainerId.isBlank()) trainerIds.add(trainerId);
            }
            for (String trainerId : trainerIds) {
                if (run(server, "rctmod player set defeats " + trainerId + " " + target + " 0")) defeatsReset++;
            }
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("RCT/Cobbleverse reset was only partially available for {}: {}",
                    target, exception.toString());
        }
        return new RctReset(successes > 0 || defeatsReset > 0, defeatsReset);
    }

    private static boolean run(MinecraftServer server, String command) {
        ServerCommandSource source = server.getCommandSource().withLevel(4);
        try {
            return server.getCommandManager().getDispatcher().execute(command, source) > 0;
        } catch (CommandSyntaxException exception) {
            Chainacobblemon.LOGGER.debug("Admin reset command failed: {}", command, exception);
            return false;
        }
    }

    private record RctReset(boolean success, int defeatsReset) {}
}
