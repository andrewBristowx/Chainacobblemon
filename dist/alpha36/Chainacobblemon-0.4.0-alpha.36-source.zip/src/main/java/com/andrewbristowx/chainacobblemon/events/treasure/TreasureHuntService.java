package com.andrewbristowx.chainacobblemon.events.treasure;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.dungeon.TreasureStructureCatalog;
import com.andrewbristowx.chainacobblemon.events.ChainaEventManager;
import com.andrewbristowx.chainacobblemon.events.ChainaEventType;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Competitive Treasure Hunt hosted in a dedicated void dimension.
 * Every participant receives the exact same maze layout in a separated slot, so the race is fair
 * and no third-party village/dungeon worldgen is required for the event itself.
 */
public final class TreasureHuntService {
    public static final Identifier WORLD_ID = Identifier.of(Chainacobblemon.MOD_ID, "treasure_maze");
    public static final RegistryKey<World> WORLD_KEY = RegistryKey.of(RegistryKeys.WORLD, WORLD_ID);

    private static final String INTERACTION_TAG = "chaina_treasure_interaction";
    private static final String DISPLAY_TAG = "chaina_treasure_display";
    private static final String BATTLE_POKEMON_TAG = "chaina_treasure_battle_pokemon";
    private static final int BASE_Y = 64;
    private static final int CELL_STEP = 5;
    private static final int SLOT_SPACING = 220;
    private static final int PARKOUR_RESET_Y = BASE_Y - 3;
    private static final Set<UUID> ADMIN_BUILD = new HashSet<>();
    private static final Map<UUID, PlayerRun> RUNS = new LinkedHashMap<>();
    private static EventRun eventRun;
    private static int forcedTier;

    private TreasureHuntService() { }

    public static void initialize() {
        // Current Treasure Hunt builds only inside chainacobblemon:treasure_maze. On boot, also purge
        // any tagged Treasure entities left by much older test builds in normal dimensions.
        ServerLifecycleEvents.SERVER_STARTED.register(TreasureHuntService::purgeLegacyTreasureEntities);
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !world.getRegistryKey().equals(WORLD_KEY) || ADMIN_BUILD.contains(player.getUuid()));
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.getRegistryKey().equals(WORLD_KEY) || ADMIN_BUILD.contains(player.getUuid())) return ActionResult.PASS;
            // The maze is immutable. Allow no block interactions/placement that could shortcut a corridor.
            return player.getStackInHand(hand).getItem() instanceof BlockItem ? ActionResult.FAIL : ActionResult.FAIL;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!entity.getCommandTags().contains(INTERACTION_TAG)) return ActionResult.PASS;
            if (!(player instanceof ServerPlayerEntity serverPlayer)) return ActionResult.FAIL;
            PlayerRun run = RUNS.get(serverPlayer.getUuid());
            if (run == null || !ChainaEventManager.isTreasureParticipant(serverPlayer.getUuid())) {
                serverPlayer.sendMessage(Text.literal("§cEste tesoro no pertenece a tu Cacería."), false);
                return ActionResult.FAIL;
            }
            if (run.interactionId != null && !run.interactionId.equals(entity.getUuid())) {
                serverPlayer.sendMessage(Text.literal("§cEsa Poké Ball pertenece a otro participante."), false);
                return ActionResult.FAIL;
            }
            if (!canClaim(serverPlayer)) {
                serverPlayer.sendMessage(Text.literal("§eLa Poké Ball está sellada. Derrota todos tus guardianes primero."), false);
                return ActionResult.FAIL;
            }
            return ChainaEventManager.claimTreasure(serverPlayer) ? ActionResult.SUCCESS : ActionResult.FAIL;
        });
    }

    public static void forceNextTier(int stars) {
        forcedTier = Math.max(1, Math.min(5, stars));
    }

    public static boolean start(MinecraftServer server, boolean test) {
        cleanup(server, true);
        ServerWorld world = server.getWorld(WORLD_KEY);
        if (world == null) {
            Chainacobblemon.LOGGER.error("Treasure Hunt dimension {} is not loaded. Restart after installing alpha.18.", WORLD_ID);
            return false;
        }

        int stars = forcedTier > 0 ? forcedTier : chooseTier(test);
        forcedTier = 0;
        long seed = ThreadLocalRandom.current().nextLong();
        MazePlan plan = MazePlan.generate(stars, seed);
        eventRun = new EventRun(UUID.randomUUID(), stars, seed, plan, theme(stars));

        List<ServerPlayerEntity> participants = server.getPlayerManager().getPlayerList().stream()
                .filter(player -> ChainaEventManager.isTreasureParticipant(player.getUuid()))
                .sorted(Comparator.comparing(player -> player.getUuid().toString()))
                .toList();
        if (participants.isEmpty()) return false;

        int slot = 0;
        for (ServerPlayerEntity player : participants) {
            PlayerRun run = createRun(player, slot++);
            RUNS.put(player.getUuid(), run);
            clearSlot(world, run.bounds.expand(4.0D));
            buildMaze(world, run);
            buildParkour(world, run);
            spawnTrainers(world, run);
            spawnTreasureBall(server, world, run);
            teleportToStart(player, run, true);
            ChainaEventManager.onTreasureProgress(player, 0, eventRun.plan.trainerCells.size());
        }

        server.getPlayerManager().broadcast(Text.literal("§6🗺 CACERÍA DEL TESORO " + starLabel(stars)
                + " §f· §d" + eventRun.theme.display + " §7· cada participante tiene la misma mazmorra personal."), false);
        server.getPlayerManager().broadcast(Text.literal("§7Encuentra el camino, derrota los guardianes de los pasillos y llega primero a la "
                + ballName(stars) + "§7."), false);
        Chainacobblemon.LOGGER.info("Treasure maze ready: event={} tier={} seed={} cells={}x{} solution={} trainers={} participants={}",
                eventRun.eventId, stars, seed, plan.width, plan.height, plan.solution.size(), plan.trainerCells.size(), RUNS.size());
        return true;
    }

    public static void tick(MinecraftServer server, Set<UUID> participants) {
        if (eventRun == null) return;
        ServerWorld world = server.getWorld(WORLD_KEY);
        if (world == null) return;
        for (UUID id : new HashSet<>(participants)) {
            PlayerRun run = RUNS.get(id);
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(id);
            if (run == null || player == null) continue;
            // A reconnect or external teleport should not strand/skip the participant.
            if (!player.getWorld().getRegistryKey().equals(WORLD_KEY)
                    || player.getY() < BASE_Y - 8
                    || !run.bounds.expand(6.0D).contains(player.getPos())) {
                teleportToStart(player, run, false);
            }

            // The maze ends at a sealed final cell. Once every trainer is defeated, entering that
            // cell moves the participant into the separate final parkour instead of carving a
            // shortcut through the maze. Every participant receives the exact same parkour.
            if (!run.parkourEntered
                    && run.progress >= eventRun.plan.trainerCells.size()
                    && player.getWorld().getRegistryKey().equals(WORLD_KEY)
                    && player.squaredDistanceTo(run.mazeFinalPos.getX() + .5D, run.mazeFinalPos.getY(), run.mazeFinalPos.getZ() + .5D) <= 7.0D) {
                enterParkour(player, run);
            }

            if (run.parkourEntered && player.getWorld().getRegistryKey().equals(WORLD_KEY)) {
                // No fall death in the final challenge. Falling simply restarts this parkour.
                player.fallDistance = 0.0F;
                if (player.getY() <= PARKOUR_RESET_Y || !run.parkourBounds.expand(2.0D).contains(player.getPos())) {
                    resetParkour(player, run, true);
                }
            }

            // Keep the treasure visibly magical instead of emitting particles only on spawn.
            if (run.interactionId != null && world.getTime() % 10L == 0L) {
                BlockPos p = run.ballPos;
                world.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD,
                        p.getX() + .5D, p.getY() + 1.25D, p.getZ() + .5D,
                        eventRun.stars >= 4 ? 6 : 3, .65D, .8D, .65D, .015D);
                if (eventRun.stars >= 4) {
                    world.spawnParticles(net.minecraft.particle.ParticleTypes.PORTAL,
                            p.getX() + .5D, p.getY() + 1.1D, p.getZ() + .5D,
                            5, .5D, .6D, .5D, .03D);
                }
            }
            markTrainerPokemon(world, run);
        }
    }

    public static boolean canChallengeTrainer(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null || eventRun == null) return false;
        PlayerRun run = RUNS.get(player.getUuid());
        if (run == null || !run.structureKey.equals(npc.dungeonStructureKey())) return false;
        Integer index = run.trainerIndexByNpc.get(npc.getUuid());
        return index != null && index == run.progress + 1;
    }

    public static void onTrainerVictory(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null || eventRun == null) return;
        PlayerRun run = RUNS.get(player.getUuid());
        if (run == null || !run.structureKey.equals(npc.dungeonStructureKey())) return;
        Integer index = run.trainerIndexByNpc.get(npc.getUuid());
        if (index == null || index > run.progress + 1) return;
        run.progress = Math.max(run.progress, index);
        openGate(player.getServerWorld(), run, index);
        // A defeated corridor trainer must disappear immediately. Keeping old NPCs in the maze
        // both clutters the route and can reveal/checkpoint the solved path. Clean its temporary
        // battle Pokemon first so no drops/XP can leak, then discard only this trainer.
        cleanupTrainerPokemon(player, npc);
        UUID defeatedNpcId = npc.getUuid();
        npc.discard();
        run.trainerIndexByNpc.remove(defeatedNpcId);
        ChainaEventManager.onTreasureProgress(player, run.progress, eventRun.plan.trainerCells.size());
        if (run.progress >= eventRun.plan.trainerCells.size()) {
            player.sendMessage(Text.literal("§6✦ Todos los guardianes fueron derrotados. §fEncuentra la cámara final y supera el parkour para alcanzar la " + ballName(eventRun.stars) + "§f."), false);
            player.getServerWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                    SoundCategory.PLAYERS, 1.0F, 1.25F);
        } else {
            player.sendMessage(Text.literal("§a✓ Sello " + run.progress + "/" + eventRun.plan.trainerCells.size()
                    + " roto. §7El siguiente corredor está abierto."), false);
        }
    }

    public static boolean canClaim(ServerPlayerEntity player) {
        if (player == null || eventRun == null) return false;
        PlayerRun run = RUNS.get(player.getUuid());
        return run != null
                && player.getWorld().getRegistryKey().equals(WORLD_KEY)
                && run.progress >= eventRun.plan.trainerCells.size()
                && player.squaredDistanceTo(run.ballPos.getX() + .5D, run.ballPos.getY() + 1.0D, run.ballPos.getZ() + .5D) <= 36.0D;
    }

    public static void animateClaim(ServerPlayerEntity player) {
        if (player == null || eventRun == null) return;
        PlayerRun winner = RUNS.get(player.getUuid());
        if (winner == null || !(player.getWorld() instanceof ServerWorld world)) return;
        BlockPos p = winner.ballPos;
        world.spawnParticles(net.minecraft.particle.ParticleTypes.FIREWORK, p.getX() + .5, p.getY() + 1.5, p.getZ() + .5,
                55, 2.0, 1.8, 2.0, .10);
        world.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD, p.getX() + .5, p.getY() + 1.3, p.getZ() + .5,
                42, 1.6, 1.5, 1.6, .06);
        world.playSound(null, p, SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, SoundCategory.MASTER, 1.3F, 1.05F);
        removeInteraction(world, winner);
    }

    public static void cleanup(MinecraftServer server, boolean returnPlayers) {
        if (server == null) return;
        ServerWorld world = server.getWorld(WORLD_KEY);
        if (world != null) {
            for (PlayerRun run : new ArrayList<>(RUNS.values())) {
                for (Entity entity : world.getOtherEntities(null, run.bounds.expand(8.0D), e ->
                        e.getCommandTags().contains(INTERACTION_TAG)
                                || e.getCommandTags().contains(DISPLAY_TAG)
                                || e.getCommandTags().contains(BATTLE_POKEMON_TAG)
                                || (e instanceof ServiceNpcEntity npc && run.structureKey.equals(npc.dungeonStructureKey()))
                                || isPokemonEntity(e))) {
                    entity.discard();
                }
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(run.playerId);
                if (player != null) returnPlayer(player, run);
                clearSlot(world, run.bounds.expand(3.0D));
            }
        }
        RUNS.clear();
        eventRun = null;
        ADMIN_BUILD.clear();
        purgeLegacyTreasureEntities(server);
    }

    private static void purgeLegacyTreasureEntities(MinecraftServer server) {
        if (server == null) return;
        int removed = 0;
        for (ServerWorld other : server.getWorlds()) {
            if (other.getRegistryKey().equals(WORLD_KEY)) continue;
            List<Entity> legacy = new ArrayList<>();
            for (Entity entity : other.iterateEntities()) {
                if (entity.getCommandTags().contains(INTERACTION_TAG)
                        || entity.getCommandTags().contains(DISPLAY_TAG)
                        || entity.getCommandTags().contains(BATTLE_POKEMON_TAG)) legacy.add(entity);
            }
            for (Entity entity : legacy) { entity.discard(); removed++; }
        }
        if (removed > 0) Chainacobblemon.LOGGER.info("Removed {} legacy Treasure entities from normal dimensions", removed);
    }

    public static void playerJoined(ServerPlayerEntity player) {
        if (player == null || !player.getWorld().getRegistryKey().equals(WORLD_KEY)) return;
        PlayerRun run = RUNS.get(player.getUuid());
        if (run != null && ChainaEventManager.isTreasureParticipant(player.getUuid())) {
            teleportToStart(player, run, false);
            return;
        }
        // Safe recovery after a server restart while someone was inside the temporary event dimension.
        ServerWorld overworld = player.getServer().getOverworld();
        BlockPos spawn = overworld.getSpawnPos();
        player.teleport(overworld, spawn.getX() + .5D, spawn.getY() + 1.0D, spawn.getZ() + .5D, player.getYaw(), player.getPitch());
        player.changeGameMode(GameMode.SURVIVAL);
        player.sendMessage(Text.literal("§eLa Cacería anterior ya no estaba activa; regresaste al spawn de forma segura."), false);
    }

    public static void playerLeft(UUID playerId) {
        // Runtime is intentionally retained so a reconnect during the same event resumes the same maze/progress.
    }

    public static void cleanupTrainerPokemon(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null || !(npc.getWorld() instanceof ServerWorld world)) return;
        PlayerRun run = RUNS.get(player.getUuid());
        if (run == null) return;
        int removedPokemon = 0;
        int removedDrops = 0;
        // Battle entities are temporary. Prefer ownership/tag checks so the player's own sent-out Pokémon
        // is never discarded just because it is standing inside the same maze slot.
        for (Entity entity : world.getOtherEntities(null, run.bounds.expand(2.0D), e ->
                isPokemonEntity(e) || e instanceof ItemEntity || e instanceof ExperienceOrbEntity)) {
            if (entity.isRemoved()) continue;
            if (isPokemonEntity(entity)) {
                if (!entity.getCommandTags().contains(BATTLE_POKEMON_TAG) && !isOwnedByNpc(entity, npc)) continue;
                entity.discard();
                removedPokemon++;
            } else if (entity.squaredDistanceTo(npc) <= 24.0D * 24.0D) {
                // No species loot / XP / held-item leakage from competitive trainer encounters.
                entity.discard();
                removedDrops++;
            }
        }
        if (removedPokemon > 0 || removedDrops > 0) {
            Chainacobblemon.LOGGER.debug("Treasure maze cleanup for {}: pokemon={} drops/xp={}",
                    player.getName().getString(), removedPokemon, removedDrops);
        }
    }

    public static int levelOffsetFor(ServiceNpcEntity npc) {
        if (eventRun == null || npc == null) return 0;
        int base = switch (eventRun.stars) {
            case 1 -> 0;
            case 2 -> 1;
            case 3 -> 2;
            case 4 -> 4;
            default -> 6;
        };
        for (PlayerRun run : RUNS.values()) {
            Integer index = run.trainerIndexByNpc.get(npc.getUuid());
            if (index != null) {
                int extra = eventRun.plan.trainerCells.size() <= 1 ? 0
                        : Math.min(2, (index - 1) * 3 / Math.max(1, eventRun.plan.trainerCells.size() - 1));
                return base + extra;
            }
        }
        return base;
    }

    public static boolean teleportAdmin(ServerPlayerEntity admin, String target, int room) {
        if (admin == null || eventRun == null) return false;
        PlayerRun run = RUNS.get(admin.getUuid());
        if (run == null && !RUNS.isEmpty()) run = RUNS.values().iterator().next();
        if (run == null) return false;
        BlockPos p = run.startPos;
        if ("final".equalsIgnoreCase(target)) p = run.ballPos;
        else if ("room".equalsIgnoreCase(target)) {
            int index = Math.max(1, Math.min(run.trainerPositions.size(), room));
            p = run.trainerPositions.get(index - 1);
        }
        ServerWorld world = admin.getServer().getWorld(WORLD_KEY);
        if (world == null) return false;
        admin.teleport(world, p.getX() + .5D, p.getY(), p.getZ() + .5D, admin.getYaw(), admin.getPitch());
        return true;
    }

    public static boolean toggleBuildMode(ServerPlayerEntity player) {
        if (player == null || !player.getWorld().getRegistryKey().equals(WORLD_KEY)) return false;
        if (ADMIN_BUILD.remove(player.getUuid())) {
            player.changeGameMode(GameMode.ADVENTURE);
            player.sendMessage(Text.literal("§eBuildmode de Cacería desactivado."), false);
            return false;
        }
        ADMIN_BUILD.add(player.getUuid());
        player.changeGameMode(GameMode.CREATIVE);
        player.sendMessage(Text.literal("§aBuildmode de Cacería activado para admin."), false);
        return true;
    }

    public static String debugSummary() {
        if (eventRun == null) return "No hay Cacería del Tesoro activa.";
        StringBuilder out = new StringBuilder("§d[Treasure Maze Debug]")
                .append("\n§7dimensión: §f").append(WORLD_ID)
                .append("\n§7tier: §f").append(starLabel(eventRun.stars))
                .append(" §7· tema: §f").append(eventRun.theme.display)
                .append("\n§7seed: §f").append(eventRun.seed)
                .append("\n§7grid: §f").append(eventRun.plan.width).append("x").append(eventRun.plan.height)
                .append(" §7· camino solución: §f").append(eventRun.plan.solution.size())
                .append(" §7· entrenadores: §f").append(eventRun.plan.trainerCells.size())
                .append("\n§7participantes/slots: §f").append(RUNS.size());
        for (PlayerRun run : RUNS.values()) {
            out.append("\n§e").append(run.playerName).append(" §7slot ").append(run.slot)
                    .append(" · progreso §f").append(run.progress).append("/").append(eventRun.plan.trainerCells.size())
                    .append(" §7· inicio §f").append(run.startPos.toShortString())
                    .append(" §7· salida §f").append(run.mazeFinalPos.toShortString())
                    .append(" §7· parkour §f").append(run.parkourStartPos.toShortString())
                    .append(" §7· ball §f").append(run.ballPos.toShortString());
        }
        return out.toString();
    }

    public static int trainerCount() { return eventRun == null ? 0 : eventRun.plan.trainerCells.size(); }

    public static String hudFooter() {
        if (eventRun == null) return "Preparando laberintos...";
        return starLabel(eventRun.stars) + " · " + eventRun.theme.display + " · laberinto + parkour final · " + ballName(eventRun.stars);
    }

    public static Identifier structureId() {
        return eventRun == null ? null : Identifier.of(Chainacobblemon.MOD_ID, "treasure_maze_tier_" + eventRun.stars);
    }

    public static String structureKey() {
        return eventRun == null ? "" : "treasure_event:" + eventRun.eventId;
    }

    public static String scanSummary(ServerWorld ignored) {
        return "Cacería del Tesoro ya no usa estructuras externas."
                + "\n§a★ Poké Ball §7· laberinto 7x7 · 2 entrenadores"
                + "\n§b★★ Great Ball §7· laberinto 9x9 · 3 entrenadores"
                + "\n§e★★★ Ultra Ball §7· laberinto 11x11 · 4 entrenadores"
                + "\n§d★★★★ Luxury Ball §7· laberinto 13x13 · 5 entrenadores"
                + "\n§6★★★★★ Master Ball §7· laberinto 15x15 · 6 entrenadores"
                + "\n§7WDA/DnT/MVS/Repurposed/YUNG siguen siendo usados por Chaina Dungeon Loot normal.";
    }

    /** Compatibility command: query may be 1..5 or tier1..tier5 and creates an event preview for the admin. */
    public static boolean spawnSpecific(MinecraftServer server, ServerPlayerEntity admin, String query, boolean fullEvent) {
        if (server == null || admin == null) return false;
        int tier = parseTier(query);
        if (tier <= 0) {
            admin.sendMessage(Text.literal("§cAhora Cacería usa laberintos propios. Usa un tier 1, 2, 3, 4 o 5."), false);
            return false;
        }
        forceNextTier(tier);
        admin.sendMessage(Text.literal("§aTier " + tier + " preparado. §7Usa /chainacobblemon event test treasure " + tier + " para probarlo completo."), false);
        return true;
    }

    private static int parseTier(String query) {
        if (query == null) return 0;
        String clean = query.toLowerCase().replace("tier", "").replace("★", "").trim();
        try { return Math.max(1, Math.min(5, Integer.parseInt(clean))); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private static int chooseTier(boolean test) {
        if (test) return 3;
        int roll = ThreadLocalRandom.current().nextInt(100);
        if (roll < 30) return 1;
        if (roll < 58) return 2;
        if (roll < 80) return 3;
        if (roll < 95) return 4;
        return 5;
    }

    private static PlayerRun createRun(ServerPlayerEntity player, int slot) {
        int widthBlocks = eventRun.plan.width * CELL_STEP + 8;
        int heightBlocks = eventRun.plan.height * CELL_STEP + 8;
        int originX = slot * SLOT_SPACING;
        int originZ = 0;
        int minX = originX - widthBlocks / 2;
        int minZ = originZ - heightBlocks / 2;
        BlockPos start = cellCenter(minX, minZ, eventRun.plan.start);
        BlockPos mazeFinal = cellCenter(minX, minZ, eventRun.plan.finalCell);

        int mazeMaxX = minX + eventRun.plan.width * CELL_STEP + 7;
        BlockPos parkourStartBlock = new BlockPos(mazeMaxX + 12, BASE_Y, mazeFinal.getZ());
        BlockPos parkourStart = parkourStartBlock.up();
        List<BlockPos> platforms = parkourPlatforms(parkourStartBlock, eventRun.stars);
        BlockPos last = platforms.get(platforms.size() - 1);
        BlockPos ball = new BlockPos(last.getX() + 5, last.getY() + 1, last.getZ());

        int parkourMinZ = platforms.stream().mapToInt(BlockPos::getZ).min().orElse(mazeFinal.getZ()) - 6;
        int parkourMaxZ = platforms.stream().mapToInt(BlockPos::getZ).max().orElse(mazeFinal.getZ()) + 6;
        int parkourMaxY = Math.max(BASE_Y + 10, platforms.stream().mapToInt(BlockPos::getY).max().orElse(BASE_Y) + 7);
        Box parkourBounds = new Box(parkourStartBlock.getX() - 5, BASE_Y - 6, parkourMinZ,
                ball.getX() + 6, parkourMaxY, parkourMaxZ);
        Box bounds = new Box(minX - 2, BASE_Y - 6, Math.min(minZ - 2, parkourMinZ),
                ball.getX() + 8, Math.max(BASE_Y + 10, parkourMaxY), Math.max(minZ + heightBlocks + 2, parkourMaxZ));

        Identifier returnWorld = player.getWorld().getRegistryKey().getValue();
        boolean creative = player.isCreative();
        return new PlayerRun(player.getUuid(), player.getName().getString(), slot, minX, minZ, bounds, start, mazeFinal,
                parkourStart, parkourBounds, ball, returnWorld, player.getX(), player.getY(), player.getZ(),
                player.getYaw(), player.getPitch(), creative,
                "treasure_event:" + eventRun.eventId + ":" + player.getUuid());
    }

    private static BlockPos cellCenter(int minX, int minZ, Cell cell) {
        return new BlockPos(minX + 4 + cell.x * CELL_STEP + 1, BASE_Y + 1, minZ + 4 + cell.z * CELL_STEP + 1);
    }

    private static void buildMaze(ServerWorld world, PlayerRun run) {
        MazePlan plan = eventRun.plan;
        MazeTheme theme = eventRun.theme;
        int minX = run.minX;
        int minZ = run.minZ;
        int maxX = minX + plan.width * CELL_STEP + 7;
        int maxZ = minZ + plan.height * CELL_STEP + 7;
        BlockState floor = theme.floor.getDefaultState();
        BlockState wall = theme.wall.getDefaultState();
        BlockState roof = theme.roof.getDefaultState();
        BlockState accent = theme.accent.getDefaultState();

        // Solid shell first; carve the perfect maze out of it. A roof prevents jumping/flying shortcuts.
        for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) {
            world.setBlockState(new BlockPos(x, BASE_Y, z), floor, Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(x, BASE_Y + 6, z), roof, Block.NOTIFY_LISTENERS);
            for (int y = BASE_Y + 1; y <= BASE_Y + 5; y++) {
                world.setBlockState(new BlockPos(x, y, z), wall, Block.NOTIFY_LISTENERS);
            }
        }

        for (int z = 0; z < plan.height; z++) for (int x = 0; x < plan.width; x++) {
            Cell c = new Cell(x, z);
            BlockPos center = cellCenter(minX, minZ, c);
            carveRoom(world, center);
            for (Cell n : plan.neighbors(c)) if (compareCell(c, n) < 0) carveCorridor(world, center, cellCenter(minX, minZ, n));
        }

        // Alpha.23: illuminate after every room/corridor has been carved. Previously the corridor
        // carving pass could erase LIGHT blocks placed earlier, leaving long sections almost black.
        for (int z = 0; z < plan.height; z++) for (int x = 0; x < plan.width; x++) {
            Cell c = new Cell(x, z);
            BlockPos center = cellCenter(minX, minZ, c);
            placeInvisibleLight(world, center.up(4));
            for (Cell n : plan.neighbors(c)) if (compareCell(c, n) < 0) {
                BlockPos other = cellCenter(minX, minZ, n);
                BlockPos midpoint = new BlockPos((center.getX() + other.getX()) / 2, BASE_Y + 5,
                        (center.getZ() + other.getZ()) / 2);
                placeInvisibleLight(world, midpoint);
            }
        }

        // Entry marker and final chamber make orientation/readability better without revealing the solution.
        decorateCell(world, run.startPos, Blocks.LIME_CONCRETE.getDefaultState());
        decorateCell(world, run.mazeFinalPos, accent);
        for (Cell checkpoint : plan.trainerCells) decorateCell(world, cellCenter(minX, minZ, checkpoint), accent);

        run.trainerPositions.clear();
        run.gates.clear();
        for (int i = 0; i < plan.trainerCells.size(); i++) {
            Cell cell = plan.trainerCells.get(i);
            BlockPos trainer = cellCenter(minX, minZ, cell);
            run.trainerPositions.add(trainer);
            int solutionIndex = plan.solution.indexOf(cell);
            if (solutionIndex >= 0 && solutionIndex + 1 < plan.solution.size()) {
                BlockPos next = cellCenter(minX, minZ, plan.solution.get(solutionIndex + 1));
                List<BlockPos> gate = gateBlocks(trainer, next);
                run.gates.put(i + 1, gate);
                for (BlockPos p : gate) world.setBlockState(p, Blocks.IRON_BARS.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
    }

    private static void buildParkour(ServerWorld world, PlayerRun run) {
        MazeTheme theme = eventRun.theme;
        List<BlockPos> platforms = parkourPlatforms(run.parkourStartPos.down(), eventRun.stars);
        int minX = (int)Math.floor(run.parkourBounds.minX);
        int maxX = (int)Math.ceil(run.parkourBounds.maxX);
        int minZ = (int)Math.floor(run.parkourBounds.minZ);
        int maxZ = (int)Math.ceil(run.parkourBounds.maxZ);
        int minY = BASE_Y - 6;
        int maxY = (int)Math.ceil(run.parkourBounds.maxY);

        BlockState wall = theme.wall.getDefaultState();
        BlockState roof = theme.roof.getDefaultState();
        // Closed independent chamber: players cannot use the maze shell or another participant's route.
        for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) {
            world.setBlockState(new BlockPos(x, minY, z), wall, Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(x, maxY, z), roof, Block.NOTIFY_LISTENERS);
            for (int y = minY + 1; y < maxY; y++) {
                boolean edge = x == minX || x == maxX || z == minZ || z == maxZ;
                world.setBlockState(new BlockPos(x, y, z), edge ? wall : Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }

        // Safe start pad. Difficulty now comes from route length, turns and platform size rather
        // than impossible height. Every upward transition is at most one block.
        BlockPos startBlock = run.parkourStartPos.down();
        fillPlatform(world, startBlock, 1, theme.accent.getDefaultState());
        for (int i = 1; i < platforms.size(); i++) {
            int radius;
            if (eventRun.stars == 1) {
                // Tier 1 is no longer a chain of giant 3x3 pads: alternate small landing pads with
                // occasional forgiving rest platforms.
                radius = (i % 3 == 0) ? 1 : 0;
            } else if (eventRun.stars == 2) {
                radius = (i % 5 == 0) ? 1 : 0;
            } else {
                radius = 0;
            }
            fillPlatform(world, platforms.get(i), radius, i % 4 == 0 ? theme.accent.getDefaultState() : theme.floor.getDefaultState());
        }

        // Strong, invisible route lighting. One source above every landing keeps the parkour readable
        // without visible lamps or destroying the dungeon atmosphere.
        for (BlockPos platform : platforms) placeInvisibleLight(world, platform.up(4));

        // The reward chamber is deliberately symmetrical, making the Poké Ball visually centered.
        BlockPos ballFloor = run.ballPos.down();
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            world.setBlockState(ballFloor.add(dx, 0, dz), theme.accent.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        for (int dy = 1; dy <= 4; dy++) {
            world.setBlockState(ballFloor.add(-3, dy, 0), Blocks.LIGHT.getDefaultState().with(Properties.LEVEL_15, 15), Block.NOTIFY_LISTENERS);
            world.setBlockState(ballFloor.add(3, dy, 0), Blocks.LIGHT.getDefaultState().with(Properties.LEVEL_15, 15), Block.NOTIFY_LISTENERS);
        }
        world.setBlockState(ballFloor.up(4), Blocks.LIGHT.getDefaultState().with(Properties.LEVEL_15, 15), Block.NOTIFY_LISTENERS);
    }

    private static List<BlockPos> parkourPlatforms(BlockPos startBlock, int stars) {
        int jumps = switch (stars) {
            case 1 -> 9;
            case 2 -> 11;
            case 3 -> 14;
            case 4 -> 17;
            default -> 20;
        };
        List<BlockPos> out = new ArrayList<>();
        out.add(startBlock);
        BlockPos current = startBlock;

        // Deterministic wave shared by every participant. Horizontal/turn difficulty grows with tier,
        // but vertical delta between consecutive platforms is strictly -1/0/+1. For an upward jump
        // the X advance is capped at 2, so no tier can generate a 2+ block climb or a long rising leap.
        int[] sideWave = {0, 1, 0, -1, -2, -1, 0, 1, 2, 1, 0, -1};
        int relativeY = 0;
        for (int i = 1; i <= jumps; i++) {
            int desiredZ = startBlock.getZ() + sideWave[(i + stars) % sideWave.length];
            int dz = desiredZ - current.getZ();
            if (dz > 1) desiredZ = current.getZ() + 1;
            if (dz < -1) desiredZ = current.getZ() - 1;

            int dy = 0;
            if (stars >= 2 && i % 5 == 2 && relativeY < 2) dy = 1;
            else if (stars >= 3 && i % 5 == 4 && relativeY > 0) dy = -1;
            else if (stars >= 4 && i % 7 == 0 && relativeY < 2) dy = 1;
            if (relativeY + dy < 0) dy = 0;
            if (relativeY + dy > 2) dy = 0;

            int dx;
            if (dy > 0) {
                dx = 2; // safe one-block ascent
            } else if (stars == 1) {
                dx = (i % 4 == 0) ? 3 : 2;
            } else if (stars <= 3) {
                dx = (i % 3 == 0) ? 3 : 2;
            } else {
                // Higher tiers are longer and use more 3-block/diagonal landings, never vertical abuse.
                dx = (i % 2 == 0) ? 3 : 2;
            }

            relativeY += dy;
            current = new BlockPos(current.getX() + dx, current.getY() + dy, desiredZ);
            out.add(current);
        }
        return List.copyOf(out);
    }

    private static void placeInvisibleLight(ServerWorld world, BlockPos pos) {
        world.setBlockState(pos, Blocks.LIGHT.getDefaultState().with(Properties.LEVEL_15, 15), Block.NOTIFY_LISTENERS);
    }

    private static void fillPlatform(ServerWorld world, BlockPos center, int radius, BlockState state) {
        for (int dx = -radius; dx <= radius; dx++) for (int dz = -radius; dz <= radius; dz++) {
            world.setBlockState(center.add(dx, 0, dz), state, Block.NOTIFY_LISTENERS);
        }
    }

    private static void enterParkour(ServerPlayerEntity player, PlayerRun run) {
        run.parkourEntered = true;
        resetParkour(player, run, false);
        player.sendMessage(Text.literal("§d✦ PRUEBA FINAL §7· supera el parkour para reclamar la " + ballName(eventRun.stars)
                + "§7. Si caes, volverás al inicio sin morir."), false);
        player.getServerWorld().playSound(null, run.parkourStartPos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                SoundCategory.PLAYERS, 1.0F, 1.15F);
    }

    private static void resetParkour(ServerPlayerEntity player, PlayerRun run, boolean failed) {
        ServerWorld world = player.getServer().getWorld(WORLD_KEY);
        if (world == null) return;
        player.fallDistance = 0.0F;
        player.teleport(world, run.parkourStartPos.getX() + .5D, run.parkourStartPos.getY(),
                run.parkourStartPos.getZ() + .5D, 0.0F, 0.0F);
        if (!ADMIN_BUILD.contains(player.getUuid())) player.changeGameMode(GameMode.ADVENTURE);
        if (failed) {
            player.sendMessage(Text.literal("§eFallaste el salto. §7Vuelves al inicio del parkour."), true);
            world.playSound(null, run.parkourStartPos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, .65F, .75F);
        }
    }

    private static void carveRoom(ServerWorld world, BlockPos center) {
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) for (int dy = 0; dy <= 4; dy++) {
            world.setBlockState(center.add(dx, dy, dz), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
    }

    private static void carveCorridor(ServerWorld world, BlockPos a, BlockPos b) {
        int dx = Integer.compare(b.getX(), a.getX());
        int dz = Integer.compare(b.getZ(), a.getZ());
        int steps = Math.max(Math.abs(b.getX() - a.getX()), Math.abs(b.getZ() - a.getZ()));
        for (int i = 0; i <= steps; i++) {
            BlockPos c = a.add(dx * i, 0, dz * i);
            for (int side = -1; side <= 1; side++) for (int dy = 0; dy <= 4; dy++) {
                BlockPos p = dx != 0 ? c.add(0, dy, side) : c.add(side, dy, 0);
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
    }

    private static void decorateCell(ServerWorld world, BlockPos center, BlockState state) {
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            if (Math.abs(dx) + Math.abs(dz) == 2) world.setBlockState(center.add(dx, -1, dz), state, Block.NOTIFY_LISTENERS);
        }
    }

    private static List<BlockPos> gateBlocks(BlockPos a, BlockPos b) {
        int dx = Integer.compare(b.getX(), a.getX());
        int dz = Integer.compare(b.getZ(), a.getZ());
        BlockPos middle = a.add(dx * (CELL_STEP / 2), 0, dz * (CELL_STEP / 2));
        List<BlockPos> result = new ArrayList<>();
        for (int side = -1; side <= 1; side++) for (int dy = 0; dy <= 3; dy++) {
            result.add(dx != 0 ? middle.add(0, dy, side) : middle.add(side, dy, 0));
        }
        return result;
    }

    private static void openGate(ServerWorld world, PlayerRun run, int index) {
        List<BlockPos> gate = run.gates.get(index);
        if (gate == null) return;
        for (BlockPos p : gate) world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
    }

    private static void spawnTrainers(ServerWorld world, PlayerRun run) {
        int total = eventRun.plan.trainerCells.size();
        for (int i = 1; i <= total; i++) {
            ServiceNpcEntity npc = ModRegistries.CUSTOM_NPC.create(world);
            if (npc == null) continue;
            BlockPos p = run.trainerPositions.get(i - 1);
            npc.refreshPositionAndAngles(p.getX() + .5D, p.getY(), p.getZ() + .5D, 0.0F, 0.0F);
            npc.setNpcId("treasure_" + shortId(eventRun.eventId) + "_" + shortId(run.playerId) + "_" + i + "_skin" + String.format("%02d", i - 1));
            npc.setDungeonStructureKey(run.structureKey);
            npc.setDungeonTier(TreasureStructureCatalog.tierIdForStars(eventRun.stars));
            npc.setDungeonTheme(eventRun.theme.battleTheme);
            npc.setDungeonRole(i == total ? "guardian" : i == 1 ? "scout" : i >= total - 1 ? "elite" : "veteran");
            // Treasure is a maze race: any overhead label is a wallhack. Keep the entity custom name
            // empty so vanilla/client renderers have nothing to draw through walls; NpcBattleService
            // supplies the proper battle-facing trainer name from the Treasure role instead.
            npc.setCustomName(Text.empty());
            npc.setCustomNameVisible(false);
            npc.setDialogue("Este pasillo está sellado. Mi equipo se adapta al promedio de tus Pokémon más fuertes; vence para romper el sello.");
            npc.setPokemonTeam(List.of("eevee level=10"));
            npc.setBattleRewards(List.of());
            npc.setBattleRewardRepeatable(false);
            if (world.spawnEntity(npc)) run.trainerIndexByNpc.put(npc.getUuid(), i);
        }
    }

    private static void spawnTreasureBall(MinecraftServer server, ServerWorld world, PlayerRun run) {
        BlockPos p = run.ballPos;
        String ownerTag = ownerTag(run.playerId);
        String itemId = TreasureStructureCatalog.ballItemForStars(eventRun.stars);
        // Server command sources default to the overworld. In alpha.20 the summon commands therefore
        // created the display/interaction at the same coordinates in the wrong dimension. Explicitly
        // execute inside treasure_maze and verify both entities exist before the player can reach the end.
        world.getChunk(p.getX() >> 4, p.getZ() >> 4);
        String prefix = "execute in " + WORLD_ID + " run ";
        String display = prefix + "summon minecraft:item_display " + (p.getX()+.5) + " " + (p.getY()+1.35) + " " + (p.getZ()+.5)
                + " {Tags:[\"" + DISPLAY_TAG + "\",\"" + ownerTag + "\"],item:{id:\"" + itemId + "\",count:1},billboard:\"fixed\",transformation:{scale:[3.2f,3.2f,3.2f]},interpolation_duration:8}";
        String interaction = prefix + "summon minecraft:interaction " + (p.getX()+.5) + " " + p.getY() + " " + (p.getZ()+.5)
                + " {Tags:[\"" + INTERACTION_TAG + "\",\"" + ownerTag + "\"],width:3.2f,height:3.2f,response:1b}";
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), display);
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), interaction);
        Box find = new Box(p).expand(3.0D);
        boolean foundDisplay = false;
        boolean foundInteraction = false;
        for (Entity entity : world.getOtherEntities(null, find, e -> e.getCommandTags().contains(ownerTag))) {
            if (entity.getCommandTags().contains(DISPLAY_TAG)) foundDisplay = true;
            if (entity.getCommandTags().contains(INTERACTION_TAG)) {
                run.interactionId = entity.getUuid();
                foundInteraction = true;
            }
        }
        if (!foundDisplay || !foundInteraction) {
            Chainacobblemon.LOGGER.error("Treasure ball spawn verification failed for {} in {} at {}: display={} interaction={}",
                    run.playerName, WORLD_ID, p, foundDisplay, foundInteraction);
        } else {
            Chainacobblemon.LOGGER.info("Treasure ball ready for {}: {} at {} in {}", run.playerName, itemId, p, WORLD_ID);
        }
        world.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD, p.getX()+.5, p.getY()+1.2, p.getZ()+.5, 20, .8, 1, .8, .03);
    }

    private static void removeInteraction(ServerWorld world, PlayerRun run) {
        String owner = ownerTag(run.playerId);
        for (Entity entity : world.getOtherEntities(null, run.bounds, e -> e.getCommandTags().contains(INTERACTION_TAG) && e.getCommandTags().contains(owner))) {
            entity.discard();
        }
    }

    private static void markTrainerPokemon(ServerWorld world, PlayerRun run) {
        List<Entity> trainers = new ArrayList<>();
        for (UUID npcId : run.trainerIndexByNpc.keySet()) {
            Entity npc = world.getEntity(npcId);
            if (npc != null && !npc.isRemoved()) trainers.add(npc);
        }
        if (trainers.isEmpty()) return;
        for (Entity entity : world.getOtherEntities(null, run.bounds.expand(1.0D), TreasureHuntService::isPokemonEntity)) {
            for (Entity trainer : trainers) {
                if (isOwnedByNpc(entity, trainer)) {
                    entity.addCommandTag(BATTLE_POKEMON_TAG);
                    break;
                }
            }
        }
    }

    private static boolean isOwnedByNpc(Entity pokemonEntity, Entity npc) {
        if (pokemonEntity == null || npc == null) return false;
        try {
            Object owner = pokemonEntity.getClass().getMethod("getOwner").invoke(pokemonEntity);
            if (owner == npc) return true;
        } catch (ReflectiveOperationException ignored) {
        }
        try {
            Object pokemon = pokemonEntity.getClass().getMethod("getPokemon").invoke(pokemonEntity);
            if (pokemon != null) {
                Object owner = pokemon.getClass().getMethod("getOwnerEntity").invoke(pokemon);
                return owner == npc;
            }
        } catch (ReflectiveOperationException ignored) {
        }
        return false;
    }

    private static boolean isPokemonEntity(Entity entity) {
        return entity != null && entity.getClass().getName().equals("com.cobblemon.mod.common.entity.pokemon.PokemonEntity");
    }

    private static void teleportToStart(ServerPlayerEntity player, PlayerRun run, boolean announce) {
        ServerWorld world = player.getServer().getWorld(WORLD_KEY);
        if (world == null) return;
        player.teleport(world, run.startPos.getX() + .5D, run.startPos.getY(), run.startPos.getZ() + .5D, 0.0F, 0.0F);
        if (!ADMIN_BUILD.contains(player.getUuid())) player.changeGameMode(GameMode.ADVENTURE);
        if (announce) {
            player.sendMessage(Text.literal("§d✦ Tu laberinto personal está listo · " + starLabel(eventRun.stars)
                    + " §7· guardianes: §f" + eventRun.plan.trainerCells.size()).formatted(Formatting.WHITE), false);
        }
    }

    private static void returnPlayer(ServerPlayerEntity player, PlayerRun run) {
        Identifier id = run.returnWorld;
        ServerWorld target = player.getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, id));
        if (target == null) {
            Chainacobblemon.LOGGER.warn("Treasure return world {} was unavailable for {}; using overworld fallback", id, run.playerName);
            target = player.getServer().getOverworld();
        }
        // Force the destination chunk to be present before the cross-dimension teleport packet is sent.
        // This avoids the client spending the post-reward transition looking at the Treasure dimension fog/void.
        int chunkX = ((int)Math.floor(run.returnX)) >> 4;
        int chunkZ = ((int)Math.floor(run.returnZ)) >> 4;
        target.getChunk(chunkX, chunkZ);
        player.teleport(target, run.returnX, run.returnY, run.returnZ, run.returnYaw, run.returnPitch);
        player.changeGameMode(run.returnCreative ? GameMode.CREATIVE : GameMode.SURVIVAL);
        Chainacobblemon.LOGGER.info("Treasure return: {} -> {} @ {} {} {}",
                run.playerName, target.getRegistryKey().getValue(), run.returnX, run.returnY, run.returnZ);
    }

    private static void clearSlot(ServerWorld world, Box box) {
        int minX = (int)Math.floor(box.minX);
        int minY = Math.max(world.getBottomY(), (int)Math.floor(box.minY));
        int minZ = (int)Math.floor(box.minZ);
        int maxX = (int)Math.ceil(box.maxX);
        int maxY = Math.min(world.getBottomY() + world.getHeight() - 1, (int)Math.ceil(box.maxY));
        int maxZ = (int)Math.ceil(box.maxZ);
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) for (int y = minY; y <= maxY; y++) {
            pos.set(x, y, z);
            if (!world.getBlockState(pos).isAir()) world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
    }

    private static String shortId(UUID uuid) { return uuid.toString().replace("-", "").substring(0, 6); }
    private static String ownerTag(UUID uuid) { return "chaina_owner_" + uuid.toString().replace("-", ""); }
    private static int compareCell(Cell a, Cell b) { return a.z != b.z ? Integer.compare(a.z, b.z) : Integer.compare(a.x, b.x); }

    private static String starLabel(int stars) { return "★".repeat(Math.max(1, Math.min(5, stars))); }
    private static String ballName(int stars) {
        return switch (stars) {
            case 1 -> "§cPoké Ball";
            case 2 -> "§9Great Ball";
            case 3 -> "§eUltra Ball";
            case 4 -> "§dLuxury Ball";
            default -> "§5Master Ball";
        };
    }

    private static MazeTheme theme(int stars) {
        return switch (stars) {
            case 1 -> new MazeTheme("Ruinas Chaina", "grass", Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.LIME_TERRACOTTA);
            case 2 -> new MazeTheme("Mina Chaina", "rock", Blocks.DEEPSLATE_BRICKS, Blocks.SPRUCE_PLANKS, Blocks.DEEPSLATE_TILES, Blocks.GOLD_BLOCK);
            case 3 -> new MazeTheme("Santuario Chaina", "psychic", Blocks.SMOOTH_QUARTZ, Blocks.PRISMARINE_BRICKS, Blocks.QUARTZ_BRICKS, Blocks.SEA_LANTERN);
            case 4 -> new MazeTheme("Fortaleza Chaina", "ghost", Blocks.DEEPSLATE_TILES, Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.DARK_PRISMARINE, Blocks.MAGENTA_GLAZED_TERRACOTTA);
            default -> new MazeTheme("Distorsión Master", "mixed", Blocks.POLISHED_BLACKSTONE, Blocks.PURPUR_BLOCK, Blocks.OBSIDIAN, Blocks.AMETHYST_BLOCK);
        };
    }

    private record MazeTheme(String display, String battleTheme, Block floor, Block wall, Block roof, Block accent) { }
    private record Cell(int x, int z) { }

    private static final class MazePlan {
        final int width;
        final int height;
        final Cell start;
        final Cell finalCell;
        final Map<Cell, Set<Cell>> links;
        final List<Cell> solution;
        final List<Cell> trainerCells;

        MazePlan(int width, int height, Cell start, Cell finalCell, Map<Cell, Set<Cell>> links,
                 List<Cell> solution, List<Cell> trainerCells) {
            this.width = width;
            this.height = height;
            this.start = start;
            this.finalCell = finalCell;
            this.links = links;
            this.solution = solution;
            this.trainerCells = trainerCells;
        }

        Set<Cell> neighbors(Cell cell) { return links.getOrDefault(cell, Set.of()); }

        static MazePlan generate(int stars, long seed) {
            int size = switch (stars) { case 1 -> 7; case 2 -> 9; case 3 -> 11; case 4 -> 13; default -> 15; };
            int trainers = switch (stars) { case 1 -> 2; case 2 -> 3; case 3 -> 4; case 4 -> 5; default -> 6; };
            Random random = new Random(seed);
            Cell start = new Cell(0, 0);
            Map<Cell, Set<Cell>> links = new HashMap<>();
            Set<Cell> visited = new HashSet<>();
            ArrayDeque<Cell> stack = new ArrayDeque<>();
            stack.push(start);
            visited.add(start);
            while (!stack.isEmpty()) {
                Cell current = stack.peek();
                List<Cell> options = rawNeighbors(current, size, size).stream().filter(c -> !visited.contains(c)).toList();
                if (options.isEmpty()) { stack.pop(); continue; }
                Cell next = options.get(random.nextInt(options.size()));
                links.computeIfAbsent(current, ignored -> new HashSet<>()).add(next);
                links.computeIfAbsent(next, ignored -> new HashSet<>()).add(current);
                visited.add(next);
                stack.push(next);
            }
            for (int z = 0; z < size; z++) for (int x = 0; x < size; x++) links.computeIfAbsent(new Cell(x,z), ignored -> new HashSet<>());

            Map<Cell, Cell> parent = new HashMap<>();
            Map<Cell, Integer> distance = new HashMap<>();
            ArrayDeque<Cell> queue = new ArrayDeque<>();
            queue.add(start);
            distance.put(start, 0);
            Cell farthest = start;
            while (!queue.isEmpty()) {
                Cell c = queue.removeFirst();
                if (distance.get(c) > distance.get(farthest)) farthest = c;
                for (Cell n : links.get(c)) if (!distance.containsKey(n)) {
                    distance.put(n, distance.get(c) + 1);
                    parent.put(n, c);
                    queue.addLast(n);
                }
            }
            List<Cell> path = new ArrayList<>();
            for (Cell c = farthest; c != null; c = parent.get(c)) path.add(c);
            Collections.reverse(path);

            List<Cell> checkpoints = new ArrayList<>();
            int usable = Math.max(1, path.size() - 4);
            for (int i = 1; i <= trainers; i++) {
                int index = 2 + (int)Math.round((usable - 1) * (i / (double)(trainers + 1)));
                index = Math.max(2, Math.min(path.size() - 3, index));
                Cell candidate = path.get(index);
                if (!checkpoints.contains(candidate)) checkpoints.add(candidate);
            }
            // Very short pathological DFS path fallback (normally impossible at these sizes).
            for (Cell c : path) {
                if (checkpoints.size() >= trainers) break;
                if (!c.equals(start) && !c.equals(farthest) && !checkpoints.contains(c)) checkpoints.add(c);
            }
            checkpoints.sort(Comparator.comparingInt(path::indexOf));
            return new MazePlan(size, size, start, farthest, links, List.copyOf(path), List.copyOf(checkpoints));
        }

        private static List<Cell> rawNeighbors(Cell c, int width, int height) {
            List<Cell> out = new ArrayList<>(4);
            if (c.x > 0) out.add(new Cell(c.x - 1, c.z));
            if (c.x + 1 < width) out.add(new Cell(c.x + 1, c.z));
            if (c.z > 0) out.add(new Cell(c.x, c.z - 1));
            if (c.z + 1 < height) out.add(new Cell(c.x, c.z + 1));
            return out;
        }
    }

    private static final class EventRun {
        final UUID eventId;
        final int stars;
        final long seed;
        final MazePlan plan;
        final MazeTheme theme;
        EventRun(UUID eventId, int stars, long seed, MazePlan plan, MazeTheme theme) {
            this.eventId = eventId; this.stars = stars; this.seed = seed; this.plan = plan; this.theme = theme;
        }
    }

    private static final class PlayerRun {
        final UUID playerId;
        final String playerName;
        final int slot;
        final int minX;
        final int minZ;
        final Box bounds;
        final BlockPos startPos;
        final BlockPos mazeFinalPos;
        final BlockPos parkourStartPos;
        final Box parkourBounds;
        final BlockPos ballPos;
        final Identifier returnWorld;
        final double returnX, returnY, returnZ;
        final float returnYaw, returnPitch;
        final boolean returnCreative;
        final String structureKey;
        final List<BlockPos> trainerPositions = new ArrayList<>();
        final Map<Integer, List<BlockPos>> gates = new HashMap<>();
        final Map<UUID, Integer> trainerIndexByNpc = new HashMap<>();
        int progress;
        boolean parkourEntered;
        UUID interactionId;
        PlayerRun(UUID playerId, String playerName, int slot, int minX, int minZ, Box bounds,
                  BlockPos startPos, BlockPos mazeFinalPos, BlockPos parkourStartPos, Box parkourBounds,
                  BlockPos ballPos, Identifier returnWorld,
                  double returnX, double returnY, double returnZ, float returnYaw, float returnPitch,
                  boolean returnCreative, String structureKey) {
            this.playerId = playerId; this.playerName = playerName; this.slot = slot; this.minX = minX; this.minZ = minZ;
            this.bounds = bounds; this.startPos = startPos; this.mazeFinalPos = mazeFinalPos;
            this.parkourStartPos = parkourStartPos; this.parkourBounds = parkourBounds;
            this.ballPos = ballPos; this.returnWorld = returnWorld;
            this.returnX = returnX; this.returnY = returnY; this.returnZ = returnZ; this.returnYaw = returnYaw; this.returnPitch = returnPitch;
            this.returnCreative = returnCreative; this.structureKey = structureKey;
        }
    }
}
