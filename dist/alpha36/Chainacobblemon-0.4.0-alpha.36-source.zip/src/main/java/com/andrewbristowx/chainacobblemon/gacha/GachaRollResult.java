package com.andrewbristowx.chainacobblemon.gacha;

import com.andrewbristowx.chainacobblemon.gacha.catalog.PokemonCatalogEntry;

public record GachaRollResult(
        String bannerId,
        PokemonCatalogEntry pokemon,
        GachaTier tier,
        int level,
        boolean shiny,
        boolean epicPityTriggered,
        boolean legendaryPityTriggered,
        String nature,
        int minPerfectIvs
) {
    public GachaRollResult {
        nature = nature == null ? "" : nature;
        minPerfectIvs = Math.max(0, Math.min(6, minPerfectIvs));
    }

    public boolean hasNatureBonus() {
        return !nature.isBlank();
    }

    public boolean hasPerfectIvBonus() {
        return minPerfectIvs > 0;
    }

    public boolean hasExtraBonuses() {
        return hasNatureBonus() || hasPerfectIvBonus();
    }
}
