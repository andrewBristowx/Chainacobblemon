package com.andrewbristowx.chainacobblemon.gacha.banner;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

public final class BannerManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Double> CHAINA_FEATURED = Map.ofEntries(
            Map.entry("cobblemon:absol", 4.0D),
            Map.entry("cobblemon:froslass", 4.0D),
            Map.entry("cobblemon:skitty", 3.0D),
            Map.entry("cobblemon:mienfoo", 3.0D),
            Map.entry("cobblemon:chingling", 3.0D),
            Map.entry("cobblemon:litten", 4.0D),
            Map.entry("cobblemon:purrloin", 3.0D),
            Map.entry("cobblemon:sneasel", 4.0D),
            Map.entry("cobblemon:tinkatink", 4.0D),
            Map.entry("cobblemon:lurantis", 4.0D),
            Map.entry("cobblemon:persian", 4.0D),
            Map.entry("cobblemon:delphox", 5.0D),
            Map.entry("cobblemon:ceruledge", 5.0D)
    );

    private final Path bannerDirectory = FabricLoader.getInstance().getConfigDir()
            .resolve(Chainacobblemon.MOD_ID).resolve("gacha").resolve("banners");
    private volatile Map<String, BannerDefinition> banners = Map.of();

    public synchronized void initialize() {
        try {
            Files.createDirectories(bannerDirectory);
            createDefaultsIfMissing();
            reload();
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not initialize gacha banners", exception);
        }
    }

    public synchronized boolean reload() {
        try {
            Files.createDirectories(bannerDirectory);
            Map<String, BannerDefinition> loaded = new HashMap<>();
            try (Stream<Path> files = Files.list(bannerDirectory)) {
                for (Path path : files.filter(file -> file.getFileName().toString().endsWith(".json")).toList()) {
                    try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                        BannerDefinition banner = GSON.fromJson(reader, BannerDefinition.class);
                        if (banner == null) throw new IllegalStateException("Empty banner file: " + path);
                        banner.normalize();
                        applyBuiltInDefaults(banner);
                        if (loaded.putIfAbsent(banner.id, banner) != null) {
                            throw new IllegalStateException("Duplicate banner id: " + banner.id);
                        }
                    }
                }
            }
            if (loaded.isEmpty()) throw new IllegalStateException("No gacha banners were loaded");
            banners = Map.copyOf(loaded);
            Chainacobblemon.LOGGER.info("Loaded {} Chainacobblemon gacha banners", banners.size());
            return true;
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Gacha banner reload failed; keeping last known-good banners", exception);
            return false;
        }
    }

    public BannerDefinition get(String id) {
        if (id == null) return null;
        return banners.get(id.toLowerCase(Locale.ROOT));
    }

    public List<BannerDefinition> all() {
        return new ArrayList<>(banners.values()).stream()
                .sorted(Comparator.comparing(banner -> banner.id))
                .toList();
    }

    public int size() {
        return banners.size();
    }

    public List<BannerDefinition> active() {
        return all().stream().filter(BannerDefinition::activeNow)
                .sorted(Comparator.comparingInt((BannerDefinition banner) -> banner.rotationPriority).reversed()
                        .thenComparing(banner -> banner.id))
                .toList();
    }

    public synchronized boolean save(BannerDefinition banner) {
        if (banner == null) return false;
        try {
            banner.normalize();
            if (!banner.id.matches("[a-z0-9_-]{1,32}")) {
                throw new IllegalArgumentException("ID de banner no válido");
            }
            Files.createDirectories(bannerDirectory);
            Path target = bannerDirectory.resolve(banner.id + ".json");
            Path temporary = bannerDirectory.resolve(banner.id + ".json.uploading");
            write(temporary, banner);
            try {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
            return reload();
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not save banner", exception);
            return false;
        }
    }

    public Path directory() {
        return bannerDirectory;
    }

    private void createDefaultsIfMissing() throws Exception {
        Path standard = bannerDirectory.resolve("standard.json");
        if (Files.notExists(standard)) {
            BannerDefinition banner = new BannerDefinition();
            banner.id = "standard";
            banner.displayName = "Gacha Estandar";
            banner.normalize();
            write(standard, banner);
        }

        Path rayquaza = bannerDirectory.resolve("rayquaza_hoenn.json");
        if (Files.notExists(rayquaza)) {
            BannerDefinition banner = new BannerDefinition();
            banner.id = "rayquaza_hoenn";
            banner.displayName = "Rayquaza - Cielos de Hoenn";
            banner.generations.add(3);
            banner.featuredSpecies.put("cobblemon:rayquaza", 6.0);
            banner.normalize();
            write(rayquaza, banner);
        }

        Path chainaSpecial = bannerDirectory.resolve("chaina_special.json");
        if (Files.notExists(chainaSpecial)) {
            BannerDefinition banner = new BannerDefinition();
            banner.id = "chaina_special";
            banner.displayName = "Gasha Especial de Chaina";
            banner.shinyChanceByTier.put("COMMON", 1.0 / 2048.0);
            banner.shinyChanceByTier.put("UNCOMMON", 1.0 / 1536.0);
            banner.shinyChanceByTier.put("RARE", 1.0 / 1024.0);
            banner.shinyChanceByTier.put("EPIC", 1.0 / 768.0);
            banner.shinyChanceByTier.put("LEGENDARY", 1.0 / 512.0);
            banner.shinyChanceByTier.put("MYTHICAL", 1.0 / 512.0);
            banner.minPerfectIvsByTier.put("RARE", 1);
            banner.minPerfectIvsByTier.put("EPIC", 2);
            banner.minPerfectIvsByTier.put("LEGENDARY", 3);
            banner.minPerfectIvsByTier.put("MYTHICAL", 3);
            banner.rareNatureChance = 0.18;
            banner.rareNaturePool.addAll(List.of("Modest", "Timid", "Adamant", "Jolly", "Calm", "Careful"));
            banner.featuredSpecies.putAll(CHAINA_FEATURED);
            banner.normalize();
            write(chainaSpecial, banner);
        }
    }

    private void applyBuiltInDefaults(BannerDefinition banner) {
        if (banner == null) return;
        if ("standard".equals(banner.id)) {
            if (!banner.excludedLabels.contains("custom")) banner.excludedLabels.add("custom");
            for (String speciesId : CHAINA_FEATURED.keySet()) {
                if (!banner.excludedSpecies.contains(speciesId)) banner.excludedSpecies.add(speciesId);
            }
        } else if ("chaina_special".equals(banner.id)) {
            // Applied on every reload so existing servers receive newly accepted Chaina variants
            // without deleting their current banner configuration.
            CHAINA_FEATURED.forEach(banner.featuredSpecies::putIfAbsent);
        }
    }

    private void write(Path path, BannerDefinition banner) throws Exception {
        try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            GSON.toJson(banner, writer);
        }
    }
}
