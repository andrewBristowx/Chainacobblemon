package com.andrewbristowx.chainacobblemon.gacha.treasure;

import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.data.PlayerDataManager;
import com.andrewbristowx.chainacobblemon.gacha.GachaProgress;
import com.andrewbristowx.chainacobblemon.gacha.GachaTier;
import com.andrewbristowx.chainacobblemon.gacha.banner.BannerDefinition;
import com.andrewbristowx.chainacobblemon.gacha.economy.GachaCurrencyService;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.andrewbristowx.chainacobblemon.rewards.RewardWalletService;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/** Server-authoritative non-Pokemon gacha used by the dedicated Tesoros de Chaina machine. */
public final class TreasureGachaService {
    public static final String PROGRESS_ID = "chaina_treasures";
    public static final int NETHERITE_PITY = 30;
    public static final int CHAINA_PITY = 90;

    private static final Map<GachaTier, Double> TIER_WEIGHTS = Map.of(
            GachaTier.COMMON, 45.0D,
            GachaTier.UNCOMMON, 27.0D,
            GachaTier.RARE, 15.0D,
            GachaTier.EPIC, 9.0D,
            GachaTier.LEGENDARY, 4.0D
    );

    private final PlayerDataManager dataManager;
    private final GachaCurrencyService currency;
    private final Map<GachaTier, List<RewardDefinition>> pools = new EnumMap<>(GachaTier.class);

    public TreasureGachaService(PlayerDataManager dataManager, RewardWalletService wallet) {
        this.dataManager = dataManager;
        this.currency = new GachaCurrencyService(wallet);
        for (GachaTier tier : GachaTier.values()) pools.put(tier, new ArrayList<>());
        buildPools();
    }

    public PullOutcome pull(ServerPlayerEntity player) {
        if (player == null) return PullOutcome.failure("Jugador inválido.");
        BannerDefinition.Currency cost = ticketCost();
        GachaCurrencyService.Result withdrawal = currency.withdraw(player, cost);
        if (!withdrawal.success()) return PullOutcome.failure("Necesitas 1x Ticket de Tesoros de Chaina.");

        PlayerData data = dataManager.getOrLoad(player.getUuid());
        GachaProgress progress = data.gacha(PROGRESS_ID);
        GachaTier tier = rollTier(progress);
        RewardDefinition reward = weightedReward(pools.getOrDefault(tier, List.of()));
        if (reward == null) {
            currency.refund(player, withdrawal);
            return PullOutcome.failure("El Gasha de Tesoros no tiene recompensas válidas.");
        }

        PreparedReward prepared = createRewardStack(player, reward);
        ItemStack stack = prepared.stack();
        if (stack.isEmpty()) {
            currency.refund(player, withdrawal);
            return PullOutcome.failure("No se pudo preparar la recompensa; el ticket fue devuelto.");
        }

        if (!player.getInventory().insertStack(stack)) {
            player.dropItem(stack, false);
        } else if (!stack.isEmpty()) {
            player.dropItem(stack, false);
        }
        player.getInventory().markDirty();

        progress.record(tier, reward.id());
        dataManager.saveNow(player.getUuid());
        return PullOutcome.success(new TreasureResult(
                reward.id(), reward.displayName(), tier,
                Registries.ITEM.getId(reward.item()).toString(), prepared.count()
        ));
    }

    public GachaProgress progress(ServerPlayerEntity player) {
        return dataManager.getOrLoad(player.getUuid()).gacha(PROGRESS_ID);
    }

    public Map<GachaTier, Integer> poolCounts() {
        Map<GachaTier, Integer> result = new EnumMap<>(GachaTier.class);
        for (GachaTier tier : GachaTier.values()) result.put(tier, pools.getOrDefault(tier, List.of()).size());
        return result;
    }

    private GachaTier rollTier(GachaProgress progress) {
        if (progress.pullsSinceLegendaryOrBetter + 1 >= CHAINA_PITY) return GachaTier.LEGENDARY;
        if (progress.pullsSinceEpicOrBetter + 1 >= NETHERITE_PITY) {
            return ThreadLocalRandom.current().nextDouble(13.0D) < 4.0D ? GachaTier.LEGENDARY : GachaTier.EPIC;
        }
        double roll = ThreadLocalRandom.current().nextDouble(100.0D);
        double cursor = 0.0D;
        for (GachaTier tier : List.of(GachaTier.COMMON, GachaTier.UNCOMMON, GachaTier.RARE, GachaTier.EPIC, GachaTier.LEGENDARY)) {
            cursor += TIER_WEIGHTS.get(tier);
            if (roll < cursor) return tier;
        }
        return GachaTier.COMMON;
    }

    private RewardDefinition weightedReward(List<RewardDefinition> candidates) {
        if (candidates == null || candidates.isEmpty()) return null;
        double total = candidates.stream().mapToDouble(RewardDefinition::weight).sum();
        double roll = ThreadLocalRandom.current().nextDouble(total);
        double cursor = 0.0D;
        for (RewardDefinition reward : candidates) {
            cursor += reward.weight();
            if (roll < cursor) return reward;
        }
        return candidates.getLast();
    }

    private PreparedReward createRewardStack(ServerPlayerEntity player, RewardDefinition reward) {
        int count = reward.minCount() == reward.maxCount()
                ? reward.minCount()
                : ThreadLocalRandom.current().nextInt(reward.minCount(), reward.maxCount() + 1);
        ItemStack stack = new ItemStack(reward.item(), count);
        applyTierEnchantments(player, stack, reward.tier());
        return new PreparedReward(stack, count);
    }

    private void applyTierEnchantments(ServerPlayerEntity player, ItemStack stack, GachaTier tier) {
        Item item = stack.getItem();
        if (tier == GachaTier.RARE) {
            if (isArmor(item)) add(player, stack, Enchantments.PROTECTION, 3);
            else if (item == Items.DIAMOND_SWORD) add(player, stack, Enchantments.SHARPNESS, 4);
            else if (isDiamondTool(item)) {
                add(player, stack, Enchantments.EFFICIENCY, 4);
                if (item != Items.DIAMOND_HOE) add(player, stack, Enchantments.FORTUNE, 2);
            }
        } else if (tier == GachaTier.EPIC) {
            if (isArmor(item)) add(player, stack, Enchantments.PROTECTION, 4);
            else if (item == Items.NETHERITE_SWORD) {
                add(player, stack, Enchantments.SHARPNESS, 5);
                add(player, stack, Enchantments.LOOTING, 3);
            } else if (isNetheriteTool(item)) {
                add(player, stack, Enchantments.EFFICIENCY, 5);
                if (item != Items.NETHERITE_HOE) add(player, stack, Enchantments.FORTUNE, 3);
            }
        } else if (tier == GachaTier.LEGENDARY) {
            if (item == ModRegistries.CHAINA_HELMET) {
                add(player, stack, Enchantments.PROTECTION, 4);
                add(player, stack, Enchantments.RESPIRATION, 3);
                add(player, stack, Enchantments.AQUA_AFFINITY, 1);
            } else if (item == ModRegistries.CHAINA_CHESTPLATE) {
                add(player, stack, Enchantments.PROTECTION, 4);
                add(player, stack, Enchantments.THORNS, 2);
            } else if (item == ModRegistries.CHAINA_LEGGINGS) {
                add(player, stack, Enchantments.PROTECTION, 4);
                add(player, stack, Enchantments.SWIFT_SNEAK, 2);
            } else if (item == ModRegistries.CHAINA_BOOTS) {
                add(player, stack, Enchantments.PROTECTION, 4);
                add(player, stack, Enchantments.FEATHER_FALLING, 4);
                add(player, stack, Enchantments.DEPTH_STRIDER, 3);
            } else if (item == ModRegistries.CHAINA_SWORD) {
                add(player, stack, Enchantments.SHARPNESS, 5);
                add(player, stack, Enchantments.LOOTING, 3);
            } else if (item == ModRegistries.CHAINA_PICKAXE || item == ModRegistries.CHAINA_AXE) {
                add(player, stack, Enchantments.EFFICIENCY, 5);
                add(player, stack, Enchantments.FORTUNE, 3);
            } else if (item == ModRegistries.CHAINA_SHOVEL || item == ModRegistries.CHAINA_HOE) {
                add(player, stack, Enchantments.EFFICIENCY, 5);
            }
        }
    }

    private void add(ServerPlayerEntity player, ItemStack stack, RegistryKey<Enchantment> key, int level) {
        player.getRegistryManager().get(RegistryKeys.ENCHANTMENT).getEntry(key)
                .ifPresent(entry -> stack.addEnchantment(entry, level));
    }

    private static boolean isArmor(Item item) {
        return item == Items.DIAMOND_HELMET || item == Items.DIAMOND_CHESTPLATE || item == Items.DIAMOND_LEGGINGS || item == Items.DIAMOND_BOOTS
                || item == Items.NETHERITE_HELMET || item == Items.NETHERITE_CHESTPLATE || item == Items.NETHERITE_LEGGINGS || item == Items.NETHERITE_BOOTS
                || item == ModRegistries.CHAINA_HELMET || item == ModRegistries.CHAINA_CHESTPLATE || item == ModRegistries.CHAINA_LEGGINGS || item == ModRegistries.CHAINA_BOOTS;
    }

    private static boolean isDiamondTool(Item item) {
        return item == Items.DIAMOND_PICKAXE || item == Items.DIAMOND_AXE || item == Items.DIAMOND_SHOVEL || item == Items.DIAMOND_HOE;
    }

    private static boolean isNetheriteTool(Item item) {
        return item == Items.NETHERITE_PICKAXE || item == Items.NETHERITE_AXE || item == Items.NETHERITE_SHOVEL || item == Items.NETHERITE_HOE;
    }

    private BannerDefinition.Currency ticketCost() {
        BannerDefinition.Currency cost = new BannerDefinition.Currency();
        cost.type = "ITEM";
        cost.itemId = "chainacobblemon:treasure_gacha_ticket";
        cost.amount = 1;
        cost.normalize();
        return cost;
    }

    private void buildPools() {
        add(GachaTier.COMMON, "bread", "Pan x4-12", Items.BREAD, 4, 12, 1.0);
        add(GachaTier.COMMON, "cooked_beef", "Carne cocida x4-10", Items.COOKED_BEEF, 4, 10, 1.0);
        add(GachaTier.COMMON, "baked_potato", "Patatas asadas x8-16", Items.BAKED_POTATO, 8, 16, 0.9);
        add(GachaTier.COMMON, "coal", "Carbón x8-24", Items.COAL, 8, 24, 1.0);
        add(GachaTier.COMMON, "iron", "Hierro x4-12", Items.IRON_INGOT, 4, 12, 1.0);
        add(GachaTier.COMMON, "copper", "Cobre x8-24", Items.COPPER_INGOT, 8, 24, 0.9);
        add(GachaTier.COMMON, "redstone", "Redstone x12-32", Items.REDSTONE, 12, 32, 0.9);
        add(GachaTier.COMMON, "lapis", "Lapislázuli x8-24", Items.LAPIS_LAZULI, 8, 24, 0.9);

        add(GachaTier.UNCOMMON, "gold", "Oro x4-10", Items.GOLD_INGOT, 4, 10, 1.0);
        add(GachaTier.UNCOMMON, "emerald", "Esmeraldas x3-8", Items.EMERALD, 3, 8, 1.0);
        add(GachaTier.UNCOMMON, "golden_carrot", "Zanahorias doradas x4-10", Items.GOLDEN_CARROT, 4, 10, 0.9);
        add(GachaTier.UNCOMMON, "xp_bottle", "Frascos de experiencia x8-20", Items.EXPERIENCE_BOTTLE, 8, 20, 0.9);
        add(GachaTier.UNCOMMON, "amethyst", "Fragmentos de amatista x8-20", Items.AMETHYST_SHARD, 8, 20, 0.8);

        add(GachaTier.RARE, "diamond", "Diamantes x2-6", Items.DIAMOND, 2, 6, 1.4);
        addGear(GachaTier.RARE, "diamond", Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

        add(GachaTier.EPIC, "netherite_scrap", "Restos de netherita x2-4", Items.NETHERITE_SCRAP, 2, 4, 1.2);
        add(GachaTier.EPIC, "netherite_ingot", "Lingote de netherita x1-2", Items.NETHERITE_INGOT, 1, 2, 0.8);
        addGear(GachaTier.EPIC, "netherite", Items.NETHERITE_SWORD, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE, Items.NETHERITE_SHOVEL, Items.NETHERITE_HOE,
                Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS);

        add(GachaTier.LEGENDARY, "chaina_sword", "Espada de Chaina", ModRegistries.CHAINA_SWORD, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_pickaxe", "Pico de Chaina 3×3", ModRegistries.CHAINA_PICKAXE, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_axe", "Hacha taladora de Chaina", ModRegistries.CHAINA_AXE, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_shovel", "Pala de Chaina 3×3", ModRegistries.CHAINA_SHOVEL, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_hoe", "Azada minera de Chaina", ModRegistries.CHAINA_HOE, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_helmet", "Casco de Chaina", ModRegistries.CHAINA_HELMET, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_chestplate", "Pechera de Chaina", ModRegistries.CHAINA_CHESTPLATE, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_leggings", "Grebas de Chaina", ModRegistries.CHAINA_LEGGINGS, 1, 1, 1.0);
        add(GachaTier.LEGENDARY, "chaina_boots", "Botas de Chaina", ModRegistries.CHAINA_BOOTS, 1, 1, 1.0);
    }

    private void addGear(GachaTier tier, String prefix, Item... items) {
        for (Item item : items) {
            String path = Registries.ITEM.getId(item).getPath();
            add(tier, path, gearName(path), item, 1, 1, 1.0);
        }
    }

    private void add(GachaTier tier, String id, String name, Item item, int min, int max, double weight) {
        pools.get(tier).add(new RewardDefinition(id, name, item, min, max, weight, tier));
    }

    private static String gearName(String path) {
        String material = path.startsWith("netherite_") ? "Netherita" : path.startsWith("diamond_") ? "Diamante" : "";
        String piece = path.substring(path.indexOf('_') + 1);
        String type = switch (piece) {
            case "sword" -> "Espada";
            case "pickaxe" -> "Pico";
            case "axe" -> "Hacha";
            case "shovel" -> "Pala";
            case "hoe" -> "Azada";
            case "helmet" -> "Casco";
            case "chestplate" -> "Pechera";
            case "leggings" -> "Grebas";
            case "boots" -> "Botas";
            default -> piece;
        };
        return type + (material.isBlank() ? "" : " de " + material);
    }

    public static final class RewardDefinition {
        private final String id;
        private final String displayName;
        private final Item item;
        private final int minCount;
        private final int maxCount;
        private final double weight;
        private final GachaTier tier;

        private RewardDefinition(String id, String displayName, Item item, int minCount, int maxCount, double weight, GachaTier tier) {
            this.id = id; this.displayName = displayName; this.item = item; this.minCount = minCount;
            this.maxCount = maxCount; this.weight = weight; this.tier = tier;
        }
        public String id() { return id; }
        public String displayName() { return displayName; }
        public Item item() { return item; }
        public int minCount() { return minCount; }
        public int maxCount() { return maxCount; }
        public double weight() { return weight; }
        public GachaTier tier() { return tier; }
    }

    private record PreparedReward(ItemStack stack, int count) { }

    public record TreasureResult(String rewardId, String displayName, GachaTier tier, String itemId, int count) { }
    public record PullOutcome(boolean success, String error, TreasureResult result) {
        public static PullOutcome success(TreasureResult result) { return new PullOutcome(true, null, result); }
        public static PullOutcome failure(String error) { return new PullOutcome(false, error, null); }
    }
}
