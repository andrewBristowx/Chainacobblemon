package com.andrewbristowx.chainacobblemon.armor;

import org.apache.commons.lang3.mutable.MutableObject;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;

import java.util.function.Consumer;

/** Shared GeckoLib armor contract for split-source Fabric. */
public interface ChainaGeoArmorPiece extends GeoItem {
    RawAnimation CHAINA_ARMOR_IDLE = RawAnimation.begin().thenLoop("animation.chainacobblemon.chaina_armor.idle");
    AnimatableInstanceCache chainaArmorGeoCache();
    MutableObject<GeoRenderProvider> chainaArmorRenderProviderHolder();

    @Override
    default AnimatableInstanceCache getAnimatableInstanceCache() {
        return chainaArmorGeoCache();
    }

    @Override
    default void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "chaina_armor_idle", 5, state -> state.setAndContinue(CHAINA_ARMOR_IDLE)));
    }

    @Override
    default void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(chainaArmorRenderProviderHolder().getValue());
    }
}
