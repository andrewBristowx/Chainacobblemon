package com.andrewbristowx.chainacobblemon.events.data;

import java.util.HashMap;
import java.util.Map;

/** Persistent postgame event records. */
public final class EventProgress {
    public long totalParticipations;
    public long totalWins;
    public Map<String, Long> winsByType = new HashMap<>();
    public Map<String, Long> bestScoreByType = new HashMap<>();
    public int bestBeautyRound;
    public String bestFishingPokemon = "";
    public String bestSafariPokemon = "";

    public void normalize() {
        if (winsByType == null) winsByType = new HashMap<>();
        if (bestScoreByType == null) bestScoreByType = new HashMap<>();
        if (bestFishingPokemon == null) bestFishingPokemon = "";
        if (bestSafariPokemon == null) bestSafariPokemon = "";
    }

    public void recordParticipation() {
        totalParticipations++;
    }

    public void recordWin(String type) {
        totalWins++;
        winsByType.merge(type, 1L, Long::sum);
    }

    public void recordBest(String type, long score) {
        bestScoreByType.merge(type, Math.max(0L, score), Math::max);
    }
}
