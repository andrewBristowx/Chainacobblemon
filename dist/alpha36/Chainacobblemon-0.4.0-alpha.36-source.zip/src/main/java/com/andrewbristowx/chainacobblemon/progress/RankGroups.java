package com.andrewbristowx.chainacobblemon.progress;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/** Canonical LuckPerms groups configured on the Chaina server. */
public final class RankGroups {
    public static final String DEFAULT = "default";
    public static final String BASIC = DEFAULT;
    public static final String VIP = "vip";
    public static final String DONATOR = VIP;
    public static final String MODERATOR = "moderator";
    public static final String ADMIN = "admin";
    public static final String OWNER = "owner";
    public static final String OWNERS = OWNER;
    public static final String CHAINA = "chaina";

    /** Secondary Twitch groups created by ChainaBridge/Chainacobblemon. */
    public static final String SUB_1 = "sub_chaina";
    public static final String SUB_2 = "sub_chaina_plus";
    public static final String SUB_3 = "sub_chaina_plus_plus";
    public static final String TWITCH_VIP = "vip_chaina";
    public static final String TWITCH_MOD = "mod_chaina";

    public static final Set<String> ALL = uniqueSet(
            DEFAULT, VIP, MODERATOR, "mod", "moderador", ADMIN, "administrator", OWNER, CHAINA,
            SUB_1, SUB_2, SUB_3, TWITCH_VIP, TWITCH_MOD);

    /** Compatibility aliases retained for older shop/config code. */
    public static final Set<String> SUPPORTERS = uniqueSet(VIP, DONATOR);
    public static final Set<String> STAFF = uniqueSet(MODERATOR, "mod", "moderador", OWNER, ADMIN, "administrator", CHAINA, TWITCH_MOD);

    /** Ranks that receive every simultaneous job slot. */
    public static final Set<String> FULL_ACCESS = uniqueSet(ADMIN, "administrator", OWNER, CHAINA);
    /** Ranks with four simultaneous jobs. */
    public static final Set<String> FOUR_JOB = uniqueSet(VIP, MODERATOR, "mod", "moderador", TWITCH_VIP, TWITCH_MOD, SUB_3);
    /** Subscriber tiers with three simultaneous jobs. */
    public static final Set<String> THREE_JOB = uniqueSet(SUB_1, SUB_2);
    /** Battle-pass premium ranks. */
    public static final Set<String> PREMIUM = uniqueSet(
            VIP, MODERATOR, "mod", "moderador", ADMIN, "administrator", OWNER, CHAINA,
            SUB_1, SUB_2, SUB_3, TWITCH_VIP, TWITCH_MOD);

    private RankGroups() { }

    private static Set<String> uniqueSet(String... groups) {
        return Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(groups)));
    }

    public static String normalize(String value) {
        return value == null ? "" : value.strip().toLowerCase(Locale.ROOT);
    }
}
