package com.andrewbristowx.chainacobblemon.tower;

public final class TowerProgress {
    public boolean adminUnlocked;
    public boolean activeAttempt;
    public int currentFloor;
    public int bestFloor;
    public int completions;
    public long cooldownUntilEpochMillis;
    public long rouletteCooldownUntilEpochMillis;
    public String returnWorld = "minecraft:overworld";
    public double returnX;
    public double returnY;
    public double returnZ;
    public float returnYaw;
    public float returnPitch;
    public boolean returnCreative;

    public void normalize() {
        currentFloor = Math.max(0, Math.min(10, currentFloor));
        bestFloor = Math.max(0, Math.min(10, bestFloor));
        completions = Math.max(0, completions);
        cooldownUntilEpochMillis = Math.max(0L, cooldownUntilEpochMillis);
        rouletteCooldownUntilEpochMillis = Math.max(0L, rouletteCooldownUntilEpochMillis);
        if (returnWorld == null || returnWorld.isBlank()) returnWorld = "minecraft:overworld";
        if (!activeAttempt) currentFloor = 0;
    }
}
