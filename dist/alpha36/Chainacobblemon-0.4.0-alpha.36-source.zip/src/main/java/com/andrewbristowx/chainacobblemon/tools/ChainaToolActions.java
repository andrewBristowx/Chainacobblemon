package com.andrewbristowx.chainacobblemon.tools;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Server-authoritative multi-block actions. Every extra block uses the normal interaction manager. */
final class ChainaToolActions {
    private static final ThreadLocal<Boolean> EXPANDING = ThreadLocal.withInitial(() -> false);
    private static final int MAX_TREE_LOGS = 192;

    private ChainaToolActions() { }

    static void minePlane(ServerWorld world, ServerPlayerEntity player, BlockPos origin,
                          TagKey<Block> mineable, Item expectedTool) {
        if (player.isSneaking() || EXPANDING.get()) return;
        EXPANDING.set(true);
        try {
            boolean floorPlane = Math.abs(player.getPitch()) >= 55.0F;
            boolean xNormal = player.getHorizontalFacing().getAxis() == Direction.Axis.X;
            for (int first = -1; first <= 1; first++) {
                for (int second = -1; second <= 1; second++) {
                    if (first == 0 && second == 0) continue;
                    BlockPos target = floorPlane
                            ? origin.add(first, 0, second)
                            : xNormal ? origin.add(0, first, second) : origin.add(first, second, 0);
                    BlockState targetState = world.getBlockState(target);
                    if (!targetState.isAir() && targetState.isIn(mineable)) {
                        breakNormally(player, target, expectedTool);
                    }
                }
            }
        } finally {
            EXPANDING.set(false);
        }
    }

    static void fellTree(ServerWorld world, ServerPlayerEntity player, BlockPos origin, Item expectedTool) {
        if (player.isSneaking() || EXPANDING.get()) return;
        Set<BlockPos> visited = new HashSet<>();
        Set<BlockPos> logs = new HashSet<>();
        ArrayDeque<BlockPos> pending = new ArrayDeque<>();
        visited.add(origin.toImmutable());
        pending.add(origin.toImmutable());

        while (!pending.isEmpty() && logs.size() < MAX_TREE_LOGS) {
            BlockPos current = pending.removeFirst();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos next = current.add(dx, dy, dz).toImmutable();
                        if (!insideTreeBounds(origin, next) || !visited.add(next)) continue;
                        if (world.getBlockState(next).isIn(BlockTags.LOGS)) {
                            logs.add(next);
                            pending.addLast(next);
                        }
                    }
                }
            }
        }
        if (logs.size() < 2 || !hasLeaves(world, logs)) return;

        List<BlockPos> ordered = new ArrayList<>(logs);
        ordered.sort(Comparator.comparingInt(BlockPos::getY));
        EXPANDING.set(true);
        try {
            for (BlockPos log : ordered) {
                if (!world.getBlockState(log).isIn(BlockTags.LOGS)) continue;
                if (!breakNormally(player, log, expectedTool)) break;
            }
        } finally {
            EXPANDING.set(false);
        }
    }

    static boolean expanding() {
        return EXPANDING.get();
    }

    private static boolean breakNormally(ServerPlayerEntity player, BlockPos pos, Item expectedTool) {
        if (!player.getMainHandStack().isOf(expectedTool)) return false;
        return player.interactionManager.tryBreakBlock(pos);
    }

    private static boolean insideTreeBounds(BlockPos origin, BlockPos candidate) {
        return Math.abs(candidate.getX() - origin.getX()) <= 9
                && candidate.getY() >= origin.getY() - 3
                && candidate.getY() <= origin.getY() + 32
                && Math.abs(candidate.getZ() - origin.getZ()) <= 9;
    }

    private static boolean hasLeaves(ServerWorld world, Set<BlockPos> logs) {
        for (BlockPos log : logs) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (world.getBlockState(log.add(dx, dy, dz)).isIn(BlockTags.LEAVES)) return true;
                    }
                }
            }
        }
        return false;
    }
}
