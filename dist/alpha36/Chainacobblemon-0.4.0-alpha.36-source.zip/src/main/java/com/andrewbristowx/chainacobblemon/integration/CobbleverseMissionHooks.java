package com.andrewbristowx.chainacobblemon.integration;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public final class CobbleverseMissionHooks {
    private CobbleverseMissionHooks() {
    }

    public static void altarInvocationAccepted(ServerPlayerEntity player, Identifier altarId) {
        if (altarId == null || !"lumymon".equals(altarId.getNamespace())) return;
        switch (altarId.getPath()) {
            case "articuno_altar", "zapdos_altar", "moltres_altar" ->
                    Chainacobblemon.progressionService().recordExactAltarInvocation(player, altarId);
            default -> {
                // This release intentionally implements only audited quest altar IDs.
            }
        }
    }
}
