package com.andrewbristowx.chainacobblemon.admin;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Final Overworld pregeneration for CHAINA SERVER.
 *
 * <p>This is intentionally separate from {@link SelectivePregenService}. The selective service is ideal while
 * building/testing the campaign. This service is the final-map step: it derives a square border from the Overworld
 * spawn and the farthest located regional structure, adds a safety margin, aligns the radius to Minecraft region
 * files (512 blocks), applies the world border and asks Chunky to generate the entire square.</p>
 *
 * <p>It keeps the same hard safety philosophy as the selective pregenerator: no direct getChunk loops, only one
 * Chunky task, automatic TPS pauses and a 30 GiB free-disk reserve.</p>
 */
public final class FullWorldPregenService {
    public static final int DEFAULT_MARGIN_BLOCKS = 1024;
    public static final int REGION_ALIGNMENT_BLOCKS = 512;

    private static final double DEFAULT_DISK_CAP_GIB = 146.0;
    private static final double MIN_FREE_GIB = 30.0;
    private static final double DISK_WARN_GIB = 45.0;
    private static final double PAUSE_MSPT = 45.0;
    private static final double RESUME_MSPT = 32.0;
    private static final int OVERLOAD_TICKS = 20;
    private static final int RECOVERY_TICKS = 100;
    private static final int DISK_RESCAN_TICKS = 2400;
    private static final long GIB = 1024L * 1024L * 1024L;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final ExecutorService DISK_EXECUTOR = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "Chaina-FullPregen-Disk-Scanner");
        thread.setDaemon(true);
        return thread;
    });

    private static ConfigManager configManager;
    private static boolean initialized;
    private static long loadedSeed = Long.MIN_VALUE;
    private static State state = new State();
    private static UUID requester;

    private static long tickStartNs;
    private static double smoothedMspt;
    private static int overloadTicks;
    private static int recoveryTicks;
    private static int diskTickCounter;
    private static volatile long measuredDirectoryBytes = -1L;
    private static volatile boolean diskScanRunning;
    private static volatile String diskScanError = "";
    private static boolean diskWarningSent;

    private FullWorldPregenService() {}

    /** Square plan centred on the Overworld spawn. */
    public record BorderPlan(
            int centerX,
            int centerZ,
            int marginBlocks,
            int rawFarthestDistanceBlocks,
            int radiusBlocks,
            int diameterBlocks,
            long chunksPerAxis,
            long totalChunks,
            int overworldLocations,
            String farthestRegion,
            String farthestLabel,
            int farthestX,
            int farthestY,
            int farthestZ
    ) {
        public int radiusChunks() {
            return (int) Math.ceil(radiusBlocks / 16.0);
        }

        /** DH pregen uses a radial distance; diagonal covers all corners of our square border. */
        public int distantHorizonsRadiusChunks() {
            return (int) Math.ceil((radiusBlocks * Math.sqrt(2.0)) / 16.0);
        }
    }

    private record DiskSnapshot(boolean ready, double usedGiB, double freeGiB) {}

    private static final class State {
        long seed;
        boolean borderApplied;
        int marginBlocks = DEFAULT_MARGIN_BLOCKS;
        int centerX;
        int centerZ;
        int radiusBlocks;
        int diameterBlocks;
        boolean running;
        boolean pausedForDisk;
        boolean pausedForTps;
        boolean pausedManually;
        boolean taskWasStarted;
        boolean taskNeedsResume;
        boolean finished;
        double diskCapacityGiB = DEFAULT_DISK_CAP_GIB;
        String lastError = "";
    }

    public static synchronized void initialize(ConfigManager config) {
        configManager = config;
        if (initialized) return;
        initialized = true;
        ServerTickEvents.START_SERVER_TICK.register(server -> tickStartNs = System.nanoTime());
        ServerTickEvents.END_SERVER_TICK.register(FullWorldPregenService::tick);
    }

    public static synchronized BorderPlan calculatePlan(MinecraftServer server, int requestedMargin) {
        if (server == null || server.getOverworld() == null) return null;
        ImportantLocationService.MapSnapshot snapshot = ImportantLocationService.snapshot(server);
        ServerWorld overworld = server.getOverworld();
        BlockPos spawn = overworld.getSpawnPos();
        int margin = Math.max(0, Math.min(16384, requestedMargin));

        ImportantLocationService.LocationView farthest = null;
        int farthestDistance = 0;
        int count = 0;
        String overworldId = World.OVERWORLD.getValue().toString();
        for (ImportantLocationService.RegionView region : snapshot.regions()) {
            for (ImportantLocationService.LocationView location : region.locations()) {
                if (!location.located() || !overworldId.equals(location.dimensionId())) continue;
                count++;
                int dx = Math.abs(location.x() - spawn.getX());
                int dz = Math.abs(location.z() - spawn.getZ());
                int edgeDistance = Math.max(dx, dz); // square world border metric
                if (farthest == null || edgeDistance > farthestDistance) {
                    farthest = location;
                    farthestDistance = edgeDistance;
                }
            }
        }
        if (farthest == null) return null;

        long padded = (long) farthestDistance + margin;
        int radius = alignUp((int) Math.min(Integer.MAX_VALUE - REGION_ALIGNMENT_BLOCKS, padded), REGION_ALIGNMENT_BLOCKS);
        radius = Math.max(REGION_ALIGNMENT_BLOCKS, radius);
        int diameter = Math.multiplyExact(radius, 2);
        long chunksPerAxis = (long) diameter / 16L;
        long totalChunks = chunksPerAxis * chunksPerAxis;

        String regionName = farthest.region();
        for (ImportantLocationService.RegionView region : snapshot.regions()) {
            if (region.id().equals(farthest.region())) {
                regionName = region.name();
                break;
            }
        }
        return new BorderPlan(spawn.getX(), spawn.getZ(), margin, farthestDistance, radius, diameter,
                chunksPerAxis, totalChunks, count, regionName, farthest.label(), farthest.x(), farthest.y(), farthest.z());
    }

    public static synchronized int calculate(ServerCommandSource source, int margin) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        ImportantLocationService.MapSnapshot snapshot = ImportantLocationService.snapshot(server);
        if (RegionalLayoutService.blocksFinalBorder(server)) {
            source.sendFeedback(() -> Text.literal("§eHay un Regional Layout preparado o en progreso. Termina §f/chainacobblemon regionlayout generar confirm §eantes de fijar el borde final."), false);
        }
        BorderPlan plan = calculatePlan(server, margin);
        if (plan == null) {
            source.sendFeedback(() -> Text.literal("§cNo hay ubicaciones del Overworld localizadas para calcular el borde."), false);
            return 0;
        }

        source.sendFeedback(() -> Text.literal("§d§lCHAINA · BORDE FINAL DEL OVERWORLD"), false);
        source.sendFeedback(() -> Text.literal("§7Plan regional: " + (snapshot.complete() ? "§a" : "§e")
                + snapshot.located() + "/" + snapshot.total() + " §7· ubicaciones Overworld: §f" + plan.overworldLocations()), false);
        source.sendFeedback(() -> Text.literal("§7Centro: §fX " + plan.centerX() + " Z " + plan.centerZ()
                + " §7(spawn del Overworld)"), false);
        source.sendFeedback(() -> Text.literal("§7Más lejana para un borde cuadrado: §f" + plan.farthestRegion() + " · "
                + plan.farthestLabel() + " §7en §fX " + plan.farthestX() + " Y " + plan.farthestY() + " Z " + plan.farthestZ()), false);
        source.sendFeedback(() -> Text.literal("§7Distancia al borde desde spawn: §f" + plan.rawFarthestDistanceBlocks()
                + " bloques §7· margen pedido: §f" + plan.marginBlocks() + " §7· alineado a regiones de 512 bloques."), false);
        source.sendFeedback(() -> Text.literal("§aBorde recomendado: radio §f" + plan.radiusBlocks()
                + "§a · diámetro §f" + plan.diameterBlocks() + "§a bloques."), false);
        source.sendFeedback(() -> Text.literal("§7Pregeneración completa: §f" + plan.chunksPerAxis() + " × " + plan.chunksPerAxis()
                + " chunks §7= §f" + formatLong(plan.totalChunks()) + " chunks§7."), false);
        reportDiskEstimate(source, plan);
        if (!snapshot.complete()) {
            source.sendFeedback(() -> Text.literal("§cEste cálculo es PROVISIONAL. Completa 69/69 antes de aplicar el borde final."), false);
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§bSiguiente: §f/chainacobblemon worldborder aplicar confirm"), false);
        return 1;
    }

    public static synchronized int applyBorder(ServerCommandSource source, int margin, boolean confirm) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        ImportantLocationService.MapSnapshot snapshot = ImportantLocationService.snapshot(server);
        if (RegionalLayoutService.blocksFinalBorder(server)) {
            source.sendFeedback(() -> Text.literal("§cNo se puede fijar el borde mientras el Regional Layout esté pendiente. Termina la reubicación primero."), false);
            return 0;
        }
        BorderPlan plan = calculatePlan(server, margin);
        if (plan == null) {
            source.sendFeedback(() -> Text.literal("§cNo se pudo calcular el borde final."), false);
            return 0;
        }
        if (!snapshot.complete()) {
            source.sendFeedback(() -> Text.literal("§cNo se puede fijar el borde final hasta tener 69/69 ubicaciones."), false);
            return 0;
        }
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eEsto cambiará el world border del Overworld a centro §fX " + plan.centerX()
                    + " Z " + plan.centerZ() + "§e y diámetro §f" + plan.diameterBlocks() + "§e."), false);
            source.sendFeedback(() -> Text.literal("§7No borra chunks. Confirma con §f/chainacobblemon worldborder aplicar confirm"), false);
            return 0;
        }

        ServerWorld overworld = server.getOverworld();
        overworld.getWorldBorder().setCenter(plan.centerX(), plan.centerZ());
        overworld.getWorldBorder().setSize(plan.diameterBlocks());

        state.borderApplied = true;
        state.marginBlocks = plan.marginBlocks();
        state.centerX = plan.centerX();
        state.centerZ = plan.centerZ();
        state.radiusBlocks = plan.radiusBlocks();
        state.diameterBlocks = plan.diameterBlocks();
        state.finished = false;
        state.lastError = "";
        save(server);

        source.sendFeedback(() -> Text.literal("§a§lWORLD BORDER FINAL APLICADO §7· centro §fX " + plan.centerX()
                + " Z " + plan.centerZ() + " §7· diámetro §f" + plan.diameterBlocks() + " bloques"), true);
        source.sendFeedback(() -> Text.literal("§7Ahora puedes iniciar la pregeneración COMPLETA con §f/chainacobblemon worldborder pregen iniciar"), false);
        return 1;
    }

    public static synchronized int status(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        BorderPlan plan = calculatePlan(server, state.marginBlocks > 0 ? state.marginBlocks : DEFAULT_MARGIN_BLOCKS);
        ServerWorld overworld = server.getOverworld();
        double currentCenterX = overworld.getWorldBorder().getCenterX();
        double currentCenterZ = overworld.getWorldBorder().getCenterZ();
        double currentSize = overworld.getWorldBorder().getSize();
        boolean matches = plan != null && borderMatches(overworld, plan);

        source.sendFeedback(() -> Text.literal("§d§lCHAINA · WORLD BORDER / PREGEN FINAL"), false);
        source.sendFeedback(() -> Text.literal("§7Borde actual: centro §fX " + format(currentCenterX) + " Z " + format(currentCenterZ)
                + " §7· diámetro §f" + format(currentSize)), false);
        source.sendFeedback(() -> Text.literal("§7Coincide con plan CHAINA: " + (matches ? "§aSÍ" : "§cNO")), false);
        if (plan != null) {
            source.sendFeedback(() -> Text.literal("§7Plan: radio §f" + plan.radiusBlocks() + " §7· diámetro §f" + plan.diameterBlocks()
                    + " §7· chunks objetivo §f" + formatLong(plan.totalChunks())), false);
        }
        String pregen = state.finished ? "§aCOMPLETADA"
                : state.running ? state.pausedForTps ? "§6ESPERANDO TPS" : "§aEN CURSO"
                : state.pausedForDisk ? "§cPAUSADA POR DISCO"
                : state.pausedManually ? "§ePAUSADA" : "§7SIN INICIAR";
        source.sendFeedback(() -> Text.literal("§7Pregeneración completa: " + pregen + " §7· MSPT suavizado §f" + format(smoothedMspt)), false);
        DiskSnapshot disk = diskSnapshot();
        if (disk.ready()) {
            source.sendFeedback(() -> Text.literal("§7Disco: usado §f" + format(disk.usedGiB()) + " GiB§7 / límite lógico §f"
                    + format(state.diskCapacityGiB) + " GiB§7 · libre seguro §f" + format(disk.freeGiB()) + " GiB"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§7Disco: §emedición en curso..."), false);
        }
        ChunkyBridge.Probe probe = ChunkyBridge.probe();
        source.sendFeedback(() -> Text.literal("§7Chunky: " + (probe.available() ? "§aOK API v" + probe.apiVersion() : "§cNO DISPONIBLE · " + probe.message())), false);
        if (!state.lastError.isBlank()) source.sendFeedback(() -> Text.literal("§cÚltimo error: §f" + state.lastError), false);
        return matches ? 1 : 0;
    }

    public static synchronized int start(ServerCommandSource source, boolean confirm) {
        MinecraftServer server = source.getServer();
        ensureLoaded(server);
        ImportantLocationService.MapSnapshot snapshot = ImportantLocationService.snapshot(server);
        if (RegionalLayoutService.blocksFinalBorder(server)) {
            source.sendFeedback(() -> Text.literal("§cLa pregeneración final está bloqueada hasta terminar Regional Layout."), false);
            return 0;
        }
        if (!snapshot.complete()) {
            source.sendFeedback(() -> Text.literal("§cNo se puede pregenerar el mapa final hasta completar 69/69 ubicaciones."), false);
            return 0;
        }
        BorderPlan plan = calculatePlan(server, state.marginBlocks > 0 ? state.marginBlocks : DEFAULT_MARGIN_BLOCKS);
        if (plan == null) return 0;
        if (!state.borderApplied || !borderMatches(server.getOverworld(), plan)) {
            source.sendFeedback(() -> Text.literal("§cEl world border todavía no coincide con el plan CHAINA. Ejecuta primero §f/chainacobblemon worldborder aplicar confirm"), false);
            return 0;
        }
        ChunkyBridge.Probe probe = ChunkyBridge.probe();
        if (!probe.available()) {
            source.sendFeedback(() -> Text.literal("§cChunky no está disponible: §7" + probe.message()), false);
            return 0;
        }
        if (state.finished) {
            source.sendFeedback(() -> Text.literal("§aLa pregeneración completa del Overworld ya figura como terminada."), false);
            return 1;
        }
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eSe pregenerará TODO el cuadrado del Overworld dentro del borde: §f"
                    + plan.diameterBlocks() + " × " + plan.diameterBlocks() + " bloques§e."), false);
            source.sendFeedback(() -> Text.literal("§7Objetivo aproximado: §f" + formatLong(plan.totalChunks())
                    + " chunks§7. Chaina pausará Chunky por TPS alto o al quedar 30 GiB libres."), false);
            reportDiskEstimate(source, plan);
            source.sendFeedback(() -> Text.literal("§cEs una operación grande. §7Confirma con §f/chainacobblemon worldborder pregen iniciar confirm"), false);
            return 0;
        }

        if (ChunkyBridge.isRunning(World.OVERWORLD.getValue().toString()) && !state.taskWasStarted) {
            source.sendFeedback(() -> Text.literal("§cYa existe otra tarea de Chunky en el Overworld. Páusala o termínala antes."), false);
            return 0;
        }
        requester = source.getEntity() instanceof ServerPlayerEntity player ? player.getUuid() : null;
        state.running = true;
        state.pausedForDisk = false;
        state.pausedForTps = false;
        state.pausedManually = false;
        state.lastError = "";
        state.centerX = plan.centerX();
        state.centerZ = plan.centerZ();
        state.radiusBlocks = plan.radiusBlocks();
        state.diameterBlocks = plan.diameterBlocks();
        diskWarningSent = false;
        requestDiskScan(true);
        save(server);

        source.sendFeedback(() -> Text.literal("§d§lPREGENERACIÓN COMPLETA CHAINA ARMADA"), false);
        source.sendFeedback(() -> Text.literal("§7Chunky generará el cuadrado de §f" + plan.diameterBlocks() + " × "
                + plan.diameterBlocks() + " bloques§7. El watchdog decidirá el momento seguro para iniciar/reanudar."), false);
        return 1;
    }

    public static synchronized int resume(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        if (state.finished) {
            source.sendFeedback(() -> Text.literal("§aLa pregeneración ya está completada."), false);
            return 1;
        }
        if (!state.borderApplied) {
            source.sendFeedback(() -> Text.literal("§cNo hay un world border CHAINA aplicado."), false);
            return 0;
        }
        state.running = true;
        state.pausedManually = false;
        state.pausedForDisk = false;
        state.lastError = "";
        requester = source.getEntity() instanceof ServerPlayerEntity player ? player.getUuid() : requester;
        requestDiskScan(true);
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aPregeneración final marcada para reanudar de forma segura."), false);
        return 1;
    }

    public static synchronized int pause(ServerCommandSource source) {
        ensureLoaded(source.getServer());
        if (!state.running && !state.pausedForTps) {
            source.sendFeedback(() -> Text.literal("§eLa pregeneración final ya está pausada."), false);
            return 0;
        }
        if (state.taskWasStarted && ChunkyBridge.probe().available() && ChunkyBridge.isRunning(World.OVERWORLD.getValue().toString())) {
            ChunkyBridge.pauseTask(World.OVERWORLD.getValue().toString());
            state.taskNeedsResume = true;
        }
        state.running = false;
        state.pausedForTps = false;
        state.pausedManually = true;
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§ePregeneración final pausada. §7Usa §f/chainacobblemon worldborder pregen reanudar"), false);
        return 1;
    }

    public static synchronized int cancel(ServerCommandSource source, boolean confirm) {
        ensureLoaded(source.getServer());
        if (!confirm) {
            source.sendFeedback(() -> Text.literal("§eCancelar detiene la tarea de Chunky pero NO borra chunks ya generados ni cambia el world border. "
                    + "Confirma con §f/chainacobblemon worldborder pregen cancelar confirm"), false);
            return 0;
        }
        if (ChunkyBridge.probe().available() && ChunkyBridge.isRunning(World.OVERWORLD.getValue().toString())) {
            ChunkyBridge.cancelTask(World.OVERWORLD.getValue().toString());
        }
        state.running = false;
        state.pausedForDisk = false;
        state.pausedForTps = false;
        state.pausedManually = true;
        state.taskWasStarted = false;
        state.taskNeedsResume = false;
        state.finished = false;
        state.lastError = "Cancelada manualmente";
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§eTarea Chunky cancelada. §7Los chunks ya generados permanecen."), true);
        return 1;
    }

    public static synchronized int setDiskCapacity(ServerCommandSource source, int gib) {
        ensureLoaded(source.getServer());
        state.diskCapacityGiB = gib;
        requestDiskScan(true);
        save(source.getServer());
        source.sendFeedback(() -> Text.literal("§aCapacidad lógica para pregeneración final: §f" + gib
                + " GiB§a. Reserva dura: §f30 GiB§a."), false);
        return 1;
    }

    public static synchronized boolean isFinishedAndBorderValid(MinecraftServer server) {
        ensureLoaded(server);
        if (!state.finished || !state.borderApplied) return false;
        BorderPlan plan = calculatePlan(server, state.marginBlocks);
        return plan != null && borderMatches(server.getOverworld(), plan);
    }

    public static synchronized BorderPlan appliedPlan(MinecraftServer server) {
        ensureLoaded(server);
        if (!state.borderApplied) return null;
        BorderPlan plan = calculatePlan(server, state.marginBlocks);
        return plan != null && borderMatches(server.getOverworld(), plan) ? plan : null;
    }

    private static void tick(MinecraftServer server) {
        synchronized (FullWorldPregenService.class) {
            recordTickDuration();
            ensureLoaded(server);
            if (!state.running || state.finished) return;

            ChunkyBridge.Probe probe = ChunkyBridge.probe();
            if (!probe.available()) {
                pauseWithError(server, "Chunky dejó de estar disponible: " + probe.message());
                return;
            }
            BorderPlan plan = calculatePlan(server, state.marginBlocks);
            if (plan == null || !borderMatches(server.getOverworld(), plan)) {
                pauseWithError(server, "El world border ya no coincide con el plan final de CHAINA.");
                return;
            }

            if (++diskTickCounter >= DISK_RESCAN_TICKS) {
                diskTickCounter = 0;
                requestDiskScan(false);
            }
            DiskSnapshot disk = diskSnapshot();
            if (!disk.ready()) {
                requestDiskScan(false);
                return;
            }
            if (disk.freeGiB() <= MIN_FREE_GIB) {
                if (state.taskWasStarted && ChunkyBridge.isRunning(World.OVERWORLD.getValue().toString())) {
                    ChunkyBridge.pauseTask(World.OVERWORLD.getValue().toString());
                    state.taskNeedsResume = true;
                }
                state.running = false;
                state.pausedForDisk = true;
                state.pausedForTps = false;
                state.lastError = "Reserva de disco alcanzada: " + format(disk.freeGiB()) + " GiB libres.";
                save(server);
                notifyRequester(server, "§c§lPREGEN FINAL PAUSADA POR DISCO §7· quedan §f" + format(disk.freeGiB())
                        + " GiB libres§7. Reserva mínima: 30 GiB.");
                return;
            }
            if (disk.freeGiB() <= DISK_WARN_GIB && !diskWarningSent) {
                diskWarningSent = true;
                notifyRequester(server, "§6Aviso de disco: quedan §f" + format(disk.freeGiB())
                        + " GiB libres§6; la tarea se detendrá automáticamente a 30 GiB.");
            }

            String overworldId = World.OVERWORLD.getValue().toString();
            if (state.taskNeedsResume) {
                if (ChunkyBridge.isRunning(overworldId)) return;
                if (state.pausedForTps) {
                    if (recoveryTicks < RECOVERY_TICKS) return;
                    state.pausedForTps = false;
                }
                boolean resumed = ChunkyBridge.continueTask(overworldId);
                if (!resumed) resumed = ChunkyBridge.startTask(overworldId, plan.centerX(), plan.centerZ(), plan.radiusBlocks());
                if (!resumed) {
                    pauseWithError(server, "Chunky no pudo reanudar/iniciar el Overworld completo.");
                    return;
                }
                state.taskNeedsResume = false;
                state.taskWasStarted = true;
                save(server);
                notifyRequester(server, "§aChunky reanudado para el Overworld completo.");
                return;
            }

            if (state.taskWasStarted) {
                if (ChunkyBridge.isRunning(overworldId)) {
                    if (overloadTicks >= OVERLOAD_TICKS) {
                        if (ChunkyBridge.pauseTask(overworldId)) {
                            state.taskNeedsResume = true;
                            state.pausedForTps = true;
                            overloadTicks = 0;
                            recoveryTicks = 0;
                            save(server);
                            notifyRequester(server, "§6Chunky pausado automáticamente por carga · MSPT ~§f"
                                    + format(smoothedMspt) + "§6. Se reanudará al estabilizarse.");
                        }
                    }
                    return;
                }
                // The only task owned by this state stopped without us asking it to pause: Chunky completed naturally.
                finish(server, plan);
                return;
            }

            if (smoothedMspt >= PAUSE_MSPT || overloadTicks > 0) return;
            if (ChunkyBridge.isRunning(overworldId)) {
                pauseWithError(server, "Ya existe otra tarea Chunky activa en el Overworld.");
                return;
            }
            if (!ChunkyBridge.startTask(overworldId, plan.centerX(), plan.centerZ(), plan.radiusBlocks())) {
                pauseWithError(server, "Chunky rechazó la pregeneración completa. Revisa /chunky progress.");
                return;
            }
            state.taskWasStarted = true;
            save(server);
            notifyRequester(server, "§dChunky inició el Overworld completo · radio §f" + plan.radiusBlocks()
                    + "§d bloques · §f" + formatLong(plan.totalChunks()) + "§d chunks objetivo.");
        }
    }

    private static void finish(MinecraftServer server, BorderPlan plan) {
        state.running = false;
        state.pausedForDisk = false;
        state.pausedForTps = false;
        state.pausedManually = false;
        state.taskWasStarted = false;
        state.taskNeedsResume = false;
        state.finished = true;
        state.lastError = "";
        save(server);
        notifyRequester(server, "§a§lOVERWORLD COMPLETO PREGENERADO §7· borde §f" + plan.diameterBlocks()
                + " × " + plan.diameterBlocks() + "§7. Siguiente: §f/chainacobblemon worldborder distant preparar§7 y después §f... distant iniciar§7.");
        Chainacobblemon.LOGGER.info("Full Overworld Chunky pregeneration finished: center {},{} radius {} blocks (~{} chunks)",
                plan.centerX(), plan.centerZ(), plan.radiusBlocks(), plan.totalChunks());
    }

    private static void pauseWithError(MinecraftServer server, String error) {
        String overworldId = World.OVERWORLD.getValue().toString();
        if (state.taskWasStarted && ChunkyBridge.probe().available() && ChunkyBridge.isRunning(overworldId)) {
            ChunkyBridge.pauseTask(overworldId);
            state.taskNeedsResume = true;
        }
        state.running = false;
        state.lastError = error;
        save(server);
        notifyRequester(server, "§cPregeneración final pausada: §f" + error);
    }

    private static boolean borderMatches(ServerWorld world, BorderPlan plan) {
        if (world == null || plan == null) return false;
        return Math.abs(world.getWorldBorder().getCenterX() - plan.centerX()) < 0.51
                && Math.abs(world.getWorldBorder().getCenterZ() - plan.centerZ()) < 0.51
                && Math.abs(world.getWorldBorder().getSize() - plan.diameterBlocks()) < 1.0;
    }

    private static int alignUp(int value, int alignment) {
        if (value <= 0) return alignment;
        long result = ((long) value + alignment - 1L) / alignment * alignment;
        return (int) Math.min(Integer.MAX_VALUE, result);
    }

    private static void reportDiskEstimate(ServerCommandSource source, BorderPlan plan) {
        // Modded chunk NBT varies wildly. This is deliberately a broad planning range, not a promise.
        double lowGiB = plan.totalChunks() * 20.0 * 1024.0 / GIB;
        double highGiB = plan.totalChunks() * 100.0 * 1024.0 / GIB;
        source.sendFeedback(() -> Text.literal("§8Estimación orientativa de datos de chunks (20–100 KiB/chunk): §7~"
                + format(lowGiB) + "–" + format(highGiB) + " GiB. §8El tamaño real depende mucho del modpack."), false);
    }

    private static void recordTickDuration() {
        if (tickStartNs <= 0L) return;
        double ms = (System.nanoTime() - tickStartNs) / 1_000_000.0;
        smoothedMspt = smoothedMspt <= 0.0 ? ms : smoothedMspt * 0.92 + ms * 0.08;
        if (smoothedMspt >= PAUSE_MSPT) {
            overloadTicks++;
            recoveryTicks = 0;
        } else if (smoothedMspt <= RESUME_MSPT) {
            recoveryTicks++;
            overloadTicks = 0;
        } else {
            overloadTicks = Math.max(0, overloadTicks - 1);
            recoveryTicks = Math.max(0, recoveryTicks - 1);
        }
    }

    private static void requestDiskScan(boolean force) {
        if (diskScanRunning) return;
        diskScanRunning = true;
        Path gameDir = FabricLoader.getInstance().getGameDir();
        CompletableFuture.supplyAsync(() -> directorySize(gameDir), DISK_EXECUTOR).whenComplete((size, error) -> {
            if (error != null) {
                diskScanError = error.getClass().getSimpleName() + ": " + error.getMessage();
            } else {
                measuredDirectoryBytes = Math.max(0L, size);
                diskScanError = "";
            }
            diskScanRunning = false;
        });
    }

    private static long directorySize(Path root) {
        try (var stream = Files.walk(root)) {
            return stream.filter(Files::isRegularFile).mapToLong(path -> {
                try {
                    return Files.size(path);
                } catch (IOException ignored) {
                    return 0L;
                }
            }).sum();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private static DiskSnapshot diskSnapshot() {
        if (measuredDirectoryBytes < 0) return new DiskSnapshot(false, 0.0, 0.0);
        double used = measuredDirectoryBytes / (double) GIB;
        double logicalFree = Math.max(0.0, state.diskCapacityGiB - used);
        double physicalFree = Double.MAX_VALUE;
        try {
            FileStore store = Files.getFileStore(FabricLoader.getInstance().getGameDir());
            physicalFree = store.getUsableSpace() / (double) GIB;
        } catch (IOException exception) {
            if (diskScanError.isBlank()) diskScanError = exception.getClass().getSimpleName();
        }
        return new DiskSnapshot(true, used, Math.min(logicalFree, physicalFree));
    }

    private static void notifyRequester(MinecraftServer server, String message) {
        if (requester != null) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(requester);
            if (player != null) {
                player.sendMessage(Text.literal(message), false);
                return;
            }
        }
        Chainacobblemon.LOGGER.info(message.replaceAll("§.", ""));
    }

    private static void ensureLoaded(MinecraftServer server) {
        if (configManager == null || server == null || server.getOverworld() == null) return;
        long seed = server.getOverworld().getSeed();
        if (loadedSeed == seed) return;
        loadedSeed = seed;
        state = new State();
        state.seed = seed;
        Path file = stateFile(seed);
        if (Files.exists(file)) {
            try {
                State loaded = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), State.class);
                if (loaded != null && loaded.seed == seed) {
                    if (loaded.diskCapacityGiB <= 0) loaded.diskCapacityGiB = DEFAULT_DISK_CAP_GIB;
                    if (loaded.marginBlocks < 0) loaded.marginBlocks = DEFAULT_MARGIN_BLOCKS;
                    if (loaded.running) {
                        loaded.running = false;
                        loaded.pausedManually = true;
                        if (loaded.taskWasStarted && !loaded.finished) loaded.taskNeedsResume = true;
                    }
                    state = loaded;
                }
            } catch (Exception exception) {
                Chainacobblemon.LOGGER.warn("Could not read full Overworld pregeneration state {}", file, exception);
            }
        }
        requester = null;
        smoothedMspt = 0.0;
        overloadTicks = 0;
        recoveryTicks = 0;
        diskTickCounter = 0;
        measuredDirectoryBytes = -1L;
        requestDiskScan(true);
    }

    private static void save(MinecraftServer server) {
        if (configManager == null || server == null) return;
        Path file = stateFile(state.seed);
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(temp, GSON.toJson(state), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            Chainacobblemon.LOGGER.warn("Could not save full Overworld pregeneration state {}", file, exception);
        }
    }

    private static Path stateFile(long seed) {
        return configManager.configDirectory().resolve("final-overworld-pregen-v1-" + Long.toUnsignedString(seed) + ".json");
    }

    private static String format(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    private static String formatLong(long value) {
        return String.format(Locale.ROOT, "%,d", value);
    }

    /** Reflection-only bridge: Chunky remains optional and server-side. */
    private static final class ChunkyBridge {
        private static Object api;
        private static Method version;
        private static Method isRunning;
        private static Method startTask;
        private static Method pauseTask;
        private static Method continueTask;
        private static Method cancelTask;
        private static String error = "";
        private static boolean attempted;

        record Probe(boolean available, int apiVersion, String message) {}

        static synchronized Probe probe() {
            if (!FabricLoader.getInstance().isModLoaded("chunky")) {
                return new Probe(false, -1, "mod 'chunky' no instalado");
            }
            if (!attempted) bind();
            if (api == null) return new Probe(false, -1, error.isBlank() ? "API no encontrada" : error);
            try {
                int v = ((Number) version.invoke(api)).intValue();
                if (v != 0) return new Probe(false, v, "API Chunky no soportada (esperada 0, encontrada " + v + ")");
                return new Probe(true, v, "OK");
            } catch (ReflectiveOperationException exception) {
                return new Probe(false, -1, rootMessage(exception));
            }
        }

        private static void bind() {
            attempted = true;
            try {
                Class<?> provider = Class.forName("org.popcraft.chunky.ChunkyProvider");
                Object chunky = provider.getMethod("get").invoke(null);
                api = chunky.getClass().getMethod("getApi").invoke(chunky);
                Class<?> apiClass = Class.forName("org.popcraft.chunky.api.ChunkyAPI");
                version = apiClass.getMethod("version");
                isRunning = apiClass.getMethod("isRunning", String.class);
                startTask = apiClass.getMethod("startTask", String.class, String.class,
                        double.class, double.class, double.class, double.class, String.class);
                pauseTask = apiClass.getMethod("pauseTask", String.class);
                continueTask = apiClass.getMethod("continueTask", String.class);
                cancelTask = apiClass.getMethod("cancelTask", String.class);
                error = "";
            } catch (ReflectiveOperationException | RuntimeException exception) {
                api = null;
                error = rootMessage(exception);
                Chainacobblemon.LOGGER.warn("Chunky full-pregen soft integration unavailable: {}", error);
            }
        }

        static boolean isRunning(String world) {
            return invokeBool(isRunning, world);
        }

        static boolean startTask(String world, int centerX, int centerZ, int radiusBlocks) {
            if (!probe().available()) return false;
            try {
                return (Boolean) startTask.invoke(api, world, "square",
                        (double) centerX, (double) centerZ,
                        (double) radiusBlocks, (double) radiusBlocks, "concentric");
            } catch (ReflectiveOperationException exception) {
                error = rootMessage(exception);
                Chainacobblemon.LOGGER.error("Chunky full Overworld startTask failed", exception);
                return false;
            }
        }

        static boolean pauseTask(String world) { return invokeBool(pauseTask, world); }
        static boolean continueTask(String world) { return invokeBool(continueTask, world); }
        static boolean cancelTask(String world) { return invokeBool(cancelTask, world); }

        private static boolean invokeBool(Method method, String world) {
            if (!probe().available() || method == null) return false;
            try {
                return (Boolean) method.invoke(api, world);
            } catch (ReflectiveOperationException exception) {
                error = rootMessage(exception);
                Chainacobblemon.LOGGER.error("Chunky full-pregen API call failed in {}", world, exception);
                return false;
            }
        }

        private static String rootMessage(Throwable throwable) {
            Throwable current = throwable;
            if (current instanceof InvocationTargetException ite && ite.getCause() != null) current = ite.getCause();
            String msg = current.getMessage();
            return current.getClass().getSimpleName() + (msg == null || msg.isBlank() ? "" : ": " + msg);
        }
    }
}
