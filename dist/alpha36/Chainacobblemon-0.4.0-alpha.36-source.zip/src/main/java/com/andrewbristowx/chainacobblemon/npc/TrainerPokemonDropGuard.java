package com.andrewbristowx.chainacobblemon.npc;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.cobblemon.mod.common.api.drop.DropTable;
import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.cobblemon.mod.common.pokemon.Pokemon;

import java.lang.reflect.Method;
import java.util.function.Consumer;

/** Prevents NPC/trainer-owned battle Pokémon from producing the wild Pokémon loot table. */
public final class TrainerPokemonDropGuard {
    private TrainerPokemonDropGuard() { }

    public static void initialize() {
        @SuppressWarnings({"rawtypes", "unchecked"})
        Consumer rawConsumer = (Consumer<Object>) TrainerPokemonDropGuard::onPokemonSpawn;
        CobblemonEvents.POKEMON_ENTITY_SPAWN.subscribe(rawConsumer);
        Chainacobblemon.LOGGER.info("Trainer Pokemon no-drop guard initialized");
    }

    private static void onPokemonSpawn(Object event) {
        try {
            Object entity = invoke(event, "getEntity");
            Object rawPokemon = invoke(entity, "getPokemon");
            if (!(rawPokemon instanceof Pokemon pokemon)) return;
            Object npcOwned = invoke(pokemon, "isNPCOwned");
            if (!(npcOwned instanceof Boolean value) || !value) return;
            Method setter = entity.getClass().getMethod("setDrops", DropTable.class);
            setter.invoke(entity, new DropTable());
        } catch (Throwable error) {
            Chainacobblemon.LOGGER.debug("Could not suppress trainer Pokemon drops", error);
        }
    }

    private static Object invoke(Object target, String method) throws ReflectiveOperationException {
        if (target == null) return null;
        return target.getClass().getMethod(method).invoke(target);
    }
}
