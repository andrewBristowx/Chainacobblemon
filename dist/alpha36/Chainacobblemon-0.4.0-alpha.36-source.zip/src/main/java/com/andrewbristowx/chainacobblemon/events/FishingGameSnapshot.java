package com.andrewbristowx.chainacobblemon.events;

/** Lightweight server-authoritative state for the Chaina fishing minigame. */
public final class FishingGameSnapshot {
    public boolean visible = true;
    public String sessionId = "";
    public String speciesName = "Pokémon";
    public String speciesId = "unknown";
    public String rodName = "Poké Rod";
    public String rodId = "cobblemon:poke_rod";
    public String ballName = "Poké Ball";
    public String ballItemId = "cobblemon:poke_ball";
    public String effectLabel = "Equilibrada";
    public String difficultyLabel = "Normal";
    public double fishPosition = 0.5D;
    public double zonePosition = 0.28D;
    public double zoneHeight = 0.22D;
    public double progress = 0.25D;
    public long endsAtEpochMillis;
    public boolean completed;
    public boolean success;
    public long score;
    public String resultDetail = "";
}
