package com.andrewbristowx.chainacobblemon.armor;

import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import org.joml.Vector3f;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/** Full-set Chaina bonuses. No bonus is active unless all four armor pieces are equipped. */
public final class ChainaSetBonusService {
    public static final double MOVEMENT_SPEED_BONUS = 0.07D;
    public static final float SHINY_RELATIVE_MULTIPLIER = 1.12F;
    private static final Identifier SPEED_ID = Identifier.of(Chainacobblemon.MOD_ID, "full_chaina_set_speed");
    private static final DustParticleEffect CHAINA_PINK = new DustParticleEffect(new Vector3f(1.0F, 0.28F, 0.76F), 0.85F);
    private int ticks;

    public void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            ticks++;
            if (ticks % 10 != 0) return;
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                updateSpeed(player);
                if (ticks % 40 == 0 && hasFullSet(player)) emitAura(player);
            }
        });
        CobblemonEvents.SHINY_CHANCE_CALCULATION.subscribe(ChainaSetBonusService::installShinyModifier);
        Chainacobblemon.LOGGER.info("Chaina full-set bonuses initialized: +7% movement, +12% relative shiny odds (Cobblemon denominator / 1.12), pink aura");
    }

    /**
     * Cobblemon 1.7.3 publishes this Kotlin event with Mojmap ServerPlayer in its generic
     * Function3 signature while this Fabric/Yarn project compiles against ServerPlayerEntity.
     * Installing the modifier reflectively keeps the runtime event authoritative without
     * making javac resolve the incompatible named class.
     */
    private static void installShinyModifier(Object event) {
        try {
            Method addModificationFunction = null;
            for (Method method : event.getClass().getMethods()) {
                if (method.getName().equals("addModificationFunction") && method.getParameterCount() == 1) {
                    addModificationFunction = method;
                    break;
                }
            }
            if (addModificationFunction == null) {
                Chainacobblemon.LOGGER.error("Cobblemon shiny event does not expose addModificationFunction");
                return;
            }

            Class<?> function3 = Class.forName("kotlin.jvm.functions.Function3");
            Object modifier = Proxy.newProxyInstance(
                    function3.getClassLoader(),
                    new Class<?>[]{function3},
                    (proxy, method, args) -> {
                        if (method.getName().equals("invoke") && args != null && args.length == 3) {
                            float chance = ((Number) args[0]).floatValue();
                            Object rawPlayer = args[1];
                            if (rawPlayer instanceof ServerPlayerEntity player && hasFullSet(player)) {
                                return chance / SHINY_RELATIVE_MULTIPLIER;
                            }
                            return chance;
                        }
                        if (method.getName().equals("toString")) return "ChainacobblemonFullSetShinyModifier";
                        if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
                        if (method.getName().equals("equals")) return args != null && args.length == 1 && proxy == args[0];
                        return null;
                    });
            addModificationFunction.invoke(event, modifier);
        } catch (ReflectiveOperationException | LinkageError exception) {
            Chainacobblemon.LOGGER.error("Could not install Chaina full-set shiny modifier in Cobblemon", exception);
        }
    }

    public static boolean hasFullSet(ServerPlayerEntity player) {
        if (player == null) return false;
        return player.getEquippedStack(EquipmentSlot.HEAD).isOf(ModRegistries.CHAINA_HELMET)
                && player.getEquippedStack(EquipmentSlot.CHEST).isOf(ModRegistries.CHAINA_CHESTPLATE)
                && player.getEquippedStack(EquipmentSlot.LEGS).isOf(ModRegistries.CHAINA_LEGGINGS)
                && player.getEquippedStack(EquipmentSlot.FEET).isOf(ModRegistries.CHAINA_BOOTS);
    }

    private static void updateSpeed(ServerPlayerEntity player) {
        EntityAttributeInstance movement = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (movement == null) return;
        boolean full = hasFullSet(player);
        boolean active = movement.hasModifier(SPEED_ID);
        if (full && !active) {
            movement.addTemporaryModifier(new EntityAttributeModifier(
                    SPEED_ID, MOVEMENT_SPEED_BONUS, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        } else if (!full && active) {
            movement.removeModifier(SPEED_ID);
        }
    }

    private static void emitAura(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        double x = player.getX();
        double y = player.getY() + 1.0D;
        double z = player.getZ();
        world.spawnParticles(CHAINA_PINK, x, y, z, 4, 0.32D, 0.7D, 0.32D, 0.01D);
        world.spawnParticles(ParticleTypes.HEART, x, y + 0.45D, z, 1, 0.28D, 0.25D, 0.28D, 0.01D);
    }
}
