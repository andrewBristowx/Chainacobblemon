package com.andrewbristowx.chainacobblemon.twitch;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.config.ConfigManager;
import com.andrewbristowx.chainacobblemon.visual.VisualAssetService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Optional server-side integration with Styled Player List + Text Placeholder API. */
public final class StyledPlayerListIntegration {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final String STYLE_ID = "chaina";
    private static final int STYLE_VERSION = 2;
    private static final String STYLED_PLAYER_LIST_MOD = "styledplayerlist";

    // Current ChainaVT Twitch subscription emotes chosen for the TAB decoration.
    private static final String CUTE_EMOTE_URL = "https://static-cdn.jtvnw.net/emoticons/v2/emotesv2_e810ce339ab04b278cbe0546e3c6a83c/static/light/3.0";
    private static final String AWA_EMOTE_URL = "https://static-cdn.jtvnw.net/emoticons/v2/emotesv2_493077d79e884b40943bd86bf21a00bf/static/light/3.0";

    private static volatile boolean active;
    private static volatile TwitchService twitch;

    private StyledPlayerListIntegration() { }

    public static void initialize(TwitchService service) {
        twitch = service;
        register("twitch_status", StyledPlayerListIntegration::statusText);
        register("stream_bonuses", StyledPlayerListIntegration::bonusesText);
        register("stream_jackpot", StyledPlayerListIntegration::jackpotText);
        register("stream_bonus_1", () -> bonusText(0));
        register("stream_bonus_2", () -> bonusText(1));
        register("stream_bonus_3", () -> bonusText(2));
        register("stream_bonus_4", () -> bonusText(3));
        register("twitch_channel", () -> Text.literal("twitch.tv/" + broadcaster()).formatted(Formatting.LIGHT_PURPLE));
        Placeholders.register(Identifier.of(Chainacobblemon.MOD_ID, "styled_name"), (context, argument) ->
                PlaceholderResult.value(RankDisplayService.styledName(context.player(), twitch)));
    }

    public static void serverStarted(MinecraftServer server, ConfigManager configManager, VisualAssetService assets) {
        active = false;
        if (!configManager.get().twitch.styledPlayerListAutoConfigure) return;
        if (!FabricLoader.getInstance().isModLoaded(STYLED_PLAYER_LIST_MOD)) {
            Chainacobblemon.LOGGER.info("Styled Player List not detected; keeping Chaina Twitch HUD fallback");
            return;
        }

        try {
            Path splDir = FabricLoader.getInstance().getConfigDir().resolve("styledplayerlist");
            Path stylesDir = splDir.resolve("styles");
            Path styleFile = stylesDir.resolve(STYLE_ID + ".json");
            Path configFile = splDir.resolve("config.json");
            Path marker = configManager.configDirectory().resolve("styledplayerlist-auto-installed.json");

            Files.createDirectories(stylesDir);
            JsonObject markerData = readObject(marker);
            int installedStyleVersion = markerData.has("style_version") ? markerData.get("style_version").getAsInt() : 0;
            boolean managedStyle = markerData.has("installed") && markerData.get("installed").getAsBoolean();

            if (Files.notExists(styleFile) || (managedStyle && installedStyleVersion < STYLE_VERSION)) {
                if (Files.exists(styleFile)) {
                    Path backup = stylesDir.resolve("chaina.json.alpha10-backup");
                    if (Files.notExists(backup)) Files.copy(styleFile, backup, StandardCopyOption.COPY_ATTRIBUTES);
                }
                Files.writeString(styleFile, defaultStyleJson(), StandardCharsets.UTF_8);
                Chainacobblemon.LOGGER.info("Installed Chaina Styled Player List style v{} at {}", STYLE_VERSION, styleFile);
            }

            JsonObject config = Files.exists(configFile)
                    ? JsonParser.parseString(Files.readString(configFile, StandardCharsets.UTF_8)).getAsJsonObject()
                    : new JsonObject();

            if (Files.notExists(marker)) {
                if (Files.exists(configFile)) {
                    Path backup = splDir.resolve("config.json.chaina-backup");
                    if (Files.notExists(backup)) Files.copy(configFile, backup, StandardCopyOption.COPY_ATTRIBUTES);
                }
                if (!config.has("config_version")) config.addProperty("config_version", 2);
                config.addProperty("default_style", STYLE_ID);
                config.addProperty("client_show_in_singleplayer", true);
            } else if (installedStyleVersion < STYLE_VERSION && Files.exists(configFile)) {
                Path backup = splDir.resolve("config.json.chaina-alpha11-backup");
                if (Files.notExists(backup)) Files.copy(configFile, backup, StandardCopyOption.COPY_ATTRIBUTES);
            }

            configurePlayerNames(config);
            Files.writeString(configFile, GSON.toJson(config), StandardCharsets.UTF_8);

            markerData.addProperty("installed", true);
            markerData.addProperty("style", STYLE_ID);
            markerData.addProperty("style_version", STYLE_VERSION);
            markerData.addProperty("note", "Chainacobblemon updates only its managed Chaina style. Manual default_style changes are respected.");
            Files.createDirectories(marker.getParent());
            Files.writeString(marker, GSON.toJson(markerData), StandardCharsets.UTF_8);

            server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), "styledplayerlist reload");
            active = true;
            Chainacobblemon.LOGGER.info("Styled Player List Chaina integration active with rank placeholders");
            if (configManager.get().twitch.styledPlayerListTabEmotes) ensureTabEmotes(server, assets);
        } catch (Throwable exception) {
            active = false;
            Chainacobblemon.LOGGER.warn("Could not auto-configure Styled Player List; Twitch HUD fallback remains enabled", exception);
        }
    }

    public static boolean active() {
        return active;
    }

    private static void configurePlayerNames(JsonObject config) {
        JsonObject player;
        if (config.has("player") && config.get("player").isJsonObject()) player = config.getAsJsonObject("player");
        else {
            player = new JsonObject();
            config.add("player", player);
        }
        player.addProperty("modify_name", true);
        player.addProperty("format", "%chainacobblemon:styled_name%");
        player.addProperty("update_tick_time", 20);
    }

    private static JsonObject readObject(Path file) {
        try {
            if (Files.exists(file)) return JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception ignored) { }
        return new JsonObject();
    }

    private static void ensureTabEmotes(MinecraftServer server, VisualAssetService assets) {
        if (assets == null) return;
        CompletableFuture.runAsync(() -> {
            installEmote(server, assets, "chaina_tab_cute", CUTE_EMOTE_URL);
            installEmote(server, assets, "chaina_tab_awa", AWA_EMOTE_URL);
        });
    }

    private static void installEmote(MinecraftServer server, VisualAssetService assets, String id, String url) {
        try {
            Path folder = assets.mediaFolder(id);
            VisualAssetService.Asset asset = Files.isRegularFile(folder.resolve("media.png"))
                    ? assets.loadMedia(id)
                    : assets.downloadMedia(id, url);
            server.execute(() -> assets.broadcast(server, asset));
            Chainacobblemon.LOGGER.info("Chaina TAB emote ready: {}", id);
        } catch (Throwable exception) {
            Chainacobblemon.LOGGER.warn("Could not prepare optional Chaina TAB emote {}", id, exception);
        }
    }

    private static void register(String path, java.util.function.Supplier<Text> supplier) {
        Placeholders.register(Identifier.of(Chainacobblemon.MOD_ID, path), (context, argument) -> PlaceholderResult.value(supplier.get()));
    }

    private static Text statusText() {
        TwitchService service = twitch;
        if (service == null || !service.channelKnownForIntegration()) {
            return Text.literal("◌ CHAINA · COMPROBANDO TWITCH").formatted(Formatting.GRAY);
        }
        if (service.channelOnlineForIntegration()) {
            return Text.literal("● CHAINA EN VIVO").formatted(Formatting.RED, Formatting.BOLD);
        }
        return Text.literal("● CHAINA OFFLINE").formatted(Formatting.DARK_GRAY, Formatting.BOLD);
    }

    private static Text bonusesText() {
        TwitchService service = twitch;
        if (service == null || !service.channelOnlineForIntegration() || !service.streamBonuses().active()) {
            return Text.literal("✦ Bonus de stream inactivos ✦").formatted(Formatting.GRAY);
        }
        return Text.literal(service.streamBonuses().summary()).formatted(Formatting.LIGHT_PURPLE);
    }

    private static Text jackpotText() {
        TwitchService service = twitch;
        if (service == null || !service.channelOnlineForIntegration() || !service.streamBonuses().jackpot()) return Text.empty();
        return Text.literal("★ DIRECTO LEGENDARIO ★").formatted(Formatting.GOLD, Formatting.BOLD);
    }

    private static Text bonusText(int index) {
        TwitchService service = twitch;
        if (service == null || !service.channelOnlineForIntegration() || !service.streamBonuses().active()) return Text.empty();
        List<String> labels = service.streamBonuses().hudLabels();
        if (index < 0 || index >= labels.size()) return Text.empty();
        return Text.literal(labels.get(index)).formatted(Formatting.LIGHT_PURPLE);
    }

    private static String broadcaster() {
        TwitchService service = twitch;
        return service == null ? "chainavt" : service.broadcasterForIntegration();
    }

    private static String defaultStyleJson() {
        return """
                {
                  "style_name": "Chaina Server",
                  "update_tick_time": 20,
                  "list_header": [
                    "<color:#7e45bd>╭━━━━━━━━━━━━━━━━━━ ✦ ━━━━━━━━━━━━━━━━━━╮</color>",
                    "<bold><color:#ff70cc>✦  CHAINA SERVER  ✦</color></bold>",
                    "<color:#b778ff>• ───────────────────────────────── •</color>",
                    "%chainacobblemon:twitch_status%",
                    "%chainacobblemon:stream_jackpot%",
                    "%chainacobblemon:stream_bonuses%",
                    "<dark_gray>• ───────────────────────────────── •</dark_gray>",
                    "<gray>Entrenadores conectados</gray> <color:#ffffff><bold>%server:online%</bold></color><dark_gray>/</dark_gray><gray>%server:max_players%</gray>",
                    "<color:#7e45bd>╰━━━━━━━━━━━━━━━━━━ ✦ ━━━━━━━━━━━━━━━━━━╯</color>"
                  ],
                  "list_footer": [
                    "<color:#7e45bd>✦━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━✦</color>",
                    "<color:#dba8ff>Gachas</color> <dark_gray>•</dark_gray> <color:#ff8fd4>Eventos</color> <dark_gray>•</dark_gray> <color:#8feaff>Cobblemon</color>",
                    "<gray>Hosting gracias a</gray> <aqua><bold>Holy.gg</bold></aqua> <light_purple>♥</light_purple>"
                  ],
                  "hidden_in_commands": false
                }
                """;
    }
}
