package com.andrewbristowx.chainacobblemon.dungeon;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Integrated successor to EmiDungeonLoot. Dungeon completion creates a personal, tiered Poké Ball treasure. */
public final class ChainaDungeonLootService {
    private static final String TAG_PREFIX = "chaina_dungeon_reward_";
    private static final long EXPIRE_MS = 20L * 60L * 1000L;
    private static final Map<String, Claim> CLAIMS = new HashMap<>();
    private static int ticks;

    private static final List<RewardItem> POKEMON_ITEMS = List.of(
            new RewardItem("cobblemon:ultra_ball", 3, 8), new RewardItem("cobblemon:quick_ball", 2, 6),
            new RewardItem("cobblemon:rare_candy", 1, 4), new RewardItem("cobblemon:exp_candy_s", 3, 8),
            new RewardItem("cobblemon:hyper_potion", 2, 6), new RewardItem("cobblemon:max_revive", 1, 2));
    private static final List<RewardItem> RARE_ITEMS = List.of(
            new RewardItem("cobblemon:dawn_stone", 1, 2), new RewardItem("cobblemon:dusk_stone", 1, 2),
            new RewardItem("cobblemon:shiny_stone", 1, 2), new RewardItem("cobblemon:kings_rock", 1, 1),
            new RewardItem("cobblemon:metal_coat", 1, 1), new RewardItem("cobblemon:razor_claw", 1, 1),
            new RewardItem("cobblemon:leftovers", 1, 1));

    private ChainaDungeonLootService() { }

    public static void initialize() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            String token = token(entity);
            if (token == null) return ActionResult.PASS;
            if (!(player instanceof ServerPlayerEntity serverPlayer)) return ActionResult.FAIL;
            return claim(serverPlayer, token) ? ActionResult.SUCCESS : ActionResult.FAIL;
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks % 200 != 0) return;
            long now = System.currentTimeMillis();
            CLAIMS.entrySet().removeIf(entry -> {
                if (entry.getValue().expiresAt > now) return false;
                removeVisual(server, entry.getKey(), entry.getValue());
                return true;
            });
        });
        Chainacobblemon.LOGGER.info("Chaina Dungeon Loot initialized (integrated EmiDungeonLoot successor; WDA/YUNG/DnT/MVS/Repurposed)");
    }

    public static void onDungeonCleared(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null || npc.dungeonStructureKey().startsWith("treasure_event:")) return;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        String claimKey = "dungeon:" + npc.dungeonStructureKey();
        if (data.claimedDungeonLoot.contains(claimKey)) return;
        if (CLAIMS.values().stream().anyMatch(c -> c.owner.equals(player.getUuid()) && c.claimKey.equals(claimKey))) return;

        int stars = starsFromNpc(npc);
        String token = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        BlockPos pos = player.getBlockPos().add(2, 0, 0);
        ServerWorld world = player.getServerWorld();
        pos = findSafe(world, pos);
        Claim claim = new Claim(player.getUuid(), claimKey, stars, world.getRegistryKey().getValue().toString(), pos, System.currentTimeMillis() + EXPIRE_MS);
        CLAIMS.put(token, claim);
        summonVisual(player.getServer(), world, pos, stars, token);
        player.sendMessage(Text.literal("§d✦ Tesoro de Dungeon " + TreasureStructureCatalog.starLabel(stars)
                + " §fha aparecido junto a ti. §7Haz clic en la Poké Ball grande para reclamarlo."), false);
    }

    private static boolean claim(ServerPlayerEntity player, String token) {
        Claim claim = CLAIMS.get(token);
        if (claim == null) return false;
        if (!claim.owner.equals(player.getUuid())) {
            player.sendMessage(Text.literal("§cEste Tesoro de Dungeon pertenece a otro jugador."), false);
            return false;
        }
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        if (!data.claimedDungeonLoot.add(claim.claimKey)) {
            CLAIMS.remove(token); removeVisual(player.getServer(), token, claim); return false;
        }
        grant(player, claim.stars);
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        animate(player.getServerWorld(), claim.pos, claim.stars);
        removeVisual(player.getServer(), token, claim);
        CLAIMS.remove(token);
        return true;
    }

    private static void grant(ServerPlayerEntity player, int stars) {
        long coins = switch (stars) { case 1 -> 300; case 2 -> 500; case 3 -> 750; case 4 -> 1_200; default -> 2_000; };
        Chainacobblemon.progressionService().adminGive(player, coins, "chaina_dungeon_loot");
        int rolls = stars >= 5 ? 3 : stars >= 4 ? 2 : 1;
        int chance = stars == 1 ? 30 : stars == 2 ? 60 : 100;
        int delivered = 0;
        for (int i = 0; i < rolls; i++) {
            if (ThreadLocalRandom.current().nextInt(100) >= chance) continue;
            RewardItem reward = randomReward(stars);
            giveItem(player, reward.id, ThreadLocalRandom.current().nextInt(reward.min, reward.max + 1));
            delivered++;
        }
        if (stars >= 4 && ThreadLocalRandom.current().nextInt(100) < 35) give(player, ModRegistries.CHAINA_SPECIAL_BANNER_TICKET, 1);
        if (stars >= 5) give(player, ModRegistries.TREASURE_GACHA_TICKET, 1);
        player.sendMessage(Text.literal("§6✦ Chaina Dungeon Loot §f" + TreasureStructureCatalog.starLabel(stars)
                + " §7· §6+" + coins + " ChaiBells §7· recompensas: §f" + delivered + (stars >= 5 ? " + Ticket Tesoro" : "")), false);
    }

    private static RewardItem randomReward(int stars) {
        List<RewardItem> list = stars >= 3 && ThreadLocalRandom.current().nextBoolean() ? RARE_ITEMS : POKEMON_ITEMS;
        return list.get(ThreadLocalRandom.current().nextInt(list.size()));
    }

    private static void summonVisual(MinecraftServer server, ServerWorld world, BlockPos p, int stars, String token) {
        String ball = TreasureStructureCatalog.ballItemForStars(stars);
        String tag = TAG_PREFIX + token;
        String display = "summon minecraft:item_display " + (p.getX()+.5) + " " + (p.getY()+1.25) + " " + (p.getZ()+.5)
                + " {Tags:[\"" + tag + "\"],item:{id:\"" + ball + "\",count:1},transformation:{scale:[2.8f,2.8f,2.8f]}}";
        String interaction = "summon minecraft:interaction " + (p.getX()+.5) + " " + p.getY() + " " + (p.getZ()+.5)
                + " {Tags:[\"" + tag + "\"],width:2.8f,height:2.8f,response:1b}";
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), display);
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), interaction);
        world.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD, p.getX()+.5, p.getY()+1.2, p.getZ()+.5, 16, .6, .9, .6, .03);
    }

    private static void animate(ServerWorld world, BlockPos p, int stars) {
        world.spawnParticles(stars >= 5 ? net.minecraft.particle.ParticleTypes.FIREWORK : net.minecraft.particle.ParticleTypes.END_ROD,
                p.getX()+.5, p.getY()+1.3, p.getZ()+.5, stars >= 5 ? 45 : 28, 1.0, 1.2, 1.0, .06);
        world.playSound(null, p, net.minecraft.sound.SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE,
                net.minecraft.sound.SoundCategory.MASTER, 1.0f, stars >= 5 ? 1.25f : 1.05f);
    }

    private static void removeVisual(MinecraftServer server, String token, Claim claim) {
        ServerWorld world = server.getWorld(net.minecraft.registry.RegistryKey.of(net.minecraft.registry.RegistryKeys.WORLD, Identifier.of(claim.worldId)));
        if (world == null) world = server.getOverworld();
        String tag = TAG_PREFIX + token;
        Box box = new Box(claim.pos).expand(8);
        for (Entity e : world.getOtherEntities(null, box, entity -> entity.getCommandTags().contains(tag))) e.discard();
    }

    private static String token(Entity entity) {
        for (String tag : entity.getCommandTags()) if (tag.startsWith(TAG_PREFIX)) return tag.substring(TAG_PREFIX.length());
        return null;
    }

    private static int starsFromNpc(ServiceNpcEntity npc) {
        String tier = npc.dungeonTier().toLowerCase(Locale.ROOT);
        if (tier.contains("epic")) return 4;
        if (tier.contains("treasure")) return 3;
        if (tier.contains("rare")) return 2;
        return 1;
    }

    private static BlockPos findSafe(ServerWorld world, BlockPos base) {
        for (int y = base.getY() + 6; y >= base.getY() - 5; y--) {
            BlockPos p = new BlockPos(base.getX(), y, base.getZ());
            if (world.getBlockState(p).isAir() && world.getBlockState(p.up()).isAir() && world.getBlockState(p.down()).isSolidBlock(world, p.down())) return p;
        }
        return base;
    }
    private static void giveItem(ServerPlayerEntity player, String rawId, int amount) {
        Identifier id = Identifier.tryParse(rawId); Item item = id != null && Registries.ITEM.containsId(id) ? Registries.ITEM.get(id) : Items.DIAMOND;
        if (item == Items.AIR) item = Items.DIAMOND; give(player, item, amount);
    }
    private static void give(ServerPlayerEntity player, Item item, int amount) {
        int left = amount; while (left > 0) { int take = Math.min(left, item.getMaxCount()); ItemStack stack = new ItemStack(item, take); if (!player.getInventory().insertStack(stack) && !stack.isEmpty()) player.dropItem(stack, false); left -= take; }
    }

    private record RewardItem(String id, int min, int max) { }
    private record Claim(UUID owner, String claimKey, int stars, String worldId, BlockPos pos, long expiresAt) { }
}
