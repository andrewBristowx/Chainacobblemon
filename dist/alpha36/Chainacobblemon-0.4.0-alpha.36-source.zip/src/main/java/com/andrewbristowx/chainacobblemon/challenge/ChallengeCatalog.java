package com.andrewbristowx.chainacobblemon.challenge;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ChallengeCatalog {
    public static final String PROFESSOR_NPC_ID = "profesora_chaina";

    private static final List<ChallengeProfile> PROFILES = List.of(
            // KANTO
            p("kanto", "Kanto", "brock", "Brock", "Roca", "Medalla Roca", 1, "", true,
                    team("geodude level=14", "onix level=16"),
                    pages("La roca no necesita moverse para ser fuerte. Yo tampoco.",
                            "Si quieres comenzar el circuito de Kanto, demuéstrame que tu equipo puede romper una defensa sólida."),
                    pages("Buen combate. Superaste mi defensa y abriste tu camino por Kanto."),
                    pages("Ya conozco tu fuerza. Si quieres una revancha, esta vez no pienso darte espacio para respirar.")),
            p("kanto", "Kanto", "misty", "Misty", "Agua", "Medalla Cascada", 2, "kanto:brock", true,
                    team("staryu level=20", "psyduck level=20", "starmie level=22"),
                    pages("Un combate de Agua cambia de ritmo en un instante.",
                            "Si derrotaste a Brock, veamos si también sabes adaptarte cuando la batalla empieza a fluir."),
                    pages("Supiste cambiar de ritmo conmigo. Esa victoria es tuya."),
                    pages("¿Otra vez? Perfecto. Quiero ver si puedes seguirme cuando acelere desde el primer turno.")),
            p("kanto", "Kanto", "lt_surge", "Lt. Surge", "Eléctrico", "Medalla Trueno", 3, "kanto:misty", false,
                    team("voltorb level=24", "pikachu level=25", "raichu level=27"),
                    pages("Aquí no hay tiempo para dudar. Un turno lento y la electricidad te pasa por encima.",
                            "Enséñame que tu equipo puede mantener la calma bajo presión."),
                    pages("Buena reacción. No te paralizaste cuando la pelea se volvió rápida."),
                    pages("Vuelve a conectar tu estrategia. Esta revancha será todavía más rápida.")),
            p("kanto", "Kanto", "erika", "Erika", "Planta", "Medalla Arcoíris", 4, "kanto:lt_surge", true,
                    team("victreebel level=29", "tangela level=29", "vileplume level=31"),
                    pages("Las plantas parecen tranquilas hasta que sus raíces ya rodearon todo el campo.",
                            "No subestimes una estrategia que crece poco a poco."),
                    pages("Fuiste paciente y encontraste el momento correcto para atacar."),
                    pages("Las raíces vuelven a crecer. Cuando quieras, podemos intentarlo de nuevo.")),
            p("kanto", "Kanto", "koga", "Koga", "Veneno", "Medalla Alma", 5, "kanto:erika", false,
                    team("koffing level=35", "muk level=36", "weezing level=38", "crobat level=38"),
                    pages("Una batalla no siempre se gana con fuerza directa. El desgaste también decide combates.",
                            "Si entras sin un plan, mis trampas harán el trabajo por mí."),
                    pages("No caíste en mis engaños. Mereces continuar."),
                    pages("La misma trampa rara vez funciona dos veces. Por eso ya preparé otras.")),
            p("kanto", "Kanto", "sabrina", "Sabrina", "Psíquico", "Medalla Pantano", 6, "kanto:koga", true,
                    team("mr_mime level=40", "espeon level=41", "alakazam level=43"),
                    pages("Antes de elegir un movimiento, piensa en lo que ocurrirá después.",
                            "La mejor ventaja es obligar al rival a tomar la decisión que tú esperabas."),
                    pages("Cambiaste el futuro del combate con buenas decisiones. Has ganado."),
                    pages("Ya vi una versión de tu estrategia. Enséñame una que todavía no pueda anticipar.")),
            p("kanto", "Kanto", "blaine", "Blaine", "Fuego", "Medalla Volcán", 7, "kanto:sabrina", false,
                    team("rapidash level=45", "magmar level=45", "ninetales level=46", "arcanine level=48"),
                    pages("El fuego premia la decisión. Si dudas demasiado, el combate se consume solo.",
                            "Quiero ver si puedes aguantar el calor hasta el final."),
                    pages("¡Excelente! Mantuviste la cabeza fría en el combate más caliente de Kanto."),
                    pages("Las brasas siguen encendidas. Una revancha puede convertirlas otra vez en incendio.")),
            p("kanto", "Kanto", "giovanni", "Giovanni", "Tierra", "Medalla Tierra", 8, "kanto:blaine", false,
                    team("nidoking level=50", "nidoqueen level=50", "rhyperior level=51", "dugtrio level=49", "persian level=50"),
                    pages("Has recorrido todo Kanto para llegar hasta aquí. Eso ya dice bastante de ti.",
                            "Pero una liga no se conquista con intención. Se conquista demostrando control absoluto del combate."),
                    pages("Has terminado el circuito de Kanto. Esa victoria no fue suerte."),
                    pages("Un campeón no debería temer volver al primer campo de batalla. Adelante.")),

            p("kanto", "Kanto", "elite_lorelei", "Lorelei", "Hielo", "", 9, "kanto:giovanni", true,
                    team("dewgong level=54", "cloyster level=53", "slowbro level=54", "jynx level=56", "lapras level=56"),
                    pages("Los gimnasios fueron solo la entrada. La Liga empieza aquí.", "Mi equipo de Hielo castiga cualquier error de ritmo."),
                    pages("Superaste la primera sala del Alto Mando. Bruno te espera."),
                    pages("El hielo vuelve a formarse. Si quieres repetir el desafío, adelante.")),
            p("kanto", "Kanto", "elite_bruno", "Bruno", "Lucha", "", 10, "kanto:elite_lorelei", false,
                    team("onix level=55", "hitmonchan level=55", "hitmonlee level=55", "onix level=56", "machamp level=58"),
                    pages("La fuerza sin disciplina no sirve. Quiero ver si tus decisiones aguantan la presión."),
                    pages("Tu equipo resistió. Agatha será la siguiente prueba."), pages("Entrenar nunca termina. Podemos medir fuerzas otra vez.")),
            p("kanto", "Kanto", "elite_agatha", "Agatha", "Fantasma", "", 11, "kanto:elite_bruno", true,
                    team("gengar level=56", "golbat level=56", "haunter level=55", "arbok level=58", "gengar level=60"),
                    pages("Los combates largos revelan la paciencia de un entrenador.", "No te confíes solo porque hayas llegado hasta aquí."),
                    pages("No pude atraparte en mis trucos. Lance te espera."), pages("Los fantasmas siempre regresan. Yo también.")),
            p("kanto", "Kanto", "elite_lance", "Lance", "Dragón", "", 12, "kanto:elite_agatha", false,
                    team("gyarados level=58", "dragonair level=58", "dragonair level=58", "aerodactyl level=60", "dragonite level=62"),
                    pages("Has derrotado a tres miembros del Alto Mando. Ahora demuestra que puedes vencer a los Dragones."),
                    pages("Has superado al Alto Mando. Solo queda el Campeón de Kanto."), pages("Los Dragones no pierden su orgullo. Una revancha siempre es bienvenida.")),
            p("kanto", "Kanto", "champion_blue", "Blue", "", "", 13, "kanto:elite_lance", false,
                    team("pidgeot level=61", "alakazam level=59", "rhydon level=61", "exeggutor level=61", "gyarados level=63", "arcanine level=63"),
                    pages("Ocho medallas y cuatro victorias en la Liga. Bien, llegaste hasta mí.", "Si quieres ser Campeón de Kanto, tendrás que ganártelo aquí."),
                    pages("Lo lograste. Kanto está completado y una nueva región puede comenzar."), pages("Ser Campeón no significa dejar de entrenar. Ven cuando quieras.")),

            // JOHTO
            p("johto", "Johto", "falkner", "Falkner", "Volador", "Medalla Céfiro", 1, "kanto:champion_blue", true,
                    team("pidgeotto level=22", "noctowl level=23", "fearow level=24"),
                    pages("Johto comienza mirando al cielo. Un buen entrenador debe saber cuándo atacar y cuándo tomar altura.",
                            "Si Kanto ya quedó atrás, prueba que todavía puedes aprender algo nuevo."),
                    pages("Leíste bien mis cambios de ritmo. Bienvenido al circuito de Johto."),
                    pages("El viento cambia todos los días. Mi estrategia también.")),
            p("johto", "Johto", "bugsy", "Bugsy", "Bicho", "Medalla Colmena", 2, "johto:falkner", true,
                    team("scyther level=25", "heracross level=25", "ariados level=24"),
                    pages("Los Pokémon Bicho parecen simples hasta que entiendes cómo trabajan juntos.",
                            "Hoy quiero comprobar si estudias al rival antes de lanzarte al ataque."),
                    pages("Observaste bien el campo. Esa curiosidad te hizo ganar."),
                    pages("He estudiado tu equipo desde la última vez. Ahora te toca sorprenderme.")),
            p("johto", "Johto", "whitney", "Whitney", "Normal", "Medalla Planicie", 3, "johto:bugsy", true,
                    team("clefairy level=28", "miltank level=30", "girafarig level=29"),
                    pages("Que un Pokémon sea Normal no significa que su combate vaya a ser sencillo.",
                            "A veces la estrategia más molesta es la que parece más inocente."),
                    pages("¡Eso estuvo mucho más difícil de lo que esperaba! Bien jugado."),
                    pages("Esta vez vengo preparada. Y sí, Miltank también.")),
            p("johto", "Johto", "morty", "Morty", "Fantasma", "Medalla Niebla", 4, "johto:whitney", false,
                    team("haunter level=31", "mismagius level=32", "gengar level=34"),
                    pages("No todo lo que importa en un combate puede verse a simple vista.",
                            "Lee los cambios de estado, los turnos y las intenciones. Ahí encontrarás la salida."),
                    pages("No te perdiste entre mis ilusiones. Puedes continuar."),
                    pages("La niebla volvió. Tal vez esta vez no encuentres el mismo camino.")),
            p("johto", "Johto", "chuck", "Chuck", "Lucha", "Medalla Tormenta", 5, "johto:morty", false,
                    team("primeape level=35", "hitmontop level=35", "poliwrath level=37", "machamp level=37"),
                    pages("¡Nada de rodeos! Quiero fuerza, resistencia y decisiones rápidas.",
                            "Si tu plan solo funciona cuando todo sale perfecto, aquí se romperá."),
                    pages("¡Eso sí fue un combate! Te ganaste el derecho a seguir."),
                    pages("Todavía me quedan fuerzas. ¿A ti también?")),
            p("johto", "Johto", "jasmine", "Jasmine", "Acero", "Medalla Mineral", 6, "johto:chuck", true,
                    team("magneton level=38", "skarmory level=39", "steelix level=41"),
                    pages("El Acero resiste, pero una defensa sin propósito solo retrasa la derrota.",
                            "Muéstrame que sabes encontrar una grieta incluso en una estrategia sólida."),
                    pages("Encontraste la apertura correcta. Fue una victoria muy limpia."),
                    pages("He reforzado mis puntos débiles. Puedes comprobarlo cuando quieras.")),
            p("johto", "Johto", "pryce", "Pryce", "Hielo", "Medalla Glaciar", 7, "johto:jasmine", false,
                    team("dewgong level=42", "sneasel level=42", "piloswine level=44", "mamoswine level=45"),
                    pages("La experiencia enseña que un combate perdido todavía puede recuperarse.",
                            "Mantén la disciplina incluso cuando el campo parezca congelado en tu contra."),
                    pages("Tu paciencia fue mejor que mi defensa. Has vencido."),
                    pages("El frío vuelve cada invierno. También las buenas revanchas.")),
            p("johto", "Johto", "clair", "Clair", "Dragón", "Medalla Dragón", 8, "johto:pryce", true,
                    team("dragonair level=47", "gyarados level=47", "kingdra level=49", "dragonite level=50"),
                    pages("Llegar al último gimnasio de Johto no te convierte automáticamente en alguien digno de vencerlo.",
                            "Quiero ver una estrategia capaz de sobrevivir contra Dragones sin depender de una sola respuesta."),
                    pages("Lo admito: estuviste a la altura. Johto ya no tiene nada más que probarte."),
                    pages("No confundas una victoria con superioridad permanente. Vuelve a demostrarla.")),

            p("johto", "Johto", "elite_will", "Will", "Psíquico", "", 9, "johto:clair", true,
                    team("xatu level=52", "jynx level=52", "exeggutor level=53", "slowbro level=53", "xatu level=54"),
                    pages("Bienvenido al Alto Mando de Johto. Aquí cada turno importa."), pages("Has ganado. Koga es el siguiente."), pages("Podemos volver a intentarlo cuando quieras.")),
            p("johto", "Johto", "elite_koga", "Koga", "Veneno", "", 10, "johto:elite_will", false,
                    team("ariados level=54", "forretress level=54", "muk level=55", "crobat level=56", "venomoth level=55"),
                    pages("Volvemos a encontrarnos, pero esta vez como Alto Mando."), pages("Has superado mis trampas. Bruno te espera."), pages("La próxima vez prepararé algo distinto.")),
            p("johto", "Johto", "elite_bruno", "Bruno", "Lucha", "", 11, "johto:elite_koga", false,
                    team("hitmontop level=55", "hitmonlee level=55", "hitmonchan level=55", "onix level=56", "machamp level=57"),
                    pages("La disciplina vuelve a ser tu prueba."), pages("Has ganado. Karen es la siguiente."), pages("Seguiremos entrenando.")),
            p("johto", "Johto", "elite_karen", "Karen", "Siniestro", "", 12, "johto:elite_bruno", true,
                    team("umbreon level=57", "vileplume level=56", "gengar level=56", "muk level=57", "houndoom level=59"),
                    pages("Los buenos entrenadores ganan con los Pokémon que realmente quieren usar."), pages("Has superado al Alto Mando. Lance te espera."), pages("Haz que la próxima batalla sea igual de interesante.")),
            p("johto", "Johto", "champion_lance", "Lance", "Dragón", "", 13, "johto:elite_karen", false,
                    team("gyarados level=60", "dragonite level=62", "dragonite level=62", "aerodactyl level=61", "charizard level=61", "dragonite level=64"),
                    pages("Llegaste al final de Johto. Ahora demuestra que mereces el título."), pages("Johto está completado. Puedes continuar hacia Hoenn."), pages("Un Campeón siempre tiene tiempo para una gran revancha.")),

            // HOENN
            p("hoenn", "Hoenn", "roxanne", "Roxanne", "Roca", "Medalla Piedra", 1, "johto:champion_lance", true,
                    team("nosepass level=24", "geodude level=23", "lileep level=25"),
                    pages("Un gimnasio también es un lugar para aprender. Cada turno revela algo sobre tu forma de pensar.",
                            "Empecemos Hoenn con una pregunta sencilla: ¿puedes aplicar lo que ya sabes en un combate distinto?"),
                    pages("Aplicaste muy bien lo aprendido. Hoenn queda oficialmente abierto para ti."),
                    pages("He preparado una nueva lección. Esta vez el examen será más difícil.")),
            p("hoenn", "Hoenn", "brawly", "Brawly", "Lucha", "Medalla Puño", 2, "hoenn:roxanne", false,
                    team("machoke level=27", "meditite level=27", "hariyama level=29"),
                    pages("Un buen combate tiene ritmo, como una ola. Si luchas contra él, pierdes energía.",
                            "Encuentra el momento correcto y golpea cuando la oportunidad llegue."),
                    pages("Encontraste el ritmo antes que yo. Buena victoria."),
                    pages("Las olas nunca son iguales. Nuestra revancha tampoco.")),
            p("hoenn", "Hoenn", "wattson", "Wattson", "Eléctrico", "Medalla Dinamo", 3, "hoenn:brawly", false,
                    team("magneton level=31", "electrode level=31", "manectric level=33"),
                    pages("¡Una batalla aburrida es energía desperdiciada!",
                            "Veamos si puedes mantener tu estrategia encendida mientras cambio el voltaje del combate."),
                    pages("¡Eso sí tuvo energía! Te llevas una victoria merecida."),
                    pages("He recargado el equipo. Cuando quieras, volvemos a encender esto.")),
            p("hoenn", "Hoenn", "flannery", "Flannery", "Fuego", "Medalla Calor", 4, "hoenn:wattson", true,
                    team("numel level=34", "camerupt level=35", "torkoal level=36"),
                    pages("No necesito parecer tranquila para saber exactamente lo que quiero hacer.",
                            "Mi Fuego irá de frente. Tu trabajo es encontrar cómo detenerlo."),
                    pages("¡Lo hiciste! Aguantaste la presión y mantuviste tu plan."),
                    pages("He practicado desde nuestra última pelea. No esperes el mismo error dos veces.")),
            p("hoenn", "Hoenn", "norman", "Norman", "Normal", "Medalla Equilibrio", 5, "hoenn:flannery", false,
                    team("vigoroth level=38", "zangoose level=38", "slaking level=40", "exploud level=39"),
                    pages("En este punto ya no basta con conocer ventajas de tipo.",
                            "Quiero ver si sabes administrar recursos, turnos seguros y riesgos."),
                    pages("Tu control del combate fue mejor. Has avanzado mucho."),
                    pages("Una revancha es una buena forma de medir cuánto seguimos avanzando los dos.")),
            p("hoenn", "Hoenn", "winona", "Winona", "Volador", "Medalla Pluma", 6, "hoenn:norman", true,
                    team("swellow level=41", "pelipper level=41", "skarmory level=42", "altaria level=44"),
                    pages("Desde arriba se ve el campo completo. Cada cambio se vuelve más evidente.",
                            "Si quieres vencerme, no mires solo al Pokémon que tienes delante."),
                    pages("Viste el campo completo y no solo el siguiente turno. Muy bien."),
                    pages("Volvamos a tomar altura. Quiero ver qué notas esta vez.")),
            p("hoenn", "Hoenn", "tate_liza", "Tate & Liza", "Psíquico", "Medalla Mente", 7, "hoenn:winona", true,
                    team("solrock level=45", "lunatone level=45", "claydol level=44", "xatu level=44"),
                    pages("Dos entrenadores, una sola estrategia. Nuestro combate exige que mires más de una amenaza a la vez.",
                            "Si te concentras demasiado en un lado del campo, el otro decidirá la pelea."),
                    pages("Coordinaste muy bien tus respuestas. Nuestra sincronía no fue suficiente."),
                    pages("Hemos preparado una combinación distinta. ¿Puedes adaptarte otra vez?")),
            p("hoenn", "Hoenn", "juan", "Juan", "Agua", "Medalla Lluvia", 8, "hoenn:tate_liza", false,
                    team("whiscash level=47", "kingdra level=48", "walrein level=48", "milotic level=50"),
                    pages("La elegancia de una estrategia está en ganar sin desperdiciar movimientos.",
                            "Has llegado al final de Hoenn. Haz que cada turno de este combate tenga un propósito."),
                    pages("Una actuación impecable. Has completado los gimnasios de Hoenn."),
                    pages("Una gran actuación merece repetirse. Intenta superar la anterior.")),

            p("hoenn", "Hoenn", "elite_sidney", "Sidney", "Siniestro", "", 9, "hoenn:juan", false,
                    team("mightyena level=50", "shiftry level=50", "cacturne level=51", "sharpedo level=51", "absol level=52"),
                    pages("El Alto Mando de Hoenn empieza conmigo. Veamos cómo respondes a la presión."), pages("Phoebe te espera."), pages("Vuelve cuando quieras.")),
            p("hoenn", "Hoenn", "elite_phoebe", "Phoebe", "Fantasma", "", 10, "hoenn:elite_sidney", true,
                    team("dusclops level=52", "banette level=52", "sableye level=53", "banette level=53", "dusknoir level=54"),
                    pages("Los espíritus y yo hemos preparado una prueba distinta."), pages("Glacia será tu siguiente rival."), pages("Los espíritus estarán listos otra vez.")),
            p("hoenn", "Hoenn", "elite_glacia", "Glacia", "Hielo", "", 11, "hoenn:elite_phoebe", true,
                    team("glalie level=54", "froslass level=54", "walrein level=55", "glalie level=55", "walrein level=56"),
                    pages("Mantén la calma. El frío castiga las decisiones apresuradas."), pages("Drake te espera."), pages("El hielo no desaparece para siempre.")),
            p("hoenn", "Hoenn", "elite_drake", "Drake", "Dragón", "", 12, "hoenn:elite_glacia", false,
                    team("shelgon level=56", "altaria level=56", "flygon level=56", "flygon level=57", "salamence level=58"),
                    pages("Los Dragones son la última prueba antes del Campeón."), pages("Has superado al Alto Mando. Steven te espera."), pages("Una revancha será bienvenida.")),
            p("hoenn", "Hoenn", "champion_steven", "Steven", "Acero", "", 13, "hoenn:elite_drake", false,
                    team("skarmory level=59", "claydol level=59", "aggron level=60", "cradily level=60", "armaldo level=60", "metagross level=62"),
                    pages("Has recorrido Hoenn y llegado hasta aquí. Muéstrame el equipo que construiste en el camino."), pages("Hoenn está completado. Sinnoh será tu siguiente gran desafío."), pages("Siempre hay algo nuevo que aprender de una revancha.")),

            // SINNOH
            p("sinnoh", "Sinnoh", "roark", "Roark", "Roca", "Medalla Carbón", 1, "hoenn:champion_steven", false,
                    team("geodude level=26", "onix level=27", "cranidos level=29"),
                    pages("Sinnoh empieza bajo tierra. Aquí aprendes rápido que la presión revela qué tan sólido es un equipo.",
                            "Veamos si tu experiencia de otras regiones resiste un comienzo nuevo."),
                    pages("Tu equipo soportó la presión. Sinnoh ya está en marcha."),
                    pages("He excavado una estrategia nueva. Cuando quieras, la probamos.")),
            p("sinnoh", "Sinnoh", "gardenia", "Gardenia", "Planta", "Medalla Bosque", 2, "sinnoh:roark", true,
                    team("cherubi level=30", "turtwig level=30", "roserade level=32"),
                    pages("Las plantas no tienen prisa. Preparan el terreno y esperan a que el rival se equivoque.",
                            "No dejes que mi campo se vuelva cómodo para mí."),
                    pages("Cortaste mi estrategia antes de que pudiera crecer. Buena lectura."),
                    pages("Esta vez plantaré algo distinto. A ver si también lo descubres a tiempo.")),
            p("sinnoh", "Sinnoh", "maylene", "Maylene", "Lucha", "Medalla Adoquín", 3, "sinnoh:gardenia", true,
                    team("meditite level=34", "machoke level=35", "lucario level=37"),
                    pages("Entreno para reaccionar sin perder la concentración.",
                            "Tu equipo también deberá mantener el control cuando el combate se vuelva físico."),
                    pages("Tu disciplina fue excelente. Esa victoria está bien ganada."),
                    pages("He seguido entrenando. Espero que tú también.")),
            p("sinnoh", "Sinnoh", "crasher_wake", "Crasher Wake", "Agua", "Medalla Ciénaga", 4, "sinnoh:maylene", false,
                    team("gyarados level=39", "quagsire level=39", "floatzel level=41"),
                    pages("¡Un combate bueno tiene que sentirse enorme! Pero el espectáculo no sirve si la estrategia falla.",
                            "Aguanta el impacto y responde con algo mejor."),
                    pages("¡Gran pelea! Tu estrategia estuvo a la altura del espectáculo."),
                    pages("¡La arena sigue abierta! Ven cuando quieras por otra pelea grande.")),
            p("sinnoh", "Sinnoh", "fantina", "Fantina", "Fantasma", "Medalla Reliquia", 5, "sinnoh:crasher_wake", true,
                    team("drifblim level=42", "gengar level=42", "mismagius level=44"),
                    pages("Una batalla memorable necesita sorpresa, ritmo y un poco de misterio.",
                            "Intenta seguir mi plan si puedes descubrir cuál es."),
                    pages("Magnifique. Convertiste mi sorpresa en tu oportunidad."),
                    pages("Una segunda función nunca debe ser idéntica a la primera.")),
            p("sinnoh", "Sinnoh", "byron", "Byron", "Acero", "Medalla Mina", 6, "sinnoh:fantina", false,
                    team("bronzor level=45", "steelix level=46", "bastiodon level=48"),
                    pages("Construir una defensa fuerte lleva tiempo. Derribarla requiere método.",
                            "No malgastes golpes contra una pared si puedes encontrar dónde sostiene su peso."),
                    pages("Encontraste el punto débil y lo aprovechaste. Buen trabajo."),
                    pages("He reconstruido la defensa. Puedes venir a comprobarla.")),
            p("sinnoh", "Sinnoh", "candice", "Candice", "Hielo", "Medalla Carámbano", 7, "sinnoh:byron", true,
                    team("sneasel level=48", "abomasnow level=49", "froslass level=50", "mamoswine level=50"),
                    pages("La concentración es lo que mantiene una estrategia unida cuando todo empieza a complicarse.",
                            "No pierdas el enfoque aunque el combate se vuelva incómodo."),
                    pages("Tu concentración no se quebró. Te mereces seguir adelante."),
                    pages("Mantengamos el enfoque y hagamos una revancha todavía mejor.")),
            p("sinnoh", "Sinnoh", "volkner", "Volkner", "Eléctrico", "Medalla Faro", 8, "sinnoh:candice", false,
                    team("raichu level=52", "luxray level=53", "electivire level=55", "jolteon level=53"),
                    pages("Has llegado al último gimnasio de Sinnoh. Espero que no hayas venido buscando una victoria automática.",
                            "Dame una batalla capaz de obligarme a pensar hasta el último turno."),
                    pages("Eso era exactamente lo que quería. Has completado los cuatro circuitos regionales."),
                    pages("Si todavía quieres una batalla difícil, ya sabes dónde encontrarme.")),

            p("sinnoh", "Sinnoh", "elite_aaron", "Aaron", "Bicho", "", 9, "sinnoh:volkner", true,
                    team("dustox level=53", "beautifly level=53", "vespiquen level=54", "heracross level=54", "drapion level=55"),
                    pages("La Liga de Sinnoh comienza con una prueba de adaptación."), pages("Bertha te espera."), pages("Mis Pokémon Bicho estarán listos otra vez.")),
            p("sinnoh", "Sinnoh", "elite_bertha", "Bertha", "Tierra", "", 10, "sinnoh:elite_aaron", true,
                    team("quagsire level=55", "whiscash level=55", "sudowoodo level=56", "golem level=56", "hippowdon level=57"),
                    pages("La experiencia se nota cuando una estrategia sigue funcionando bajo presión."), pages("Flint será tu siguiente rival."), pages("Siempre se puede aprender algo de otra batalla.")),
            p("sinnoh", "Sinnoh", "elite_flint", "Flint", "Fuego", "", 11, "sinnoh:elite_bertha", false,
                    team("rapidash level=57", "steelix level=57", "drifblim level=58", "lopunny level=58", "infernape level=59"),
                    pages("Quiero una batalla que arda desde el primer turno."), pages("Lucian te espera."), pages("La llama sigue encendida.")),
            p("sinnoh", "Sinnoh", "elite_lucian", "Lucian", "Psíquico", "", 12, "sinnoh:elite_flint", false,
                    team("mr_mime level=59", "girafarig level=59", "medicham level=60", "alakazam level=60", "bronzong level=61"),
                    pages("Llegar lejos no basta. Ahora debes demostrar precisión."), pages("Has superado al Alto Mando. Cynthia te espera."), pages("Una revancha revelará si tu estrategia sigue evolucionando.")),
            p("sinnoh", "Sinnoh", "champion_cynthia", "Cynthia", "Mixto", "", 13, "sinnoh:elite_lucian", true,
                    team("spiritomb level=61", "roserade level=60", "gastrodon level=60", "lucario level=63", "milotic level=63", "garchomp level=66"),
                    pages("Cada región te ha preparado para este momento.", "Muéstrame hasta dónde puede llegar tu equipo."), pages("Has completado Sinnoh. Las cuatro Ligas regionales quedan registradas en tu aventura."), pages("Los grandes entrenadores nunca dejan de mejorar. Podemos volver a combatir."))
    );

    private static final Map<String, ChallengeProfile> BY_KEY;
    private static final Map<String, ChallengeProfile> BY_NPC;

    static {
        Map<String, ChallengeProfile> byKey = new LinkedHashMap<>();
        Map<String, ChallengeProfile> byNpc = new LinkedHashMap<>();
        for (ChallengeProfile profile : PROFILES) {
            if (byKey.put(profile.key(), profile) != null) {
                throw new IllegalStateException("Duplicate challenge key: " + profile.key());
            }
            if (byNpc.put(profile.npcId(), profile) != null) {
                throw new IllegalStateException("Duplicate challenge NPC id: " + profile.npcId());
            }
        }
        BY_KEY = Map.copyOf(byKey);
        BY_NPC = Map.copyOf(byNpc);
    }

    private ChallengeCatalog() {
    }

    public static List<ChallengeProfile> all() {
        return PROFILES;
    }

    public static ChallengeProfile byKey(String key) {
        if (key == null) return null;
        return BY_KEY.get(key.trim().toLowerCase(Locale.ROOT));
    }

    public static ChallengeProfile byNpcId(String npcId) {
        if (npcId == null) return null;
        return BY_NPC.get(npcId.trim().toLowerCase(Locale.ROOT));
    }

    public static ChallengeProfile byRegionLeader(String region, String leader) {
        String regionId = normalize(region);
        String leaderId = normalize(leader);
        ChallengeProfile direct = byKey(regionId + ":" + leaderId);
        if (direct != null) return direct;
        for (ChallengeProfile profile : PROFILES) {
            if (!profile.regionId().equals(regionId)) continue;
            if (normalize(profile.displayName()).equals(leaderId)) return profile;
        }
        return null;
    }

    public static List<String> regions() {
        return List.of("kanto", "johto", "hoenn", "sinnoh");
    }

    public static List<String> leaders(String region) {
        String normalized = normalize(region);
        List<String> result = new ArrayList<>();
        for (ChallengeProfile profile : PROFILES) {
            if (profile.regionId().equals(normalized)) result.add(profile.leaderId());
        }
        return List.copyOf(result);
    }

    public static String naturalAdvancementPath(ChallengeProfile profile) {
        if (profile == null) return "";
        String token = RctCobbleverseBridge.baseToken(profile.leaderId());
        if (profile.isChampion()) return "rctmod:trainers/defeat_champ_" + token;
        if (profile.isEliteFour()) return "rctmod:trainers/defeat_e4_" + token;
        return "rctmod:trainers/defeat_leader_" + token;
    }

    private static ChallengeProfile p(String regionId, String regionName, String leaderId, String displayName,
                                      String typeName, String badgeName, int order, String prerequisiteKey,
                                      boolean slim, List<String> team, List<String> intro, List<String> victory,
                                      List<String> rematch) {
        return new ChallengeProfile(regionId, regionName, leaderId, displayName, typeName, badgeName, order,
                prerequisiteKey, slim, team, intro, victory, rematch);
    }

    private static List<String> team(String... values) {
        return List.of(values);
    }

    private static List<String> pages(String... values) {
        return List.of(values);
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.trim().toLowerCase(Locale.ROOT)
                .replace("&", "and")
                .replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
    }
}
