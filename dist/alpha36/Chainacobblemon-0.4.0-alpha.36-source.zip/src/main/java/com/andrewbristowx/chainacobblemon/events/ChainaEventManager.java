package com.andrewbristowx.chainacobblemon.events;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.events.treasure.TreasureHuntService;
import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.cobblemon.mod.common.api.events.fishing.BobberSpawnPokemonEvent;
import com.cobblemon.mod.common.api.events.fishing.PokerodReelEvent;
import com.cobblemon.mod.common.api.events.pokemon.PokemonCapturedEvent;
import com.cobblemon.mod.common.pokemon.Pokemon;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

/** Server-authoritative event engine. Events happen in the normal world; joining never teleports players except admin tests. */
public final class ChainaEventManager {
    public enum Phase { IDLE, JOINING, RUNNING, RESULTS }
    private static final int JOIN_SECONDS = 60;
    private static final int HUD_INTERVAL_TICKS = 20;
    private static final long FIRST_AUTO_DELAY_MS = 60L * 60L * 1000L;
    private static final String[] BEAUTY_MOVES = {"surf", "rain_dance", "body_slam", "dazzling_gleam"};
    private static final String[] BEAUTY_LABELS = {"🌊 Surf", "🌧 Danza Lluvia", "💥 Golpe Cuerpo", "✨ Brillo Mágico"};
    private static final long FISHING_ENCOUNTER_TTL_MS = 15L * 60L * 1000L;
    private static final Map<UUID, List<FishingEncounter>> FISHING_ENCOUNTERS = new HashMap<>();
    private static RecentReel RECENT_REEL;
    private static Active active;
    private static long nextAutomaticEpochMillis;
    private static final java.util.ArrayDeque<ChainaEventType> RECENT_AUTOMATIC = new java.util.ArrayDeque<>();
    private static final java.util.EnumMap<ChainaEventType, Integer> AUTO_DROUGHT = new java.util.EnumMap<>(ChainaEventType.class);
    private static int ticks;

    private ChainaEventManager() { }

    public static void initialize() {
        nextAutomaticEpochMillis = System.currentTimeMillis() + FIRST_AUTO_DELAY_MS;
        for (ChainaEventType type : ChainaEventType.values()) AUTO_DROUGHT.put(type, 0);
        ServerTickEvents.END_SERVER_TICK.register(ChainaEventManager::tick);
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (player instanceof ServerPlayerEntity serverPlayer) onMine(serverPlayer, state);
        });
        CobblemonEvents.POKEMON_CAPTURED.subscribe((Consumer<PokemonCapturedEvent>) ChainaEventManager::onCapture);
        CobblemonEvents.POKEROD_REEL.subscribe((Consumer<PokerodReelEvent>) ChainaEventManager::onPokerodReel);
        CobblemonEvents.BOBBER_SPAWN_POKEMON_POST.subscribe((Consumer<BobberSpawnPokemonEvent.Post>) ChainaEventManager::onFishedSpawn);
        Chainacobblemon.LOGGER.info("Eventos Chaina initialized: fishing, safari, exhibition, mining and treasure hunt");
    }

    public static Phase phase() { return active == null ? Phase.IDLE : active.phase; }
    public static ChainaEventType type() { return active == null ? null : active.type; }
    public static boolean isActive(ChainaEventType type) { return active != null && active.type == type && active.phase != Phase.IDLE; }
    public static boolean isTreasureParticipant(UUID playerId) { return active != null && active.type == ChainaEventType.TREASURE && active.participants.containsKey(playerId); }

    public static boolean start(MinecraftServer server, ChainaEventType type, ServerPlayerEntity admin, boolean test) {
        if (server == null || type == null) return false;
        if (active != null) {
            if (admin != null) admin.sendMessage(Text.literal("§cYa hay un Evento Chaina activo: " + active.type.displayName), false);
            return false;
        }
        // A manual Treasure Hunt test can leave a temporary session/protection behind.
        // Never let that leak into Fishing/Safari/Mining/Beauty. The placed structure itself is kept.
        if (type != ChainaEventType.TREASURE) TreasureHuntService.cleanup(server, true);
        if (type == ChainaEventType.FISHING) { FISHING_ENCOUNTERS.clear(); RECENT_REEL = null; }
        long now = System.currentTimeMillis();
        active = new Active(type, Phase.JOINING, now, now + (test ? 10_000L : JOIN_SECONDS * 1000L), test);
        broadcastInvite(server, type, test ? 10 : JOIN_SECONDS);
        if (test && admin != null) join(admin);
        return true;
    }

    public static boolean join(ServerPlayerEntity player) {
        if (player == null || active == null || active.phase != Phase.JOINING) {
            if (player != null) player.sendMessage(Text.literal("§7No hay un Evento Chaina aceptando participantes ahora mismo."), false);
            return false;
        }
        Participant p = active.participants.computeIfAbsent(player.getUuid(), id -> new Participant(id, player.getName().getString()));
        p.online = true;
        p.lives = 3;
        player.sendMessage(Text.literal("§a✓ Te uniste a §f" + active.type.displayName + "§a. El evento empezará pronto."), false);
        sendHudTo(player);
        return true;
    }

    public static void leave(ServerPlayerEntity player) {
        if (player == null || active == null) return;
        active.participants.remove(player.getUuid());
        EventNetworking.hideHud(player);
        player.sendMessage(Text.literal("§7Saliste del Evento Chaina."), false);
    }

    public static void playerJoined(ServerPlayerEntity player) {
        if (player == null || active == null) return;
        Participant p = active.participants.get(player.getUuid());
        if (p != null) { p.online = true; sendHudTo(player); }
    }

    public static void playerLeft(UUID playerId) {
        if (active == null || playerId == null) return;
        Participant p = active.participants.get(playerId);
        if (p != null) p.online = false;
    }

    public static String status() {
        if (active == null) {
            long remaining = Math.max(0L, nextAutomaticEpochMillis - System.currentTimeMillis());
            String recent = RECENT_AUTOMATIC.isEmpty() ? "ninguno" : RECENT_AUTOMATIC.stream()
                    .map(type -> type.displayName).collect(java.util.stream.Collectors.joining(" → "));
            return "No hay Evento Chaina activo. Próximo automático ~" + formatTime(remaining)
                    + " · recientes: " + recent;
        }
        long remain = Math.max(0L, (active.phaseEndEpochMillis - System.currentTimeMillis()) / 1000L);
        return active.type.displayName + " · " + active.phase + " · " + remain + "s · participantes " + active.participants.size();
    }

    public static void stop(MinecraftServer server, String reason) {
        if (active == null) return;
        // Treasure players must only be returned once the results/reward presentation has finished.
        // Returning them while the roulette screen is opening can leave the client visually stranded
        // in the temporary dimension with no chunks rendered.
        TreasureHuntService.cleanup(server, active.type == ChainaEventType.TREASURE);
        for (UUID id : active.participants.keySet()) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(id);
            if (player != null) EventNetworking.hideHud(player);
        }
        server.getPlayerManager().broadcast(Text.literal("§7Evento Chaina finalizado" + (reason == null || reason.isBlank() ? "." : ": " + reason)), false);
        if (active.type == ChainaEventType.FISHING) { FISHING_ENCOUNTERS.clear(); RECENT_REEL = null; }
        boolean automatic = active.automatic;
        active = null;
        // Admin tests/manual events no longer push the natural-event timer backwards.
        if (automatic) scheduleNextAuto();
    }

    private static void tick(MinecraftServer server) {
        long now = System.currentTimeMillis();
        if (ticks % 200 == 0) pruneFishingEncounters(now);
        if (active == null) {
            if (now >= nextAutomaticEpochMillis && server.getPlayerManager().getCurrentPlayerCount() > 0) {
                ChainaEventType selected = randomAutomaticType();
                if (start(server, selected, null, false) && active != null) {
                    active.automatic = true;
                    recordAutomatic(selected);
                }
            }
            return;
        }
        ticks++;
        active.serverHint = server;
        if (active.phase == Phase.JOINING && now >= active.phaseEndEpochMillis) beginRunning(server);
        if (active == null) return;
        if (active.phase == Phase.RUNNING) {
            if (active.type == ChainaEventType.BEAUTY) beautyTick(server, now);
            if (active.type == ChainaEventType.TREASURE) TreasureHuntService.tick(server, active.participants.keySet());
            if (now >= active.phaseEndEpochMillis) finish(server, "Tiempo terminado");
        }
        if (active != null && active.phase == Phase.RESULTS && now >= active.phaseEndEpochMillis) {
            stop(server, "Resultados entregados");
            return;
        }
        if (active != null && ticks % HUD_INTERVAL_TICKS == 0) refreshHud(server);
    }

    private static void beginRunning(MinecraftServer server) {
        if (active == null) return;
        if (active.participants.isEmpty()) { stop(server, "No hubo participantes"); return; }
        active.phase = Phase.RUNNING;
        active.startedEpochMillis = System.currentTimeMillis();
        active.phaseEndEpochMillis = active.startedEpochMillis + active.type.defaultDurationSeconds * 1000L;
        server.getPlayerManager().broadcast(Text.literal("§d✦ " + active.type.displayName + " §fHA COMENZADO §d✦"), false);
        if (active.type == ChainaEventType.BEAUTY) startBeautyRound(server, 1);
        if (active.type == ChainaEventType.TREASURE) {
            boolean prepared;
            try {
                prepared = TreasureHuntService.start(server, active.test);
            } catch (Exception e) {
                Chainacobblemon.LOGGER.error("Treasure Hunt failed to prepare safely; cancelling event instead of crashing the server", e);
                TreasureHuntService.cleanup(server, true);
                prepared = false;
            }
            if (!prepared) {
                finish(server, "No se pudo preparar una estructura compatible");
                return;
            }
        }
        refreshHud(server);
    }

    private static void onCapture(PokemonCapturedEvent event) {
        Active a = active;
        if (a == null || a.phase != Phase.RUNNING || (a.type != ChainaEventType.SAFARI && a.type != ChainaEventType.FISHING)) return;
        Object pokemonValue = reflected(event, "getPokemon");
        Pokemon pokemon = pokemonValue instanceof Pokemon p ? p : null;
        ServerPlayerEntity player = reflectedPlayer(event, pokemon);
        if (player == null || pokemon == null) return;
        Participant p = a.participants.get(player.getUuid());
        if (p == null || p.eliminated) return;
        boolean fishing = a.type == ChainaEventType.FISHING;
        if (fishing && !consumeFishingEncounter(player, pokemon)) {
            Chainacobblemon.LOGGER.debug("Fishing event ignored non-fished capture {} by {}", pokemon.getUuid(), player.getName().getString());
            return;
        }
        PokemonEventMetrics.Result result = PokemonEventMetrics.score(pokemon, fishing);
        boolean wasTop = leaderId() != null && leaderId().equals(player.getUuid());
        p.active = true;
        // FishingMinigameService already sends the complete Pokémon/score breakdown in normal chat.
        // Keep Safari's compact actionbar, but avoid duplicating Fishing information.
        if (!fishing) player.sendMessage(Text.literal("§a🌿 " + result.compactDetail() + " §7· §e" + result.score() + " pts"), true);
        if (result.score() > p.score) {
            p.score = result.score();
            p.detail = result.compactDetail();
            p.bestPokemon = result.displayName();
            p.lastUpdateEpochMillis = System.currentTimeMillis();
            boolean topNow = leaderId() != null && leaderId().equals(player.getUuid());
            if (topNow && !wasTop) announceNewTop(player, result);
            updateBestPersistent(player, a.type, result);
        }
    }

    private static void onPokerodReel(PokerodReelEvent event) {
        try {
            Active a = active;
            if (a == null || a.phase != Phase.RUNNING || a.type != ChainaEventType.FISHING) return;
            // PokerodReelEvent owns its player property (stable Kotlin accessor). We intentionally invoke it
            // reflectively because Cobblemon's published jar exposes Mojmap Minecraft classes while this mod
            // compiles against Yarn. The event is fired synchronously immediately before bobber.retrieve().
            Object playerObject = reflected(event, "getPlayer");
            if (!(playerObject instanceof ServerPlayerEntity player)) return;
            Participant participant = a.participants.get(player.getUuid());
            if (participant == null || participant.eliminated) return;
            RECENT_REEL = new RecentReel(player.getUuid(), System.nanoTime());
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not register Pokerod reel owner: {}", exception.toString());
        }
    }

    private static void onFishedSpawn(BobberSpawnPokemonEvent.Post event) {
        try {
            Active a = active;
            if (a == null || a.phase != Phase.RUNNING || a.type != ChainaEventType.FISHING) return;

            // Cobblemon fires BOBBER_SPAWN_POKEMON_POST from inside the same synchronous retrieve() call
            // that follows POKEROD_REEL. Using that reel event avoids reflecting FishingHook#getOwner, whose
            // runtime Minecraft method name is mapping-sensitive on Fabric.
            RecentReel reel = RECENT_REEL;
            if (reel == null || System.nanoTime() - reel.nanoTime() > 3_000_000_000L) return;
            ServerPlayerEntity player = a.serverHint == null ? null : a.serverHint.getPlayerManager().getPlayer(reel.playerId());
            if (player == null) return;
            Participant participant = a.participants.get(player.getUuid());
            if (participant == null || participant.eliminated) return;

            Object entityObject = reflected(event, "getPokemon");
            Object pokemonObject = reflected(entityObject, "getPokemon");
            if (!(pokemonObject instanceof Pokemon pokemon)) return;

            UUID entityId = reflectedUuid(entityObject);
            String species = pokemon.getSpecies().showdownId().toLowerCase(Locale.ROOT);
            long now = System.currentTimeMillis();
            List<FishingEncounter> encounters = FISHING_ENCOUNTERS.computeIfAbsent(player.getUuid(), ignored -> new ArrayList<>());
            encounters.removeIf(encounter -> now - encounter.createdAt() > FISHING_ENCOUNTER_TTL_MS);
            encounters.add(new FishingEncounter(pokemon.getUuid(), entityId, species, now));
            while (encounters.size() > 12) encounters.remove(0);
            Chainacobblemon.LOGGER.info("Fishing encounter registered from Cobblemon reel: player={} pokemon={} entity={} species={}",
                    player.getName().getString(), pokemon.getUuid(), entityId, species);
            RECENT_REEL = null;
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not register Cobblemon fishing encounter: {}", exception.toString());
        }
    }

    private static UUID reflectedUuid(Object entity) {
        Object value = reflected(entity, "getUuid", "getUUID");
        return value instanceof UUID uuid ? uuid : null;
    }

    private static boolean consumeFishingEncounter(ServerPlayerEntity player, Pokemon pokemon) {
        List<FishingEncounter> encounters = FISHING_ENCOUNTERS.get(player.getUuid());
        if (encounters == null || encounters.isEmpty()) return false;
        long now = System.currentTimeMillis();
        encounters.removeIf(encounter -> now - encounter.createdAt() > FISHING_ENCOUNTER_TTL_MS);
        if (encounters.isEmpty()) { FISHING_ENCOUNTERS.remove(player.getUuid()); return false; }
        for (int i = encounters.size() - 1; i >= 0; i--) {
            FishingEncounter encounter = encounters.get(i);
            if (encounter.pokemonId().equals(pokemon.getUuid())) {
                encounters.remove(i);
                if (encounters.isEmpty()) FISHING_ENCOUNTERS.remove(player.getUuid());
                return true;
            }
        }
        // Cobblemon may move the caught Pokémon between entity/storage contexts before POKEMON_CAPTURED.
        // The Post event is still authoritative that this species came from this player's bobber, so use a
        // short-lived species fallback only for the same participant and consume it exactly once.
        String species = pokemon.getSpecies().showdownId().toLowerCase(Locale.ROOT);
        for (int i = encounters.size() - 1; i >= 0; i--) {
            FishingEncounter encounter = encounters.get(i);
            if (!encounter.speciesId().equals(species)) continue;
            encounters.remove(i);
            if (encounters.isEmpty()) FISHING_ENCOUNTERS.remove(player.getUuid());
            return true;
        }
        return false;
    }

    private static void pruneFishingEncounters(long now) {
        FISHING_ENCOUNTERS.entrySet().removeIf(entry -> {
            entry.getValue().removeIf(encounter -> now - encounter.createdAt() > FISHING_ENCOUNTER_TTL_MS);
            return entry.getValue().isEmpty();
        });
    }

    private static void onMine(ServerPlayerEntity player, BlockState state) {
        Active a = active;
        if (a == null || a.phase != Phase.RUNNING || a.type != ChainaEventType.MINING) return;
        Participant p = a.participants.get(player.getUuid());
        if (p == null) return;
        Identifier id = Registries.BLOCK.getId(state.getBlock());
        int points = miningPoints(id);
        if (points <= 0) return;
        UUID before = leaderId();
        p.score += points;
        p.active = true;
        p.detail = prettyBlock(id) + " +" + points;
        p.lastUpdateEpochMillis = System.currentTimeMillis();
        UUID after = leaderId();
        if (after != null && after.equals(player.getUuid()) && !after.equals(before)) {
            player.getServer().getPlayerManager().broadcast(Text.literal("§6🏆 ¡NUEVO TOP 1! §f" + player.getName().getString()
                    + " §7· §e" + p.score + " puntos §7(" + p.detail + ")"), false);
        }
    }

    private static int miningPoints(Identifier id) {
        if (id == null) return 0;
        String p = id.getPath();
        if (p.contains("ancient_debris")) return 100;
        if (p.contains("diamond_ore")) return 40;
        if (p.contains("emerald_ore")) return 55;
        if (p.contains("gold_ore")) return 10;
        if (p.contains("lapis_ore")) return 8;
        if (p.contains("redstone_ore")) return 6;
        if (p.contains("iron_ore")) return 5;
        if (p.contains("copper_ore")) return 3;
        if (p.contains("coal_ore")) return 2;
        return p.endsWith("_ore") ? 5 : 0;
    }

    public static void beautyMove(ServerPlayerEntity player, String moveId) {
        Active a = active;
        if (player == null || a == null || a.phase != Phase.RUNNING || a.type != ChainaEventType.BEAUTY) return;
        Participant p = a.participants.get(player.getUuid());
        if (p == null || p.eliminated || p.roundDone) return;
        long now = System.currentTimeMillis();
        if (now < a.beautyRevealUntil || now > a.beautyResponseUntil) return;
        p.active = true;
        String expected = a.beautySequence.get(Math.min(p.beautyIndex, a.beautySequence.size() - 1));
        if (!expected.equals(moveId)) {
            loseBeautyLife(player, p, "Secuencia incorrecta");
            p.roundDone = true;
            return;
        }
        p.beautyIndex++;
        if (p.beautyIndex >= a.beautySequence.size()) {
            p.roundDone = true;
            p.score += 100L + a.beautyRound * 20L;
            p.detail = "Ronda " + a.beautyRound + " · " + hearts(p.lives);
            player.sendMessage(Text.literal("§a✓ Secuencia perfecta · ronda " + a.beautyRound), true);
        }
    }

    private static void beautyTick(MinecraftServer server, long now) {
        if (active == null || active.type != ChainaEventType.BEAUTY) return;
        if (now > active.beautyResponseUntil && !active.beautyRoundResolved) {
            active.beautyRoundResolved = true;
            for (Participant p : active.participants.values()) {
                if (p.eliminated || p.roundDone) continue;
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(p.playerId);
                if (player != null) loseBeautyLife(player, p, "Se acabó el tiempo");
                p.roundDone = true;
            }
            active.nextBeautyRoundAt = now + 1_800L;
        }
        long alive = active.participants.values().stream().filter(p -> !p.eliminated).count();
        if (active.test && alive == 0 && active.beautyRound >= 1) {
            finish(server, "Prueba Beauty finalizada: sin vidas");
            return;
        }
        if (!active.test && alive <= 1 && active.beautyRound >= 1) {
            finish(server, "Último concursante en pie");
            return;
        }
        if (active.beautyRoundResolved && now >= active.nextBeautyRoundAt) {
            if (active.beautyRound >= 20) { finish(server, "Ronda máxima alcanzada"); return; }
            startBeautyRound(server, active.beautyRound + 1);
        }
    }

    private static void startBeautyRound(MinecraftServer server, int round) {
        if (active == null) return;
        active.beautyRound = round;
        active.beautySequence.add(BEAUTY_MOVES[ThreadLocalRandom.current().nextInt(BEAUTY_MOVES.length)]);
        long revealDuration = Math.max(1_600L, active.beautySequence.size() * Math.max(550L, 1_450L - round * 55L));
        long now = System.currentTimeMillis();
        active.beautyRevealUntil = now + revealDuration;
        active.beautyResponseUntil = active.beautyRevealUntil + Math.max(4_000L, active.beautySequence.size() * 1_300L + 2_000L);
        active.beautyRoundResolved = false;
        for (Participant p : active.participants.values()) {
            p.roundDone = p.eliminated;
            p.beautyIndex = 0;
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(p.playerId);
            if (player == null) continue;
            BeautyRoundSnapshot snapshot = new BeautyRoundSnapshot();
            snapshot.round = round;
            snapshot.lives = p.lives;
            snapshot.eliminated = p.eliminated;
            snapshot.revealUntilEpochMillis = active.beautyRevealUntil;
            snapshot.responseUntilEpochMillis = active.beautyResponseUntil;
            snapshot.message = p.eliminated ? "Eliminado" : "Memoriza la secuencia y repítela";
            snapshot.sequence = new ArrayList<>(active.beautySequence);
            snapshot.options = List.of(BEAUTY_LABELS);
            EventNetworking.openBeauty(player, snapshot);
        }
        server.getPlayerManager().broadcast(Text.literal("§d✨ Exhibición Chaina · §fRONDA " + round + " §7· secuencia de " + active.beautySequence.size()), false);
    }

    private static void loseBeautyLife(ServerPlayerEntity player, Participant p, String reason) {
        p.lives = Math.max(0, p.lives - 1);
        p.errors++;
        p.detail = "Ronda " + active.beautyRound + " · " + hearts(p.lives);
        if (p.lives <= 0) {
            p.eliminated = true;
            player.sendMessage(Text.literal("§c✖ ELIMINADO · " + reason), false);
        } else player.sendMessage(Text.literal("§c✖ " + reason + " · " + hearts(p.lives)), false);
    }

    public static void onTreasureProgress(ServerPlayerEntity player, int room, int total) {
        if (player == null || active == null || active.type != ChainaEventType.TREASURE || active.phase != Phase.RUNNING) return;
        Participant p = active.participants.get(player.getUuid());
        if (p == null) return;
        p.active = true;
        p.treasureRoom = Math.max(p.treasureRoom, room);
        p.score = Math.max(p.score, room * 1000L + (System.currentTimeMillis() - active.startedEpochMillis) / -1000L);
        p.detail = "Sala " + room + "/" + total;
        if (room >= total) player.getServer().getPlayerManager().broadcast(Text.literal("§6⚠ ¡" + player.getName().getString() + " está cerca del tesoro!"), false);
    }

    public static boolean claimTreasure(ServerPlayerEntity player) {
        if (player == null || active == null || active.type != ChainaEventType.TREASURE || active.phase != Phase.RUNNING) return false;
        Participant p = active.participants.get(player.getUuid());
        if (p == null || !TreasureHuntService.canClaim(player)) return false;
        if (active.treasureWinner != null) return false;
        active.treasureWinner = player.getUuid();
        p.active = true;
        p.score = Long.MAX_VALUE / 4;
        p.detail = "🏆 TESORO ENCONTRADO";
        player.getServer().getPlayerManager().broadcast(Text.literal("§6🏆 ¡TESORO ENCONTRADO! §f" + player.getName().getString()
                + " §eabrió primero el Tesoro Chaina."), false);
        TreasureHuntService.animateClaim(player);
        active.phaseEndEpochMillis = Math.min(active.phaseEndEpochMillis, System.currentTimeMillis() + 4_500L);
        return true;
    }

    private static void finish(MinecraftServer server, String reason) {
        if (active == null || active.phase == Phase.RESULTS) return;
        active.phase = Phase.RESULTS;
        active.phaseEndEpochMillis = System.currentTimeMillis() + 10_000L;
        List<Participant> ranking = ranking();
        server.getPlayerManager().broadcast(Text.literal("§d✦ RESULTADOS · " + active.type.displayName + " §d✦"), false);
        int rank = 0;
        for (Participant p : ranking) {
            rank++;
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(p.playerId);
            if (rank <= 3) server.getPlayerManager().broadcast(Text.literal(placeSymbol(rank) + " §f" + p.name + " §7· §e" + scoreLabel(p)), false);
            if (player != null && !active.test) {
                updateEventStats(player, p, rank);
                EventRewardService.rewardPlace(player, active.type, rank, p.active);
            } else if (player != null) {
                player.sendMessage(Text.literal("§7[TEST] Sin recompensas ni estadísticas persistentes."), false);
            }
        }
        // Do not teleport/clear Treasure here. The winner roulette is opened above and needs a stable
        // world for its full animation. stop() runs after the results phase and performs the safe return.
        refreshHud(server);
    }

    private static void updateEventStats(ServerPlayerEntity player, Participant p, int place) {
        PlayerData d = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        d.events.totalParticipations++;
        if (place == 1) { d.events.totalWins++; d.events.winsByType.merge(active.type.id, 1L, Long::sum); }
        d.events.bestScoreByType.merge(active.type.id, p.score, Math::max);
        if (active.type == ChainaEventType.BEAUTY) d.events.bestBeautyRound = Math.max(d.events.bestBeautyRound, active.beautyRound);
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
    }

    private static void updateBestPersistent(ServerPlayerEntity player, ChainaEventType type, PokemonEventMetrics.Result r) {
        PlayerData d = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        long before = d.events.bestScoreByType.getOrDefault(type.id, 0L);
        if (r.score() > before) {
            d.events.bestScoreByType.put(type.id, r.score());
            if (type == ChainaEventType.FISHING) d.events.bestFishingPokemon = r.compactDetail();
            if (type == ChainaEventType.SAFARI) d.events.bestSafariPokemon = r.compactDetail();
            Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        }
    }

    private static void announceNewTop(ServerPlayerEntity player, PokemonEventMetrics.Result r) {
        player.getServer().getPlayerManager().broadcast(Text.literal("§6🏆 ¡NUEVO TOP 1! §f" + player.getName().getString()
                + " §7· §d" + r.displayName() + " §7· §e" + r.score() + " pts §7· " + r.compactDetail()), false);
    }

    private static void refreshHud(MinecraftServer server) {
        if (active == null) return;
        for (UUID id : new HashSet<>(active.participants.keySet())) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(id);
            if (player != null) sendHudTo(player);
        }
    }

    private static void sendHudTo(ServerPlayerEntity player) {
        if (active == null || player == null) return;
        EventHudSnapshot s = new EventHudSnapshot();
        s.visible = true;
        s.eventId = active.type.id;
        s.title = active.type.displayName;
        s.subtitle = switch (active.phase) {
            case JOINING -> "Inscripciones abiertas";
            case RUNNING -> active.type == ChainaEventType.BEAUTY ? "Ronda " + active.beautyRound : "Ranking en vivo";
            case RESULTS -> "Resultados finales";
            default -> "";
        };
        s.timer = formatTime(Math.max(0L, active.phaseEndEpochMillis - System.currentTimeMillis()));
        s.footer = switch (active.type) {
            case FISHING -> "Cuenta tu mejor Pokémon pescado";
            case SAFARI -> "Cuenta tu mejor captura";
            case BEAUTY -> "3 vidas · repite la secuencia";
            case MINING -> "Los minerales raros valen más";
            case TREASURE -> TreasureHuntService.hudFooter();
        };
        List<Participant> list = ranking();
        for (int i = 0; i < Math.min(5, list.size()); i++) {
            Participant p = list.get(i);
            s.entries.add(new EventHudSnapshot.Entry(i + 1, p.name, scoreLabel(p), p.detail, p.playerId.equals(player.getUuid())));
        }
        EventNetworking.sendHud(player, s);
    }

    private static List<Participant> ranking() {
        if (active == null) return List.of();
        List<Participant> list = new ArrayList<>(active.participants.values());
        Comparator<Participant> comparator;
        if (active.type == ChainaEventType.BEAUTY) comparator = Comparator
                .comparing((Participant p) -> p.eliminated)
                .thenComparing((Participant p) -> -p.lives)
                .thenComparingInt(p -> p.errors)
                .thenComparingLong(p -> -p.score);
        else if (active.type == ChainaEventType.TREASURE) comparator = Comparator
                .comparing((Participant p) -> active.treasureWinner == null || !active.treasureWinner.equals(p.playerId))
                .thenComparing((Participant p) -> -p.treasureRoom)
                .thenComparingLong(p -> p.lastUpdateEpochMillis);
        else comparator = Comparator.comparingLong((Participant p) -> p.score).reversed().thenComparing(p -> p.name);
        list.sort(comparator);
        return list;
    }

    private static UUID leaderId() {
        List<Participant> list = ranking();
        return list.isEmpty() || list.get(0).score <= 0 ? null : list.get(0).playerId;
    }

    private static String scoreLabel(Participant p) {
        if (active == null) return Long.toString(p.score);
        return switch (active.type) {
            case BEAUTY -> hearts(p.lives) + " · R" + active.beautyRound;
            case TREASURE -> active.treasureWinner != null && active.treasureWinner.equals(p.playerId) ? "GANADOR" : "Sala " + p.treasureRoom + "/" + TreasureHuntService.trainerCount();
            default -> p.score + " pts";
        };
    }

    private static void broadcastInvite(MinecraftServer server, ChainaEventType type, int seconds) {
        MutableText join = Text.literal(" [ ✦ UNIRSE ✦ ] ").formatted(Formatting.BLACK, Formatting.BOLD)
                .setStyle(Style.EMPTY.withColor(0xFF79B8)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/chainacobblemon event join"))
                        .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal("Entrar al Evento Chaina"))));
        MutableText msg = Text.literal("\n§d━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§f" + type.displayName + "\n§7Inscripciones durante §f" + seconds + "s§7. Todo ocurre en el mundo normal.\n")
                .append(join).append(Text.literal("\n§d━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        server.getPlayerManager().broadcast(msg, false);
    }

    private static ChainaEventType randomAutomaticType() {
        // Hard bad-luck protection: no event type may be skipped for more than four automatic cycles.
        int worst = AUTO_DROUGHT.values().stream().mapToInt(Integer::intValue).max().orElse(0);
        if (worst >= 4) {
            List<ChainaEventType> overdue = new ArrayList<>();
            for (ChainaEventType type : ChainaEventType.values()) if (AUTO_DROUGHT.getOrDefault(type, 0) == worst) overdue.add(type);
            return overdue.get(ThreadLocalRandom.current().nextInt(overdue.size()));
        }
        int total = 0;
        for (ChainaEventType type : ChainaEventType.values()) {
            int drought = AUTO_DROUGHT.getOrDefault(type, 0);
            total += type.autoWeight + drought * 3;
        }
        int roll = ThreadLocalRandom.current().nextInt(Math.max(1, total));
        for (ChainaEventType type : ChainaEventType.values()) {
            roll -= type.autoWeight + AUTO_DROUGHT.getOrDefault(type, 0) * 3;
            if (roll < 0) return type;
        }
        return ChainaEventType.FISHING;
    }

    private static void recordAutomatic(ChainaEventType selected) {
        for (ChainaEventType type : ChainaEventType.values()) {
            AUTO_DROUGHT.put(type, type == selected ? 0 : AUTO_DROUGHT.getOrDefault(type, 0) + 1);
        }
        RECENT_AUTOMATIC.addLast(selected);
        while (RECENT_AUTOMATIC.size() > 5) RECENT_AUTOMATIC.removeFirst();
    }

    private static void scheduleNextAuto() {
        long min = 60L * 60L * 1000L;
        long spread = 30L * 60L * 1000L;
        nextAutomaticEpochMillis = System.currentTimeMillis() + min + ThreadLocalRandom.current().nextLong(spread + 1L);
    }

    private static String prettyBlock(Identifier id) {
        if (id == null) return "Mineral";
        String s = id.getPath().replace("deepslate_", "").replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
    private static String formatTime(long millis) { long s = Math.max(0L, millis / 1000L); return String.format(Locale.ROOT, "%02d:%02d", s / 60L, s % 60L); }
    private static String hearts(int lives) { return "❤".repeat(Math.max(0, lives)) + "♡".repeat(Math.max(0, 3 - lives)); }
    private static String placeSymbol(int place) { return place == 1 ? "§6🥇" : place == 2 ? "§7🥈" : "§c🥉"; }

    private static ServerPlayerEntity reflectedPlayer(Object event, Pokemon pokemon) {
        Object value = reflected(event, "getPlayer", "getOwner", "getFisher");
        if (value instanceof ServerPlayerEntity sp) return sp;
        if (pokemon != null && pokemon.getOwnerUUID() != null && active != null) {
            for (Participant p : active.participants.values()) {
                if (p.playerId.equals(pokemon.getOwnerUUID())) {
                    MinecraftServer server = active.serverHint;
                    if (server != null) return server.getPlayerManager().getPlayer(p.playerId);
                }
            }
        }
        return null;
    }
    private static Object reflected(Object target, String... methods) {
        if (target == null) return null;
        for (String name : methods) try {
            Method m = target.getClass().getMethod(name); m.setAccessible(true); Object r = m.invoke(target); if (r != null) return r;
        } catch (Throwable ignored) { }
        return null;
    }

    private record FishingEncounter(UUID pokemonId, UUID entityId, String speciesId, long createdAt) { }
    private record RecentReel(UUID playerId, long nanoTime) { }

    private static final class Active {
        final ChainaEventType type;
        Phase phase;
        final long announcedEpochMillis;
        long startedEpochMillis;
        long phaseEndEpochMillis;
        final boolean test;
        boolean automatic;
        final Map<UUID, Participant> participants = new LinkedHashMap<>();
        final List<String> beautySequence = new ArrayList<>();
        int beautyRound;
        long beautyRevealUntil;
        long beautyResponseUntil;
        long nextBeautyRoundAt;
        boolean beautyRoundResolved;
        UUID treasureWinner;
        MinecraftServer serverHint;
        Active(ChainaEventType type, Phase phase, long announced, long end, boolean test) {
            this.type = type; this.phase = phase; this.announcedEpochMillis = announced; this.phaseEndEpochMillis = end; this.test = test;
        }
    }

    private static final class Participant {
        final UUID playerId;
        final String name;
        long score;
        String detail = "Esperando...";
        String bestPokemon = "";
        boolean active;
        boolean online = true;
        int lives = 3;
        int errors;
        int beautyIndex;
        boolean roundDone;
        boolean eliminated;
        int treasureRoom;
        long lastUpdateEpochMillis;
        Participant(UUID playerId, String name) { this.playerId = playerId; this.name = name; }
    }
}
