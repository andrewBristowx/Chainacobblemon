package com.andrewbristowx.chainacobblemon.client.progress;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.LongSupplier;

/** Inventory shortcut that exposes the synchronized ChaiBell balance on hover. */
final class ChaiBellsButton extends ButtonWidget {
    private final LongSupplier balance;

    ChaiBellsButton(int x, int y, Runnable action, LongSupplier balance) {
        super(x, y, 22, 24, Text.literal("ChaiBells"), button -> action.run(), DEFAULT_NARRATION_SUPPLIER);
        this.balance = balance;
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        int x = getX(), y = getY();
        boolean hi = isHovered();
        context.fill(x + 2, y + 3, x + width + 2, y + height + 3, 0x72000000);
        context.fill(x, y, x + width, y + height, hi ? 0xFFF6AD4B : 0xFFF9556D);
        context.fill(x + 1, y + 1, x + width - 1, y + height - 1, 0xFF292A2E);
        context.fill(x + 2, y + 2, x + width - 2, y + 4, hi ? 0xFFFDC7CB : 0xFFFB9AA6);
        drawCoin(context, x + 4, y + 5, hi);
        if (isHovered()) {
            long current = balance.getAsLong();
            Text tooltip = current >= 0 ? Text.literal("Saldo: " + current + " ChaiBells") : Text.literal("Sincronizando ChaiBells…");
            context.drawTooltip(MinecraftClient.getInstance().textRenderer, tooltip, mouseX, mouseY);
        }
    }

    private static void drawCoin(DrawContext c, int x, int y, boolean hi) {
        int gold = hi ? 0xFFFFD469 : 0xFFF6AD4B, light = 0xFFFFE5A8, coral = 0xFFF9556D, dark = 0xFF5A3037;
        c.fill(x+3,y,x+11,y+1,light); c.fill(x+1,y+2,x+13,y+13,gold); c.fill(x,y+4,x+14,y+11,gold);
        c.fill(x+3,y+14,x+11,y+15,dark); c.fill(x+3,y+3,x+11,y+12,0xFFE99A36);
        // Chaina bell stamp for the server currency.
        c.fill(x+5,y+4,x+9,y+5,coral); c.fill(x+4,y+5,x+10,y+10,coral); c.fill(x+3,y+9,x+11,y+11,coral);
        c.fill(x+6,y+11,x+8,y+13,dark); c.fill(x+6,y+3,x+8,y+4,light);
    }
}
