package com.andrewbristowx.chainacobblemon.client.gacha;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.gacha.GachaNetworking.GachaActionPayload;
import com.andrewbristowx.chainacobblemon.gacha.GachaNetworking.GachaView;
import com.andrewbristowx.chainacobblemon.gacha.GachaNetworking.OpenGachaPayload;
import com.andrewbristowx.chainacobblemon.gacha.GachaNetworking.SeasonalDisplayPayload;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineBlockEntity;
import net.minecraft.util.math.BlockPos;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public final class GachaClient {
    private static final Gson GSON = new Gson();

    private GachaClient() { }

    public static void initialize() {
        ClientPlayNetworking.registerGlobalReceiver(OpenGachaPayload.ID, (payload, context) ->
                context.client().execute(() -> open(payload.json())));
        ClientPlayNetworking.registerGlobalReceiver(SeasonalDisplayPayload.ID, (payload, context) ->
                context.client().execute(() -> applySeasonalDisplay(payload)));
    }

    private static void applySeasonalDisplay(SeasonalDisplayPayload payload) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        BlockPos pos = BlockPos.fromLong(payload.blockPos());
        if (client.world.getBlockEntity(pos) instanceof GachaMachineBlockEntity machine) {
            machine.applyClientFeaturedPokemon(payload.speciesId(), payload.name());
        }
    }

    static void pull(long blockPos, int count) {
        if (ClientPlayNetworking.canSend(GachaActionPayload.ID))
            ClientPlayNetworking.send(new GachaActionPayload(blockPos, count));
    }

    private static void open(String json) {
        try {
            GachaView view = GSON.fromJson(json, GachaView.class);
            if (view == null) return;
            MinecraftClient client = MinecraftClient.getInstance();
            Screen current = client.currentScreen;
            Screen parent = current instanceof GachaScreen gacha ? gacha.parent() : current;
            client.setScreen(new GachaScreen(parent, view));
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not open gacha screen", exception);
        }
    }
}
