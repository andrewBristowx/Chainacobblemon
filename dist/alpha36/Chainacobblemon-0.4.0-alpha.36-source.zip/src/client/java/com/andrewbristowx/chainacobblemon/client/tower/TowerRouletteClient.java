package com.andrewbristowx.chainacobblemon.client.tower;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.tower.TowerRouletteNetworking.OpenTowerRoulettePayload;
import com.andrewbristowx.chainacobblemon.tower.TowerRouletteSnapshot;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public final class TowerRouletteClient {
    private static final Gson GSON = new Gson();

    private TowerRouletteClient() { }

    public static void initialize() {
        ClientPlayNetworking.registerGlobalReceiver(OpenTowerRoulettePayload.ID, (payload, context) ->
                context.client().execute(() -> open(payload.json())));
    }

    private static void open(String json) {
        try {
            TowerRouletteSnapshot snapshot = GSON.fromJson(json, TowerRouletteSnapshot.class);
            if (snapshot == null || snapshot.selected == null) return;
            MinecraftClient client = MinecraftClient.getInstance();
            Screen parent = client.currentScreen instanceof TowerRouletteScreen roulette ? roulette.parent() : client.currentScreen;
            client.setScreen(new TowerRouletteScreen(parent, snapshot));
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not open Tower roulette", exception);
        }
    }
}
