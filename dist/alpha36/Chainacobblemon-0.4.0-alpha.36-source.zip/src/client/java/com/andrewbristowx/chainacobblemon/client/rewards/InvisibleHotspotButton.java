package com.andrewbristowx.chainacobblemon.client.rewards;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Clickable area for arrows and close ornaments that are already painted into a GUI background. */
final class InvisibleHotspotButton extends ButtonWidget {
    InvisibleHotspotButton(int x, int y, int width, int height, Text narration, PressAction action) {
        super(x, y, width, height, narration, action, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        // The generated GUI owns the visible arrow/X. Keeping this empty avoids duplicate rectangles and glyphs.
    }
}
