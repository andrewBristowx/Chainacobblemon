package com.andrewbristowx.chainacobblemon.client.render;

import com.andrewbristowx.chainacobblemon.client.model.ChainaToolGeoModel;
import com.andrewbristowx.chainacobblemon.tools.ChainaGeoToolItem;
import net.minecraft.item.Item;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/** Client-only GeckoLib item renderer shared by all five Chaina tools. */
public final class ChainaToolGeoRenderer<T extends Item & ChainaGeoToolItem> extends GeoItemRenderer<T> {
    public ChainaToolGeoRenderer(String toolId) {
        super(new ChainaToolGeoModel<>(toolId));
    }
}
