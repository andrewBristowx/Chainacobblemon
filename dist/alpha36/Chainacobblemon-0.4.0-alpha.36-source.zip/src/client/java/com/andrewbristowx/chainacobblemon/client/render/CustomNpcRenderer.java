package com.andrewbristowx.chainacobblemon.client.render;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeCatalog;
import com.andrewbristowx.chainacobblemon.client.visual.ClientVisualAssetCache;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

public final class CustomNpcRenderer extends MobEntityRenderer<ServiceNpcEntity, PlayerEntityModel<ServiceNpcEntity>> {
    private final Identifier fallback;

    public CustomNpcRenderer(EntityRendererFactory.Context context, boolean slim) {
        super(context, new PlayerEntityModel<>(
                context.getPart(slim ? EntityModelLayers.PLAYER_SLIM : EntityModelLayers.PLAYER), slim), 0.5f);
        this.fallback = Identifier.of(Chainacobblemon.MOD_ID,
                slim ? "textures/entity/nurse_npc.png" : "textures/entity/shop_npc.png");
    }

    @Override
    public Identifier getTexture(ServiceNpcEntity entity) {
        String npcId = entity.npcId();
        boolean dynamicTrainer = npcId.startsWith("tower_") || npcId.startsWith("treasure_") || npcId.startsWith("dng_");
        Identifier selectedFallback = dynamicTrainer
                ? RctTrainerTextureResolver.resolveTower(npcId, fallback)
                : RctTrainerTextureResolver.resolve(ChallengeCatalog.byNpcId(npcId), fallback);
        String key = "npc:" + entity.npcId();
        return ClientVisualAssetCache.has(key) ? ClientVisualAssetCache.texture(key, selectedFallback) : selectedFallback;
    }

}
