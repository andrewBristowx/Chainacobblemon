package com.andrewbristowx.chainacobblemon.client.twitch;

import com.andrewbristowx.chainacobblemon.client.visual.ClientVisualAssetCache;
import com.andrewbristowx.chainacobblemon.twitch.TwitchSnapshot;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Adds two Chaina Twitch emotes around the Styled Player List title. */
public final class ChainaTabDecoration {
    private static final String CUTE = "media:chaina_tab_cute";
    private static final String AWA = "media:chaina_tab_awa";
    private static final Identifier FALLBACK = Identifier.of("minecraft", "textures/misc/unknown_server.png");

    private ChainaTabDecoration() { }

    public static void initialize() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        TwitchSnapshot snapshot = TwitchClient.latest();
        if (client.player == null || client.options.hudHidden || snapshot == null || !snapshot.styledPlayerListIntegrated) return;
        if (!client.options.playerListKey.isPressed()) return;

        int size = 28;
        int centerX = context.getScaledWindowWidth() / 2;
        int y = 43;
        int spread = Math.min(220, Math.max(145, context.getScaledWindowWidth() / 5));
        draw(context, CUTE, centerX - spread - size / 2, y, size);
        draw(context, AWA, centerX + spread - size / 2, y, size);
    }

    private static void draw(DrawContext context, String key, int x, int y, int size) {
        if (!ClientVisualAssetCache.has(key)) return;
        Identifier texture = ClientVisualAssetCache.texture(key, FALLBACK);
        context.fill(x - 2, y - 2, x + size + 2, y + size + 2, 0x68200F2B);
        context.drawTexture(texture, x, y, size, size, 0.0F, 0.0F, 112, 112, 112, 112);
    }
}
