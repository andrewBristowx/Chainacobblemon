package com.andrewbristowx.chainacobblemon.client.twitch;

import com.andrewbristowx.chainacobblemon.twitch.TwitchSnapshot;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmLinkScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class TwitchScreen extends Screen {
    private final Screen parent;
    private TwitchSnapshot snapshot;
    private int linkPollTicks;

    TwitchScreen(Screen parent, TwitchSnapshot snapshot) {
        super(Text.literal("Chaina × Twitch"));
        this.parent = parent;
        this.snapshot = snapshot;
    }

    void update(TwitchSnapshot next) {
        this.snapshot = next;
        if (next.linked) linkPollTicks = 0;
        clearChildren();
        init();
    }

    private boolean linking() {
        return !snapshot.adminView && !snapshot.linked && snapshot.linkUrl != null && !snapshot.linkUrl.isBlank();
    }

    @Override
    public void tick() {
        super.tick();
        if (!linking()) return;
        linkPollTicks++;
        if (linkPollTicks % 40 == 0) TwitchClient.action("link_poll");
    }

    @Override
    protected void init() {
        if (snapshot.adminView) {
            initAdmin();
        } else {
            initLegacy();
        }
    }

    private void initAdmin() {
        int panelW = Math.min(430, width - 30);
        int x = (width - panelW) / 2;
        int y = Math.max(30, height / 2 - 145);
        int buttonY = y + 182;
        int gap = 6;
        int third = (panelW - gap * 2) / 3;
        int half = (panelW - gap) / 2;
        String id = snapshot.targetUuid == null ? "" : snapshot.targetUuid;

        ButtonWidget refresh = ButtonWidget.builder(Text.literal("Actualizar estado"), button -> TwitchClient.action("admin_sync:" + id))
                .dimensions(x, buttonY, third, 20).build();
        ButtonWidget unlink = ButtonWidget.builder(Text.literal("Desvincular"), button -> TwitchClient.action("admin_unlink:" + id))
                .dimensions(x + third + gap, buttonY, third, 20).build();
        unlink.active = snapshot.linked;
        ButtonWidget prompt = ButtonWidget.builder(Text.literal("Reenviar aviso"), button -> TwitchClient.action("admin_prompt:" + id))
                .dimensions(x + (third + gap) * 2, buttonY, third, 20).build();
        prompt.active = !snapshot.linked;
        addDrawableChild(refresh);
        addDrawableChild(unlink);
        addDrawableChild(prompt);

        addDrawableChild(ButtonWidget.builder(Text.literal("§dVer stream"), button -> openStream())
                .dimensions(x, buttonY + 27, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Copiar link"), button -> copyStreamLink())
                .dimensions(x + half + gap, buttonY + 27, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"), button -> close())
                .dimensions(x, buttonY + 54, panelW, 20).build());
    }

    private void initLegacy() {
        int panelW = Math.min(390, width - 30);
        int x = (width - panelW) / 2;
        int y = Math.max(35, height / 2 - 135);
        int buttonY = y + 170;
        int gap = 6;
        int third = (panelW - gap * 2) / 3;
        int half = (panelW - gap) / 2;

        String primary = snapshot.linked ? "Sincronizar" : (linking() ? "Comprobar ahora" : "Vincular Twitch");
        String action = snapshot.linked ? "sync" : (linking() ? "link_poll" : "link");
        addDrawableChild(ButtonWidget.builder(Text.literal(primary), button -> TwitchClient.action(action))
                .dimensions(x, buttonY, third, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Desvincular"), button -> TwitchClient.action("unlink"))
                .dimensions(x + third + gap, buttonY, third, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Actualizar"), button -> TwitchClient.action("status"))
                .dimensions(x + (third + gap) * 2, buttonY, third, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("§dVer stream"), button -> openStream())
                .dimensions(x, buttonY + 27, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Copiar link"), button -> copyStreamLink())
                .dimensions(x + half + gap, buttonY + 27, half, 20).build());

        int nextY = buttonY + 54;
        if (snapshot.linkUrl != null && !snapshot.linkUrl.isBlank()) {
            addDrawableChild(ButtonWidget.builder(Text.literal("§dAUTORIZAR EN TWITCH"), button -> openLink(snapshot.linkUrl))
                    .dimensions(x, nextY, half, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Copiar codigo"), button -> copyLinkCode())
                    .dimensions(x + half + gap, nextY, half, 20).build());
            nextY += 27;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"), button -> close())
                .dimensions(x, nextY, panelW, 20).build());
    }

    private String streamUrl() {
        String broadcaster = snapshot.broadcaster == null || snapshot.broadcaster.isBlank() ? "chainavt" : snapshot.broadcaster;
        return "https://twitch.tv/" + broadcaster;
    }

    private void openStream() {
        if (client == null) return;
        ConfirmLinkScreen.open(this, streamUrl(), false);
    }

    private void copyStreamLink() {
        if (client == null) return;
        client.keyboard.setClipboard(streamUrl());
    }

    private void openLink(String url) {
        if (client == null || url == null || url.isBlank()) return;
        ConfirmLinkScreen.open(this, url, false);
    }

    private void copyLinkCode() {
        if (client == null) return;
        String value = snapshot.linkCode == null || snapshot.linkCode.isBlank() ? snapshot.linkUrl : snapshot.linkCode;
        if (value != null && !value.isBlank()) client.keyboard.setClipboard(value);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Intentionally empty. render() draws our non-blurred dim layer instead.
    }

    @Override
    public void renderInGameBackground(DrawContext context) {
        // Intentionally empty. Avoid a second vanilla in-world background pass.
    }

    @Override
    protected void applyBlur(float delta) {
        // Intentionally empty. This screen must never activate the vanilla blur shader.
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0x22000000);
        if (snapshot.adminView) renderAdmin(context);
        else renderLegacy(context);
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderAdmin(DrawContext context) {
        int panelW = Math.min(430, width - 30);
        int x = (width - panelW) / 2;
        int y = Math.max(30, height / 2 - 145);
        int panelH = 286;
        context.fill(x - 10, y - 14, x + panelW + 10, y + panelH, 0xE6191020);
        context.fill(x - 10, y - 14, x + panelW + 10, y - 10, 0xFFFF72B6);
        context.drawCenteredTextWithShadow(textRenderer, "§d§lCHAiNA × TWITCH §f· §eADMIN", width / 2, y, 0xFFFF83C4);
        context.drawCenteredTextWithShadow(textRenderer,
                snapshot.channelOnline ? "§c● EN DIRECTO §f@" + snapshot.broadcaster : "§7● Offline §f@" + snapshot.broadcaster,
                width / 2, y + 22, 0xFFFFFFFF);

        String target = snapshot.targetName == null || snapshot.targetName.isBlank() ? "Desconocido" : snapshot.targetName;
        context.drawTextWithShadow(textRenderer, "§7Jugador: §f§l" + target, x, y + 48, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Cuenta Twitch: §f" + (snapshot.linked ? "@" + snapshot.twitchLogin : "No vinculada"), x, y + 64, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Suscripción: §f" + tierText(snapshot.tier), x, y + 80, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Rango Twitch: §d" + snapshot.rankLabel, x, y + 96, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Última sync: §f" + snapshot.lastSync, x, y + 112, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Modo: §f" + ("bridge".equalsIgnoreCase(snapshot.mode) ? "Twitch real (ChainaBridge)" : snapshot.mode), x, y + 128, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Canal: §d§n" + streamUrl().replace("https://", ""), x, y + 144, 0xFFFFFFFF);
        if (snapshot.message != null && !snapshot.message.isBlank()) {
            String text = snapshot.message.length() > 72 ? snapshot.message.substring(0, 71) + "…" : snapshot.message;
            context.drawTextWithShadow(textRenderer, "§b" + text, x, y + 162, 0xFFFFFFFF);
        }
    }

    private void renderLegacy(DrawContext context) {
        int panelW = Math.min(390, width - 30);
        int x = (width - panelW) / 2;
        int y = Math.max(35, height / 2 - 135);
        int panelH = snapshot.linkUrl != null && !snapshot.linkUrl.isBlank() ? 302 : 275;
        context.fill(x - 10, y - 14, x + panelW + 10, y + panelH, 0xE6191020);
        context.fill(x - 10, y - 14, x + panelW + 10, y - 10, 0xFFFF72B6);
        context.drawCenteredTextWithShadow(textRenderer, "§d§lCHAiNA × TWITCH", width / 2, y, 0xFFFF83C4);
        context.drawCenteredTextWithShadow(textRenderer,
                snapshot.channelOnline ? "§c● EN DIRECTO §f@" + snapshot.broadcaster : "§7● Offline §f@" + snapshot.broadcaster,
                width / 2, y + 22, 0xFFFFFFFF);

        context.drawTextWithShadow(textRenderer, "§7Modo: §f" + ("bridge".equalsIgnoreCase(snapshot.mode) ? "Twitch real (ChainaBridge)" : snapshot.mode), x, y + 48, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Cuenta: §f" + (snapshot.linked ? "@" + snapshot.twitchLogin : "No vinculada"), x, y + 64, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Suscripcion: §f" + tierText(snapshot.tier), x, y + 80, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Rango Twitch: §d" + snapshot.rankLabel, x, y + 96, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Ultima sync: §f" + snapshot.lastSync, x, y + 112, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "§7Canal: §d§n" + streamUrl().replace("https://", ""), x, y + 128, 0xFFFFFFFF);
        if (snapshot.linkCode != null && !snapshot.linkCode.isBlank()) {
            context.drawTextWithShadow(textRenderer, "§7Codigo: §e§l" + snapshot.linkCode, x, y + 144, 0xFFFFFFFF);
        }
        if (snapshot.message != null && !snapshot.message.isBlank()) {
            String text = snapshot.message.length() > 64 ? snapshot.message.substring(0, 63) + "…" : snapshot.message;
            context.drawTextWithShadow(textRenderer, "§b" + text, x, y + 160, 0xFFFFFFFF);
        }
    }

    private static String tierText(int tier) {
        return switch (tier) {
            case 3 -> "Tier 3";
            case 2 -> "Tier 2";
            case 1 -> "Tier 1";
            default -> "Sin sub";
        };
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
