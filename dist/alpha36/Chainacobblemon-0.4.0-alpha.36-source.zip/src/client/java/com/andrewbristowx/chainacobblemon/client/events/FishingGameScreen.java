package com.andrewbristowx.chainacobblemon.client.events;

import com.andrewbristowx.chainacobblemon.events.EventNetworking.FishingInputPayload;
import com.andrewbristowx.chainacobblemon.events.FishingGameSnapshot;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Stardew-like vertical fishing minigame driven by authoritative server snapshots. */
final class FishingGameScreen extends Screen {
    private static final int BG = 0xE817101E;
    private static final int PANEL = 0xF02B1D32;
    private static final int INNER = 0xF0372840;
    private static final int PINK = 0xFFFF79B8;
    private static final int GOLD = 0xFFFFD36A;
    private static final int TEXT = 0xFFF8F4FA;
    private static final int MUTED = 0xFFC9B9CF;
    private static final int GREEN = 0xFF8FF0AF;
    private static final int RED = 0xFFFF7777;

    private final Screen parent;
    private FishingGameSnapshot snapshot;
    private boolean held;
    private long completedAt;

    FishingGameScreen(Screen parent, FishingGameSnapshot snapshot) {
        super(Text.literal("Pesca Chaina"));
        this.parent = parent;
        this.snapshot = snapshot;
        if (snapshot != null && snapshot.completed) completedAt = System.currentTimeMillis();
    }

    String sessionId() { return snapshot == null ? "" : snapshot.sessionId; }

    void update(FishingGameSnapshot next) {
        if (next == null) return;
        boolean wasComplete = snapshot != null && snapshot.completed;
        this.snapshot = next;
        if (!wasComplete && next.completed) {
            completedAt = System.currentTimeMillis();
            setHeld(false);
        }
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        FishingGameSnapshot s = snapshot;
        if (s == null) { closeNow(); return; }
        if (s.completed && completedAt > 0L && System.currentTimeMillis() - completedAt > 1_850L) {
            closeNow();
            return;
        }

        c.fill(0, 0, width, height, BG);
        int pw = Math.min(650, Math.max(400, width - 46));
        int ph = Math.min(440, Math.max(300, height - 38));
        int x = (width - pw) / 2;
        int y = (height - ph) / 2;
        c.fill(x, y, x + pw, y + ph, PANEL);
        outline(c, x, y, pw, ph, s.completed ? (s.success ? GOLD : RED) : PINK, 3);

        c.drawCenteredTextWithShadow(textRenderer, Text.literal("✦ PESCA CHAINA ✦"), width / 2, y + 18, PINK);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(s.speciesName + "  §7·  " + s.difficultyLabel), width / 2, y + 38, TEXT);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(s.rodName + "  §7→  §f" + s.ballName), width / 2, y + 56, GOLD);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("§7" + s.effectLabel), width / 2, y + 73, MUTED);

        if (s.completed) {
            renderCompleted(c, s, x, y, pw, ph);
            super.render(c, mouseX, mouseY, delta);
            return;
        }

        int barH = Math.min(245, ph - 150);
        int barW = 86;
        int bx = width / 2 - barW / 2;
        int by = y + 96;
        c.fill(bx - 4, by - 4, bx + barW + 4, by + barH + 4, 0xFF16101C);
        c.fill(bx, by, bx + barW, by + barH, INNER);

        double zoneCenter = clamp(s.zonePosition, 0.0D, 1.0D);
        double zoneHeight = clamp(s.zoneHeight, 0.08D, 0.60D);
        int zonePixels = Math.max(18, (int)Math.round(barH * zoneHeight));
        int zoneCenterY = by + barH - (int)Math.round(zoneCenter * barH);
        int zy1 = Math.max(by, zoneCenterY - zonePixels / 2);
        int zy2 = Math.min(by + barH, zoneCenterY + zonePixels / 2);
        c.fill(bx + 5, zy1, bx + barW - 5, zy2, 0xAA55D98A);
        outline(c, bx + 5, zy1, barW - 10, Math.max(2, zy2 - zy1), GREEN, 1);

        int fishY = by + barH - (int)Math.round(clamp(s.fishPosition, 0.0D, 1.0D) * barH);
        c.fill(bx + 12, fishY - 7, bx + barW - 12, fishY + 7, 0xE8FF79B8);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("◆"), bx + barW / 2, fishY - 5, TEXT);

        int progX = bx + barW + 24;
        int progW = 18;
        c.fill(progX, by, progX + progW, by + barH, 0xFF16101C);
        int filled = (int)Math.round(barH * clamp(s.progress, 0.0D, 1.0D));
        c.fill(progX + 3, by + barH - filled + 3, progX + progW - 3, by + barH - 3, GOLD);
        c.drawTextWithShadow(textRenderer, Text.literal((int)Math.round(s.progress * 100.0D) + "%"), progX + 26, by + barH / 2 - 4, GOLD);

        drawBall(c, s.ballItemId, bx - 46, by + barH / 2, 34);
        long seconds = Math.max(0L, (s.endsAtEpochMillis - System.currentTimeMillis() + 999L) / 1000L);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Tiempo: " + seconds + "s"), width / 2, by + barH + 12, MUTED);
        c.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Mantén §fESPACIO§7 o §fCLIC§7 para subir · suelta para bajar"), width / 2, y + ph - 43, MUTED);
        c.drawCenteredTextWithShadow(textRenderer,
                Text.literal(held ? "§a▲ SUBIENDO" : "§d▼ BAJANDO"), width / 2, y + ph - 24, held ? GREEN : PINK);
        super.render(c, mouseX, mouseY, delta);
    }

    private void renderCompleted(DrawContext c, FishingGameSnapshot s, int x, int y, int pw, int ph) {
        int cx = width / 2;
        int cy = y + ph / 2 + 10;
        long elapsed = Math.max(0L, System.currentTimeMillis() - completedAt);
        float pulse = 1.0F + (float)Math.sin(elapsed / 95.0D) * 0.08F;
        int size = (int)(72 * pulse);
        drawBall(c, s.ballItemId, cx, cy - 18, size);
        c.drawCenteredTextWithShadow(textRenderer,
                Text.literal(s.success ? "★ ¡CAPTURADO! ★" : "¡ESCAPÓ!"), cx, cy + 45, s.success ? GOLD : RED);
        if (s.success) {
            c.drawCenteredTextWithShadow(textRenderer, Text.literal(s.speciesName + " · " + s.score + " pts"), cx, cy + 65, TEXT);
            c.drawCenteredTextWithShadow(textRenderer, Text.literal("Autocaptura: " + s.ballName), cx, cy + 82, MUTED);
        } else {
            String detail = s.resultDetail == null || s.resultDetail.isBlank() ? "La barra de captura llegó a cero." : s.resultDetail;
            c.drawCenteredTextWithShadow(textRenderer, Text.literal(detail), cx, cy + 66, MUTED);
        }
    }

    private void drawBall(DrawContext c, String itemId, int cx, int cy, int size) {
        Identifier id = Identifier.tryParse(itemId);
        Item item = id != null && Registries.ITEM.containsId(id) ? Registries.ITEM.get(id) : Items.PAPER;
        ItemStack stack = new ItemStack(item);
        float scale = Math.max(1.0F, size / 16.0F);
        c.getMatrices().push();
        c.getMatrices().translate(cx - 8.0F * scale, cy - 8.0F * scale, 200.0F);
        c.getMatrices().scale(scale, scale, 1.0F);
        c.drawItem(stack, 0, 0);
        c.getMatrices().pop();
    }

    private void setHeld(boolean value) {
        if (snapshot == null || snapshot.completed || held == value) return;
        held = value;
        ClientPlayNetworking.send(new FishingInputPayload(snapshot.sessionId, held, false));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_SPACE) {
            setHeld(true);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_SPACE) {
            setHeld(false);
            return true;
        }
        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setHeld(true);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setHeld(false);
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return snapshot != null && snapshot.completed;
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }

    private void closeNow() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void close() {
        if (snapshot != null && !snapshot.completed) {
            ClientPlayNetworking.send(new FishingInputPayload(snapshot.sessionId, false, true));
            return;
        }
        closeNow();
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private static void outline(DrawContext c, int x, int y, int w, int h, int color, int t) {
        c.fill(x, y, x + w, y + t, color);
        c.fill(x, y + h - t, x + w, y + h, color);
        c.fill(x, y, x + t, y + h, color);
        c.fill(x + w - t, y, x + w, y + h, color);
    }
}
