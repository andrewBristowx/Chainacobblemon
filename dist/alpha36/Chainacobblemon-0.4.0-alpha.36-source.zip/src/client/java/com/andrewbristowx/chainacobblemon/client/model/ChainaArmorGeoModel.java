package com.andrewbristowx.chainacobblemon.client.model;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.armor.ChainaGeoArmorItem;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

/** Single shared GeckoLib armor model for all four Chaina armor pieces. */
public final class ChainaArmorGeoModel extends GeoModel<ChainaGeoArmorItem> {
    private static final Identifier MODEL = Identifier.of(Chainacobblemon.MOD_ID, "geo/armor/chaina_armor.geo.json");
    private static final Identifier TEXTURE = Identifier.of(Chainacobblemon.MOD_ID, "textures/models/armor/chaina_gecko_armor.png");
    private static final Identifier ANIMATION = Identifier.of(Chainacobblemon.MOD_ID, "animations/armor/chaina_armor.animation.json");

    @Override public Identifier getModelResource(ChainaGeoArmorItem animatable) { return MODEL; }
    @Override public Identifier getTextureResource(ChainaGeoArmorItem animatable) { return TEXTURE; }
    @Override public Identifier getAnimationResource(ChainaGeoArmorItem animatable) { return ANIMATION; }
}
