package com.andrewbristowx.chainacobblemon.client.progress;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;

/** Inventory shortcut for the adventure journal, represented by Chaina's bell. */
final class QuestBookButton extends ButtonWidget {
    private final BooleanSupplier claimable;

    QuestBookButton(int x, int y, Runnable action, BooleanSupplier claimable) {
        super(x, y, 22, 24, Text.literal("Misiones"), button -> action.run(), DEFAULT_NARRATION_SUPPLIER);
        this.claimable = claimable;
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        int x = getX(), y = getY();
        boolean claim = claimable.getAsBoolean();
        boolean hi = isHovered() || claim;
        context.fill(x + 2, y + 3, x + width + 2, y + height + 3, 0x72000000);
        context.fill(x, y, x + width, y + height, hi ? 0xFFF6AD4B : 0xFFF9556D);
        context.fill(x + 1, y + 1, x + width - 1, y + height - 1, 0xFF292A2E);
        context.fill(x + 2, y + 2, x + width - 2, y + 4, hi ? 0xFFFDC7CB : 0xFFFB9AA6);
        drawBell(context, x + 3, y + 4, hi);
        if (claim) {
            context.fill(x + 14, y - 2, x + 23, y + 7, 0xFFF6AD4B);
            context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal("!"), x + 18, y - 1, 0xFF353434);
        }
        if (isHovered()) {
            String label = claim ? "Misiones — recompensa disponible" : "Abrir misiones";
            context.drawTooltip(MinecraftClient.getInstance().textRenderer, Text.literal(label), mouseX, mouseY);
        }
    }

    private static void drawBell(DrawContext c, int x, int y, boolean hi) {
        int gold = hi ? 0xFFFFD469 : 0xFFF6AD4B, light = 0xFFFFE7A8, coral = 0xFFF9556D, dark = 0xFF6A3B2B;
        // Bow/ribbon at the top.
        c.fill(x+2,y+1,x+6,y+4,coral); c.fill(x+10,y+1,x+14,y+4,coral); c.fill(x+6,y+2,x+10,y+5,coral);
        // Rounded gold bell body.
        c.fill(x+6,y,x+10,y+2,light); c.fill(x+4,y+4,x+12,y+6,gold); c.fill(x+3,y+6,x+13,y+11,gold);
        c.fill(x+2,y+10,x+14,y+13,gold); c.fill(x+4,y+13,x+12,y+14,dark); c.fill(x+7,y+13,x+9,y+16,dark);
        c.fill(x+4,y+6,x+5,y+9,light);
    }
}
