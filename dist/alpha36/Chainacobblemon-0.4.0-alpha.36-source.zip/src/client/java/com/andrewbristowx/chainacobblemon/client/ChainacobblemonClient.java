package com.andrewbristowx.chainacobblemon.client;

import com.andrewbristowx.chainacobblemon.client.emote.HologramStreamotesClientService;
import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.client.render.GachaMachineRenderer;
import com.andrewbristowx.chainacobblemon.client.render.ServiceNpcRenderer;
import com.andrewbristowx.chainacobblemon.client.render.CustomNpcRenderer;
import com.andrewbristowx.chainacobblemon.client.render.MediaDisplayRenderer;
import com.andrewbristowx.chainacobblemon.client.render.HologramRenderer;
import com.andrewbristowx.chainacobblemon.client.visual.ClientVisualAssetCache;
import com.andrewbristowx.chainacobblemon.client.npc.NpcAdminClient;
import com.andrewbristowx.chainacobblemon.client.emote.ChatEmoteController;
import com.andrewbristowx.chainacobblemon.client.progress.ProgressionClient;
import com.andrewbristowx.chainacobblemon.client.shop.ShopClient;
import com.andrewbristowx.chainacobblemon.client.admin.AdminClient;
import com.andrewbristowx.chainacobblemon.client.rewards.BattlePassClient;
import com.andrewbristowx.chainacobblemon.client.rewards.DailyRewardClient;
import com.andrewbristowx.chainacobblemon.client.gacha.GachaClient;
import com.andrewbristowx.chainacobblemon.client.tower.TowerRouletteClient;
import com.andrewbristowx.chainacobblemon.client.events.EventClient;
import com.andrewbristowx.chainacobblemon.client.twitch.TwitchClient;
import com.andrewbristowx.chainacobblemon.client.twitch.TwitchStatusHud;
import com.andrewbristowx.chainacobblemon.client.twitch.ChainaTabDecoration;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.util.Identifier;

public final class ChainacobblemonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HologramStreamotesClientService.initialize();
        BlockEntityRendererFactories.register(ModRegistries.GACHA_MACHINE_BLOCK_ENTITY, GachaMachineRenderer::new);
        EntityRendererRegistry.register(ModRegistries.NURSE_NPC, context -> new ServiceNpcRenderer(
                context, true, Identifier.of(Chainacobblemon.MOD_ID, "textures/entity/nurse_npc.png")));
        EntityRendererRegistry.register(ModRegistries.SHOP_NPC, context -> new ServiceNpcRenderer(
                context, false, Identifier.of(Chainacobblemon.MOD_ID, "textures/entity/shop_npc.png")));
        EntityRendererRegistry.register(ModRegistries.CUSTOM_NPC, context -> new CustomNpcRenderer(context, false));
        EntityRendererRegistry.register(ModRegistries.CUSTOM_SLIM_NPC, context -> new CustomNpcRenderer(context, true));
        EntityRendererRegistry.register(ModRegistries.MEDIA_DISPLAY, MediaDisplayRenderer::new);
        EntityRendererRegistry.register(ModRegistries.HOLOGRAM, HologramRenderer::new);
        ClientVisualAssetCache.initialize();
        NpcAdminClient.initialize();
        ChatEmoteController.initialize();
        ProgressionClient.initialize();
        ShopClient.initialize();
        AdminClient.initialize();
        BattlePassClient.initialize();
        DailyRewardClient.initialize();
        GachaClient.initialize();
        TowerRouletteClient.initialize();
        EventClient.initialize();
        TwitchClient.initialize();
        TwitchStatusHud.initialize();
        ChainaTabDecoration.initialize();
        Chainacobblemon.LOGGER.info("Chainacobblemon client layer initialized with GachaMachineRenderer");
    }


}
