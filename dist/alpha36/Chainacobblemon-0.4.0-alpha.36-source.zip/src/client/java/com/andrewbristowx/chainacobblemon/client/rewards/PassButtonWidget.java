package com.andrewbristowx.chainacobblemon.client.rewards;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

final class PassButtonWidget extends ButtonWidget {
    PassButtonWidget(int x, int y, int width, int height, Text message, PressAction action) {
        super(x, y, width, height, message, action, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        int fill = isHovered() ? 0xFFF9556D : 0xFF3A2B30;
        context.fill(getX(), getY(), getX() + width, getY() + height, fill);
        int line = isHovered() ? 0xFFF6AD4B : 0xFFFB9AA6;
        context.fill(getX(), getY(), getX() + width, getY() + 1, line);
        context.fill(getX(), getY() + height - 1, getX() + width, getY() + height, line);
        context.fill(getX(), getY(), getX() + 1, getY() + height, line);
        context.fill(getX() + width - 1, getY(), getX() + width, getY() + height, line);
        var renderer = MinecraftClient.getInstance().textRenderer;
        context.drawCenteredTextWithShadow(renderer, getMessage(), getX() + width / 2,
                getY() + (height - 8) / 2, active ? 0xFFF5F5F7 : 0xFF86827F);
    }
}
