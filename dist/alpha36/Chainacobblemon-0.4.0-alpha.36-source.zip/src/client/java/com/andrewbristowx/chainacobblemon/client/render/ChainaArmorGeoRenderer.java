package com.andrewbristowx.chainacobblemon.client.render;

import com.andrewbristowx.chainacobblemon.armor.ChainaGeoArmorItem;
import com.andrewbristowx.chainacobblemon.client.model.ChainaArmorGeoModel;
import software.bernie.geckolib.renderer.GeoArmorRenderer;

/** GeckoLib renderer for the Chaina armor set. */
public final class ChainaArmorGeoRenderer extends GeoArmorRenderer<ChainaGeoArmorItem> {
    public ChainaArmorGeoRenderer() {
        super(new ChainaArmorGeoModel());
    }
}
