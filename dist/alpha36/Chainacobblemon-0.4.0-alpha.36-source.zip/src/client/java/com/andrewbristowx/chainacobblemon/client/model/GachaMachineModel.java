package com.andrewbristowx.chainacobblemon.client.model;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineBlockEntity;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

public final class GachaMachineModel extends GeoModel<GachaMachineBlockEntity> {
    private static final Identifier STANDARD_MODEL = Identifier.of(Chainacobblemon.MOD_ID, "geo/standard_gacha_machine.geo.json");
    private static final Identifier CHAINA_MODEL = Identifier.of(Chainacobblemon.MOD_ID, "geo/chaina_gacha_machine.geo.json");
    private static final Identifier STANDARD_TEXTURE = Identifier.of(Chainacobblemon.MOD_ID, "textures/block/standard_gacha_machine.png");
    private static final Identifier CHAINA_TEXTURE = Identifier.of(Chainacobblemon.MOD_ID, "textures/block/chaina_gacha_machine.png");
    private static final Identifier TREASURE_TEXTURE = Identifier.of(Chainacobblemon.MOD_ID, "textures/block/treasure_gacha_machine.png");
    private static final Identifier ANIMATION = Identifier.of(Chainacobblemon.MOD_ID, "animations/standard_gacha_machine.animation.json");

    @Override
    public Identifier getModelResource(GachaMachineBlockEntity animatable) {
        return (animatable.isChainaThemed() || animatable.isTreasureThemed()) ? CHAINA_MODEL : STANDARD_MODEL;
    }

    @Override
    public Identifier getTextureResource(GachaMachineBlockEntity animatable) {
        if (animatable.isTreasureThemed()) return TREASURE_TEXTURE;
        return animatable.isChainaThemed() ? CHAINA_TEXTURE : STANDARD_TEXTURE;
    }

    @Override
    public Identifier getAnimationResource(GachaMachineBlockEntity animatable) {
        return ANIMATION;
    }
}
