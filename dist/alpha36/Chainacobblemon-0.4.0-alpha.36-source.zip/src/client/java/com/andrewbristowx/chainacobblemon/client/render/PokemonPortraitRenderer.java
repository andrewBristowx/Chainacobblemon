package com.andrewbristowx.chainacobblemon.client.render;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * Cobblemon 1.7.3 portrait bridge.
 *
 * The supported profile renderer lives in com.cobblemon.mod.common.api.gui.GuiUtilsKt.
 * We keep reflection here so the client can still start if Cobblemon internals move in a
 * future pack, but resolve the real 1.7.3 API instead of the removed PokemonGuiUtilsKt shim.
 */
public final class PokemonPortraitRenderer {
    private static volatile Method drawProfileMethod;
    private static volatile Constructor<?> stateConstructor;
    private static volatile boolean lookupFailed;
    private static volatile boolean failureLogged;

    private PokemonPortraitRenderer() { }

    public static boolean draw(DrawContext context, String speciesId, int centerX, int bottomY, int requestedSize) {
        boolean pushed = false;
        try {
            Method draw = resolveMethod();
            if (draw == null) return false;
            Identifier species = normalizeSpeciesId(speciesId);
            if (species == null) return false;

            Object poseState = stateConstructor.newInstance();
            float profileScale = Math.max(12.0F, requestedSize / 2.0F);
            int topY = bottomY - requestedSize;

            context.getMatrices().push();
            pushed = true;
            context.getMatrices().translate(centerX, topY, 170.0F);
            draw.invoke(null, species, context.getMatrices(), poseState, 0.0F, profileScale);
            context.getMatrices().pop();
            return true;
        } catch (Throwable exception) {
            if (pushed) try { context.getMatrices().pop(); } catch (Throwable ignored) { }
            if (!failureLogged) {
                failureLogged = true;
                Chainacobblemon.LOGGER.warn("Could not render a Cobblemon 1.7.3 profile portrait", exception);
            }
            return false;
        }
    }

    /** Cobblemon catalogs commonly store bare paths (for example "deoxys"). */
    private static Identifier normalizeSpeciesId(String speciesId) {
        if (speciesId == null || speciesId.isBlank()) return null;
        String normalized = speciesId.strip().toLowerCase(java.util.Locale.ROOT);
        return Identifier.tryParse(normalized.indexOf(':') >= 0 ? normalized : "cobblemon:" + normalized);
    }

    private static Method resolveMethod() throws Exception {
        if (drawProfileMethod != null || lookupFailed) return drawProfileMethod;
        synchronized (PokemonPortraitRenderer.class) {
            if (drawProfileMethod != null || lookupFailed) return drawProfileMethod;

            Class<?> floatingState = Class.forName(
                    "com.cobblemon.mod.common.client.render.models.blockbench.FloatingState");
            stateConstructor = floatingState.getDeclaredConstructor();
            stateConstructor.setAccessible(true);

            Class<?> utilities = Class.forName("com.cobblemon.mod.common.api.gui.GuiUtilsKt");
            for (Method method : utilities.getMethods()) {
                if (!method.getName().equals("drawProfile") || method.getParameterCount() != 5) continue;
                if (!method.getParameterTypes()[2].isAssignableFrom(floatingState)) continue;
                drawProfileMethod = method;
                break;
            }
            if (drawProfileMethod == null) lookupFailed = true;
            return drawProfileMethod;
        }
    }
}
