package com.andrewbristowx.chainacobblemon.client.render;

import com.cobblemon.mod.common.api.pokemon.PokemonProperties;
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.pokemon.Species;
import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.gacha.machine.GachaMachineBlockEntity;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.joml.Quaternionf;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * World-space featured Pokemon display.
 *
 * Alpha.77 renders through Cobblemon's own PokemonItem/PokemonItemRenderer pipeline, but reaches
 * those two classes through reflection. Cobblemon 1.7.3 is published with Mojang-named ItemStack/
 * Item signatures while this Fabric project compiles against Yarn names; linking the classes
 * directly from Java therefore fails at compile time even though Loom remaps them to the same
 * runtime classes. The small reflection bridge keeps the renderer mapping-neutral while still
 * delegating model, texture, forms, layers and PORTRAIT pose to Cobblemon itself.
 */
final class SeasonalPokemonWorldRenderer {
    private static final String POKEMON_ITEM_CLASS = "com.cobblemon.mod.common.item.PokemonItem";
    private static final String POKEMON_ITEM_RENDERER_CLASS = "com.cobblemon.mod.common.client.render.item.PokemonItemRenderer";

    private static final Map<String, Object> ITEM_CACHE = new HashMap<>();
    private static final Map<String, Boolean> FAILED_SPECIES = new HashMap<>();

    private static volatile Object pokemonItemRenderer;
    private static volatile Method pokemonItemFromSpecies;
    private static volatile Method pokemonItemRender;

    private SeasonalPokemonWorldRenderer() { }

    static void draw(GachaMachineBlockEntity machine, float partialTick, MatrixStack matrices,
                     VertexConsumerProvider vertices, TextRenderer textRenderer) {
        if (machine.getWorld() == null) return;
        MinecraftClient client = MinecraftClient.getInstance();
        Quaternionf cameraRotation = new Quaternionf(client.getEntityRenderDispatcher().getRotation());
        if (machine.isTreasureThemed()) {
            renderTreasureItem(machine, matrices, vertices, cameraRotation);
            return;
        }
        String speciesId = canonicalSpeciesId(machine.getFeaturedSpeciesId());
        if (speciesId.isBlank()) return;
        renderPokemonItem(machine, speciesId, matrices, vertices, cameraRotation);
    }


    private static void renderTreasureItem(GachaMachineBlockEntity machine, MatrixStack matrices,
                                           VertexConsumerProvider vertices, Quaternionf cameraRotation) {
        MinecraftClient client = MinecraftClient.getInstance();
        float bob = (float) Math.sin(machine.getWorld().getTime() * 0.075D + machine.getPos().asLong() * 0.01D) * 0.04F;
        matrices.push();
        matrices.translate(0.5D, 5.18D + bob, 0.5D);
        matrices.multiply(new Quaternionf(cameraRotation));
        float pulse = 1.02F + (float) Math.sin(machine.getWorld().getTime() * 0.06D) * 0.04F;
        matrices.scale(pulse, pulse, pulse);
        client.getItemRenderer().renderItem(new ItemStack(ModRegistries.CHAINA_SWORD), ModelTransformationMode.FIXED,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV, matrices, vertices,
                machine.getWorld(), (int) machine.getPos().asLong());
        matrices.pop();
    }

    private static void renderPokemonItem(GachaMachineBlockEntity machine, String speciesId, MatrixStack matrices,
                                          VertexConsumerProvider vertices, Quaternionf cameraRotation) {
        try {
            Object stack = ITEM_CACHE.computeIfAbsent(speciesId, SeasonalPokemonWorldRenderer::createPokemonStack);
            if (stack == null) return;

            ensurePokemonItemBridge(stack, matrices, vertices);

            float bob = (float)Math.sin(machine.getWorld().getTime() * 0.075D + machine.getPos().asLong() * 0.01D) * 0.04F;
            matrices.push();
            // Clearly above both approved billboard lines. Camera-facing keeps wide species readable from every side.
            matrices.translate(0.5D, 4.52D + bob, 0.5D);
            matrices.multiply(new Quaternionf(cameraRotation));
            float displayScale = machine.isChainaThemed() ? 1.35F : 1.25F;
            matrices.scale(displayScale, displayScale, displayScale);
            pokemonItemRender.invoke(pokemonItemRenderer, stack, ModelTransformationMode.NONE, matrices, vertices,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);
            matrices.pop();
            FAILED_SPECIES.remove(speciesId);
        } catch (Throwable exception) {
            if (FAILED_SPECIES.putIfAbsent(speciesId, Boolean.TRUE) == null) {
                Chainacobblemon.LOGGER.warn("Featured Pokemon native item render failed for '{}' above gacha machine at {}",
                        speciesId, machine.getPos(), exception);
            }
        }
    }

    private static Object createPokemonStack(String speciesId) {
        try {
            Species species = null;
            // Use Cobblemon's own PokemonProperties parser first. This is the same species resolution
            // path used by native commands/NPC teams and accepts addon IDs such as
            // cobblemon:absol without relying on getImplemented(), which can omit addon species.
            try {
                species = PokemonProperties.Companion.parse(canonicalSpeciesId(speciesId)).create().getSpecies();
            } catch (Throwable ignored) {
                // Keep a legacy fallback for machines saved by older builds with names instead of IDs.
            }
            if (species == null) {
                String searchKey = normalizeSpecies(speciesId);
                species = PokemonSpecies.getImplemented().stream()
                        .filter(candidate -> normalizeSpecies(candidate.showdownId()).equals(searchKey)
                                || normalizeSpecies(candidate.getName()).equals(searchKey))
                        .findFirst().orElse(null);
            }
            if (species == null) {
                Chainacobblemon.LOGGER.warn("Featured Pokemon species '{}' was not found in Cobblemon's registered species catalog", speciesId);
                return null;
            }

            Method factory = pokemonItemFromSpecies;
            if (factory == null) {
                synchronized (SeasonalPokemonWorldRenderer.class) {
                    factory = pokemonItemFromSpecies;
                    if (factory == null) {
                        Class<?> pokemonItem = Class.forName(POKEMON_ITEM_CLASS);
                        factory = findSpeciesFactory(pokemonItem, species);
                        pokemonItemFromSpecies = factory;
                    }
                }
            }

            Object stack;
            if (factory.getParameterCount() == 2) {
                // Kotlin `vararg aspects` is emitted as String[]; an empty array means base/default form.
                stack = factory.invoke(null, species, new String[0]);
            } else {
                throw new IllegalStateException("Unsupported PokemonItem.from(Species, ...) overload: " + factory);
            }
            Chainacobblemon.LOGGER.debug("Prepared native Cobblemon PokemonItem display for featured species '{}'", speciesId);
            return stack;
        } catch (Throwable exception) {
            Chainacobblemon.LOGGER.warn("Could not prepare native Cobblemon PokemonItem for featured species '{}'", speciesId, exception);
            return null;
        }
    }

    private static Method findSpeciesFactory(Class<?> pokemonItem, Species species) {
        for (Method method : pokemonItem.getMethods()) {
            if (!method.getName().equals("from") || !Modifier.isStatic(method.getModifiers())) continue;
            Class<?>[] params = method.getParameterTypes();
            if (params.length != 2 || !params[0].isInstance(species)) continue;
            if (params[1].isArray() && params[1].getComponentType() == String.class) {
                method.setAccessible(true);
                return method;
            }
        }
        throw new IllegalStateException("Cobblemon PokemonItem.from(Species, String...) overload not found");
    }

    private static void ensurePokemonItemBridge(Object stack, MatrixStack matrices, VertexConsumerProvider vertices) throws Exception {
        if (pokemonItemRenderer != null && pokemonItemRender != null) return;
        synchronized (SeasonalPokemonWorldRenderer.class) {
            if (pokemonItemRenderer != null && pokemonItemRender != null) return;
            Class<?> rendererClass = Class.forName(POKEMON_ITEM_RENDERER_CLASS);
            Object renderer = rendererClass.getDeclaredConstructor().newInstance();
            Method renderMethod = null;
            for (Method candidate : rendererClass.getMethods()) {
                if (!candidate.getName().equals("render") || candidate.getParameterCount() != 6) continue;
                Class<?>[] params = candidate.getParameterTypes();
                if (!params[0].isInstance(stack)) continue;
                if (!params[1].isInstance(ModelTransformationMode.NONE)) continue;
                if (!params[2].isInstance(matrices)) continue;
                if (!params[3].isInstance(vertices)) continue;
                if (params[4] != int.class || params[5] != int.class) continue;
                renderMethod = candidate;
                break;
            }
            if (renderMethod == null) {
                throw new IllegalStateException("Cobblemon PokemonItemRenderer.render runtime signature not found");
            }
            renderMethod.setAccessible(true);
            pokemonItemRenderer = renderer;
            pokemonItemRender = renderMethod;
            Chainacobblemon.LOGGER.debug("Resolved mapping-neutral Cobblemon PokemonItemRenderer bridge");
        }
    }

    private static String canonicalSpeciesId(String species) {
        if (species == null || species.isBlank()) return "";
        String value = species.strip().toLowerCase(Locale.ROOT).replace(" ", "_");
        return value.indexOf(':') >= 0 ? value : "cobblemon:" + value;
    }

    private static String normalizeSpecies(String species) {
        if (species == null) return "";
        String normalized = species.strip().toLowerCase(Locale.ROOT);
        int namespaceSeparator = normalized.indexOf(':');
        if (namespaceSeparator >= 0 && namespaceSeparator + 1 < normalized.length()) {
            normalized = normalized.substring(namespaceSeparator + 1);
        }
        return normalized.replace(" ", "").replace("-", "").replace("_", "");
    }

}
