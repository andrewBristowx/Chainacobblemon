package com.andrewbristowx.chainacobblemon.client.model;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.tools.ChainaGeoToolItem;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

/** Each tool keeps its original 32x32 artwork as its own GeckoLib texture. */
public final class ChainaToolGeoModel<T extends Item & ChainaGeoToolItem> extends GeoModel<T> {
    private final Identifier model;
    private final Identifier texture;
    private static final Identifier ANIMATION = Identifier.of(Chainacobblemon.MOD_ID, "animations/item/chaina_tools.animation.json");

    public ChainaToolGeoModel(String toolId) {
        this.model = Identifier.of(Chainacobblemon.MOD_ID, "geo/item/" + toolId + ".geo.json");
        this.texture = Identifier.of(Chainacobblemon.MOD_ID, "textures/item/" + toolId + ".png");
    }

    @Override public Identifier getModelResource(T animatable) { return model; }
    @Override public Identifier getTextureResource(T animatable) { return texture; }
    @Override public Identifier getAnimationResource(T animatable) { return ANIMATION; }
}
