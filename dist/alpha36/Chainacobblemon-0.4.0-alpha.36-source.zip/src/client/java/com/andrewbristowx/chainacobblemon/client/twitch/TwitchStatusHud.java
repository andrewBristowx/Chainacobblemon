package com.andrewbristowx.chainacobblemon.client.twitch;

import com.andrewbristowx.chainacobblemon.twitch.TwitchSnapshot;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Compact top-center Chaina live/offline indicator and current stream bonuses. */
public final class TwitchStatusHud {
    private TwitchStatusHud() { }

    public static void initialize() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        TwitchSnapshot snapshot = TwitchClient.latest();
        if (client.player == null || client.options.hudHidden || snapshot == null || !snapshot.enabled || !snapshot.streamHudEnabled) return;

        String title;
        int accent;
        if (!snapshot.channelKnown) {
            title = "CHAINA · COMPROBANDO TWITCH";
            accent = 0xFFAAA0B3;
        } else if (snapshot.channelOnline) {
            title = snapshot.streamJackpot ? "● CHAINA EN VIVO · DIRECTO LEGENDARIO" : "● CHAINA EN VIVO";
            accent = 0xFFFF536E;
        } else {
            title = "● CHAINA OFFLINE";
            accent = 0xFFAAA0B3;
        }

        List<String> lines = new ArrayList<>();
        lines.add(title);
        if (snapshot.channelOnline && snapshot.streamBonusesActive && snapshot.streamBonuses != null && !snapshot.streamBonuses.isEmpty()) {
            lines.add(String.join("   ", snapshot.streamBonuses));
        }

        int textWidth = 0;
        for (String line : lines) textWidth = Math.max(textWidth, client.textRenderer.getWidth(line));
        int w = Math.min(context.getScaledWindowWidth() - 24, textWidth + 22);
        int h = lines.size() == 1 ? 24 : 38;
        int x = (context.getScaledWindowWidth() - w) / 2;
        int y = 7;
        context.fill(x, y, x + w, y + h, 0xC819111F);
        context.fill(x, y, x + w, y + 2, accent);
        context.drawCenteredTextWithShadow(client.textRenderer, lines.get(0), x + w / 2, y + 8, accent);
        if (lines.size() > 1) {
            String bonuses = lines.get(1);
            if (client.textRenderer.getWidth(bonuses) > w - 12) {
                while (bonuses.length() > 4 && client.textRenderer.getWidth(bonuses + "…") > w - 12) {
                    bonuses = bonuses.substring(0, bonuses.length() - 1);
                }
                bonuses += "…";
            }
            context.drawCenteredTextWithShadow(client.textRenderer, bonuses, x + w / 2, y + 23, 0xFFFFD8EA);
        }
    }
}
