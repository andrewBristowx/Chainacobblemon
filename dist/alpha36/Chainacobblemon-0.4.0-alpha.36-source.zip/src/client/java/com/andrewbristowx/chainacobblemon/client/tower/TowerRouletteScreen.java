package com.andrewbristowx.chainacobblemon.client.tower;

import com.andrewbristowx.chainacobblemon.client.render.PokemonPortraitRenderer;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.andrewbristowx.chainacobblemon.tower.TowerRouletteSnapshot;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/** Animated Tower repeat-clear roulette. The reward name is always rendered above its icon. */
final class TowerRouletteScreen extends Screen {
    private static final int BG = 0xE817101E;
    private static final int PANEL = 0xF02B1D32;
    private static final int PANEL_INNER = 0xF0372840;
    private static final int PINK = 0xFFFF79B8;
    private static final int GOLD = 0xFFFFD36A;
    private static final int TEXT = 0xFFF8F4FA;
    private static final int MUTED = 0xFFC9B9CF;
    private static final int GREEN = 0xFF8FF0AF;

    private final Screen parent;
    private final TowerRouletteSnapshot snapshot;
    private final long openedAt = System.currentTimeMillis();

    TowerRouletteScreen(Screen parent, TowerRouletteSnapshot snapshot) {
        super(Text.literal("Ruleta de la Torre"));
        this.parent = parent;
        this.snapshot = snapshot;
    }

    Screen parent() { return parent; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long elapsed = System.currentTimeMillis() - openedAt;
        if (elapsed >= Math.max(5_000L, snapshot.closeAfterMillis)) {
            close();
            return;
        }
        context.fill(0, 0, width, height, BG);
        int panelW = Math.min(720, Math.max(360, width - 40));
        int panelH = Math.min(430, Math.max(250, height - 44));
        int x = (width - panelW) / 2;
        int y = (height - panelH) / 2;
        context.fill(x, y, x + panelW, y + panelH, PANEL);
        outline(context, x, y, panelW, panelH, snapshot.jackpot ? GOLD : PINK, 3);
        context.fill(x + 14, y + 14, x + panelW - 14, y + 66, PANEL_INNER);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(snapshot.jackpot ? "★ JACKPOT ★" : valueOr(snapshot.title, "✦ RULETA DE RECOMPENSA ✦")),
                width / 2, y + 30, snapshot.jackpot ? GOLD : PINK);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(valueOr(snapshot.subtitle, "Victoria repetida · premio secundario")), width / 2, y + 48, MUTED);

        TowerRouletteSnapshot.RewardView shown = shownReward(elapsed);
        boolean settled = elapsed >= 3_650L;
        int centerX = width / 2;
        int centerY = y + panelH / 2 + 18;

        // Requested presentation: reward name above the icon.
        String label = shown == null ? "..." : safe(shown.label);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(settled ? "★ " + label + " ★" : label),
                centerX, centerY - 102, settled ? (snapshot.jackpot ? GOLD : GREEN) : TEXT);
        context.fill(centerX - 104, centerY - 76, centerX + 104, centerY + 88, PANEL_INNER);
        outline(context, centerX - 104, centerY - 76, 208, 164, settled ? GOLD : 0xFF664D70, 2);
        drawReward(context, shown, centerX, centerY, 86);

        int count = snapshot.previews == null ? 0 : snapshot.previews.size();
        if (!settled) {
            int remaining = Math.max(0, 4 - (int)(elapsed / 800L));
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("La ruleta está frenando" + ".".repeat(Math.max(1, remaining))),
                    centerX, centerY + 108, MUTED);
        } else {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(snapshot.jackpot
                            ? "¡Premio súper raro! 10 tickets de cada máquina"
                            : valueOr(snapshot.settledMessage, "Premio entregado automáticamente")),
                    centerX, centerY + 108, snapshot.jackpot ? GOLD : TEXT);
        }

        // Small icon strip reinforces the roulette motion without hiding the main result.
        if (count > 0) {
            int stripY = y + panelH - 54;
            int cards = Math.min(7, count);
            int spacing = 52;
            int startX = centerX - (cards - 1) * spacing / 2;
            int base = (int)((elapsed / Math.max(70L, 165L - Math.min(95L, elapsed / 30L))) % count);
            for (int i = 0; i < cards; i++) {
                TowerRouletteSnapshot.RewardView rv = snapshot.previews.get((base + i) % count);
                context.fill(startX + i * spacing - 20, stripY - 18, startX + i * spacing + 20, stripY + 22, 0xAA24192A);
                drawReward(context, rv, startX + i * spacing, stripY + 2, 28);
            }
        }
        super.render(context, mouseX, mouseY, delta);
    }

    private TowerRouletteSnapshot.RewardView shownReward(long elapsed) {
        if (elapsed >= 3_650L || snapshot.previews == null || snapshot.previews.isEmpty()) return snapshot.selected;
        List<TowerRouletteSnapshot.RewardView> previews = snapshot.previews;
        long step;
        if (elapsed < 1_500L) step = 85L;
        else if (elapsed < 2_500L) step = 145L;
        else if (elapsed < 3_150L) step = 230L;
        else step = 360L;
        int index = (int)((elapsed / step) % previews.size());
        return previews.get(index);
    }

    private void drawReward(DrawContext context, TowerRouletteSnapshot.RewardView reward, int cx, int cy, int size) {
        if (reward == null) return;
        if ("POKEMON".equals(reward.type)) {
            if (reward.speciesId != null && !reward.speciesId.isBlank()
                    && PokemonPortraitRenderer.draw(context, reward.speciesId, cx, cy + size / 2, size)) return;
            drawItem(context, new ItemStack(ModRegistries.RANDOM_POKEMON_ICON), cx, cy, size);
            return;
        }
        if ("TICKETS".equals(reward.type)) {
            int each = Math.max(1, size * 2 / 5);
            int dx = each + 8;
            drawItem(context, new ItemStack(ModRegistries.GACHA_TICKET), cx - dx, cy, each);
            drawItem(context, new ItemStack(ModRegistries.CHAINA_SPECIAL_BANNER_TICKET), cx, cy, each);
            drawItem(context, new ItemStack(ModRegistries.TREASURE_GACHA_TICKET), cx + dx, cy, each);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("×" + Math.max(1, reward.amount)), cx, cy + each / 2 + 12, TEXT);
            return;
        }
        Identifier id = Identifier.tryParse(reward.value);
        if (id != null && Registries.ITEM.containsId(id)) {
            Item item = Registries.ITEM.get(id);
            if (item != Items.AIR) {
                drawItem(context, new ItemStack(item), cx, cy, size);
                if (reward.amount > 1) context.drawCenteredTextWithShadow(textRenderer,
                        Text.literal("×" + reward.amount), cx + size / 2, cy + size / 3, TEXT);
                return;
            }
        }
        drawItem(context, new ItemStack(ModRegistries.CHAIBELL_ICON), cx, cy, size);
    }

    private void drawItem(DrawContext context, ItemStack stack, int cx, int cy, int size) {
        float scale = Math.max(1.0F, size / 16.0F);
        context.getMatrices().push();
        context.getMatrices().translate(cx - 8.0F * scale, cy - 8.0F * scale, 180.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.drawItem(stack, 0, 0);
        context.getMatrices().pop();
    }

    private void outline(DrawContext c, int x, int y, int w, int h, int color, int t) {
        c.fill(x, y, x + w, y + t, color);
        c.fill(x, y + h - t, x + w, y + h, color);
        c.fill(x, y, x + t, y + h, color);
        c.fill(x + w - t, y, x + w, y + h, color);
    }

    private static String safe(String value) { return value == null || value.isBlank() ? "Premio sorpresa" : value; }
    private static String valueOr(String value, String fallback) { return value == null || value.isBlank() ? fallback : value; }
    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
