# 0.4.0-alpha.35 — Final Overworld border + full Chunky + Distant Horizons guard

- Añade `/chainacobblemon worldborder calcular [margen]`: calcula un borde cuadrado centrado en el spawn del Overworld usando la ubicación regional más lejana, margen configurable y alineación a regiones de 512 bloques.
- Añade aplicación confirmada del world border final y muestra el número total de chunks y una estimación amplia de disco antes de generar.
- Añade pregeneración COMPLETA del cuadrado del Overworld con Chunky, separada de la pregeneración selectiva existente. Incluye pausa/reanudación, persistencia, watchdog de MSPT y reserva dura de 30 GiB.
- Añade integración blanda con Distant Horizons 2.3+: fuerza `generation.mode=PRE_EXISTING_ONLY`, limita DH al mismo centro/radio del world border y permite iniciar/status/detener `/dh pregen` desde los comandos de Chaina.
- DH permanece habilitado para seguir enviando LODs a clientes; PRE_EXISTING_ONLY + bounds impiden que DH cree terreno vanilla nuevo fuera del mapa final.
- Conserva íntegros los sistemas de alpha.34, incluido el combate doble real de Lulita + Duber.


## 0.4.0-alpha.26
- El planificador de 69 ubicaciones prueba todos los IDs STRUCTURE candidatos por ubicación.
- Las estructuras no encontradas se reintentan con radios progresivos de 65k a 196k bloques.
- Añade `mapmissing` con las pendientes exactas, IDs candidatos y plantillas que requieren marcado manual.
- El plan ya no se anuncia como completo ni muestra un área final de Chunky hasta llegar a 69/69.
- Conserva las coordenadas ya localizadas y solo reintenta las pendientes salvo `mapplan refresh`.
- Mantiene intacta la colocación persistente/separada de entrenadores de alpha.25.
## 0.4.0-alpha.25 — Stable separated dungeon trainers

- Generic Chaina dungeon trainer positions are persisted after one successful accessibility validation.
- Re-entering or stepping through the same structure no longer teleports already valid trainers toward the current player.
- Existing alpha.24 trainers are migrated once, then their accepted placement is locked in NBT.
- Placement reserves occupied tiles and enforces 5-block horizontal separation between generic Chaina dungeon trainers.
- Legacy trainers stacked on one tile are redistributed to distinct reachable room/corridor positions when possible.
- If a dungeon cannot provide enough separated accessible tiles, Chaina keeps fewer trainers instead of stacking them.
- Authored Radical/Cobbleverse Trainer Spawner behavior remains unchanged.

## 0.4.0-alpha.24 — Accessible dungeon trainer placement

- Dungeon NPC placement now uses a bounded walkability flood-fill from the player instead of accepting any collision-free air pocket.
- New generic dungeon trainers only spawn on reachable full-floor tiles with at least two walkable exits (room or corridor), rejecting sealed niches/decorative cavities.
- Existing Chaina dungeon trainers are revalidated when players enter; inaccessible trainers are moved to the nearest reachable room/passage without breaking blocks.
- Traversal understands one-block steps, stairs/slabs as support, and open OPEN-state blocks while keeping the final NPC floor stable/full.
- Authored Cobbleverse/RCT Trainer Spawner behavior from alpha.22/23 remains unchanged.

# 0.4.0-alpha.23

- Añade la pestaña `Ubicaciones` al Diario de Chaina con las 69 ubicaciones regionales oficiales: Kanto 13, Johto 14, Hoenn 18 y Sinnoh 24, mostrando orden, estado y coordenadas guardadas por mundo/seed.
- Nuevo planificador administrativo `/chainacobblemon admin structures mapplan`: localiza progresivamente las estructuras registradas, guarda sus coordenadas y calcula el rectángulo mínimo del mapa con margen de seguridad para preparar la pregeneración.
- Añade `mapstatus`, `mapplan refresh`, `mapclear` y `mapmark <region> <número>` para auditar/reanudar y marcar los pocos assets de plantilla sin ID STRUCTURE.
- Los diálogos de entrenadores nativos de Radical reciben su `trainerId` real y el cliente resuelve la textura `textures/trainers/single/...` para dibujar la cara y segunda capa de la skin en lugar del retrato genérico.
- La progresión regional se sincroniza en ambos sentidos: victorias naturales RCT se importan a Chaina y una primera victoria contra un líder/Alto Mando/Campeón de Chaina actualiza también la progresión/derrota correspondiente de Radical cuando el entrenador nativo puede resolverse.
- Mantiene intacta la integración validada de `Trainer Spawner` de 0.4.0-alpha.22.

# 0.4.0-alpha.22

- Corrige los Trainer Spawner regionales de Cobbleverse cuando la estructura no aparece en `StructureAccessor` desde el chunk actual: Chaina ahora escanea `rctmod:trainer_spawner` cercanos de forma independiente a la detección de dungeon.
- `/chainacobblemon admin dungeontrainers scan` funciona directamente al lado de un Trainer Spawner configurado aunque Chaina no pueda resolver el ID de la estructura contenedora.
- El feedback administrativo muestra cuántos spawners RCT configurados se encontraron, cuántos entrenadores ya estaban activos y cuántos fueron creados por Chaina.
- Se siguen reutilizando exclusivamente los `TrainerIds` originales guardados por Cobbleverse; no se inventan entrenadores ni posiciones.

# 0.4.0-alpha.21

- Cobbleverse regional structures now reuse the `rctmod:trainer_spawner` blocks already authored into the builds instead of spawning generic Chaina dungeon NPCs at guessed offsets.
- Chaina reads each spawner's native `TrainerIds` and, when RCT's conditional spawner has not produced an NPC, summons one of those exact Radical trainer IDs directly on top of the original spawner.
- Native RCT trainer identity, skin, team definition, progression, cooldowns, rewards and battle rules remain owned by Radical; Chaina's existing dialogue/adaptive bridge still wraps the encounter.
- Passive regional landmarks without configured Trainer Spawners remain untouched.
- `/chainacobblemon admin dungeontrainers scan` can be used while standing near a configured regional spawner to force an immediate check.

# 0.4.0-alpha.20
- Los entrenadores nativos de Radical explican el motivo exacto cuando un combate está bloqueado en lugar de mostrar solo un mensaje genérico.
- Si el equipo supera el level cap actual, el diálogo muestra el nivel más alto detectado y el límite de Radical (por ejemplo, Nv.50 frente a cap Nv.25).
- También se explican cooldown, entrenador/jugador ocupado, falta de Pokémon activos, serie incorrecta, series/entrenadores requisito pendientes y combates ya agotados cuando RCT expone esos datos.
- La explicación es informativa: no se saltan las reglas de progresión, cooldown ni requisitos originales de Radical.

# 0.4.0-alpha.19
- Corrige la adaptación de entrenadores de dungeon: el rival usa los niveles REALES del jugador y deja de quedar limitado por el cap regional de RCT.
- El equipo del jugador ya no se sincroniza hacia abajo en combates de dungeon; se adapta el oponente, no el jugador.
- Los entrenadores nativos de Radical que aparecen por el mundo también calculan su nivel desde el equipo real del jugador, manteniendo la progresión/cooldowns/IA nativos de Radical.
- Mejora el spawn seguro de entrenadores de dungeon: búsqueda horizontal/vertical, dos bloques libres, suelo de bloque completo y rechazo de escaleras, slabs, vallas, muros y fluidos.
- Los entrenadores de dungeon ya existentes que hayan quedado encajados se reubican automáticamente a una posición segura cercana cuando la dungeon vuelve a inspeccionarse.

# 0.4.0-alpha.16

- Gimnasios regionales: conserva equipos/movimientos nativos cuando es posible, pero usa una copia aislada del entrenador RCT con Tera/Dynamax/G-Max explícitamente desactivados.
- Alto Mando: una sola mecánica especial por combate y únicamente en el as; miembros 1/3 usan Teracristalización y 2/4 Dynamax. No se combinan mecánicas RCT.
- Campeones: sin Tera/Dynamax; un único as recibe su megapiedra de Mega Showdown (Blue/Pidgeot, Lance/Dragonite, Steven/Metagross, Cynthia/Garchomp).
- IA RCT escalonada: reduce progresivamente el margen de decisiones aleatorias y aumenta la prioridad de movimientos/switches útiles en Liga y Torre.
- Torre pisos 7-10: equipos con sets ofensivos/coverage explícitos para evitar turnos pasivos inútiles; Mega posible desde piso 8, 50% en piso 9 y garantizada en piso 10, siempre una sola por combate.
- Mantiene intactas las correcciones de servidor validadas en 0.4.0-alpha.15.

# 0.4.0-alpha.13

- Corrige el crash al entrar causado por aliases de rangos duplicados (`default`/`basic` y `vip`/`donator`) dentro de `Set.of(...)`.
- Los conjuntos de rangos ahora se construyen con deduplicación segura para que un alias repetido nunca pueda tumbar el servidor al conectar un jugador.
- Mantiene sin cambios LuckPerms alpha.12, TAB, Styled Chat, Twitch, stream bonuses y ChainaBridge 0.4.0-alpha.7.

# 0.4.0-alpha.12

- Corrige el bootstrap real de LuckPerms 5.4.140 en Java 21: todas las llamadas reflectivas pasan por interfaces públicas de la API oficial en lugar de implementaciones internas package-private (`NodeMapImpl`).
- Mantiene sin cambios TAB v2, Styled Chat, Twitch, stream bonuses y ChainaBridge 0.4.0-alpha.7.

# 0.4.0-alpha.11

- TAB Chaina v2: elimina el recordatorio duplicado de vincular Twitch, añade una cabecera/footer más decorados y usa nombres con rango coloreado.
- Integración visual opcional con emotes Twitch actuales de Chaina (`chainavtCute` y `chainavtAwa`), descargados/cacheados por el servidor y enviados al cliente con el sistema de assets existente.
- LuckPerms bootstrap no destructivo: crea los grupos Twitch configurados si faltan y encadena twitch -> SUB I -> SUB II -> SUB III sin reemplazar el grupo principal del jugador.
- Styled Chat se autoconfigura una sola vez con copia de seguridad para usar el mismo nombre/rango coloreado que el TAB.
- El placeholder `%chainacobblemon:styled_name%` muestra rango principal + SUB secundaria y funciona también sin LuckPerms usando el estado Twitch interno.

# 0.4.0-alpha.10

- Integración opcional con Styled Player List: placeholders dinámicos de Twitch/bonus, estilo `Chaina Server` autogenerado y seleccionado una sola vez como TAB predeterminado.
- El TAB muestra estado EN VIVO/OFFLINE, DIRECTO LEGENDARIO, bonus activos, jugadores conectados y crédito `Holy.gg`.
- En singleplayer fuerza `client_show_in_singleplayer=true`. Se respalda `styledplayerlist/config.json` antes de la primera modificación.
- Si Styled Player List está activo, el HUD flotante de Twitch se oculta por defecto para evitar información duplicada; si falta o falla la integración, el HUD sigue como fallback.
- Text Placeholder API 2.4.2+1.21 se incluye dentro de Chainacobblemon.

# 0.4.0-alpha.8

- La GUI `CHAINA × TWITCH` pasa a ser exclusivamente una herramienta de administración.
- Los jugadores normales mantienen solo el flujo directo del chat `AQUÍ` -> Twitch -> vinculación automática, sin panel.
- `/twitch admin <jugador>` permite inspeccionar cuenta, Tier, rango y última sincronización de un jugador online.
- El panel admin permite actualizar su estado, desvincularlo y reenviarle el aviso privado de vinculación.
- Todas las acciones administrativas se validan también en servidor con nivel de permiso 2; no dependen de la GUI del cliente.
- ChainaBridge 0.4.0-alpha.5 y su persistencia cifrada no cambian.

# 0.4.0-alpha.7

- El aviso privado de Twitch ahora abre la autorización directamente, sin mostrar la GUI de administración.
- El código de Device Flow se copia automáticamente al portapapeles y se muestra en chat por si Twitch lo solicita.
- La autorización directa se comprueba desde el servidor cada 2 segundos; al completarse aplica cuenta, tier y rango sin abrir ninguna pantalla del mod.
- `/twitch` y `/twitch vincular` conservan la GUI manual para administración/diagnóstico.
- ChainaBridge 0.4.0-alpha.5 sigue siendo compatible y no cambia.

# 0.4.0-alpha.6

- Twitch onboarding: al entrar, un jugador no vinculado recibe un aviso privado clickeable en chat.
- El clic inicia `/twitch vincular` y abre la GUI con código/URL de autorización.
- La GUI consulta automáticamente ChainaBridge cada 2 segundos mientras espera a Twitch.
- Al completar OAuth, la cuenta, tier y rango se aplican automáticamente sin `/twitch sync`.
- Jugadores ya vinculados se sincronizan silenciosamente al entrar, sin abrir GUI.
- ChainaBridge 0.4.0-alpha.5 sigue siendo compatible y no cambia en esta release.

# Chainacobblemon 0.3.0-alpha.2

- Port funcional de paridad basado en la versión madura de referencia.
- Catálogo regional completo de entrenadores (Brock, Misty y resto de Kanto/Johto/Hoenn/Sinnoh).
- NPCs editables con autodetección/carpeta de skins y resolución RCT/Cobbleverse.
- Gasha con revelado progresivo x10 (135 ms por tarjeta y efecto pop de 190 ms).
- Misiones, trabajos, tienda, pase, login diario, hologramas, emotes, kits y panel admin portados.
- Identidad visual Chaina en coral/dorado/sakura y fondos claros.
- El contenido de apuestas queda excluido por diseño.
- Pokémon custom del proyecto anterior excluidos; el banner Chaina usa especies oficiales hasta aprobar variantes Chaina.
