package com.andrewbristowx.chainacobblemon.dungeon;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.npc.RctWorldTrainerService;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cobbleverse's regional structures already author encounter positions with RCT Trainer Spawner blocks.
 *
 * RCT normally decides if/when those blocks may spawn based on player progression, level difference and
 * the global trainer cap. For story structures that can leave the authored room visually empty (for
 * example when a player is temporarily above the current level cap). Chaina keeps RCT's trainer identity
 * and battle/progression rules, but guarantees the configured NPC itself is present: it reads the exact
 * TrainerIds from the block entity and uses RCT's own summon command at the center of the spawner.
 *
 * Once the native TrainerMob exists, RctWorldTrainerService provides Chaina's dialogue/adaptive wrapper.
 */
public final class RctDungeonSpawnerService {
    private static final Identifier TRAINER_SPAWNER_ID = Identifier.of("rctmod", "trainer_spawner");
    private static final int HORIZONTAL_SCAN = 14;
    private static final int VERTICAL_SCAN = 10;
    private static final long RETRY_TICKS = 100L;
    private static final Map<String, Long> LAST_ATTEMPT = new ConcurrentHashMap<>();

    private RctDungeonSpawnerService() {}

    public static Result ensureNearby(ServerWorld world, ServerPlayerEntity player, Identifier structureId, String structureKey) {
        if (world == null || player == null) return Result.EMPTY;

        int configured = 0;
        int active = 0;
        int forced = 0;
        Set<BlockPos> visited = new LinkedHashSet<>();

        for (BlockPos cursor : BlockPos.iterateOutwards(player.getBlockPos(), HORIZONTAL_SCAN, VERTICAL_SCAN, HORIZONTAL_SCAN)) {
            BlockPos pos = cursor.toImmutable();
            if (!visited.add(pos)) continue;
            Identifier blockId = Registries.BLOCK.getId(world.getBlockState(pos).getBlock());
            if (!TRAINER_SPAWNER_ID.equals(blockId)) continue;

            SpawnerData data = readSpawner(world, pos);
            if (data.trainerIds().isEmpty()) continue;
            configured++;

            Entity occupant = findOccupant(world, pos, data);
            if (occupant != null) {
                snapToSpawner(occupant, pos);
                active++;
                continue;
            }

            // RCT requires the two blocks above a Trainer Spawner to be air. Do not destroy authored
            // structure blocks to make room; just report it in the server log so the structure can be fixed.
            if (!world.getBlockState(pos.up()).isAir() || !world.getBlockState(pos.up(2)).isAir()) {
                Chainacobblemon.LOGGER.warn("Configured RCT Trainer Spawner at {} in {} is blocked above; "
                        + "the two blocks above it must be air", pos, structureId);
                continue;
            }

            String retryKey = world.getRegistryKey().getValue() + "@" + pos.asLong();
            long now = world.getTime();
            long last = LAST_ATTEMPT.getOrDefault(retryKey, Long.MIN_VALUE / 4);
            if (now - last < RETRY_TICKS) continue;
            LAST_ATTEMPT.put(retryKey, now);

            if (forceNativeTrainer(world, player, pos, data.trainerIds())) {
                forced++;
                Entity spawned = findOccupant(world, pos, data);
                if (spawned != null) {
                    snapToSpawner(spawned, pos);
                    active++;
                }
                Chainacobblemon.LOGGER.info("Activated authored RCT Trainer Spawner at {} for {} in {} "
                                + "(TrainerIds={})", pos, player.getName().getString(), structureId, data.trainerIds());
            }
        }

        return new Result(configured, active, forced);
    }

    private static SpawnerData readSpawner(ServerWorld world, BlockPos pos) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity == null) return SpawnerData.EMPTY;
        try {
            NbtCompound nbt = blockEntity.createNbt(world.getRegistryManager());
            List<String> ids = new ArrayList<>();
            NbtList trainerIds = nbt.getList("TrainerIds", NbtElement.STRING_TYPE);
            for (int i = 0; i < trainerIds.size(); i++) {
                String id = trainerIds.getString(i).trim();
                if (!id.isBlank()) ids.add(id);
            }
            return new SpawnerData(List.copyOf(ids), nbt.containsUuid("OwnerUUID") ? nbt.getUuid("OwnerUUID").toString() : "");
        } catch (RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not read RCT Trainer Spawner NBT at {}: {}", pos, exception.toString());
            return SpawnerData.EMPTY;
        }
    }

    private static Entity findOccupant(ServerWorld world, BlockPos pos, SpawnerData data) {
        // Prefer RCT's own OwnerUUID link when present.
        if (!data.ownerUuid().isBlank()) {
            try {
                Entity owner = world.getEntity(java.util.UUID.fromString(data.ownerUuid()));
                if (owner != null && RctWorldTrainerService.isNativeWorldTrainer(owner)) return owner;
            } catch (IllegalArgumentException ignored) {
            }
        }

        Box box = new Box(pos).expand(4.0D, 3.0D, 4.0D);
        for (Entity entity : world.getOtherEntities(null, box, RctWorldTrainerService::isNativeWorldTrainer)) {
            String id = RctWorldTrainerService.nativeTrainerId(entity);
            if (data.trainerIds().contains(id)) return entity;
        }
        return null;
    }

    private static boolean forceNativeTrainer(ServerWorld world, ServerPlayerEntity player, BlockPos pos, List<String> trainerIds) {
        if (trainerIds.isEmpty() || player.getServer() == null) return false;

        // The native spawner may contain several valid variants. Keep selection deterministic for the same
        // player + block while still distributing different variants across players/locations.
        int start = Math.floorMod(java.util.Objects.hash(player.getUuid(), pos.asLong()), trainerIds.size());
        for (int i = 0; i < trainerIds.size(); i++) {
            String trainerId = trainerIds.get((start + i) % trainerIds.size());
            if (!safeTrainerId(trainerId)) continue;

            String command = String.format(Locale.ROOT, "rctmod trainer summon %s %.1f %d %.1f",
                    trainerId, pos.getX() + 0.5D, pos.getY() + 1, pos.getZ() + 0.5D);
            try {
                player.getServer().getCommandManager().executeWithPrefix(
                        player.getCommandSource().withLevel(4).withSilent(), command);
                // In 1.21.1 executeWithPrefix returns void. The command is synchronous, so verify that
                // a matching native RCT trainer now occupies the authored spawner before reporting success.
                if (findOccupant(world, pos, new SpawnerData(trainerIds, "")) != null) return true;
            } catch (RuntimeException exception) {
                Chainacobblemon.LOGGER.warn("Could not summon configured RCT trainer {} above spawner {}: {}",
                        trainerId, pos, exception.toString());
            }
        }
        return false;
    }

    private static boolean safeTrainerId(String value) {
        if (value == null || value.isBlank() || value.length() > 160) return false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == '_' || c == '-' || c == ':' || c == '.')) return false;
        }
        return true;
    }

    private static void snapToSpawner(Entity trainer, BlockPos pos) {
        if (trainer == null || pos == null) return;
        double x = pos.getX() + 0.5D;
        double y = pos.getY() + 1.0D;
        double z = pos.getZ() + 0.5D;
        if (trainer.squaredDistanceTo(x, y, z) <= 0.04D) return;
        trainer.refreshPositionAndAngles(x, y, z, trainer.getYaw(), trainer.getPitch());
    }

    private record SpawnerData(List<String> trainerIds, String ownerUuid) {
        private static final SpawnerData EMPTY = new SpawnerData(List.of(), "");
    }

    public record Result(int configuredSpawners, int activeTrainers, int forcedSpawns) {
        private static final Result EMPTY = new Result(0, 0, 0);
    }
}
