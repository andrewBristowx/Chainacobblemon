package com.andrewbristowx.chainacobblemon.client.npc;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeCatalog;
import com.andrewbristowx.chainacobblemon.client.visual.ClientVisualAssetCache;
import com.andrewbristowx.chainacobblemon.client.render.RctTrainerTextureResolver;
import com.andrewbristowx.chainacobblemon.npc.NpcNetworking.DialogueActionPayload;
import com.andrewbristowx.chainacobblemon.npc.NpcNetworking.DialogueChoice;
import com.andrewbristowx.chainacobblemon.npc.NpcNetworking.DialogueState;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

final class NpcDialogueScreen extends Screen {
    private static final Gson GSON = new Gson();
    private final Screen parent;
    private final DialogueState state;
    private int page;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    NpcDialogueScreen(Screen parent, String json) {
        super(Text.literal("Diálogo Chaina"));
        this.parent = parent;
        this.state = GSON.fromJson(json, DialogueState.class);
    }

    @Override
    protected void init() {
        clearChildren();
        panelWidth = Math.min(980, width - 36);
        panelHeight = Math.min(210, height - 30);
        panelX = (width - panelWidth) / 2;
        panelY = height - panelHeight - 18;
        int bottom = panelY + panelHeight - 29;

        if (page < state.pages().size() - 1) {
            addDrawableChild(new AdminButtonWidget(panelX + panelWidth - 126, bottom, 108, 20,
                    Text.literal("Siguiente ▶"), () -> {
                page++;
                init();
            }));
            if (state.pages().size() > 2) {
                addDrawableChild(new AdminButtonWidget(panelX + 118, bottom, 64, 20,
                        Text.literal("Saltar"), () -> {
                    page = state.pages().size() - 1;
                    init();
                }));
            }
            addDrawableChild(new AdminButtonWidget(panelX + 190, bottom, 64, 20,
                    Text.literal("Salir"), this::close));
        } else {
            addChoiceButtons(bottom);
        }
    }

    private void addChoiceButtons(int bottom) {
        List<DialogueChoice> choices = state.choices();
        if (choices == null || choices.isEmpty()) {
            addDrawableChild(new AdminButtonWidget(panelX + panelWidth - 118, bottom, 100, 20,
                    Text.literal("Cerrar"), this::close));
            return;
        }
        int columns = Math.min(4, choices.size());
        int gap = 6;
        int available = panelWidth - 150;
        int buttonWidth = Math.max(86, Math.min(158, (available - gap * (columns - 1)) / columns));
        int total = columns * buttonWidth + (columns - 1) * gap;
        int startX = panelX + panelWidth - 18 - total;
        for (int index = 0; index < choices.size(); index++) {
            DialogueChoice choice = choices.get(index);
            int x = startX + (index % columns) * (buttonWidth + gap);
            int y = bottom - (index / columns) * 23;
            addDrawableChild(new AdminButtonWidget(x, y, buttonWidth, 20,
                    Text.literal(choice.label()), () -> select(choice.id())));
        }
    }

    private void select(String action) {
        if ("close".equalsIgnoreCase(action)) {
            close();
            return;
        }
        boolean battleAction = "battle".equalsIgnoreCase(action);
        if (ClientPlayNetworking.canSend(DialogueActionPayload.ID)) {
            ClientPlayNetworking.send(new DialogueActionPayload(state.id(), action));
        }
        // Never restore a stale Cobblemon BattleGUI underneath a dialogue. Treasure dialogues can be
        // delivered on the same client tick in which the previous battle screen is being torn down;
        // reinitializing that old BattleGUI has no active battle and crashes inside BattleGUI.init().
        if (battleAction && client != null) {
            client.setScreen(null);
            return;
        }
        close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        drawPanel(context);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Keep the world visible behind the conversation, like the old ChainaProgresion dialogue.
    }

    private void drawPanel(DrawContext context) {
        context.fill(panelX + 5, panelY + 5, panelX + panelWidth + 5, panelY + panelHeight + 5, 0x78000000);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF202124);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + 4, 0xFFF9556D);
        context.fill(panelX, panelY + 4, panelX + panelWidth, panelY + 7, 0xFFF6AD4B);
        context.fill(panelX + 12, panelY + 38, panelX + panelWidth - 12, panelY + panelHeight - 34, 0xFF2D2E33);

        context.drawTextWithShadow(textRenderer, Text.literal(state.name()), panelX + 18, panelY + 16, 0xFFF5F5F7);
        if (state.subtitle() != null && !state.subtitle().isBlank()) {
            context.drawTextWithShadow(textRenderer, Text.literal(state.subtitle()), panelX + 18, panelY + 28, 0xFFFB9AA6);
        }
        String counter = (page + 1) + "/" + Math.max(1, state.pages().size());
        context.drawTextWithShadow(textRenderer, Text.literal(counter),
                panelX + panelWidth - textRenderer.getWidth(counter) - 18, panelY + 17, 0xFFF6AD4B);

        int portraitSize = 66;
        int portraitX = panelX + 22;
        int portraitY = panelY + 55;
        context.fill(portraitX - 4, portraitY - 4, portraitX + portraitSize + 4, portraitY + portraitSize + 4,
                state.locked() ? 0xFF5A4449 : 0xFFF9556D);
        Identifier fallback = Identifier.of(Chainacobblemon.MOD_ID, "textures/entity/shop_npc.png");
        fallback = RctTrainerTextureResolver.resolve(ChallengeCatalog.byNpcId(state.id()), fallback);
        String assetKey = "npc:" + state.id();
        Identifier texture = ClientVisualAssetCache.has(assetKey) ? ClientVisualAssetCache.texture(assetKey, fallback) : fallback;
        context.drawTexture(texture, portraitX, portraitY, portraitSize, portraitSize,
                8.0F, 8.0F, 8, 8, 64, 64);
        context.drawTexture(texture, portraitX, portraitY, portraitSize, portraitSize,
                40.0F, 8.0F, 8, 8, 64, 64);

        int textX = panelX + 112;
        int wrapWidth = panelX + panelWidth - 28 - textX;
        String text = state.pages().isEmpty() ? "" : state.pages().get(Math.min(page, state.pages().size() - 1));
        List<OrderedText> lines = textRenderer.wrapLines(Text.literal(text), Math.max(80, wrapWidth));
        int y = panelY + 55;
        for (OrderedText line : lines) {
            if (y > panelY + panelHeight - 67) break;
            context.drawTextWithShadow(textRenderer, line, textX, y, 0xFFF5F5F7);
            y += 14;
        }

        String reward = state.rewards() == null ? "" : state.rewards();
        if (!reward.isBlank()) {
            int rewardColor = state.rewardClaimed() ? 0xFF9CE3B0 : 0xFFF6AD4B;
            context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth("🏅 " + reward, wrapWidth)),
                    textX, panelY + panelHeight - 58, rewardColor);
        }
        if (state.locked()) {
            context.drawTextWithShadow(textRenderer, Text.literal("🔒 Desafío bloqueado"), textX,
                    panelY + panelHeight - 45, 0xFFF9556D);
        } else if (state.defeated()) {
            context.drawTextWithShadow(textRenderer, Text.literal("✓ Derrotado · revancha disponible"), textX,
                    panelY + panelHeight - 45, 0xFF91E6B1);
        } else if (page == state.pages().size() - 1 && state.choices() != null && !state.choices().isEmpty()) {
            context.drawTextWithShadow(textRenderer, Text.literal("Elige una opción:"), textX,
                    panelY + panelHeight - 45, 0xFFFB9AA6);
        }
    }

    @Override
    public void close() {
        if (client == null) return;
        if (parent != null && parent.getClass().getName().equals("com.cobblemon.mod.common.client.gui.battle.BattleGUI")) {
            client.setScreen(null);
        } else {
            client.setScreen(parent);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
