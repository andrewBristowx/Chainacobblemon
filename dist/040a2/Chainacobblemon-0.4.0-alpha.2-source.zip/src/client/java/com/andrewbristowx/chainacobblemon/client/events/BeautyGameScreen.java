package com.andrewbristowx.chainacobblemon.client.events;

import com.andrewbristowx.chainacobblemon.events.BeautyRoundSnapshot;
import com.andrewbristowx.chainacobblemon.events.EventNetworking.BeautyMovePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Simon-Says style Pokémon Exhibition. The server owns sequence/lives/timing. */
final class BeautyGameScreen extends Screen {
    private final Screen parent;
    private final BeautyRoundSnapshot snapshot;
    private final List<ButtonWidget> moveButtons = new ArrayList<>();
    private static final String[] IDS={"surf","rain_dance","body_slam","dazzling_gleam"};

    BeautyGameScreen(Screen parent, BeautyRoundSnapshot snapshot) {
        super(Text.literal("Exhibición Chaina")); this.parent=parent; this.snapshot=snapshot;
    }

    @Override protected void init() {
        moveButtons.clear();
        int bw=Math.min(190,(width-48)/2); int bh=42; int gap=12; int total=bw*2+gap; int sx=(width-total)/2; int sy=height/2+28;
        for(int i=0;i<4;i++){
            final int idx=i; String label=i<snapshot.options.size()?snapshot.options.get(i):IDS[i];
            ButtonWidget b=ButtonWidget.builder(Text.literal(label), button -> ClientPlayNetworking.send(new BeautyMovePayload(IDS[idx])))
                    .dimensions(sx+(i%2)*(bw+gap), sy+(i/2)*(bh+gap), bw,bh).build();
            moveButtons.add(addDrawableChild(b));
        }
    }

    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){
        long now=System.currentTimeMillis(); boolean reveal=now<snapshot.revealUntilEpochMillis; boolean respond=!reveal&&now<=snapshot.responseUntilEpochMillis&&!snapshot.eliminated;
        for(ButtonWidget b:moveButtons)b.active=respond;
        c.fill(0,0,width,height,0xE817101E);
        int pw=Math.min(700,width-40), ph=Math.min(410,height-30), x=(width-pw)/2,y=(height-ph)/2;
        c.fill(x,y,x+pw,y+ph,0xF02B1D32); outline(c,x,y,pw,ph,0xFFFF79B8,3);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("✦ EXHIBICIÓN CHAINA ✦"),width/2,y+22,0xFFFF79B8);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("Ronda "+snapshot.round+"   "+hearts(snapshot.lives)),width/2,y+43,0xFFFFD36A);
        String status=snapshot.eliminated?"ELIMINADO":reveal?"MEMORIZA LA SECUENCIA":"¡REPÍTELA!";
        c.drawCenteredTextWithShadow(textRenderer,Text.literal(status),width/2,y+72,snapshot.eliminated?0xFFFF6868:reveal?0xFF8FE7FF:0xFF8FF0AF);
        if(reveal&&!snapshot.sequence.isEmpty()){
            long total=Math.max(1,snapshot.revealUntilEpochMillis-(snapshot.responseUntilEpochMillis-(snapshot.responseUntilEpochMillis-snapshot.revealUntilEpochMillis)));
            long estimated=Math.max(500L,(snapshot.revealUntilEpochMillis-now)+1L);
            // Show the accumulated sequence as readable cards; the current card pulses based on remaining reveal time.
            int cards=snapshot.sequence.size(); int cardW=Math.min(120,(pw-60)/Math.max(1,Math.min(cards,5))); int start=width/2-(Math.min(cards,5)*cardW)/2;
            int from=Math.max(0,cards-5);
            for(int i=from;i<cards;i++){
                String id=snapshot.sequence.get(i); String label=label(id); int px=start+(i-from)*cardW;
                c.fill(px+3,y+105,px+cardW-3,y+154,0xFF3B2944);
                c.drawCenteredTextWithShadow(textRenderer,Text.literal(label),px+cardW/2,y+124,0xFFF8F4FA);
            }
        } else if(!reveal){
            long sec=Math.max(0,(snapshot.responseUntilEpochMillis-now+999)/1000);
            c.drawCenteredTextWithShadow(textRenderer,Text.literal("Tiempo: "+sec+"s"),width/2,y+116,0xFFC9B9CF);
        }
        super.render(c,mouseX,mouseY,delta);
    }
    private String label(String id){return switch(id){case"surf"->"🌊 SURF";case"rain_dance"->"🌧 LLUVIA";case"body_slam"->"💥 GOLPE";default->"✨ BRILLO";};}
    private String hearts(int n){return "❤".repeat(Math.max(0,n))+"♡".repeat(Math.max(0,3-n));}
    private void outline(DrawContext c,int x,int y,int w,int h,int color,int t){c.fill(x,y,x+w,y+t,color);c.fill(x,y+h-t,x+w,y+h,color);c.fill(x,y,x+t,y+h,color);c.fill(x+w-t,y,x+w,y+h,color);}
    @Override public boolean shouldPause(){return false;}
    @Override public void close(){ if(client!=null)client.setScreen(parent); }
}
