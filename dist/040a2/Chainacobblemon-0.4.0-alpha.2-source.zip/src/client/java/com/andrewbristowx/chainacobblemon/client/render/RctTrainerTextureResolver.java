package com.andrewbristowx.chainacobblemon.client.render;

import com.andrewbristowx.chainacobblemon.challenge.ChallengeCatalog;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeProfile;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Resolves the same trainer textures exposed by RCT/Cobbleverse resource packs. */
public final class RctTrainerTextureResolver {
    private static final String RCT_MOD_ID = "rctmod";
    private RctTrainerTextureResolver() {}

    public static Identifier resolve(ChallengeProfile challenge, Identifier fallback) {
        if (challenge == null) return fallback;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return fallback;
        ResourceManager resources = client.getResourceManager();

        // First follow RCT's documented/data-pack convention exactly.
        for (String trainerId : trainerCandidates(challenge)) {
            for (String path : List.of(
                    "textures/trainers/single/" + trainerId + ".png",
                    "textures/trainers/" + trainerId + ".png",
                    "textures/trainer/" + trainerId + ".png",
                    "textures/entity/trainers/" + trainerId + ".png")) {
                Identifier id = Identifier.of(RCT_MOD_ID, path);
                if (resources.getResource(id).isPresent()) return id;
            }
        }

        // Cobbleverse can layer/rename RCT resources. Discover every RCT single-trainer texture
        // currently loaded by the client and score it against region + trainer aliases.
        try {
            Map<Identifier, ?> found = resources.findResources("textures/trainers/single",
                    id -> RCT_MOD_ID.equals(id.getNamespace()) && id.getPath().endsWith(".png"));
            return found.keySet().stream()
                    .map(id -> Map.entry(id, score(id, challenge)))
                    .filter(entry -> entry.getValue() > 0)
                    .max(Comparator.comparingInt(Map.Entry::getValue))
                    .map(Map.Entry::getKey)
                    .orElse(fallback);
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }


    public static Identifier resolveTower(String npcId, Identifier fallback) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return fallback;
        ResourceManager resources = client.getResourceManager();
        try {
            Map<Identifier, ?> found = resources.findResources("textures/trainers/single",
                    id -> RCT_MOD_ID.equals(id.getNamespace()) && id.getPath().endsWith(".png"));
            if (found.isEmpty()) return fallback;

            LinkedHashSet<String> specialTokens = new LinkedHashSet<>();
            for (ChallengeProfile profile : ChallengeCatalog.all()) {
                if (!profile.isLeader() && !profile.isEliteFour() && !profile.isChampion()) continue;
                for (String token : RctCobbleverseBridge.searchTokens(profile)) {
                    String clean = clean(token);
                    if (clean.length() >= 4) specialTokens.add(clean);
                }
            }

            List<Identifier> generic = found.keySet().stream()
                    .filter(id -> isGenericTowerTexture(id, specialTokens))
                    .sorted(Comparator.comparing(Identifier::toString))
                    .toList();
            if (generic.isEmpty()) {
                generic = found.keySet().stream().sorted(Comparator.comparing(Identifier::toString)).toList();
            }
            if (generic.isEmpty()) return fallback;
            int explicit = embeddedSkinIndex(npcId);
            int index = explicit >= 0 ? Math.floorMod(explicit, generic.size())
                    : Math.floorMod((npcId == null ? 0 : npcId.hashCode()), generic.size());
            return generic.get(index);
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }


    private static int embeddedSkinIndex(String npcId) {
        if (npcId == null) return -1;
        String lower = npcId.toLowerCase(Locale.ROOT);
        int at = lower.lastIndexOf("_skin");
        if (at < 0 || at + 5 >= lower.length()) return -1;
        try { return Integer.parseInt(lower.substring(at + 5)); }
        catch (NumberFormatException ignored) { return -1; }
    }
    private static boolean isGenericTowerTexture(Identifier id, java.util.Set<String> specialTokens) {
        String path = id.getPath().toLowerCase(Locale.ROOT);
        String file = path.substring(path.lastIndexOf('/') + 1).replace(".png", "");
        if (file.contains("leader") || file.contains("champion") || file.contains("elite") || file.contains("e4_")) return false;
        for (String token : specialTokens) {
            if (file.equals(token) || file.endsWith("_" + token) || file.startsWith(token + "_")) return false;
        }
        return true;
    }

    private static List<String> trainerCandidates(ChallengeProfile p) {
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        String region = clean(p.regionId());
        for (String token : RctCobbleverseBridge.searchTokens(p)) {
            token = clean(token);
            ids.add(region + "_" + token);
            ids.add(token);
            if (p.isLeader()) {
                ids.add("leader_" + token);
                ids.add(region + "_leader_" + token);
            } else if (p.isEliteFour()) {
                ids.add(region + "_league_" + token);
                ids.add(region + "_elite_" + token);
                ids.add("elite_" + token);
                ids.add("e4_" + token);
            } else if (p.isChampion()) {
                ids.add(region + "_champion_" + token);
                ids.add("champion_" + token);
                ids.add("champ_" + token);
            }
        }
        return List.copyOf(ids);
    }

    private static int score(Identifier id, ChallengeProfile p) {
        String path = id.getPath().toLowerCase(Locale.ROOT);
        int slash = path.lastIndexOf('/');
        String file = slash >= 0 ? path.substring(slash + 1) : path;
        if (file.endsWith(".png")) file = file.substring(0, file.length() - 4);
        String region = clean(p.regionId());
        int best = 0;
        for (String tokenRaw : RctCobbleverseBridge.searchTokens(p)) {
            String token = clean(tokenRaw);
            if (!file.contains(token)) continue;
            int s = 80;
            if (file.equals(token)) s += 60;
            if (file.equals(region + "_" + token)) s += 160;
            if (file.startsWith(region + "_")) s += 90;
            if (p.isLeader() && file.contains("leader")) s += 30;
            if (p.isEliteFour() && (file.contains("elite") || file.contains("league") || file.contains("e4"))) s += 40;
            if (p.isChampion() && (file.contains("champion") || file.contains("champ"))) s += 50;
            best = Math.max(best, s - Math.min(35, file.length() / 3));
        }
        return best;
    }

    private static String clean(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).replace('-', '_').replaceAll("[^a-z0-9_]+", "_");
    }
}
