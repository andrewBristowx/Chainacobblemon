package com.andrewbristowx.chainacobblemon.client.progress;

import com.andrewbristowx.chainacobblemon.progress.JournalSnapshot;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.List;

final class QuestJournalScreen extends Screen {
    private static final List<String> TABS = List.of("guide", "tutorial", "progression", "adventure", "jobs");
    private static final List<String> TAB_LABELS = List.of("Guía", "Minecraft", "Pokémon", "Aventura", "Trabajos");

    private final Screen parent;
    private final JournalSnapshot snapshot;
    private final String tab;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private int chapterScroll;
    private boolean draggingChapterScrollbar;

    QuestJournalScreen(Screen parent, JournalSnapshot snapshot, String tab) {
        super(Text.literal("Diario de aventuras"));
        this.parent = parent;
        this.snapshot = snapshot;
        this.tab = TABS.contains(tab) ? tab : "guide";
    }

    Screen parent() {
        return parent;
    }

    @Override
    protected void init() {
        panelWidth = Math.min(720, width - 24);
        panelHeight = Math.min(420, height - 24);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        int gap = 6;
        int tabsX = panelX + 18;
        int tabWidth = (panelWidth - 36 - gap * (TABS.size() - 1)) / TABS.size();
        for (int index = 0; index < TABS.size(); index++) {
            String value = TABS.get(index);
            addDrawableChild(new JournalButtonWidget(tabsX + index * (tabWidth + gap), panelY + 42,
                    tabWidth, 20, Text.literal(TAB_LABELS.get(index)), () -> switchTab(value), () -> value.equals(tab)));
        }
        addDrawableChild(new JournalButtonWidget(panelX + panelWidth - 30, panelY + 14, 18, 18,
                Text.literal("×"), this::close));

        if (isMissionTab()) initMissionButtons();
        if ("jobs".equals(tab)) initJobButtons();
    }

    private boolean isMissionTab() {
        return "tutorial".equals(tab) || "progression".equals(tab) || "adventure".equals(tab);
    }

    private void initMissionButtons() {
        JournalSnapshot.QuestView quest = snapshot.quest;
        if (quest != null && quest.complete && !quest.claimed) {
            addDrawableChild(new JournalButtonWidget(panelX + panelWidth - 198, panelY + panelHeight - 42, 178, 22,
                    Text.literal("Reclamar recompensa"), () -> ProgressionClient.sendAction("claim", tab)));
        }
    }

    private void initJobButtons() {
        int rowY = panelY + 84;
        int rowHeight = Math.max(31, Math.min(39, (panelHeight - 132) / Math.max(1, snapshot.jobs.size())));
        for (JournalSnapshot.JobView job : snapshot.jobs) {
            addDrawableChild(new JournalButtonWidget(panelX + panelWidth - 84, rowY + 4, 62, 20,
                    Text.literal(job.active ? "Quitar" : "Elegir"),
                    () -> ProgressionClient.sendAction(job.active ? "job_leave" : "job_join", job.id), () -> job.active));
            rowY += rowHeight;
        }
    }

    private void switchTab(String next) {
        if (!tab.equals(next)) ProgressionClient.requestOpen(next);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xB8353434);
        drawPanel(context);
        if ("guide".equals(tab)) drawGuide(context);
        else if ("jobs".equals(tab)) drawJobs(context);
        else drawMissions(context);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // The journal draws its own background before Screen renders its widgets.
    }

    private void drawPanel(DrawContext context) {
        context.fill(panelX + 6, panelY + 8, panelX + panelWidth + 6, panelY + panelHeight + 8, 0x82000000);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF202124);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + 4, 0xFFF9556D);
        context.fill(panelX, panelY + 4, panelX + panelWidth, panelY + 7, 0xFFF6AD4B);
        context.fill(panelX, panelY + panelHeight - 4, panelX + panelWidth, panelY + panelHeight, 0xFFF6AD4B);
        context.fill(panelX, panelY, panelX + 3, panelY + panelHeight, 0xFFFB9AA6);
        context.fill(panelX + panelWidth - 3, panelY, panelX + panelWidth, panelY + panelHeight, 0xFFFB9AA6);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Diario de aventuras de Chaina"),
                panelX + panelWidth / 2, panelY + 20, 0xFFF5F5F7);
        context.fill(panelX + 14, panelY + 70, panelX + panelWidth - 14, panelY + 71, 0x70F9556D);
        drawSakura(context, panelX + 24, panelY + 20, 2);
        drawSakura(context, panelX + panelWidth - 35, panelY + panelHeight - 33, 2);
    }

    private void drawGuide(DrawContext context) {
        int left = panelX + 18;
        int top = panelY + 84;
        int gap = 10;
        int cardWidth = (panelWidth - 46) / 2;
        drawGuideCard(context, left, top, cardWidth, 89, "◆ CHAIBELLS",
                "Consíguelas completando misiones, trabajando, capturando, ganando combates y jugando activamente.",
                "Saldo actual: " + snapshot.balance);
        drawGuideCard(context, left + cardWidth + gap, top, cardWidth, 89, "◆ TIRADAS Y TICKETS",
                "Reclama /diario y /pase. Las misiones también entregan tickets. Cada máquina consume su ticket indicado.",
                "Chaina = especial · Estándar = normal · Garra = garra");
        drawGuideCard(context, left, top + 99, cardWidth, 89, "◆ PASE DE CHAINA",
                "Ganas XP al jugar activamente, capturar, combatir, evolucionar, explorar, completar misiones y trabajar.",
                "Cada nivel tiene premio; cada 4 niveles incluye tirada de Chaina.");
        drawGuideCard(context, left + cardWidth + gap, top + 99, cardWidth, 89, "◆ TRABAJOS",
                "Elige oficios en la pestaña Trabajos y realiza acciones legítimas. Normal: 2; VIP: 4; staff: todos.",
                "8 XP de trabajo = 1 XP de pase (máx. 12 por minuto).");
        drawGuideCard(context, left, top + 198, cardWidth, 89, "◆ POR DÓNDE EMPEZAR",
                "Abre Minecraft para aprender desde cero. Luego usa Pokémon para tu aventura de entrenador.",
                "Aventura contiene estructuras, altares y desafíos avanzados.");
        drawGuideCard(context, left + cardWidth + gap, top + 198, cardWidth, 89, "◆ DESAFÍOS DE ENTRENADOR",
                "Las mesas muestran coste y estado antes de confirmar. Si una entrega falla, el servidor conserva o devuelve el premio.",
                "Consulta siempre el panel derecho de cada juego.");
    }

    private void drawGuideCard(DrawContext context, int x, int y, int width, int height,
                               String title, String body, String footer) {
        context.fill(x, y, x + width, y + height, 0xFF313238);
        context.fill(x, y, x + 4, y + height, 0xFFF9556D);
        context.drawTextWithShadow(textRenderer, Text.literal(title), x + 11, y + 9, 0xFFF5F5F7);
        drawWrapped(context, body, x + 11, y + 27, width - 22, 0xFFF5F5F7, 3);
        context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(footer, width - 22)),
                x + 11, y + height - 17, 0xFFF6AD4B);
    }

    private void drawMissions(DrawContext context) {
        int leftWidth = Math.min(190, panelWidth / 3);
        int leftX = panelX + 16;
        int top = panelY + 84;
        context.fill(leftX, top, leftX + leftWidth, panelY + panelHeight - 18, 0xFF292A2E);
        context.drawTextWithShadow(textRenderer, Text.literal(trackHeading()), leftX + 10, top + 9, 0xFFFB9AA6);
        int chapterTop = top + 27;
        int chapterBottom = panelY + panelHeight - 49;
        int visibleHeight = Math.max(1, chapterBottom - chapterTop);
        int contentHeight = snapshot.chapters.size() * 39;
        int maxScroll = Math.max(0, contentHeight - visibleHeight);
        chapterScroll = MathHelper.clamp(chapterScroll, 0, maxScroll);
        context.enableScissor(leftX + 5, chapterTop, leftX + leftWidth - 8, chapterBottom);
        int chapterY = chapterTop - chapterScroll;
        for (JournalSnapshot.ChapterView chapter : snapshot.chapters) {
            boolean current = snapshot.quest != null && chapter.id.equals(snapshot.quest.chapter);
            if (chapterY + 34 >= chapterTop && chapterY <= chapterBottom) {
                int color = current ? 0xFF443439 : chapter.unlocked ? 0xFF313238 : 0xFF242529;
                context.fill(leftX + 7, chapterY, leftX + leftWidth - 12, chapterY + 34, color);
                String marker = chapter.unlocked ? (current ? "◆ " : "◇ ") : "[X] ";
                context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(marker + chapter.title, leftWidth - 30)),
                        leftX + 13, chapterY + 6, current ? 0xFFF5F5F7 : 0xFFDEDEE9);
                context.drawTextWithShadow(textRenderer, Text.literal(chapter.complete + "/" + chapter.total), leftX + 13,
                        chapterY + 19, chapter.complete >= chapter.total ? 0xFF91E6B1 : 0xFFDEDEE9);
            }
            chapterY += 39;
        }
        context.disableScissor();
        drawChapterScrollbar(context, leftX, leftWidth, chapterTop, chapterBottom, maxScroll);

        int bodyX = leftX + leftWidth + 16;
        int bodyRight = panelX + panelWidth - 18;
        JournalSnapshot.QuestView quest = snapshot.quest;
        if (quest == null) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("¡Has completado todas las misiones disponibles!"),
                    (bodyX + bodyRight) / 2, top + 80, 0xFFF6AD4B);
            return;
        }
        context.drawTextWithShadow(textRenderer, Text.literal("Capítulo " + quest.chapter + " — " + quest.chapterTitle),
                bodyX, top + 4, 0xFFFB9AA6);
        context.drawTextWithShadow(textRenderer, Text.literal(quest.title), bodyX, top + 24, 0xFFF5F5F7);
        drawWrapped(context, quest.description, bodyX, top + 43, bodyRight - bodyX, 0xFFF5F5F7, 3);

        int objectiveY = top + 104;
        context.fill(bodyX, objectiveY, bodyRight, objectiveY + 64, 0xFF313238);
        context.drawTextWithShadow(textRenderer, Text.literal("OBJETIVO"), bodyX + 10, objectiveY + 8, 0xFFFB9AA6);
        context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(quest.objective, bodyRight - bodyX - 95)),
                bodyX + 10, objectiveY + 24, 0xFFF5F5F7);
        String progress = quest.progress + " / " + quest.target;
        context.drawTextWithShadow(textRenderer, Text.literal(progress), bodyRight - textRenderer.getWidth(progress) - 10,
                objectiveY + 24, quest.complete ? 0xFF9CF0B6 : 0xFFF5F5F7);
        int barLeft = bodyX + 10;
        int barRight = bodyRight - 10;
        int filled = (int) ((barRight - barLeft) * MathHelper.clamp((double) quest.progress / Math.max(1L, quest.target), 0.0D, 1.0D));
        context.fill(barLeft, objectiveY + 43, barRight, objectiveY + 52, 0xFF3A3B40);
        context.fill(barLeft + 1, objectiveY + 44, barLeft + Math.max(1, filled), objectiveY + 51,
                quest.complete ? 0xFF73D99A : 0xFFF9556D);

        int rewardY = objectiveY + 76;
        context.drawTextWithShadow(textRenderer, Text.literal("RECOMPENSAS"), bodyX, rewardY, 0xFFFB9AA6);
        context.drawTextWithShadow(textRenderer, Text.literal(quest.coins + " ChaiBells"), bodyX, rewardY + 18, 0xFFF6AD4B);
        context.drawTextWithShadow(textRenderer, Text.literal("+" + quest.battlePassXp + " XP de pase"),
                bodyX, rewardY + 33, 0xFFF9556D);
        int itemY = rewardY + 49;
        for (String item : quest.items) {
            context.drawTextWithShadow(textRenderer, Text.literal("• " + friendlyItem(item)), bodyX, itemY, 0xFFDEDEE9);
            itemY += 13;
        }
        context.drawTextWithShadow(textRenderer,
                Text.literal(trackName() + ": " + snapshot.completedQuests + "/" + snapshot.totalQuests),
                leftX + 10, panelY + panelHeight - 33, 0xFFDEDEE9);
    }

    private void drawChapterScrollbar(DrawContext context, int leftX, int leftWidth,
                                      int top, int bottom, int maxScroll) {
        int x1 = leftX + leftWidth - 7;
        int x2 = leftX + leftWidth - 3;
        context.fill(x1, top, x2, bottom, 0xFF3A3B40);
        if (maxScroll <= 0) {
            context.fill(x1, top, x2, bottom, 0xFF59515A);
            return;
        }
        int track = bottom - top;
        int content = track + maxScroll;
        int thumb = Math.max(24, track * track / Math.max(1, content));
        int travel = Math.max(1, track - thumb);
        int thumbY = top + (int) Math.round((double) chapterScroll / maxScroll * travel);
        context.fill(x1 - 1, thumbY, x2 + 1, thumbY + thumb, draggingChapterScrollbar ? 0xFFF9556D : 0xFFF9556D);
    }

    private int chapterMaxScroll() {
        if (!isMissionTab()) return 0;
        int top = panelY + 84 + 27;
        int bottom = panelY + panelHeight - 49;
        return Math.max(0, snapshot.chapters.size() * 39 - Math.max(1, bottom - top));
    }

    private boolean inChapterPanel(double mouseX, double mouseY) {
        int leftWidth = Math.min(190, panelWidth / 3);
        int leftX = panelX + 16;
        int top = panelY + 84 + 27;
        int bottom = panelY + panelHeight - 49;
        return mouseX >= leftX && mouseX <= leftX + leftWidth && mouseY >= top && mouseY <= bottom;
    }

    private void setChapterScrollFromMouse(double mouseY) {
        int max = chapterMaxScroll();
        if (max <= 0) { chapterScroll = 0; return; }
        int top = panelY + 84 + 27;
        int bottom = panelY + panelHeight - 49;
        int track = Math.max(1, bottom - top);
        int content = track + max;
        int thumb = Math.max(24, track * track / Math.max(1, content));
        int travel = Math.max(1, track - thumb);
        double pos = MathHelper.clamp(mouseY - top - thumb / 2.0, 0.0, travel);
        chapterScroll = MathHelper.clamp((int) Math.round(pos / travel * max), 0, max);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isMissionTab() && inChapterPanel(mouseX, mouseY) && chapterMaxScroll() > 0) {
            chapterScroll = MathHelper.clamp(chapterScroll - (int) Math.round(verticalAmount * 28.0), 0, chapterMaxScroll());
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isMissionTab() && inChapterPanel(mouseX, mouseY)) {
            int leftWidth = Math.min(190, panelWidth / 3);
            int scrollbarX = panelX + 16 + leftWidth - 10;
            if (mouseX >= scrollbarX) {
                draggingChapterScrollbar = true;
                setChapterScrollFromMouse(mouseY);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && draggingChapterScrollbar) {
            setChapterScrollFromMouse(mouseY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && draggingChapterScrollbar) {
            draggingChapterScrollbar = false;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void drawJobs(DrawContext context) {
        int rowY = panelY + 84;
        int rowHeight = Math.max(31, Math.min(39, (panelHeight - 132) / Math.max(1, snapshot.jobs.size())));
        for (JournalSnapshot.JobView job : snapshot.jobs) {
            int color = job.active ? 0xFF403136 : 0xFF313238;
            context.fill(panelX + 18, rowY, panelX + panelWidth - 18, rowY + rowHeight - 3, color);
            if (job.active) context.fill(panelX + 18, rowY, panelX + 22, rowY + rowHeight - 3, 0xFFF9556D);
            context.drawTextWithShadow(textRenderer, Text.literal((job.active ? "◆ " : "◇ ") + job.name + "  Nv. " + job.level),
                    panelX + 30, rowY + 5, job.active ? 0xFFF5F5F7 : 0xFFF5F5F7);
            context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(job.description, panelWidth - 330)),
                    panelX + 30, rowY + 18, 0xFFDEDEE9);
            int barLeft = panelX + panelWidth - 230;
            int barRight = panelX + panelWidth - 94;
            double fraction = job.nextLevel <= job.levelStart ? 1.0D
                    : (double) (job.xp - job.levelStart) / (double) (job.nextLevel - job.levelStart);
            int filled = (int) ((barRight - barLeft) * MathHelper.clamp(fraction, 0.0D, 1.0D));
            context.fill(barLeft, rowY + 10, barRight, rowY + 17, 0xFF3A3B40);
            context.fill(barLeft + 1, rowY + 11, barLeft + Math.max(1, filled), rowY + 16, 0xFFF9556D);
            rowY += rowHeight;
        }
        String slots = snapshot.maxActiveJobs >= snapshot.jobs.size()
                ? "Trabajos activos: " + snapshot.activeJobCount + " / todos"
                : "Trabajos activos: " + snapshot.activeJobCount + " / " + snapshot.maxActiveJobs;
        context.drawTextWithShadow(textRenderer, Text.literal(slots), panelX + 20, panelY + panelHeight - 39, 0xFFDEDEE9);
        context.drawTextWithShadow(textRenderer,
                Text.literal("Progreso del pase: 1 XP por cada 8 XP de trabajo · límite 12 XP/minuto"),
                panelX + 20, panelY + panelHeight - 25, 0xFFF6AD4B);
    }

    private String trackHeading() {
        return "tutorial".equals(tab) ? "TUTORIAL" : "CAPÍTULOS";
    }

    private String trackName() {
        return switch (tab) {
            case "tutorial" -> "Minecraft";
            case "adventure" -> "Aventura";
            default -> "Pokémon";
        };
    }

    private String friendlyItem(String value) {
        return value.replace("minecraft:", "").replace("cobblemon:", "").replace("chainacobblemon:", "")
                .replace('_', ' ');
    }

    private void drawSakura(DrawContext c, int x, int y, int s) {
        int petal = 0xFFFB9AA6, gold = 0xFFF6AD4B;
        c.fill(x+s,y,x+2*s,y+s,petal); c.fill(x,y+s,x+s,y+2*s,petal);
        c.fill(x+2*s,y+s,x+3*s,y+2*s,petal); c.fill(x+s,y+2*s,x+2*s,y+3*s,petal);
        c.fill(x+s,y+s,x+2*s,y+2*s,gold);
    }

    private void drawWrapped(DrawContext context, String value, int x, int y, int width, int color, int maxLines) {
        List<OrderedText> lines = textRenderer.wrapLines(Text.literal(value), width);
        for (int index = 0; index < Math.min(maxLines, lines.size()); index++) {
            context.drawTextWithShadow(textRenderer, lines.get(index), x, y + index * 11, color);
        }
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
