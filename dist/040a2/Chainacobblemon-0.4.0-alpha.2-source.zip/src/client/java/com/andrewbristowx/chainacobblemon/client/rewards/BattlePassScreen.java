package com.andrewbristowx.chainacobblemon.client.rewards;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.andrewbristowx.chainacobblemon.rewards.BattlePassSnapshot;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.List;

final class BattlePassScreen extends Screen {
    private static final Identifier BACKGROUND = Identifier.of(Chainacobblemon.MOD_ID, "textures/gui/battle_pass.png");
    private static final int REF_W = 1536;
    private static final int REF_H = 1024;
    private final Screen parent;
    private final BattlePassSnapshot snapshot;
    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    BattlePassScreen(Screen parent, BattlePassSnapshot snapshot) {
        super(Text.literal("Pase infinito de Chaina"));
        this.parent = parent;
        this.snapshot = snapshot;
    }

    Screen parent() { return parent; }

    @Override
    protected void init() {
        int availableW = Math.min(REF_W, Math.max(1, width - 18));
        int availableH = Math.min(REF_H, Math.max(1, height - 18));
        if (availableW / (float) availableH > REF_W / (float) REF_H) {
            panelH = availableH;
            panelW = Math.round(panelH * REF_W / (float) REF_H);
        } else {
            panelW = availableW;
            panelH = Math.round(panelW * REF_H / (float) REF_W);
        }
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        addDrawableChild(new InvisibleHotspotButton(panelX + rx(1438), panelY + ry(28), rx(70), ry(62),
                Text.literal("Cerrar pase"), button -> close()));
        addDrawableChild(new InvisibleHotspotButton(panelX + rx(25), panelY + ry(520), rx(75), ry(70),
                Text.literal("Página anterior"), button -> BattlePassClient.request("page", Math.max(0, snapshot.page - 1))));
        addDrawableChild(new InvisibleHotspotButton(panelX + rx(1435), panelY + ry(520), rx(75), ry(70),
                Text.literal("Página siguiente"), button -> BattlePassClient.request("page", snapshot.page + 1)));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xB8353434);
        context.drawTexture(BACKGROUND, panelX, panelY, panelW, panelH, 0, 0, REF_W, REF_H, REF_W, REF_H);
        drawHeader(context);
        drawTrack(context, snapshot.free, false, mouseX, mouseY);
        drawTrack(context, snapshot.premiumTrack, true, mouseX, mouseY);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawHeader(DrawContext context) {
        drawCentered(context, "PASE INFINITO DE CHAINA", 760, 54, 0xFFF5F5F7);
        drawCentered(context, "NIVEL " + snapshot.level, 760, 92, 0xFFF6AD4B);
        drawCentered(context, snapshot.playerName, 150, 54, 0xFFFFFFFF);
        drawCentered(context, "Nv. " + snapshot.level, 150, 86, 0xFFF6AD4B);
        long span = Math.max(1L, snapshot.nextLevelXp - snapshot.levelStartXp);
        double fraction = MathHelper.clamp((snapshot.experience - snapshot.levelStartXp) / (double) span, 0.0D, 1.0D);
        int left = panelX + rx(448);
        int right = panelX + rx(1073);
        int top = panelY + ry(148);
        context.fill(left, top, right, top + Math.max(4, ry(13)), 0xFF4A4245);
        context.fill(left + 1, top + 1, left + Math.max(2, Math.round((right - left - 2) * (float) fraction)),
                top + Math.max(3, ry(12)), 0xFFF9556D);
        drawCentered(context, (snapshot.experience - snapshot.levelStartXp) + " / " + span + " XP", 760, 146, 0xFFFFFFFF);
        drawCentered(context, "GRATIS", 135, 421, 0xFFF5F5F7);
        drawCentered(context, snapshot.premium ? "VIP ACTIVO" : "VIP BLOQUEADO", 135, 735,
                snapshot.premium ? 0xFFF6AD4B : 0xFFDEDEE9);
        drawCentered(context, "Todos los niveles dan premio · Cada 4 niveles: tirada de Chaina · Incluye Tickets de Tesoros", 760, 218, 0xFFF6AD4B);
        if (snapshot.message != null && !snapshot.message.isBlank()) drawCentered(context, snapshot.message, 760, 958, 0xFFFFFFFF);
    }

    private void drawTrack(DrawContext context, List<BattlePassSnapshot.RewardSlot> slots, boolean premium,
                           int mouseX, int mouseY) {
        int[] centers = {278, 432, 586, 740, 894, 1048, 1202, 1356};
        int centerY = premium ? 755 : 408;
        int iconY = premium ? 730 : 383;
        for (int index = 0; index < Math.min(centers.length, slots.size()); index++) {
            BattlePassSnapshot.RewardSlot slot = slots.get(index);
            int cx = panelX + rx(centers[index]);
            int cardX = panelX + rx(centers[index] - 67);
            int cardY = panelY + ry(premium ? 630 : 286);
            int cardW = rx(134);
            int cardH = ry(232);
            boolean hovered = mouseX >= cardX && mouseX < cardX + cardW && mouseY >= cardY && mouseY < cardY + cardH;
            if (!slot.unlocked || premium && !snapshot.premium) context.fill(cardX + 2, cardY + 2, cardX + cardW - 2, cardY + cardH - 2, 0x77000000);
            if (hovered && slot.claimable && (!premium || snapshot.premium))
                context.fill(cardX + 3, cardY + 3, cardX + cardW - 3, cardY + cardH - 3, 0x42FFFFFF);
            drawCenteredPx(context, "NIVEL " + slot.level, cx, panelY + ry(premium ? 655 : 311), 0xFFFFFFFF);
            ItemStack stack = rewardStack(slot);
            if (!stack.isEmpty()) drawLargeItem(context, stack, cx, panelY + ry(iconY), rx(46));
            else drawCenteredPx(context, "✦", cx, panelY + ry(iconY - 8), premium ? 0xFFF6AD4B : 0xFFF9556D);
            drawCenteredPx(context, "×" + slot.amount, cx, panelY + ry(premium ? 772 : 425), 0xFFF6AD4B);
            drawFittedCenteredPx(context, slot.label, cx, panelY + ry(premium ? 798 : 451), rx(112), 0xFFF5F5F7);
            String status = slot.claimed ? "RECLAMADO" : slot.unlocked && (!premium || snapshot.premium)
                    ? "RECLAMAR" : "BLOQUEADO";
            drawFittedCenteredPx(context, status, cx, panelY + ry(premium ? 824 : 477), rx(116),
                    slot.claimed ? 0xFF9CE3B0 : slot.unlocked ? 0xFFFFFFFF : 0xFFDEDEE9);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (clickTrack(snapshot.free, false, mouseX, mouseY)) return true;
            if (clickTrack(snapshot.premiumTrack, true, mouseX, mouseY)) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean clickTrack(List<BattlePassSnapshot.RewardSlot> slots, boolean premium, double mouseX, double mouseY) {
        int[] centers = {278, 432, 586, 740, 894, 1048, 1202, 1356};
        for (int index = 0; index < Math.min(centers.length, slots.size()); index++) {
            int x = panelX + rx(centers[index] - 67);
            int y = panelY + ry(premium ? 630 : 286);
            if (mouseX < x || mouseX >= x + rx(134) || mouseY < y || mouseY >= y + ry(232)) continue;
            BattlePassSnapshot.RewardSlot slot = slots.get(index);
            if (slot.claimable && (!premium || snapshot.premium)) {
                BattlePassClient.request(premium ? "claim_premium" : "claim_free", slot.level);
                return true;
            }
        }
        return false;
    }

    private void drawLargeItem(DrawContext context, ItemStack stack, int centerX, int centerY, int size) {
        float scale = Math.max(1.0F, size / 16.0F);
        context.getMatrices().push();
        context.getMatrices().translate(centerX - 8.0F * scale, centerY - 8.0F * scale, 160.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.drawItem(stack, 0, 0);
        context.getMatrices().pop();
    }

    private ItemStack rewardStack(BattlePassSnapshot.RewardSlot slot) {
        Identifier id = Identifier.tryParse(slot.itemId);
        if (id == null || !Registries.ITEM.containsId(id)) return ItemStack.EMPTY;
        Item item = Registries.ITEM.get(id);
        return item == Items.AIR ? ItemStack.EMPTY : new ItemStack(item);
    }

    private void drawFittedCenteredPx(DrawContext context, String value, int centerX, int y, int maxWidth, int color) {
        if (value == null) return;
        int width = Math.max(1, textRenderer.getWidth(value));
        float scale = Math.min(1.0F, maxWidth / (float) width);
        context.getMatrices().push();
        context.getMatrices().translate(centerX, y, 180.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.drawTextWithShadow(textRenderer, Text.literal(value), -width / 2, 0, color);
        context.getMatrices().pop();
    }

    private void drawCentered(DrawContext context, String value, int x, int y, int color) {
        drawCenteredPx(context, value, panelX + rx(x), panelY + ry(y), color);
    }

    private void drawCenteredPx(DrawContext context, String value, int x, int y, int color) {
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(value), x, y, color);
    }

    private int rx(int value) { return Math.round(value * panelW / (float) REF_W); }
    private int ry(int value) { return Math.round(value * panelH / (float) REF_H); }

    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }
    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
