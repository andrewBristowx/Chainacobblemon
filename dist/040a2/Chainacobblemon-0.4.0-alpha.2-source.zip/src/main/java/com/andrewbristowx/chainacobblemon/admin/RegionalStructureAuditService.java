package com.andrewbristowx.chainacobblemon.admin;

import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.resource.ResourceManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.structure.Structure;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Read-only audit for the final pregenerated Chainacobblemon world.
 *
 * Alpha.9 checks BOTH the live STRUCTURE registry and datapack resources. That distinction matters for
 * Cobbleverse: several legendary locations are shipped as NBT templates and can be placed/located by
 * pack logic without necessarily exposing a same-named entry in RegistryKeys.STRUCTURE. Alpha.7 only
 * inspected the registry, which caused false negatives such as Ilex Shrine/Wish Cave/New Moon.
 * Alpha.9 also removes Cobblemon's Resurrection Machine from worldgen requirements because it is a
 * player-built multiblock, and recognizes Cobbleverse 1.7.42's canonical Hoenn paired gym naming
 * (Tell & Pat / hoenn_tell; legacy hoenn_pat alias).
 *
 * The expected list follows the currently documented Cobbleverse Kanto/Johto/Hoenn/Sinnoh content.
 * Speculative Hoenn Magma/Aqua bases are deliberately not mandatory worldgen requirements.
 */
public final class RegionalStructureAuditService {
    private RegionalStructureAuditService() {}

    public enum Source {
        REGISTERED("REGISTRY", 4),
        WORLDGEN_JSON("WORLDGEN", 3),
        STRUCTURE_SET("SET", 2),
        TEMPLATE("TEMPLATE", 1);

        private final String label;
        private final int rank;
        Source(String label, int rank) { this.label = label; this.rank = rank; }
        public String label() { return label; }
        public int rank() { return rank; }
    }

    public record Candidate(Identifier id, Source source) {
        public String display() { return "[" + source.label() + "] " + id; }
    }

    public record Expected(String label, List<String> aliases) {}

    public record RegionResult(String region, int matched, int expected, int registered,
                               List<String> missing, Map<String, List<String>> matches) {
        public boolean complete() { return missing.isEmpty(); }
        public int assetOnly() { return Math.max(0, matched - registered); }
    }

    public record AuditResult(int registryCount, int datapackAssetCount, int matched, int expected,
                              int registeredMatches, Map<String, RegionResult> regions,
                              List<String> cobbleverseCandidates) {
        public boolean ready() { return regions.values().stream().allMatch(RegionResult::complete); }
        public int assetOnlyMatches() { return Math.max(0, matched - registeredMatches); }
    }

    private static final Map<String, List<Expected>> EXPECTED = new LinkedHashMap<>();
    static {
        EXPECTED.put("Kanto", List.of(
                gym("Brock", "brock"), gym("Misty", "misty"), gym("Lt. Surge", "surge", "lt surge"),
                gym("Erika", "erika"), gym("Koga", "koga"), gym("Sabrina", "sabrina"),
                gym("Blaine", "blaine"), gym("Giovanni", "giovanni"),
                core("Liga Kanto", "kanto league", "league kanto", "kanto pokemon league"),
                core("Altar Articuno", "articuno altar", "articuno tower", "articuno"),
                core("Altar Zapdos", "zapdos altar", "zapdos tower", "zapdos"),
                core("Altar Moltres", "moltres altar", "moltres tower", "moltres"),
                core("Santuario Mew", "mew shrine", "mew")
        ));

        EXPECTED.put("Johto", List.of(
                gym("Falkner/Valerio", "falkner", "valerio"), gym("Bugsy/Raffaello", "bugsy", "raffaello"),
                gym("Whitney/Chiara", "whitney", "chiara"), gym("Morty/Angelo", "morty", "angelo"),
                gym("Chuck/Furio", "chuck", "furio"), gym("Jasmine", "jasmine"),
                gym("Pryce/Alfredo", "pryce", "alfredo"), gym("Clair/Sandra", "clair", "sandra"),
                core("Liga Johto", "johto league", "league johto", "johto pokemon league"),
                core("Torre Quemada", "burned tower", "burn tower", "burned"),
                core("Torre Campana", "bell tower", "ho oh tower", "bell"),
                core("Islas Remolino", "whirl island", "whirl islands", "lugia", "whirl"),
                core("Santuario Ilex/Celebi", "ilex shrine", "ilex forest shrine", "celebi shrine", "ilex", "celebi"),
                core("Torre Radio Team Rocket", "radio tower", "rocket radio", "johto radio", "goldenrod radio")
        ));

        EXPECTED.put("Hoenn", List.of(
                gym("Roxanne/Petra", "roxanne", "petra"), gym("Brawly/Rudi", "brawly", "rudi"),
                gym("Wattson/Walter", "wattson", "walter"), gym("Flannery/Fiammetta", "flannery", "fiammetta"),
                gym("Norman", "norman"), gym("Winona/Alice", "winona", "alice"),
                gym("Tell & Pat (Tate & Liza)",
                        "tell pat", "pat tell", "tell", "pat", "hoenn tell", "hoenn pat", "hoenn_tell", "hoenn_pat",
                        "tate liza", "liza tate", "tate", "liza", "mossdeep", "amethyst rainforest"),
                gym("Juan/Adriano", "juan", "adriano"),
                core("Liga Hoenn", "hoenn league", "league hoenn", "hoenn pokemon league"),
                core("Templo Regirock", "regirock temple", "temple regirock", "regirock"),
                core("Templo Regice", "regice temple", "temple regice", "regice"),
                core("Templo Registeel", "registeel temple", "temple registeel", "registeel"),
                core("Templo Sumergido Kyogre", "kyogre submerged temple", "submerged temple", "kyogre temple", "kyogre"),
                core("Isla Volcánica Groudon", "groudon volcano", "volcanic island", "groudon island", "groudon"),
                core("Pilar Celeste / Mega Rayquaza", "sky pillar", "rayquaza pillar", "sky core", "rayquaza"),
                core("Jardín Secreto Latias/Latios", "secret garden", "latias garden", "latios garden", "lati garden"),
                core("Wish Cave / Jirachi", "wish cave", "wishcave", "jirachi cave", "jirachi"),
                core("Santuario Deoxys", "deoxys shrine", "deoxys", "meteorite shrine")
        ));

        EXPECTED.put("Sinnoh", List.of(
                gym("Roark/Pedro", "roark", "pedro"), gym("Gardenia", "gardenia"),
                gym("Maylene/Marzia", "maylene", "marzia"), gym("Crasher Wake/Omar", "crasher wake", "wake", "omar"),
                gym("Fantina/Fannie", "fantina", "fannie"), gym("Byron/Ferruccio", "byron", "ferruccio"),
                gym("Candice/Bianca", "candice", "bianca"), gym("Volkner/Corrado", "volkner", "corrado"),
                core("Liga Sinnoh", "sinnoh league", "league sinnoh", "sinnoh pokemon league"),
                core("Wind Plant", "wind plant", "valley windworks", "windworks", "turbine"),
                core("Eterna Building", "eterna building", "eterna galactic", "eterna"),
                core("Team Galactic HQ", "galactic hq", "galactic headquarters", "team galactic", "veilstone galactic"),
                core("Spear Pillar", "spear pillar", "space time altar", "space time", "spear"),
                core("Lake Valor", "lake valor", "valor lake", "valor"),
                core("Lake Acuity", "lake acuity", "acuity lake", "acuity"),
                core("Lake Verity", "lake verity", "verity lake", "verity"),
                core("Stark Mountain / Forge", "stark mountain", "stark forge", "stark"),
                core("Snowpoint Temple", "snowpoint temple", "regigigas temple", "snowpoint", "regigigas"),
                core("Split-Decision Temple", "split decision temple", "split decision", "regieleki", "regidrago"),
                core("Fullmoon Island / Cresselia", "fullmoon island", "full moon", "fullmoon", "cresselia"),
                core("Newmoon Island / Darkrai", "newmoon island", "new moon", "newmoon", "darkrai"),
                core("Flower Paradise / Shaymin", "flower paradise", "shaymin", "flowerparadise"),
                core("Turnback Cave", "turnback cave", "turnback", "giratina cave"),
                core("Templo original de Sinnoh / Arceus", "original temple of sinnoh", "temple of sinnoh", "sinnoh temple", "original temple", "arceus temple", "arceus")
        ));
    }

    private static Expected gym(String label, String... aliases) { return new Expected("Gimnasio " + label, List.of(aliases)); }
    private static Expected core(String label, String... aliases) { return new Expected(label, List.of(aliases)); }

    public static AuditResult audit(MinecraftServer server) {
        Registry<Structure> registry = server.getRegistryManager().get(RegistryKeys.STRUCTURE);
        List<Candidate> candidates = new ArrayList<>();
        for (Identifier id : registry.getIds()) candidates.add(new Candidate(id, Source.REGISTERED));

        ResourceManager resources = server.getResourceManager();
        collectResources(resources, candidates, "worldgen/structure", Source.WORLDGEN_JSON);
        collectResources(resources, candidates, "worldgen/structure_set", Source.STRUCTURE_SET);
        collectResources(resources, candidates, "structure", Source.TEMPLATE);

        // Same logical asset may be visible through more than one resource view. Keep source+ID unique.
        Map<String, Candidate> unique = new LinkedHashMap<>();
        for (Candidate candidate : candidates) unique.put(candidate.source() + "|" + candidate.id(), candidate);
        candidates = new ArrayList<>(unique.values());
        candidates.sort(Comparator
                .comparingInt((Candidate c) -> c.source().rank()).reversed()
                .thenComparing(c -> c.id().toString()));

        Map<String, RegionResult> regionResults = new LinkedHashMap<>();
        int matchedTotal = 0;
        int registeredTotal = 0;
        int expectedTotal = 0;

        for (Map.Entry<String, List<Expected>> regionEntry : EXPECTED.entrySet()) {
            List<String> missing = new ArrayList<>();
            Map<String, List<String>> matches = new LinkedHashMap<>();
            int matched = 0;
            int registered = 0;
            for (Expected expected : regionEntry.getValue()) {
                expectedTotal++;
                List<Candidate> found = findMatches(candidates, expected);
                if (found.isEmpty()) {
                    missing.add(expected.label());
                    continue;
                }
                matched++;
                matchedTotal++;
                if (found.stream().anyMatch(candidate -> candidate.source() == Source.REGISTERED)) {
                    registered++;
                    registeredTotal++;
                }
                matches.put(expected.label(), found.stream().limit(8).map(Candidate::display).toList());
            }
            regionResults.put(regionEntry.getKey(), new RegionResult(regionEntry.getKey(), matched,
                    regionEntry.getValue().size(), registered, List.copyOf(missing), new LinkedHashMap<>(matches)));
        }

        List<String> cobbleverseCandidates = candidates.stream()
                .filter(candidate -> looksLikeCobbleverse(candidate.id()))
                .map(Candidate::display)
                .distinct()
                .toList();
        int datapackAssetCount = (int) candidates.stream().filter(c -> c.source() != Source.REGISTERED).count();
        return new AuditResult(registry.size(), datapackAssetCount, matchedTotal, expectedTotal,
                registeredTotal, new LinkedHashMap<>(regionResults), cobbleverseCandidates);
    }

    private static void collectResources(ResourceManager manager, List<Candidate> candidates, String root, Source source) {
        try {
            Map<Identifier, ?> found = manager.findResources(root, id -> {
                String path = id.getPath().toLowerCase(Locale.ROOT);
                return source == Source.TEMPLATE ? path.endsWith(".nbt") : path.endsWith(".json");
            });
            for (Identifier id : found.keySet()) candidates.add(new Candidate(cleanResourceIdentifier(id, root), source));
        } catch (RuntimeException ignored) {
            // Some resource-manager implementations can reject a root that does not exist. The
            // registry scan still remains valid and the missing resource class is reported in details.
        }
    }

    private static Identifier cleanResourceIdentifier(Identifier id, String root) {
        String path = id.getPath();
        String prefix = root + "/";
        if (path.startsWith(prefix)) path = path.substring(prefix.length());
        if (path.endsWith(".json")) path = path.substring(0, path.length() - 5);
        if (path.endsWith(".nbt")) path = path.substring(0, path.length() - 4);
        return Identifier.of(id.getNamespace(), path);
    }

    public static int report(ServerCommandSource source, boolean details) {
        AuditResult result = audit(source.getServer());
        source.sendFeedback(() -> Text.literal("§d§lChainacobblemon · Verificación regional alpha.9"), false);
        source.sendFeedback(() -> Text.literal("§7Registry STRUCTURE: §f" + result.registryCount()
                + " §8| §7assets datapack inspeccionados: §f" + result.datapackAssetCount()), false);

        for (RegionResult region : result.regions().values()) {
            String status = region.complete() ? "§aOK" : "§ePARCIAL";
            source.sendFeedback(() -> Text.literal("§f" + region.region() + ": " + status + " §7(" + region.matched() + "/" + region.expected()
                    + ", registry=" + region.registered() + ", assets=" + region.assetOnly() + ")"), false);
            if (!region.missing().isEmpty()) {
                source.sendFeedback(() -> Text.literal("  §7No detectadas ni en registry ni en datapack: §c"
                        + String.join("§7, §c", region.missing())), false);
            }
            if (details) {
                region.matches().forEach((label, ids) ->
                        source.sendFeedback(() -> Text.literal("  §8" + label + " §7→ §f" + String.join(" §8| §f", ids)), false));
            }
        }

        source.sendFeedback(() -> Text.literal("§dResumen oficial: §f" + result.matched() + "/" + result.expected()
                + " §7grupos detectados; §f" + result.assetOnlyMatches() + " §7se detectan por assets/plantillas aunque no tengan un ID equivalente en STRUCTURE."), false);
        if (details) {
            source.sendFeedback(() -> Text.literal("§8Candidatos Cobbleverse encontrados: §7" + result.cobbleverseCandidates().size()), false);
            int shown = 0;
            for (String id : result.cobbleverseCandidates()) {
                if (shown++ >= 100) {
                    source.sendFeedback(() -> Text.literal("§8… lista truncada; hay más assets/IDs Cobbleverse."), false);
                    break;
                }
                source.sendFeedback(() -> Text.literal("  §7" + id), false);
            }
        }
        source.sendFeedback(() -> Text.literal("§8Kanto: la Máquina de Resurrección no se cuenta como worldgen: es el multibloque de Cobblemon (Analyzer + Tank + Monitor)."), false);
        source.sendFeedback(() -> Text.literal("§8REGISTRY = worldgen registrado. TEMPLATE/WORLDGEN/SET = contenido presente en datapacks; algunos encuentros de Cobbleverse se colocan mediante lógica del pack."), false);
        source.sendFeedback(() -> Text.literal("§8El auditor no ejecuta /locate y no garantiza que el chunk ya esté generado."), false);
        return result.ready() ? 1 : 0;
    }

    private static List<Candidate> findMatches(List<Candidate> candidates, Expected expected) {
        List<Candidate> preferred = candidates.stream()
                .filter(candidate -> looksLikeCobbleverse(candidate.id()))
                .filter(candidate -> matchesAny(candidate.id(), expected.aliases()))
                .toList();
        if (!preferred.isEmpty()) return preferred;
        return candidates.stream().filter(candidate -> matchesAny(candidate.id(), expected.aliases())).toList();
    }

    private static boolean looksLikeCobbleverse(Identifier id) {
        String namespace = id.getNamespace().toLowerCase(Locale.ROOT);
        String path = id.getPath().toLowerCase(Locale.ROOT);
        return namespace.contains("cobbleverse") || namespace.equals("lumymon") || namespace.equals("rctmod")
                || path.contains("cobbleverse") || path.contains("pokemon_league") || path.contains("gym");
    }

    private static boolean matchesAny(Identifier id, List<String> aliases) {
        String searchable = normalize(id.getNamespace() + " " + id.getPath());
        for (String alias : aliases) {
            String normalizedAlias = normalize(alias);
            String[] tokens = normalizedAlias.split(" ");
            boolean all = true;
            for (String token : tokens) {
                if (token.isBlank()) continue;
                if (!searchable.contains(token)) { all = false; break; }
            }
            if (all) return true;
        }
        return false;
    }

    private static String normalize(String value) {
        return value.toLowerCase(Locale.ROOT)
                .replace('_', ' ')
                .replace('-', ' ')
                .replace('/', ' ')
                .replace(':', ' ')
                .replace('.', ' ')
                .replaceAll("\\s+", " ")
                .trim();
    }
}
