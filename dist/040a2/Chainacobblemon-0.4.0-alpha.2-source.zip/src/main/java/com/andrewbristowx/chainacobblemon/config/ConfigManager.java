package com.andrewbristowx.chainacobblemon.config;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.function.Consumer;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path configDirectory = FabricLoader.getInstance().getConfigDir().resolve(Chainacobblemon.MOD_ID);
    private final Path configFile = configDirectory.resolve("config.json");
    private volatile ChainacobblemonConfig config = new ChainacobblemonConfig();

    public synchronized void initialize() {
        try {
            Files.createDirectories(configDirectory);
            if (Files.notExists(configFile)) {
                config = new ChainacobblemonConfig();
                save();
                Chainacobblemon.LOGGER.info("Created default config at {}", configFile);
                return;
            }
            reload();
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not initialize Chainacobblemon config. Using safe defaults.", exception);
            config = new ChainacobblemonConfig();
        }
    }

    public synchronized boolean reload() {
        try {
            ChainacobblemonConfig loaded;
            try (Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) {
                loaded = GSON.fromJson(reader, ChainacobblemonConfig.class);
            }
            if (loaded == null) {
                throw new IOException("Config file is empty");
            }
            int previousVersion = loaded.configVersion;
            boolean balanceWasMissing = loaded.balance == null;
            boolean dailyWasMissing = loaded.dailyRewards == null;
            boolean passWasMissing = loaded.battlePass == null;
            boolean kitsWereMissing = loaded.kits == null;
            boolean twitchWasMissing = loaded.twitch == null;
            loaded.normalize();
            config = loaded;
            if (previousVersion < loaded.configVersion || balanceWasMissing || dailyWasMissing || passWasMissing || kitsWereMissing || twitchWasMissing) {
                save();
                Chainacobblemon.LOGGER.info("Migrated Chainacobblemon config {} -> {}", previousVersion, loaded.configVersion);
            }
            Chainacobblemon.LOGGER.info("Reloaded Chainacobblemon config version {}", loaded.configVersion);
            return true;
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Config reload failed; keeping the last known-good configuration", exception);
            return false;
        }
    }

    public synchronized void save() throws IOException {
        Files.createDirectories(configDirectory);
        Path temporary = configFile.resolveSibling(configFile.getFileName() + ".tmp");
        try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
            GSON.toJson(config, writer);
        }
        try {
            Files.move(temporary, configFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception atomicMoveFailure) {
            Files.move(temporary, configFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public synchronized boolean update(Consumer<ChainacobblemonConfig> mutation) {
        try {
            mutation.accept(config);
            config.normalize();
            save();
            return true;
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.error("Could not persist Chainacobblemon configuration update", exception);
            return false;
        }
    }

    public ChainacobblemonConfig get() {
        return config;
    }

    public Path configDirectory() {
        return configDirectory;
    }
}
