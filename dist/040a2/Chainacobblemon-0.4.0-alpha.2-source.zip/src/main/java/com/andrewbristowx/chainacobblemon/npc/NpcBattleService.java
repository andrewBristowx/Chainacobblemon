package com.andrewbristowx.chainacobblemon.npc;

import com.cobblemon.mod.common.api.pokemon.PokemonProperties;
import com.cobblemon.mod.common.api.pokemon.PokemonSpecies;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeCatalog;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeService;
import com.andrewbristowx.chainacobblemon.challenge.ChallengeProfile;
import com.andrewbristowx.chainacobblemon.challenge.DynamicTrainerLevelService;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.andrewbristowx.chainacobblemon.dungeon.DungeonTrainerService;
import com.andrewbristowx.chainacobblemon.events.treasure.TreasureHuntService;
import com.andrewbristowx.chainacobblemon.tower.ChallengeTowerService;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;

import java.lang.reflect.Array;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class NpcBattleService {
    private static final long START_COOLDOWN_MS = 5_000L;
    private static final Map<UUID, Long> LAST_START = new ConcurrentHashMap<>();
    private static final Map<UUID, ActiveBattle> ACTIVE_BATTLES = new ConcurrentHashMap<>();
    private static Object battleEndListener;

    private NpcBattleService() {
    }

    public static boolean auditCompatibility(MinecraftServer server) {
        if (!FabricLoader.getInstance().isModLoaded("rctapi") || !FabricLoader.getInstance().isModLoaded("rctmod")) {
            Chainacobblemon.LOGGER.error("Custom trainer battles disabled: exact rctapi/rctmod dependencies are missing");
            return false;
        }
        try {
            Class<?> trainerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.Trainer");
            Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
            Class<?> trainerPlayerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerPlayer");
            Class<?> trainerBagClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerBag");
            Class<?> battleAiClass = Class.forName("com.cobblemon.mod.common.api.battles.model.ai.BattleAI");
            Class<?> rctApiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
            Class<?> pokemonArrayClass = Array.newInstance(Pokemon.class, 0).getClass();
            trainerNpcClass.getConstructor(String.class, pokemonArrayClass, trainerBagClass,
                    battleAiClass, LivingEntity.class);
            trainerPlayerClass.getConstructor(ServerPlayerEntity.class);
            Object rct = rctApiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
            if (rct == null) throw new IllegalStateException("rctmod instance missing");
            Object battleManager = rctApiClass.getMethod("getBattleManager").invoke(rct);
            battleManager.getClass().getMethod("startSingle", trainerClass, trainerClass);
            Class<?> providerClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormatProvider");
            Class<?> battleFormatClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormat");
            Object singlesProvider = battleFormatClass.getField("GEN_9_SINGLES").get(null);
            Object cobblemonFormat = providerClass.getMethod("getCobblemonBattleFormat").invoke(singlesProvider);
            copyCobblemonFormatWithLevel(cobblemonFormat, 50);
            Class<?> rulesBuilderClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleRules$Builder");
            rulesBuilderClass.getMethod("withAdjustPlayerLevels", boolean.class);
            rulesBuilderClass.getMethod("withAdjustNPCLevels", boolean.class);
            registerBattleEndListener(rct, rctApiClass);
            Chainacobblemon.LOGGER.info("Exact RCT custom trainer battle API validated on {}", server.getVersion());
            return true;
        } catch (Exception | LinkageError exception) {
            Chainacobblemon.LOGGER.error("Custom trainer battles disabled: exact RCT API audit failed", exception);
            return false;
        }
    }

    public static List<String> validateTeam(List<String> rawSpecs) {
        if (rawSpecs == null) return List.of();
        List<String> result = new ArrayList<>();
        for (String raw : rawSpecs) {
            if (result.size() >= 6) throw new IllegalArgumentException("El equipo admite como máximo 6 Pokémon.");
            String spec = raw == null ? "" : raw.strip();
            if (spec.isBlank()) continue;
            if (spec.length() > 256) throw new IllegalArgumentException("Cada Pokémon admite como máximo 256 caracteres.");
            PokemonProperties properties = PokemonProperties.Companion.parse(spec);
            if (!properties.hasSpecies() || PokemonSpecies.getByName(properties.getSpecies()) == null) {
                throw new IllegalArgumentException("Pokémon no válido en el equipo: " + spec);
            }
            Integer level = properties.getLevel();
            if (level != null && (level < 1 || level > 100)) {
                throw new IllegalArgumentException("El nivel debe estar entre 1 y 100: " + spec);
            }
            // Crear una copia durante la validación hace que Cobblemon compruebe forma, habilidad y movimientos.
            properties.create();
            result.add(spec);
        }
        return List.copyOf(result);
    }

    public static boolean start(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null || npc.isRemoved()) return false;
        ChallengeProfile profile = ChallengeCatalog.byNpcId(npc.npcId());
        if (DungeonTrainerService.isDungeonTrainer(npc) && !DungeonTrainerService.canChallenge(player, npc, true)) return false;
        if (profile != null && !ChallengeService.canChallenge(player, profile, true)) return false;
        if (player.getWorld() != npc.getWorld() || (!ChallengeTowerService.isTowerTrainer(npc) && player.squaredDistanceTo(npc) > 100.0D)) {
            player.sendMessage(net.minecraft.text.Text.literal("§cDebes estar cerca del NPC para luchar."), false);
            return false;
        }
        if (profile != null) {
            RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
            if (!cap.allowed()) {
                player.sendMessage(net.minecraft.text.Text.literal("§cTu equipo supera el límite de nivel de Cobbleverse/RCT. "
                        + "§7Límite actual: §f" + cap.cap() + " §7· nivel más alto: §f" + cap.highestPartyLevel()), false);
                return false;
            }
        }
        long now = System.currentTimeMillis();
        long previous = LAST_START.getOrDefault(player.getUuid(), 0L);
        if (now - previous < START_COOLDOWN_MS) {
            player.sendMessage(net.minecraft.text.Text.literal("§eEspera unos segundos antes de iniciar otro combate."), false);
            return false;
        }
        if (!FabricLoader.getInstance().isModLoaded("rctapi") || !FabricLoader.getInstance().isModLoaded("rctmod")) {
            player.sendMessage(net.minecraft.text.Text.literal("§cCobbleverse no tiene cargados RCT API y RCT Mod."), false);
            return false;
        }
        try {
            Class<?> trainerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.Trainer");
            Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
            Class<?> trainerPlayerClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerPlayer");
            Class<?> rctApiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
            Object rct = rctApiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
            if (rct == null) throw new IllegalStateException("La instancia rctmod no está inicializada.");

            Object npcTrainer = null;
            DynamicTrainerLevelService.ScalingResult scaling = profile == null
                    ? new DynamicTrainerLevelService.ScalingResult(List.of(), 0, 0, false)
                    : DynamicTrainerLevelService.scale(player, profile);
            // Keep the exact native Cobbleverse trainer when its authored level curve is still appropriate.
            // Once a player has progressed beyond it, build an RCTBattleAI trainer from Chainacobblemon's same
            // species composition shifted upward to that player's current progression.
            RctCobbleverseBridge.NativeTrainer nativeTrainer = profile == null || scaling.scaled() ? null
                    : RctCobbleverseBridge.attachNativeTrainer(player.getServer(), profile, npc);
            if (nativeTrainer != null) {
                npcTrainer = nativeTrainer.trainer();
                Chainacobblemon.LOGGER.info("Challenge {} uses native Cobbleverse/RCT trainer {}", profile.key(), nativeTrainer.trainerId());
            }

            if (npcTrainer == null) {
                List<String> specs;
                try {
                    List<String> requestedTeam = profile != null
                            ? scaling.team()
                            : DungeonTrainerService.isDungeonTrainer(npc)
                                ? DungeonTrainerService.scaledTeam(player, npc)
                                : npc.pokemonTeam();
                    specs = validateTeam(requestedTeam);
                } catch (IllegalArgumentException exception) {
                    player.sendMessage(net.minecraft.text.Text.literal("§cEquipo inválido: " + exception.getMessage()), false);
                    return false;
                }
                if (specs.isEmpty()) {
                    player.sendMessage(net.minecraft.text.Text.literal("§eEste NPC todavía no tiene equipo Pokémon."), false);
                    return false;
                }
                Pokemon[] team = new Pokemon[specs.size()];
                for (int index = 0; index < specs.size(); index++) {
                    team[index] = PokemonProperties.Companion.parse(specs.get(index)).create();
                }
                Class<?> trainerBagClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerBag");
                Class<?> battleAiClass = Class.forName("com.cobblemon.mod.common.api.battles.model.ai.BattleAI");
                Class<?> rctBattleAiClass = Class.forName("com.gitlab.srcmc.rctapi.api.ai.RCTBattleAI");
                Object bag = trainerBagClass.getConstructor().newInstance();
                Object ai = rctBattleAiClass.getConstructor().newInstance();
                Class<?> pokemonArrayClass = Array.newInstance(Pokemon.class, 0).getClass();
                boolean treasureBattleName = npc.dungeonStructureKey() != null && npc.dungeonStructureKey().startsWith("treasure_event:");
                String trainerName = treasureBattleName
                        ? ("guardian".equalsIgnoreCase(npc.dungeonRole()) ? "Guardián del Tesoro" : "Entrenador del Pasillo")
                        : npc.getCustomName() == null ? npc.npcId() : npc.getCustomName().getString();
                npcTrainer = trainerNpcClass.getConstructor(String.class, pokemonArrayClass, trainerBagClass,
                        battleAiClass, LivingEntity.class).newInstance(trainerName, team, bag, ai, npc);
                if (DungeonTrainerService.isDungeonTrainer(npc)) {
                    int target = DungeonTrainerService.targetLevel(player, npc);
                    boolean treasureEvent = npc.dungeonStructureKey().startsWith("treasure_event:");
                    player.sendMessage(net.minecraft.text.Text.literal(treasureEvent
                            ? "§6🗺 Cacería adaptativa · §fRival ~Nv. " + target + " §7· basado en tus 3 Pokémon más altos; tu equipo conserva sus niveles reales."
                            : "§d⚔ Mazmorra adaptativa · §fEquipo objetivo Nv. " + target + " §7· tu límite de nivel RCT no se modifica."), false);
                } else if (ChallengeTowerService.isTowerTrainer(npc)) {
                    player.sendMessage(net.minecraft.text.Text.literal("§d🏰 Torre adaptativa · §fRival generado alrededor de Nv. "
                            + ChallengeTowerService.targetLevel(player) + "§7 · tu equipo conserva sus niveles reales."), false);
                } else if (profile != null && scaling.scaled()) {
                    player.sendMessage(net.minecraft.text.Text.literal("§d⚔ Equipo adaptado a tu progreso: §fNv. "
                            + scaling.authoredMax() + " → " + scaling.targetMax()
                            + " §7(sin modificar tu límite de nivel)."), false);
                } else if (profile != null) {
                    player.sendMessage(net.minecraft.text.Text.literal("§eNo encontré el perfil nativo de este entrenador en RCT; se usará el equipo de respaldo de Chainacobblemon."), false);
                }
            }

            Object playerTrainer = trainerPlayerClass.getConstructor(ServerPlayerEntity.class).newInstance(player);
            Object battleManager = rctApiClass.getMethod("getBattleManager").invoke(rct);
            BattleLaunchConfig launchConfig;
            if (DungeonTrainerService.isDungeonTrainer(npc)) {
                if (npc.dungeonStructureKey().startsWith("treasure_event:")) {
                    // Treasure Hunt mirrors Challenge Tower: NPC team is generated at the adaptive level,
                    // but the player's battle clones are never normalized downward.
                    launchConfig = BattleLaunchConfig.fromTrainer(npcTrainer);
                } else {
                    try {
                        int target = DungeonTrainerService.targetLevel(player, npc);
                        launchConfig = dungeonLevelSyncConfig(npcTrainer, target);
                    } catch (ReflectiveOperationException | RuntimeException syncFailure) {
                        Chainacobblemon.LOGGER.error("Adaptive level synchronization could not be prepared; battle blocked for safety", syncFailure);
                        player.sendMessage(net.minecraft.text.Text.literal("§cSincronización de nivel no está disponible con esta combinación de RCT/Cobblemon. "
                                + "§7El combate se bloqueó para no modificar tus Pokémon reales."), false);
                        return false;
                    }
                }
            } else {
                // The Challenge Tower scales the NPC team to the player's real party.
                // Do not normalize the player's battle clones downward: the visible enemy
                // levels should be the adaptation, exactly as the Tower design intends.
                launchConfig = BattleLaunchConfig.fromTrainer(npcTrainer);
            }
            boolean started = startConfiguredBattle(battleManager, trainerClass, playerTrainer, npcTrainer, launchConfig);
            if (started) {
                if (launchConfig.levelSyncTarget() > 0) {
                    player.sendMessage(net.minecraft.text.Text.literal("§d↕ Sincronización de nivel activa · §ftu equipo combate temporalmente a Nv. "
                            + launchConfig.levelSyncTarget() + "§7. Tus Pokémon reales conservan su nivel, EXP y datos."), false);
                }
                LAST_START.put(player.getUuid(), now);
                ACTIVE_BATTLES.put(player.getUuid(), new ActiveBattle(npc, System.currentTimeMillis()));
                return true;
            }
            player.sendMessage(net.minecraft.text.Text.literal("§eNo se pudo iniciar: revisa tu límite de nivel, tu equipo y que no estés ya en combate."), false);
            return false;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError exception) {
            Chainacobblemon.LOGGER.error("Could not start exact RCT battle for NPC {}", npc.npcId(), exception);
            player.sendMessage(net.minecraft.text.Text.literal("§cNo se pudo conectar con el sistema de combates RCT."), false);
            return false;
        }
    }

    private static boolean startConfiguredBattle(Object battleManager, Class<?> trainerClass, Object playerTrainer,
                                                 Object npcTrainer, BattleLaunchConfig config)
            throws ReflectiveOperationException {
        Object rules = config.rules();
        Object format = config.format();
        for (String name : List.of("startBattle", "start")) {
            for (java.lang.reflect.Method method : battleManager.getClass().getMethods()) {
                if (!method.getName().equals(name)) continue;
                Class<?>[] params = method.getParameterTypes();
                try {
                    Object result;
                    if (params.length == 4 && rules != null && format != null
                            && params[0].isInstance(playerTrainer) && params[1].isInstance(npcTrainer)
                            && params[2].isInstance(format) && params[3].isInstance(rules)) {
                        result = method.invoke(battleManager, playerTrainer, npcTrainer, format, rules);
                    } else if (params.length == 3 && rules != null
                            && params[0].isInstance(playerTrainer) && params[1].isInstance(npcTrainer)
                            && params[2].isInstance(rules)) {
                        result = method.invoke(battleManager, playerTrainer, npcTrainer, rules);
                    } else continue;
                    if (result == null) return false;
                    return !(result instanceof Boolean value) || value;
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        return (boolean) battleManager.getClass().getMethod("startSingle", trainerClass, trainerClass)
                .invoke(battleManager, playerTrainer, npcTrainer);
    }

    /**
     * Builds a dungeon-only flat level format through RCT's public BattleFormatProvider + BattleRules APIs.
     * RCT clones the player's party whenever Cobblemon's BattleFormat.adjustLevel is positive, then applies
     * the requested level only to those battle clones. The stored Cobblemon party is therefore never rewritten.
     */
    private static BattleLaunchConfig dungeonLevelSyncConfig(Object npcTrainer, int targetLevel)
            throws ReflectiveOperationException {
        int target = Math.max(1, Math.min(100, targetLevel));
        Object baseProvider = invokeOptional(npcTrainer, "getBattleFormat");
        if (baseProvider == null) {
            Class<?> battleFormatClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormat");
            baseProvider = battleFormatClass.getField("GEN_9_SINGLES").get(null);
        }
        Object baseCobblemonFormat = baseProvider.getClass().getMethod("getCobblemonBattleFormat").invoke(baseProvider);
        Object syncedCobblemonFormat = copyCobblemonFormatWithLevel(baseCobblemonFormat, target);

        Class<?> providerClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleFormatProvider");
        Object syncedProvider = Proxy.newProxyInstance(providerClass.getClassLoader(), new Class<?>[]{providerClass},
                (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) {
                        return switch (method.getName()) {
                            case "toString" -> "ChainacobblemonDungeonLevelSync(" + target + ")";
                            case "hashCode" -> System.identityHashCode(proxy);
                            case "equals" -> proxy == (args == null || args.length == 0 ? null : args[0]);
                            default -> null;
                        };
                    }
                    if (method.getName().equals("getCobblemonBattleFormat") && method.getParameterCount() == 0) {
                        return syncedCobblemonFormat;
                    }
                    throw new UnsupportedOperationException("Unsupported BattleFormatProvider method: " + method);
                });

        Object rules = buildLevelSyncRules(invokeOptional(npcTrainer, "getBattleRules"));
        return new BattleLaunchConfig(syncedProvider, rules, target);
    }

    private static Object copyCobblemonFormatWithLevel(Object baseFormat, int targetLevel)
            throws ReflectiveOperationException {
        Class<?> formatClass = baseFormat.getClass();
        Object mod = formatClass.getMethod("getMod").invoke(baseFormat);
        Object battleType = formatClass.getMethod("getBattleType").invoke(baseFormat);
        Object rawRules = formatClass.getMethod("getRuleSet").invoke(baseFormat);
        Object gen = formatClass.getMethod("getGen").invoke(baseFormat);
        Set<?> ruleSet = rawRules instanceof Set<?> set ? new HashSet<>(set) : Set.of();

        for (var constructor : formatClass.getConstructors()) {
            Class<?>[] params = constructor.getParameterTypes();
            if (params.length == 5 && params[0] == String.class && Set.class.isAssignableFrom(params[2])
                    && params[3] == int.class && params[4] == int.class) {
                return constructor.newInstance(mod, battleType, ruleSet, gen, targetLevel);
            }
        }
        throw new NoSuchMethodException("Cobblemon BattleFormat(String, BattleType, Set, int, int)");
    }

    private static Object buildLevelSyncRules(Object originalRules) throws ReflectiveOperationException {
        Class<?> builderClass = Class.forName("com.gitlab.srcmc.rctapi.api.battle.BattleRules$Builder");
        Object builder = builderClass.getConstructor().newInstance();
        Object maxItemUses = originalRules == null ? null : invokeOptional(originalRules, "getMaxItemUses");
        if (maxItemUses instanceof Integer max) {
            builder = builderClass.getMethod("withMaxItemUses", int.class).invoke(builder, max);
        }
        builder = builderClass.getMethod("withAdjustPlayerLevels", boolean.class).invoke(builder, true);
        builder = builderClass.getMethod("withAdjustNPCLevels", boolean.class).invoke(builder, false);
        // The synced party consists of battle clones. Healing therefore never changes the real stored party.
        builder = builderClass.getMethod("withHealPlayers", boolean.class).invoke(builder, true);
        return builderClass.getMethod("build").invoke(builder);
    }

    private record BattleLaunchConfig(Object format, Object rules, int levelSyncTarget) {
        static BattleLaunchConfig fromTrainer(Object trainer) {
            return new BattleLaunchConfig(invokeOptional(trainer, "getBattleFormat"),
                    invokeOptional(trainer, "getBattleRules"), 0);
        }
    }

    private static Object invokeOptional(Object owner, String name) {
        try {
            return owner.getClass().getMethod(name).invoke(owner);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }

    private static synchronized void registerBattleEndListener(Object rct, Class<?> rctApiClass)
            throws ReflectiveOperationException {
        if (battleEndListener != null) return;
        Class<?> eventsClass = Class.forName("com.gitlab.srcmc.rctapi.api.events.Events");
        Class<?> eventTypeClass = Class.forName("com.gitlab.srcmc.rctapi.api.events.EventType");
        Class<?> eventListenerClass = Class.forName("com.gitlab.srcmc.rctapi.api.events.EventListener");
        Object battleEnded = eventsClass.getField("BATTLE_ENDED").get(null);
        Object context = rctApiClass.getMethod("getEventContext").invoke(rct);
        Object listener = Proxy.newProxyInstance(eventListenerClass.getClassLoader(),
                new Class<?>[]{eventListenerClass}, (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) {
                        return switch (method.getName()) {
                            case "equals" -> proxy == (args == null || args.length == 0 ? null : args[0]);
                            case "hashCode" -> System.identityHashCode(proxy);
                            case "toString" -> "ChainacobblemonBattleEndListener";
                            default -> null;
                        };
                    }
                    if ("notify".equals(method.getName()) && args != null && args.length == 1) {
                        handleBattleEnded(args[0]);
                    }
                    return null;
                });
        context.getClass().getMethod("register", eventTypeClass, eventListenerClass)
                .invoke(context, battleEnded, listener);
        battleEndListener = listener;
    }

    private static void handleBattleEnded(Object event) {
        try {
            Object state = event.getClass().getMethod("getValue").invoke(event);
            Set<UUID> participants = trainerPlayerIds(state, "getParticipants1");
            participants.addAll(trainerPlayerIds(state, "getParticipants2"));
            Set<UUID> winners = trainerPlayerIds(state, "getWinners");
            Set<UUID> losingNpcs = trainerNpcIds(state, "getLosers");
            Set<UUID> battleNpcs = trainerNpcIds(state, "getParticipants1");
            battleNpcs.addAll(trainerNpcIds(state, "getParticipants2"));

            for (UUID playerId : participants) {
                ActiveBattle active = ACTIVE_BATTLES.remove(playerId);
                if (active == null || !battleNpcs.contains(active.npc().getUuid())) continue;
                boolean won = winners.contains(playerId) && losingNpcs.contains(active.npc().getUuid());
                MinecraftServer server = active.npc().getServer();
                if (server == null) continue;
                server.execute(() -> {
                    ServerPlayerEntity player = server.getPlayerManager().getPlayer(playerId);
                    if (player == null) return;
                    if (active.npc().dungeonStructureKey().startsWith("treasure_event:")) {
                        TreasureHuntService.cleanupTrainerPokemon(player, active.npc());
                    }
                    if (ChallengeTowerService.isTowerTrainer(active.npc())) {
                        ChallengeTowerService.onBattleResult(player, active.npc(), won);
                        return;
                    }
                    if (!won || active.npc().isRemoved()) return;
                    if (ChallengeService.isChallengeNpc(active.npc())) {
                        ChallengeService.onVictory(player, active.npc());
                    }
                    if (DungeonTrainerService.isDungeonTrainer(active.npc())) {
                        DungeonTrainerService.onVictory(player, active.npc());
                    }
                    NpcRewardService.grantAfterVictory(player, active.npc());
                });
            }
            long cutoff = System.currentTimeMillis() - 3_600_000L;
            ACTIVE_BATTLES.entrySet().removeIf(entry -> entry.getValue().startedAt() < cutoff);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.error("Could not process RCT battle result for custom NPC rewards", exception);
        }
    }

    private static Set<UUID> trainerPlayerIds(Object state, String methodName) throws ReflectiveOperationException {
        Set<UUID> result = new HashSet<>();
        Object value = state.getClass().getMethod(methodName).invoke(state);
        if (!(value instanceof Iterable<?> trainers)) return result;
        for (Object trainer : trainers) {
            Object entity = trainer.getClass().getMethod("getEntity").invoke(trainer);
            if (entity instanceof ServerPlayerEntity player) result.add(player.getUuid());
        }
        return result;
    }

    private static Set<UUID> trainerNpcIds(Object state, String methodName) throws ReflectiveOperationException {
        Set<UUID> result = new HashSet<>();
        Object value = state.getClass().getMethod(methodName).invoke(state);
        if (!(value instanceof Iterable<?> trainers)) return result;
        for (Object trainer : trainers) {
            Object entity = trainer.getClass().getMethod("getEntity").invoke(trainer);
            if (entity instanceof ServiceNpcEntity npc) result.add(npc.getUuid());
        }
        return result;
    }

    private record ActiveBattle(ServiceNpcEntity npc, long startedAt) {
    }
}
