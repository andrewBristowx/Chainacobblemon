package com.andrewbristowx.chainacobblemon.progress;

/** Pure rank-to-slot rules, kept separate so migrations and permissions are testable. */
public final class JobLimitRules {
    private static final int DEFAULT_LIMIT = 2;
    private static final int SUPPORTER_LIMIT = 4;

    private JobLimitRules() {
    }

    public static int forGroups(Iterable<String> groups, int allJobs) {
        int result = DEFAULT_LIMIT;
        if (groups == null) return Math.min(result, allJobs);
        for (String group : groups) {
            String normalized = RankGroups.normalize(group);
            if (RankGroups.STAFF.contains(normalized)) return allJobs;
            if (RankGroups.SUPPORTERS.contains(normalized)) result = Math.max(result, SUPPORTER_LIMIT);
        }
        return Math.min(result, allJobs);
    }
}
