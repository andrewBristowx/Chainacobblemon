package com.andrewbristowx.chainacobblemon.tower;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.npc.NpcBattleService;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Formatting;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class ChallengeTowerService {
    public static final Identifier WORLD_ID = Identifier.of(Chainacobblemon.MOD_ID, "challenge_tower");
    public static final RegistryKey<World> WORLD_KEY = RegistryKey.of(RegistryKeys.WORLD, WORLD_ID);
    public static final long COOLDOWN_MILLIS = 4L * 24L * 60L * 60L * 1000L;
    public static final long ROULETTE_COOLDOWN_MILLIS = 6L * 60L * 60L * 1000L;
    private static final int BASE_Y = 64;
    private static final int FLOOR_SPACING = 26;
    private static final int BUILD_VERSION = 14;
    private static final Map<UUID, RuntimeSession> SESSIONS = new HashMap<>();
    private static final Set<UUID> BUILD_MODE = new HashSet<>();
    private static long serverTicks;

    private static final List<String> STAGE_ONE = List.of(
            "arcanine", "starmie", "gengar", "machamp", "snorlax", "lapras", "scizor", "heracross",
            "ampharos", "crobat", "kingdra", "espeon", "umbreon", "houndoom", "mamoswine", "togekiss",
            "breloom", "milotic", "flygon", "aggron", "manectric", "gardevoir", "gallade", "weavile"
    );
    private static final List<String> STAGE_TWO = List.of(
            "gyarados", "alakazam", "dragonite", "tyranitar", "metagross", "salamence", "swampert", "blaziken",
            "sceptile", "lucario", "magnezone", "gliscor", "rotom", "hippowdon", "staraptor", "dusknoir",
            "electivire", "magmortar", "rhyperior", "froslass", "spiritomb", "milotic", "scizor", "togekiss"
    );
    private static final List<String> STAGE_THREE = List.of(
            "garchomp", "dragonite", "tyranitar", "metagross", "salamence", "hydreigon", "volcarona", "excadrill",
            "aegislash", "goodra", "kommo-o", "dragapult", "kingambit", "baxcalibur", "ursaluna", "annihilape",
            "gholdengo", "corviknight", "toxapex", "grimmsnarl", "ceruledge", "meowscarada", "skeledirge", "quaquaval"
    );
    private static final List<String> BOSS_POOL = List.of(
            "garchomp", "metagross", "dragonite", "tyranitar", "salamence", "volcarona", "aegislash", "dragapult",
            "kingambit", "baxcalibur", "gholdengo", "ursaluna", "annihilape", "togekiss", "rotom", "milotic"
    );
    private static final List<String> TRAINER_NAMES = List.of(
            "Aster", "Mika", "Rin", "Kai", "Noa", "Luna", "Axel", "Nia", "Dante", "Vera", "Iris", "Leo"
    );
    private static final List<String> MASTER_NAMES = List.of("Astra", "Valkyr", "Orion", "Nova", "Zenith");
    private static final List<String> ROULETTE_POKEMON = List.of(
            "eevee", "riolu", "ralts", "larvitar", "bagon", "beldum", "gible", "dreepy", "tinkatink", "charcadet",
            "zorua", "rockruff", "dratini", "togepi", "feebas", "scyther", "sneasel", "rotom", "mimikyu", "axew"
    );
    private static final List<ItemReward> ROULETTE_POKEMON_ITEMS = List.of(
            new ItemReward("cobblemon:ultra_ball", "Ultra Balls", 8, 16),
            new ItemReward("cobblemon:quick_ball", "Quick Balls", 6, 12),
            new ItemReward("cobblemon:rare_candy", "Caramelos Raros", 2, 4),
            new ItemReward("cobblemon:exp_candy_s", "Caramelos EXP S", 16, 32),
            new ItemReward("cobblemon:max_revive", "Revivir Máximo", 2, 4),
            new ItemReward("cobblemon:hyper_potion", "Hiperpociones", 8, 16)
    );
    private static final List<ItemReward> ROULETTE_MINERALS = List.of(
            new ItemReward("minecraft:iron_ingot", "Lingotes de Hierro", 32, 64),
            new ItemReward("minecraft:gold_ingot", "Lingotes de Oro", 24, 48),
            new ItemReward("minecraft:diamond", "Diamantes", 6, 12),
            new ItemReward("minecraft:emerald", "Esmeraldas", 12, 24),
            new ItemReward("minecraft:netherite_scrap", "Fragmentos de Netherita", 2, 4)
    );
    private static final List<ItemReward> ROULETTE_RARE_ITEMS = List.of(
            new ItemReward("cobblemon:dawn_stone", "Piedra Alba", 1, 3),
            new ItemReward("cobblemon:dusk_stone", "Piedra Noche", 1, 3),
            new ItemReward("cobblemon:shiny_stone", "Piedra Día", 1, 3),
            new ItemReward("cobblemon:kings_rock", "Roca del Rey", 1, 2),
            new ItemReward("cobblemon:metal_coat", "Revestimiento Metálico", 1, 2),
            new ItemReward("cobblemon:razor_claw", "Garra Afilada", 1, 2),
            new ItemReward("cobblemon:leftovers", "Restos", 1, 1)
    );

    private ChallengeTowerService() {}

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(ChallengeTowerService::tick);
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !world.getRegistryKey().equals(WORLD_KEY) || BUILD_MODE.contains(player.getUuid()));
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) ->
                world.getRegistryKey().equals(WORLD_KEY) && !BUILD_MODE.contains(player.getUuid())
                        ? ActionResult.FAIL : ActionResult.PASS);
    }

    public static boolean isTowerTrainer(ServiceNpcEntity npc) {
        return npc != null && npc.npcId().startsWith("tower_");
    }

    public static int targetLevel(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        return targetLevel(player, Math.max(1, data.tower.currentFloor));
    }

    public static boolean unlocked(ServerPlayerEntity player) {
        if (player == null) return false;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        if (data.tower.adminUnlocked) return true;
        return regionalComplete(data, "kanto:champion_blue", "champion_blue")
                && regionalComplete(data, "johto:champion_lance", "defeat_johto_champion_lance")
                && regionalComplete(data, "hoenn:champion_steven", "defeat_hoenn_champion_steven")
                && regionalComplete(data, "sinnoh:champion_cynthia", "defeat_sinnoh_champion_cynthia");
    }

    private static boolean regionalComplete(PlayerData data, String trainerKey, String questId) {
        return data.defeatedTrainers.contains(trainerKey)
                || data.quests.completed.contains(questId)
                || data.quests.claimed.contains(questId);
    }

    public static long cooldownRemaining(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        return Math.max(0L, data.tower.cooldownUntilEpochMillis - System.currentTimeMillis());
    }

    public static String cooldownText(ServerPlayerEntity player) {
        return formatDuration(cooldownRemaining(player));
    }

    public static long rouletteCooldownRemaining(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        return Math.max(0L, data.tower.rouletteCooldownUntilEpochMillis - System.currentTimeMillis());
    }

    public static String rouletteCooldownText(ServerPlayerEntity player) {
        return formatDuration(rouletteCooldownRemaining(player));
    }

    private static String formatDuration(long millis) {
        if (millis <= 0L) return "disponible";
        long totalMinutes = (millis + 59_999L) / 60_000L;
        long days = totalMinutes / (24L * 60L);
        long hours = (totalMinutes / 60L) % 24L;
        long minutes = totalMinutes % 60L;
        return (days > 0 ? days + "d " : "") + hours + "h " + minutes + "m";
    }

    public static String professorSummary(ServerPlayerEntity player) {
        if (!unlocked(player)) return "Bloqueada · completa Kanto, Johto, Hoenn y Sinnoh";
        long remaining = cooldownRemaining(player);
        if (remaining > 0L) return "Premio principal en " + cooldownText(player) + " · puedes repetir por la ruleta";
        return "Disponible · 10 combates · premio: 10 tickets de cada gasha";
    }

    public static boolean start(ServerPlayerEntity player, boolean adminBypass) {
        if (player == null) return false;
        if (!adminBypass && !unlocked(player)) {
            player.sendMessage(Text.literal("§eLa Torre Desafío se desbloquea al completar Kanto, Johto, Hoenn y Sinnoh."), false);
            return false;
        }
        if (!adminBypass && cooldownRemaining(player) > 0L) {
            player.sendMessage(Text.literal("§dPuedes repetir la Torre. §eEl premio principal vuelve en §f" + cooldownText(player)
                    + "§e; si la ruleta está disponible, esta victoria dará un premio secundario."), false);
        }
        ServerWorld tower = player.getServer().getWorld(WORLD_KEY);
        if (tower == null) {
            player.sendMessage(Text.literal("§cLa dimensión chainacobblemon:challenge_tower no está cargada. Reinicia el servidor tras instalar esta versión."), false);
            return false;
        }
        cancelRuntime(player.getUuid());
        int laneX = allocateLaneX();
        ensureBuilt(tower, laneX);
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.returnWorld = player.getWorld().getRegistryKey().getValue().toString();
        data.tower.returnX = player.getX();
        data.tower.returnY = player.getY();
        data.tower.returnZ = player.getZ();
        data.tower.returnYaw = player.getYaw();
        data.tower.returnPitch = player.getPitch();
        data.tower.returnCreative = player.isCreative();
        data.tower.activeAttempt = true;
        data.tower.currentFloor = 1;
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        player.changeGameMode(GameMode.ADVENTURE);
        RuntimeSession session = new RuntimeSession(player.getUuid(), adminBypass, laneX);
        SESSIONS.put(player.getUuid(), session);
        enterFloor(player, 1, true);
        return true;
    }

    public static boolean jumpToFloor(ServerPlayerEntity player, int floor) {
        int target = Math.max(1, Math.min(10, floor));
        if (!SESSIONS.containsKey(player.getUuid())) {
            if (!start(player, true)) return false;
        }
        cleanupBattleEntities(player, target);
        removeTrainer(player.getUuid());
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.currentFloor = target;
        data.tower.activeAttempt = true;
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        enterFloor(player, target, true);
        return true;
    }

    public static void onBattleResult(ServerPlayerEntity player, ServiceNpcEntity npc, boolean won) {
        if (player == null || npc == null || !isTowerTrainer(npc)) return;
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session == null) return;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        int floor = Math.max(1, data.tower.currentFloor);

        stopTowerMusic(player);
        cleanupBattleEntities(player, floor);
        removeTrainer(player.getUuid());

        if (!won) {
            fail(player, "El rival te derrotó.");
            return;
        }

        data.tower.bestFloor = Math.max(data.tower.bestFloor, floor);
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        showTitle(player,
                Text.literal("✦ VICTORIA ✦").formatted(Formatting.GOLD, Formatting.BOLD),
                Text.literal("Piso " + floor + " superado").formatted(Formatting.LIGHT_PURPLE),
                5, 45, 10);
        player.sendMessage(Text.literal("✦ Piso " + floor + "/10 superado").formatted(Formatting.GOLD), true);

        if (floor >= 10) {
            beginCelebration(player, session);
            return;
        }

        session.pendingFloor = floor + 1;
        session.transitionFromFloor = floor;
        session.transitionPhase = (floor == 3 || floor == 6 || floor == 9) ? 1 : 2;
        session.transitionTick = serverTicks + 50L;
    }

    public static void forceWin(ServerPlayerEntity player) {
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session == null) {
            player.sendMessage(Text.literal("§eNo tienes un intento activo."), false);
            return;
        }
        ServiceNpcEntity trainer = session.trainer;
        if (trainer == null) {
            PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
            fakeVictory(player, data.tower.currentFloor, session);
            return;
        }
        onBattleResult(player, trainer, true);
    }

    private static void fakeVictory(ServerPlayerEntity player, int floor, RuntimeSession session) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.bestFloor = Math.max(data.tower.bestFloor, floor);
        if (floor >= 10) complete(player, session.adminBypass);
        else {
            data.tower.currentFloor = floor + 1;
            Chainacobblemon.playerDataManager().saveNow(player.getUuid());
            enterFloor(player, floor + 1, true);
        }
    }

    public static void forceLose(ServerPlayerEntity player) {
        if (!SESSIONS.containsKey(player.getUuid())) {
            player.sendMessage(Text.literal("§eNo tienes un intento activo."), false);
            return;
        }
        fail(player, "Derrota simulada por administrador.");
    }

    public static void forceComplete(ServerPlayerEntity player, boolean reward) {
        RuntimeSession session = SESSIONS.computeIfAbsent(player.getUuid(), id -> new RuntimeSession(id, true, allocateLaneX()));
        complete(player, !reward || session.adminBypass);
    }

    public static void playerJoined(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        if (data.tower.activeAttempt || player.getWorld().getRegistryKey().equals(WORLD_KEY)) {
            player.sendMessage(Text.literal("§eTu intento de Torre fue cancelado de forma segura porque la sesión anterior terminó o el servidor se reinició."), false);
            returnPlayer(player, false);
        }
    }

    public static void playerLeft(UUID playerId) {
        cancelRuntime(playerId);
        BUILD_MODE.remove(playerId);
    }

    public static void reset(ServerPlayerEntity player) {
        cancelRuntime(player.getUuid());
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.activeAttempt = false;
        data.tower.currentFloor = 0;
        data.tower.cooldownUntilEpochMillis = 0L;
        data.tower.rouletteCooldownUntilEpochMillis = 0L;
        BUILD_MODE.remove(player.getUuid());
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
    }

    public static void clearCooldown(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.cooldownUntilEpochMillis = 0L;
        data.tower.rouletteCooldownUntilEpochMillis = 0L;
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
    }

    public static void setAdminUnlocked(ServerPlayerEntity player, boolean value) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.adminUnlocked = value;
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
    }

    public static String status(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        return "Torre Desafío — " + player.getName().getString()
                + " | desbloqueada=" + unlocked(player)
                + " | activa=" + data.tower.activeAttempt
                + " | piso=" + data.tower.currentFloor + "/10"
                + " | mejor=" + data.tower.bestFloor
                + " | completadas=" + data.tower.completions
                + " | premioPrincipal=" + cooldownText(player)
                + " | ruleta=" + rouletteCooldownText(player);
    }

    private static void tick(MinecraftServer server) {
        serverTicks++;
        for (RuntimeSession session : new ArrayList<>(SESSIONS.values())) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(session.playerId);
            if (player == null) continue;
            if (!player.getWorld().getRegistryKey().equals(WORLD_KEY)) {
                fail(player, "Saliste de la dimensión de la Torre.");
                continue;
            }

            if (session.celebrating) {
                if (session.rouletteSnapshot != null && !session.rouletteOpened && serverTicks >= session.rouletteOpenTick) {
                    session.rouletteOpened = true;
                    TowerRouletteNetworking.open(player, session.rouletteSnapshot);
                }
                if (serverTicks >= session.nextCelebrationFxTick) {
                    celebrationFx(player, session);
                    session.nextCelebrationFxTick = serverTicks + 20L;
                }
                if (serverTicks >= session.returnTick) {
                    returnPlayer(player, false);
                }
                continue;
            }

            if (session.pendingReturn && serverTicks >= session.returnTick) {
                returnPlayer(player, false);
                continue;
            }

            if (session.towerMusic && session.trainer != null) {
                if (serverTicks >= session.nextSuppressMusicTick) {
                    suppressCompetingBattleMusic(player);
                    session.nextSuppressMusicTick = serverTicks + 10L;
                }
                if (serverTicks >= session.nextMusicTick) {
                    playTowerMusic(player);
                    session.nextMusicTick = serverTicks + 1_160L;
                }
            }

            if (session.transitionPhase > 0 && serverTicks >= session.transitionTick) {
                handleTransition(player, session);
                continue;
            }

            if (session.trainer == null && session.nextBattleTick > 0 && serverTicks >= session.nextBattleTick) {
                session.nextBattleTick = 0L;
                spawnAndStart(player, session);
            }
        }
    }

    private static void handleTransition(ServerPlayerEntity player, RuntimeSession session) {
        int from = session.transitionFromFloor;
        int next = session.pendingFloor;
        if (session.transitionPhase == 1) {
            healParty(player, true);
            if (from == 3) {
                showTitle(player,
                        Text.literal("⚔ SUBIDA DE DIFICULTAD ⚔").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                        Text.literal("Los rivales empiezan a tomarte en serio").formatted(Formatting.GOLD),
                        10, 65, 15);
            } else if (from == 6) {
                showTitle(player,
                        Text.literal("✦ ZONA ÉLITE ✦").formatted(Formatting.DARK_PURPLE, Formatting.BOLD),
                        Text.literal("Tu equipo fue curado · el verdadero reto comienza").formatted(Formatting.AQUA),
                        10, 65, 15);
            } else {
                showTitle(player,
                        Text.literal("★ DESCANSO FINAL ★").formatted(Formatting.GOLD, Formatting.BOLD),
                        Text.literal("Equipo curado · prepárate para el Maestro").formatted(Formatting.LIGHT_PURPLE),
                        10, 70, 15);
            }
            session.transitionPhase = 2;
            session.transitionTick = serverTicks + 75L;
            return;
        }
        if (session.transitionPhase == 2) {
            PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
            data.tower.currentFloor = next;
            Chainacobblemon.playerDataManager().saveNow(player.getUuid());
            teleportFloor(player, next);
            if (next == 10) {
                showTitle(player,
                        Text.literal("★ COMBATE FINAL ★").formatted(Formatting.GOLD, Formatting.BOLD),
                        Text.literal("Un Maestro de la Torre te espera").formatted(Formatting.RED),
                        10, 70, 15);
            } else {
                showFloorTitle(player, next, "Un nuevo rival se aproxima");
            }
            session.transitionPhase = 3;
            session.transitionTick = serverTicks + (next == 10 ? 95L : 75L);
            return;
        }
        session.transitionPhase = 0;
        session.transitionTick = 0L;
        session.pendingFloor = 0;
        spawnAndStart(player, session);
    }

    private static void enterFloor(ServerPlayerEntity player, int floor, boolean announce) {
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session == null) return;
        session.transitionPhase = 0;
        session.pendingFloor = 0;
        session.transitionTick = 0L;
        session.pendingReturn = false;
        teleportFloor(player, floor);
        if (floor == 1) healParty(player, false);
        if (announce) {
            if (floor == 1) {
                showTitle(player,
                        Text.literal("✦ TORRE DESAFÍO ✦").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                        Text.literal("Piso 1 / 10 · Equipo completamente curado").formatted(Formatting.AQUA),
                        10, 65, 15);
            } else if (floor == 10) {
                showTitle(player,
                        Text.literal("★ COMBATE FINAL ★").formatted(Formatting.GOLD, Formatting.BOLD),
                        Text.literal("Piso 10 / 10").formatted(Formatting.RED),
                        10, 65, 15);
            } else {
                showFloorTitle(player, floor, "Prepárate");
            }
        }
        session.nextBattleTick = serverTicks + (floor == 10 ? 95L : 85L);
    }

    private static void teleportFloor(ServerPlayerEntity player, int floor) {
        ServerWorld tower = player.getServer().getWorld(WORLD_KEY);
        if (tower == null) return;
        RuntimeSession session = SESSIONS.get(player.getUuid());
        int laneX = session == null ? 0 : session.laneX;
        double y = floorY(floor);
        player.teleport(tower, laneX + 0.5D, y, 10.5D, 180.0F, 0.0F);
    }

    private static void spawnAndStart(ServerPlayerEntity player, RuntimeSession session) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        int floor = Math.max(1, data.tower.currentFloor);
        ServerWorld world = player.getServer().getWorld(WORLD_KEY);
        if (world == null) { fail(player, "La dimensión de la Torre dejó de estar disponible."); return; }

        cleanupBattleEntities(player, floor);
        ServiceNpcEntity npc = ModRegistries.CUSTOM_NPC.create(world);
        if (npc == null) { fail(player, "No se pudo crear al combatiente."); return; }
        String displayName = floor == 10
                ? "Maestro " + MASTER_NAMES.get(ThreadLocalRandom.current().nextInt(MASTER_NAMES.size()))
                : "Entrenador " + TRAINER_NAMES.get(ThreadLocalRandom.current().nextInt(TRAINER_NAMES.size()));
        String skinSeed = Integer.toHexString(ThreadLocalRandom.current().nextInt());
        npc.setNpcId("tower_f" + floor + "_" + skinSeed);
        npc.setCustomName(Text.literal(displayName).formatted(floor == 10 ? Formatting.GOLD : Formatting.LIGHT_PURPLE));
        npc.setCustomNameVisible(true);
        npc.setDialogue("Combatiente de la Torre Desafío.");
        npc.setPokemonTeam(randomTeam(player, floor));
        npc.setBattleRewards(List.of());
        npc.setBattleRewardRepeatable(false);
        npc.setAiDisabled(true);
        npc.setInvulnerable(true);
        npc.setPersistent();
        npc.refreshPositionAndAngles(session.laneX + 0.5D, floorY(floor), -8.5D, 0.0F, 0.0F);
        if (!world.spawnEntity(npc)) { fail(player, "No se pudo generar al combatiente."); return; }
        session.trainer = npc;

        if (floor == 10) {
            showTitle(player,
                    Text.literal("♛ MAESTRO DE LA TORRE ♛").formatted(Formatting.GOLD, Formatting.BOLD),
                    Text.literal(displayName).formatted(Formatting.RED, Formatting.BOLD),
                    10, 65, 15);
        } else {
            showTitle(player,
                    Text.literal("⚔ " + displayName + " ⚔").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                    Text.literal("Piso " + floor + "/10 · Equipo ~Nv." + targetLevel(player, floor)).formatted(Formatting.AQUA),
                    5, 50, 10);
        }
        player.sendMessage(Text.literal("⚔ " + displayName + " · Piso " + floor + "/10 · rival adaptado ~Nv." + targetLevel(player, floor))
                .formatted(floor == 10 ? Formatting.GOLD : Formatting.LIGHT_PURPLE), true);

        if (!NpcBattleService.start(player, npc)) {
            cleanupBattleEntities(player, floor);
            removeTrainer(player.getUuid());
            player.sendMessage(Text.literal("No se pudo iniciar el combate. Puedes volver a intentarlo desde la Profesora Chaina.")
                    .formatted(Formatting.YELLOW), false);
            session.pendingReturn = true;
            session.returnTick = serverTicks + 60L;
            return;
        }

        session.towerMusic = true;
        session.nextMusicTick = serverTicks + 1_160L;
        session.nextSuppressMusicTick = serverTicks;
        suppressCompetingBattleMusic(player);
        playTowerMusic(player);
    }

    private static List<String> randomTeam(ServerPlayerEntity player, int floor) {
        List<String> pool = floor <= 3 ? STAGE_ONE : floor <= 6 ? STAGE_TWO : floor <= 9 ? STAGE_THREE : BOSS_POOL;
        int count = floor <= 2 ? 3 : floor == 3 ? 4 : floor <= 5 ? 4 : floor == 6 ? 5 : floor <= 8 ? 5 : 6;
        List<String> shuffled = new ArrayList<>(pool);
        Collections.shuffle(shuffled, ThreadLocalRandom.current());
        int level = targetLevel(player, floor);
        List<String> team = new ArrayList<>(count);
        Set<String> used = new LinkedHashSet<>();
        for (String species : shuffled) {
            if (!used.add(species)) continue;
            int variance = floor >= 7 ? ThreadLocalRandom.current().nextInt(-1, 2) : ThreadLocalRandom.current().nextInt(-2, 2);
            int memberLevel = Math.max(1, Math.min(100, level + variance));
            team.add(species + " level=" + memberLevel);
            if (team.size() >= count) break;
        }
        return List.copyOf(team);
    }

    private static int targetLevel(ServerPlayerEntity player, int floor) {
        int base = averageTopThree(player);
        if (base <= 0) base = Math.max(10, RctCobbleverseBridge.levelCap(player).highestPartyLevel());
        int bonus = floor <= 3 ? 0 : floor <= 6 ? 2 : floor <= 9 ? 4 : 6;
        int target = Math.min(100, Math.max(1, base + bonus));
        // Tower opponents mirror the player's real party level, independent of Cobbleverse's
        // regional RCT cap. The Tower only unlocks after the regional campaign; admin test mode
        // must also be able to validate scaling with any party.
        return target;
    }

    private static int averageTopThree(ServerPlayerEntity player) {
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                List<Integer> levels = new ArrayList<>();
                for (Pokemon pokemon : party) if (pokemon != null) levels.add(pokemon.getLevel());
                levels.sort(Collections.reverseOrder());
                int count = Math.min(3, levels.size());
                if (count == 0) return 0;
                int sum = 0;
                for (int i = 0; i < count; i++) sum += levels.get(i);
                return Math.max(1, Math.round(sum / (float) count));
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not inspect party for Tower scaling: {}", exception.toString());
        }
        return 0;
    }

    private static void complete(ServerPlayerEntity player, boolean adminBypass) {
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session == null) return;
        beginCelebration(player, session);
    }

    private static void beginCelebration(ServerPlayerEntity player, RuntimeSession session) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        data.tower.activeAttempt = false;
        data.tower.currentFloor = 0;
        data.tower.bestFloor = 10;
        data.tower.completions++;
        cleanupBattleEntities(player, 10);
        stopTowerMusic(player);

        boolean primaryReward = false;
        boolean rouletteReward = false;
        if (!session.adminBypass) {
            if (cooldownRemaining(player) <= 0L) {
                primaryReward = true;
                give(player, ModRegistries.GACHA_TICKET, 10);
                give(player, ModRegistries.CHAINA_SPECIAL_BANNER_TICKET, 10);
                give(player, ModRegistries.TREASURE_GACHA_TICKET, 10);
                data.tower.cooldownUntilEpochMillis = System.currentTimeMillis() + COOLDOWN_MILLIS;
            } else if (rouletteCooldownRemaining(player) <= 0L) {
                rouletteReward = true;
                TowerRouletteSnapshot snapshot = rollRoulette(player, false, true);
                session.rouletteSnapshot = snapshot;
                session.rouletteOpenTick = serverTicks + 35L;
                data.tower.rouletteCooldownUntilEpochMillis = System.currentTimeMillis() + ROULETTE_COOLDOWN_MILLIS;
            }
        }
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());

        session.celebrating = true;
        session.nextCelebrationFxTick = serverTicks;
        session.returnTick = serverTicks + (rouletteReward ? 360L : 280L);
        if (primaryReward) {
            showTitle(player,
                    Text.literal("★ TORRE DESAFÍO COMPLETADA ★").formatted(Formatting.GOLD, Formatting.BOLD),
                    Text.literal("+10 Normal · +10 Chaina · +10 Tesoros").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                    10, 110, 20);
            player.sendMessage(Text.literal("✦ ¡Conquistaste la Torre! +10 Ticket Gasha · +10 Ticket Chaina · +10 Ticket Tesoro · próximo premio principal en 4 días.")
                    .formatted(Formatting.GOLD, Formatting.BOLD), false);
        } else if (rouletteReward) {
            showTitle(player,
                    Text.literal("✦ RULETA DE LA TORRE ✦").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                    Text.literal("Tu victoria repetida tiene recompensa").formatted(Formatting.GOLD),
                    10, 65, 15);
            player.sendMessage(Text.literal("✦ Premio principal todavía en cooldown. Preparando tu ruleta de victoria…")
                    .formatted(Formatting.LIGHT_PURPLE), false);
        } else if (session.adminBypass) {
            showTitle(player,
                    Text.literal("★ TORRE DESAFÍO COMPLETADA ★").formatted(Formatting.GOLD, Formatting.BOLD),
                    Text.literal("Prueba administrativa completada").formatted(Formatting.LIGHT_PURPLE),
                    10, 95, 20);
            player.sendMessage(Text.literal("✦ Prueba de Torre completada. No se entregaron recompensas ni se aplicó cooldown.")
                    .formatted(Formatting.GOLD), false);
        } else {
            showTitle(player,
                    Text.literal("★ TORRE DESAFÍO COMPLETADA ★").formatted(Formatting.GOLD, Formatting.BOLD),
                    Text.literal("Ruleta disponible en " + rouletteCooldownText(player)).formatted(Formatting.AQUA),
                    10, 95, 20);
            player.sendMessage(Text.literal("✦ Puedes seguir repitiendo la Torre. La siguiente recompensa de ruleta estará disponible en "
                    + rouletteCooldownText(player) + ".").formatted(Formatting.AQUA), false);
        }
        ((ServerWorld) player.getWorld()).playSound(null, player.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.MASTER, 1.2F, 1.0F);
        player.sendMessage(Text.literal("Profesora Chaina: Impresionante. Disfruta este momento, te lo ganaste.")
                .formatted(Formatting.LIGHT_PURPLE), false);
    }

    private static void give(ServerPlayerEntity player, Item item, int count) {
        ItemStack stack = new ItemStack(item, count);
        if (!player.getInventory().insertStack(stack) && !stack.isEmpty()) player.dropItem(stack, false);
    }

    private static void fail(ServerPlayerEntity player, String reason) {
        RuntimeSession session = SESSIONS.get(player.getUuid());
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        int reached = Math.max(1, data.tower.currentFloor);
        data.tower.bestFloor = Math.max(data.tower.bestFloor, reached);
        data.tower.activeAttempt = false;
        data.tower.currentFloor = 0;
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        cleanupBattleEntities(player, reached);
        removeTrainer(player.getUuid());
        stopTowerMusic(player);
        showTitle(player,
                Text.literal("DESAFÍO FALLIDO").formatted(Formatting.RED, Formatting.BOLD),
                Text.literal("Llegaste al piso " + reached + " · puedes reintentarlo sin espera").formatted(Formatting.YELLOW),
                5, 60, 15);
        player.sendMessage(Text.literal(reason + " Puedes volver a intentarlo inmediatamente.").formatted(Formatting.YELLOW), false);
        if (session != null) {
            session.pendingReturn = true;
            session.returnTick = serverTicks + 80L;
        } else {
            returnPlayer(player, false);
        }
    }

    private static void returnPlayer(ServerPlayerEntity player, boolean keepActive) {
        stopTowerMusic(player);
        BUILD_MODE.remove(player.getUuid());
        cancelRuntime(player.getUuid());
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        Identifier id = Identifier.tryParse(data.tower.returnWorld);
        ServerWorld target = id == null ? null : player.getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, id));
        if (target == null) target = player.getServer().getOverworld();
        double x = data.tower.returnX;
        double y = data.tower.returnY;
        double z = data.tower.returnZ;
        if (x == 0.0D && y == 0.0D && z == 0.0D) {
            BlockPos spawn = target.getSpawnPos();
            x = spawn.getX() + 0.5D; y = spawn.getY() + 1.0D; z = spawn.getZ() + 0.5D;
        }
        player.teleport(target, x, y, z, data.tower.returnYaw, data.tower.returnPitch);
        player.changeGameMode(data.tower.returnCreative ? GameMode.CREATIVE : GameMode.SURVIVAL);
        if (!keepActive) {
            data.tower.activeAttempt = false;
            data.tower.currentFloor = 0;
            Chainacobblemon.playerDataManager().saveNow(player.getUuid());
        }
    }

    private static void removeTrainer(UUID playerId) {
        RuntimeSession session = SESSIONS.get(playerId);
        if (session != null && session.trainer != null) {
            if (!session.trainer.isRemoved()) session.trainer.discard();
            session.trainer = null;
        }
    }

    private static void cancelRuntime(UUID playerId) {
        RuntimeSession session = SESSIONS.remove(playerId);
        if (session != null && session.trainer != null && !session.trainer.isRemoved()) session.trainer.discard();
    }

    private static void suppressCompetingBattleMusic(ServerPlayerEntity player) {
        player.networkHandler.sendPacket(new StopSoundS2CPacket(null, SoundCategory.MUSIC));
        player.networkHandler.sendPacket(new StopSoundS2CPacket(null, SoundCategory.RECORDS));
    }

    private static void playTowerMusic(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.getWorld();
        world.playSound(null, player.getBlockPos(), ModRegistries.BADGE_RUSH, SoundCategory.MASTER, 4.0F, 1.0F);
    }

    private static void stopTowerMusic(ServerPlayerEntity player) {
        player.networkHandler.sendPacket(new StopSoundS2CPacket(Identifier.of(Chainacobblemon.MOD_ID, "badge_rush"), SoundCategory.MASTER));
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session != null) {
            session.towerMusic = false;
            session.nextMusicTick = 0L;
            session.nextSuppressMusicTick = 0L;
        }
    }

    private static void showTitle(ServerPlayerEntity player, Text title, Text subtitle, int fadeIn, int stay, int fadeOut) {
        player.networkHandler.sendPacket(new TitleFadeS2CPacket(fadeIn, stay, fadeOut));
        player.networkHandler.sendPacket(new TitleS2CPacket(title));
        player.networkHandler.sendPacket(new SubtitleS2CPacket(subtitle));
    }

    private static void showTitle(ServerPlayerEntity player, String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        showTitle(player, Text.literal(title), Text.literal(subtitle), fadeIn, stay, fadeOut);
    }

    private static void showFloorTitle(ServerPlayerEntity player, int floor, String subtitle) {
        Formatting main = floor <= 3 ? Formatting.AQUA : floor <= 6 ? Formatting.LIGHT_PURPLE : floor <= 9 ? Formatting.DARK_PURPLE : Formatting.GOLD;
        showTitle(player,
                Text.literal("✦ PISO " + floor + " / 10 ✦").formatted(main, Formatting.BOLD),
                Text.literal(subtitle).formatted(Formatting.WHITE),
                5, 55, 12);
    }

    private static void healParty(ServerPlayerEntity player, boolean announce) {
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                boolean any = false;
                for (Pokemon pokemon : party) {
                    if (pokemon == null) continue;
                    any = true;
                    pokemon.heal();
                }
                if (any && announce) {
                    player.sendMessage(Text.literal("♥ Tu equipo fue completamente curado para la siguiente etapa.")
                            .formatted(Formatting.AQUA, Formatting.BOLD), false);
                    ((ServerWorld) player.getWorld()).playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 0.9F, 1.25F);
                }
                return;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.warn("Could not heal Challenge Tower party for {}: {}", player.getName().getString(), exception.toString());
        }
    }

    private static void cleanupBattleEntities(ServerPlayerEntity player, int floor) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session == null) return;
        double y = floorY(Math.max(1, Math.min(10, floor)));
        Box box = new Box(session.laneX - 22.0D, y - 4.0D, -18.0D, session.laneX + 22.0D, y + 14.0D, 18.0D);
        List<net.minecraft.entity.Entity> pokemon = world.getOtherEntities(null, box, entity ->
            entity.getClass().getName().equals("com.cobblemon.mod.common.entity.pokemon.PokemonEntity")
        );
        for (net.minecraft.entity.Entity entity : pokemon) {
            if (!entity.isRemoved()) entity.discard();
        }
        if (!pokemon.isEmpty()) {
            Chainacobblemon.LOGGER.debug("Tower cleanup removed {} temporary Pokemon entities on floor {} for {}",
                    pokemon.size(), floor, player.getName().getString());
        }
    }

    private static void celebrationFx(ServerPlayerEntity player, RuntimeSession session) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        double x = session.laneX + 0.5D;
        double y = floorY(10) + 2.0D;
        world.spawnParticles(ParticleTypes.FIREWORK, x, y + 3.0D, 0.0D, 28, 6.0D, 2.5D, 7.0D, 0.08D);
        world.spawnParticles(ParticleTypes.END_ROD, x, y + 1.5D, 0.0D, 18, 5.0D, 2.0D, 6.0D, 0.04D);
        if ((serverTicks / 20L) % 3L == 0L) {
            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, SoundCategory.MASTER, 0.9F, 1.15F);
        }
        long seconds = Math.max(0L, (session.returnTick - serverTicks + 19L) / 20L);
        RuntimeSession current = SESSIONS.get(player.getUuid());
        String status = current != null && current.rouletteSnapshot != null
                ? "✦ Ruleta de la Torre · regresando en " + seconds + "s ✦"
                : "★ Celebración de Campeón · regresando en " + seconds + "s ★";
        player.sendMessage(Text.literal(status).formatted(Formatting.GOLD), true);
    }

    public static void forceHeal(ServerPlayerEntity player) {
        healParty(player, true);
    }

    public static void forceCleanup(ServerPlayerEntity player) {
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        cleanupBattleEntities(player, Math.max(1, data.tower.currentFloor));
        player.sendMessage(Text.literal("Limpieza de entidades temporales ejecutada.").formatted(Formatting.GREEN), false);
    }

    public static void forceCelebration(ServerPlayerEntity player) {
        RuntimeSession session = SESSIONS.get(player.getUuid());
        if (session == null) {
            if (!start(player, true)) return;
            session = SESSIONS.get(player.getUuid());
        }
        if (session != null) beginCelebration(player, session);
    }

    /** Reuses the proven Tower roulette UI/pool for other Chaina systems. */
    public static void openExternalRoulette(ServerPlayerEntity player, String title, String subtitle, boolean grant) {
        TowerRouletteSnapshot snapshot = rollRoulette(player, false, grant);
        snapshot.title = title == null ? "" : title;
        snapshot.subtitle = subtitle == null ? "" : subtitle;
        snapshot.settledMessage = "Premio del evento entregado automáticamente";
        TowerRouletteNetworking.open(player, snapshot);
    }

    public static void forceRoulette(ServerPlayerEntity player, boolean jackpot) {
        TowerRouletteSnapshot snapshot = rollRoulette(player, jackpot, false);
        TowerRouletteNetworking.open(player, snapshot);
        player.sendMessage(Text.literal(jackpot ? "§6Ruleta de prueba: JACKPOT forzado." : "§dRuleta de prueba abierta; no entrega premios."), false);
    }

    public static boolean toggleBuildMode(ServerPlayerEntity player) {
        if (!player.getWorld().getRegistryKey().equals(WORLD_KEY)) {
            player.sendMessage(Text.literal("§cDebes estar dentro de la Torre Desafío para usar el modo construcción."), false);
            return false;
        }
        if (BUILD_MODE.remove(player.getUuid())) {
            player.changeGameMode(GameMode.ADVENTURE);
            player.sendMessage(Text.literal("§eModo construcción de Torre desactivado. Arena protegida."), false);
            return false;
        }
        BUILD_MODE.add(player.getUuid());
        player.changeGameMode(GameMode.CREATIVE);
        player.sendMessage(Text.literal("§aModo construcción de Torre activado para admin."), false);
        return true;
    }

    public static void forceRebuildFloor(ServerPlayerEntity player) {
        if (!(player.getWorld() instanceof ServerWorld world) || !world.getRegistryKey().equals(WORLD_KEY)) {
            player.sendMessage(Text.literal("§cDebes estar dentro de la Torre."), false);
            return;
        }
        RuntimeSession session = SESSIONS.get(player.getUuid());
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        int laneX = session == null ? 0 : session.laneX;
        int floor = Math.max(1, data.tower.currentFloor);
        buildFloor(world, floor, laneX);
        player.sendMessage(Text.literal("§aPiso " + floor + " reconstruido con techo e iluminación invisible."), false);
    }

    private static TowerRouletteSnapshot rollRoulette(ServerPlayerEntity player, boolean forceJackpot, boolean grant) {
        int roll = forceJackpot ? 0 : ThreadLocalRandom.current().nextInt(10_000);
        RewardRoll selected = rewardForRoll(player, roll, grant);
        TowerRouletteSnapshot snapshot = new TowerRouletteSnapshot();
        snapshot.selected = selected.view();
        snapshot.jackpot = selected.jackpot();
        for (int i = 0; i < 16; i++) {
            int previewRoll = ThreadLocalRandom.current().nextInt(10_000);
            snapshot.previews.add(rewardForRoll(player, previewRoll, false).view());
        }
        snapshot.previews.add(snapshot.selected);
        snapshot.closeAfterMillis = 8_000L;
        return snapshot;
    }

    private static RewardRoll rewardForRoll(ServerPlayerEntity player, int roll, boolean grant) {
        if (roll < 100) {
            if (grant) giveTicketPack(player, 10);
            return new RewardRoll(new TowerRouletteSnapshot.RewardView(
                    "TICKETS", "", "JACKPOT · 10 tickets de cada Gasha", 10, ""), true);
        }
        if (roll < 1_000) {
            if (grant) giveTicketPack(player, 1);
            return new RewardRoll(new TowerRouletteSnapshot.RewardView(
                    "TICKETS", "", "1 ticket de cada Gasha", 1, ""), false);
        }
        if (roll < 2_500) {
            String species = ROULETTE_POKEMON.get(ThreadLocalRandom.current().nextInt(ROULETTE_POKEMON.size()));
            int level = ThreadLocalRandom.current().nextInt(20, 36);
            if (grant) givePokemon(player, species, level);
            String label = prettySpecies(species) + " · Nv." + level;
            return new RewardRoll(new TowerRouletteSnapshot.RewardView("POKEMON", "", label, 1, species), false);
        }
        if (roll < 4_500) return itemReward(player, randomOf(ROULETTE_RARE_ITEMS), grant);
        if (roll < 7_000) return itemReward(player, randomOf(ROULETTE_MINERALS), grant);
        return itemReward(player, randomOf(ROULETTE_POKEMON_ITEMS), grant);
    }

    private static RewardRoll itemReward(ServerPlayerEntity player, ItemReward reward, boolean grant) {
        int amount = ThreadLocalRandom.current().nextInt(reward.min(), reward.max() + 1);
        if (grant) giveItemId(player, reward.id(), amount);
        return new RewardRoll(new TowerRouletteSnapshot.RewardView(
                "ITEM", reward.id(), amount + "× " + reward.label(), amount, ""), false);
    }

    private static ItemReward randomOf(List<ItemReward> rewards) {
        return rewards.get(ThreadLocalRandom.current().nextInt(rewards.size()));
    }

    private static void giveTicketPack(ServerPlayerEntity player, int amount) {
        give(player, ModRegistries.GACHA_TICKET, amount);
        give(player, ModRegistries.CHAINA_SPECIAL_BANNER_TICKET, amount);
        give(player, ModRegistries.TREASURE_GACHA_TICKET, amount);
    }

    private static void giveItemId(ServerPlayerEntity player, String rawId, int amount) {
        Identifier id = Identifier.tryParse(rawId);
        if (id == null || !Registries.ITEM.containsId(id)) {
            Chainacobblemon.LOGGER.warn("Tower roulette item is unavailable: {}", rawId);
            give(player, Items.DIAMOND, Math.max(1, Math.min(8, amount)));
            return;
        }
        Item item = Registries.ITEM.get(id);
        if (item == Items.AIR) {
            give(player, Items.DIAMOND, Math.max(1, Math.min(8, amount)));
            return;
        }
        int remaining = amount;
        while (remaining > 0) {
            int stackCount = Math.min(remaining, item.getMaxCount());
            give(player, item, stackCount);
            remaining -= stackCount;
        }
    }

    private static void givePokemon(ServerPlayerEntity player, String species, int level) {
        try {
            String command = "givepokemonother " + player.getGameProfile().getName() + " " + species + " level=" + level;
            player.getServer().getCommandManager().executeWithPrefix(player.getServer().getCommandSource().withSilent(), command);
        } catch (Exception exception) {
            Chainacobblemon.LOGGER.warn("Could not deliver Tower roulette Pokemon {} to {}: {}",
                    species, player.getName().getString(), exception.toString());
            giveItemId(player, "cobblemon:rare_candy", 3);
        }
    }

    private static String prettySpecies(String id) {
        if (id == null || id.isBlank()) return "Pokémon sorpresa";
        String value = id.replace('_', ' ').replace('-', ' ');
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    private record ItemReward(String id, String label, int min, int max) { }
    private record RewardRoll(TowerRouletteSnapshot.RewardView view, boolean jackpot) { }

    private static int allocateLaneX() {
        Set<Integer> used = new LinkedHashSet<>();
        for (RuntimeSession session : SESSIONS.values()) used.add(session.laneX);
        for (int lane = 0; lane < 256; lane++) {
            int x = lane * 64;
            if (!used.contains(x)) return x;
        }
        return (SESSIONS.size() + 1) * 64;
    }

    private static void ensureBuilt(ServerWorld world, int laneX) {
        BlockPos marker = new BlockPos(laneX + BUILD_VERSION, BASE_Y - 2, 0);
        if (world.getBlockState(marker).isOf(Blocks.MAGENTA_GLAZED_TERRACOTTA)) return;
        for (int floor = 1; floor <= 10; floor++) buildFloor(world, floor, laneX);
        world.setBlockState(marker, Blocks.MAGENTA_GLAZED_TERRACOTTA.getDefaultState(), Block.NOTIFY_ALL);
    }

    private static void buildFloor(ServerWorld world, int floor, int laneX) {
        int y = floorY(floor);
        Block outside = floor <= 3 ? Blocks.SMOOTH_QUARTZ : floor <= 6 ? Blocks.POLISHED_DEEPSLATE : floor <= 9 ? Blocks.POLISHED_BLACKSTONE : Blocks.OBSIDIAN;
        Block wall = floor <= 3 ? Blocks.QUARTZ_BRICKS : floor <= 6 ? Blocks.DEEPSLATE_TILES : floor <= 9 ? Blocks.POLISHED_BLACKSTONE_BRICKS : Blocks.CRYING_OBSIDIAN;
        Block field = switch (floor) {
            case 1 -> Blocks.LIGHT_BLUE_CONCRETE;
            case 2 -> Blocks.LIME_CONCRETE;
            case 3 -> Blocks.BLUE_CONCRETE;
            case 4 -> Blocks.ORANGE_CONCRETE;
            case 5 -> Blocks.YELLOW_CONCRETE;
            case 6 -> Blocks.CYAN_CONCRETE;
            case 7 -> Blocks.PURPLE_CONCRETE;
            case 8 -> Blocks.RED_CONCRETE;
            case 9 -> Blocks.MAGENTA_CONCRETE;
            default -> Blocks.BLACK_CONCRETE;
        };
        Block accent = switch (floor) {
            case 1 -> Blocks.CYAN_CONCRETE;
            case 2 -> Blocks.GREEN_CONCRETE;
            case 3 -> Blocks.LAPIS_BLOCK;
            case 4 -> Blocks.RED_CONCRETE;
            case 5 -> Blocks.GOLD_BLOCK;
            case 6 -> Blocks.DIAMOND_BLOCK;
            case 7 -> Blocks.AMETHYST_BLOCK;
            case 8 -> Blocks.NETHERITE_BLOCK;
            case 9 -> Blocks.GOLD_BLOCK;
            default -> Blocks.AMETHYST_BLOCK;
        };

        // Stadium shell: wider than the old room so giant Pokemon do not clip into walls.
        for (int x = -19; x <= 19; x++) {
            for (int z = -15; z <= 15; z++) {
                world.setBlockState(new BlockPos(laneX + x, y - 1, z), outside.getDefaultState(), Block.NOTIFY_LISTENERS);
                for (int dy = 0; dy <= 11; dy++) {
                    boolean edge = Math.abs(x) == 19 || Math.abs(z) == 15;
                    world.setBlockState(new BlockPos(laneX + x, y + dy, z), edge ? wall.getDefaultState() : Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }

        // Main Pokemon battle court.
        for (int x = -14; x <= 14; x++) for (int z = -11; z <= 11; z++) {
            world.setBlockState(new BlockPos(laneX + x, y - 1, z), field.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        // White boundary + central division.
        for (int x = -14; x <= 14; x++) {
            world.setBlockState(new BlockPos(laneX + x, y - 1, -11), Blocks.WHITE_CONCRETE.getDefaultState(), Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(laneX + x, y - 1, 11), Blocks.WHITE_CONCRETE.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        for (int z = -11; z <= 11; z++) {
            world.setBlockState(new BlockPos(laneX - 14, y - 1, z), Blocks.WHITE_CONCRETE.getDefaultState(), Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(laneX + 14, y - 1, z), Blocks.WHITE_CONCRETE.getDefaultState(), Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(laneX, y - 1, z), Blocks.WHITE_CONCRETE.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        // Pokeball-like center emblem.
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            if (dx * dx + dz * dz > 17) continue;
            Block emblem = dz < 0 ? Blocks.RED_CONCRETE : Blocks.WHITE_CONCRETE;
            if (dz == 0) emblem = Blocks.BLACK_CONCRETE;
            world.setBlockState(new BlockPos(laneX + dx, y - 1, dz), emblem.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        world.setBlockState(new BlockPos(laneX, y - 1, 0), Blocks.SEA_LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);

        // Trainer platforms.
        for (int dx = -2; dx <= 2; dx++) for (int dz = -1; dz <= 1; dz++) {
            world.setBlockState(new BlockPos(laneX + dx, y - 1, 10 + dz), accent.getDefaultState(), Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(laneX + dx, y - 1, -9 + dz), accent.getDefaultState(), Block.NOTIFY_LISTENERS);
        }

        // Stadium stands and lighting. Every floor keeps the same readable battle layout but changes palette.
        for (int z = -10; z <= 10; z++) {
            for (int tier = 0; tier < 3; tier++) {
                world.setBlockState(new BlockPos(laneX - 17 - tier / 2, y + tier, z), wall.getDefaultState(), Block.NOTIFY_LISTENERS);
                world.setBlockState(new BlockPos(laneX + 17 + tier / 2, y + tier, z), wall.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        for (int x : new int[]{-16, 16}) for (int z : new int[]{-12, 12}) {
            for (int dy = 0; dy <= 6; dy++) world.setBlockState(new BlockPos(laneX + x, y + dy, z), accent.getDefaultState(), Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(laneX + x, y + 7, z), Blocks.SEA_LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        for (int x = -12; x <= 12; x += 6) {
            world.setBlockState(new BlockPos(laneX + x, y + 10, -13), Blocks.SEA_LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
            world.setBlockState(new BlockPos(laneX + x, y + 10, 13), Blocks.SEA_LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
        }

        // Closed stadium roof. It removes the open-sky "box" feeling while preserving enough clearance for giant Pokemon.
        for (int x = -19; x <= 19; x++) for (int z = -15; z <= 15; z++) {
            Block roofBlock = (Math.abs(x) <= 4 || Math.abs(z) <= 2) ? accent : outside;
            world.setBlockState(new BlockPos(laneX + x, y + 12, z), roofBlock.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
        // Invisible level-15 light blocks brighten the court without adding visible lamps to the arena itself.
        for (int x = -14; x <= 14; x += 4) for (int z = -10; z <= 10; z += 4) {
            world.setBlockState(new BlockPos(laneX + x, y + 9, z),
                    Blocks.LIGHT.getDefaultState().with(Properties.LEVEL_15, 15), Block.NOTIFY_LISTENERS);
        }
    }

    private static int floorY(int floor) {
        return BASE_Y + (Math.max(1, Math.min(10, floor)) - 1) * FLOOR_SPACING;
    }

    private static final class RuntimeSession {
        final UUID playerId;
        final boolean adminBypass;
        final int laneX;
        ServiceNpcEntity trainer;
        long nextBattleTick;
        boolean towerMusic;
        long nextMusicTick;
        long nextSuppressMusicTick;
        int transitionPhase;
        int transitionFromFloor;
        int pendingFloor;
        long transitionTick;
        boolean celebrating;
        boolean pendingReturn;
        long returnTick;
        long nextCelebrationFxTick;
        TowerRouletteSnapshot rouletteSnapshot;
        long rouletteOpenTick;
        boolean rouletteOpened;

        RuntimeSession(UUID playerId, boolean adminBypass, int laneX) {
            this.playerId = playerId;
            this.adminBypass = adminBypass;
            this.laneX = laneX;
        }
    }
}
