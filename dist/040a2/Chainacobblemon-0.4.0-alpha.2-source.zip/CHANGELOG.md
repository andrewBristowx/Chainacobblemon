# Chainacobblemon 0.3.0-alpha.2

- Port funcional de paridad basado en la versión madura de referencia.
- Catálogo regional completo de entrenadores (Brock, Misty y resto de Kanto/Johto/Hoenn/Sinnoh).
- NPCs editables con autodetección/carpeta de skins y resolución RCT/Cobbleverse.
- Gasha con revelado progresivo x10 (135 ms por tarjeta y efecto pop de 190 ms).
- Misiones, trabajos, tienda, pase, login diario, hologramas, emotes, kits y panel admin portados.
- Identidad visual Chaina en coral/dorado/sakura y fondos claros.
- El contenido de apuestas queda excluido por diseño.
- Pokémon custom del proyecto anterior excluidos; el banner Chaina usa especies oficiales hasta aprobar variantes Chaina.
