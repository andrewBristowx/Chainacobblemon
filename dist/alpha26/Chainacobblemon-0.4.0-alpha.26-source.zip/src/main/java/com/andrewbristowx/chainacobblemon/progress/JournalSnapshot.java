package com.andrewbristowx.chainacobblemon.progress;

import java.util.ArrayList;
import java.util.List;

public final class JournalSnapshot {
    public String questTrack = QuestDefinition.PROGRESSION;
    public long balance;
    public QuestView quest;
    public int completedQuests;
    public int totalQuests;
    public int totalAllQuests;
    public int claimableQuests;
    public List<ChapterView> chapters = new ArrayList<>();
    public int activeJobCount;
    public int maxActiveJobs;
    public List<JobView> jobs = new ArrayList<>();
    public List<LocationRegionView> locationRegions = new ArrayList<>();
    public int locatedImportantLocations;
    public int totalImportantLocations;
    public boolean locationPlanRunning;
    public int locationPlanDone;
    public int locationPlanTotal;
    public boolean locationBoundsReady;
    public int locationCenterX;
    public int locationCenterZ;
    public int locationWidth;
    public int locationLength;
    public int locationPadding;

    public static final class QuestView {
        public String id;
        public String chapter;
        public String chapterTitle;
        public String title;
        public String description;
        public String objective;
        public long progress;
        public long target;
        public long coins;
        public long battlePassXp;
        public boolean complete;
        public boolean claimed;
        public List<String> items = new ArrayList<>();
    }

    public static final class ChapterView {
        public String id;
        public String title;
        public int complete;
        public int total;
        public boolean unlocked;
    }

    public static final class LocationRegionView {
        public String id;
        public String name;
        public int located;
        public int total;
        public List<LocationView> locations = new ArrayList<>();
    }

    public static final class LocationView {
        public String key;
        public int order;
        public String label;
        public String structureId;
        public boolean registered;
        public boolean located;
        public boolean assetOnly;
        public int x;
        public int y;
        public int z;
    }

    public static final class JobView {
        public String id;
        public String name;
        public String description;
        public int level;
        public long xp;
        public long levelStart;
        public long nextLevel;
        public boolean active;
    }
}
