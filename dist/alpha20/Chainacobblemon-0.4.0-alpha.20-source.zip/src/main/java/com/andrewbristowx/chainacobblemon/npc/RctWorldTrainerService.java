package com.andrewbristowx.chainacobblemon.npc;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * Adapts the TrainerMob entities spawned natively by Radical Cobblemon Trainers without replacing
 * RCT's own battle/progression pipeline. Right click and automatic sight challenges both pass through
 * Chaina's dialogue first. Immediately before native RCT creates the battle, the registered NPC team
 * is level-shifted; RCT clones that team into the battle and the registry template is restored in a
 * finally block, so the next player gets an independent level calculation.
 */
public final class RctWorldTrainerService {
    private static final String TRAINER_MOB_CLASS = "com.gitlab.srcmc.rctmod.world.entities.TrainerMob";
    private static final String DIALOGUE_PREFIX = "rct-world:";
    private static final long AUTO_PROMPT_COOLDOWN_MS = 15_000L;
    private static final Map<Permit, Boolean> NATIVE_START_PERMITS = new ConcurrentHashMap<>();
    private static final Map<Permit, Long> AUTO_PROMPT_UNTIL = new ConcurrentHashMap<>();
    private static boolean initialized;

    private RctWorldTrainerService() {}

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (hand != Hand.MAIN_HAND || world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)
                    || !isNativeWorldTrainer(entity)) {
                return ActionResult.PASS;
            }
            openDialogue(serverPlayer, entity, false);
            return ActionResult.SUCCESS;
        });
        Chainacobblemon.LOGGER.info("RCT world-trainer dialogue/adaptive bridge initialized");
    }

    /** Called from the optional TrainerMob mixin. true means cancel the native start for now. */
    public static boolean interceptStart(Object rawTrainer, ServerPlayerEntity player) {
        if (!(rawTrainer instanceof Entity trainer) || !isNativeWorldTrainer(trainer) || player == null) return false;
        Permit key = new Permit(player.getUuid(), trainer.getUuid());
        if (NATIVE_START_PERMITS.remove(key) != null) return false;
        if (playerBusy(player)) return false;

        long now = System.currentTimeMillis();
        long until = AUTO_PROMPT_UNTIL.getOrDefault(key, 0L);
        if (now >= until) {
            AUTO_PROMPT_UNTIL.put(key, now + AUTO_PROMPT_COOLDOWN_MS);
            openDialogue(player, trainer, true);
        }
        // Even while the prompt is on cooldown, block TrainerMob's force-battle loop. The player
        // explicitly accepts through Chaina's dialogue, which grants a one-shot native-start permit.
        return true;
    }

    public static boolean handleDialogueAction(ServerPlayerEntity player, String rawId, String rawAction) {
        if (rawId == null || !rawId.toLowerCase(Locale.ROOT).startsWith(DIALOGUE_PREFIX)) return false;
        Entity trainer = resolveTrainer(player, rawId);
        if (trainer == null) {
            player.sendMessage(Text.literal("§cEse entrenador de Radical ya no está disponible cerca de ti."), false);
            return true;
        }
        String action = rawAction == null ? "" : rawAction.trim().toLowerCase(Locale.ROOT);
        if ("battle".equals(action)) startAdaptiveNativeBattle(player, trainer);
        return true;
    }

    private static void openDialogue(ServerPlayerEntity player, Entity trainer, boolean automatic) {
        if (player == null || trainer == null || player.getWorld() != trainer.getWorld() || player.squaredDistanceTo(trainer) > 144.0D) return;
        boolean eligible = canBattleAgainst(trainer, player);
        int target = targetLevel(player);
        String trainerId = trainerId(trainer);
        String name = trainer.getCustomName() != null ? trainer.getCustomName().getString() : trainer.getName().getString();
        if (name == null || name.isBlank()) name = "Entrenador Radical";

        List<String> pages = new ArrayList<>();
        if (eligible) {
            pages.add(automatic
                    ? "¡Te he visto! Antes de combatir, prepararé un equipo acorde a tu progreso actual."
                    : "¿Quieres combatir? Mi equipo se adaptará a tu nivel actual para que el reto siga siendo justo.");
            pages.add("Se conserva mi equipo original: Pokémon, movimientos, objetos y reglas de Radical. Solo se ajustan temporalmente sus niveles para esta pelea.");
        } else {
            BlockReason reason = battleBlockReason(trainer, player);
            pages.add("Todavía no puedo combatir contigo. Radical está bloqueando este desafío por esta razón:");
            pages.add(reason.message());
            if (!reason.hint().isBlank()) pages.add(reason.hint());
        }

        List<NpcNetworking.DialogueChoice> choices = new ArrayList<>();
        if (eligible) choices.add(new NpcNetworking.DialogueChoice("battle", "⚔ Combatir", "Batalla adaptativa usando las reglas originales de RCT."));
        choices.add(new NpcNetworking.DialogueChoice("close", "Salir", "No iniciar el combate."));

        String details = eligible
                ? "Equipo adaptado ~Nv." + target + " · IA y progresión de Radical"
                : "Desafío bloqueado · consulta la razón en el diálogo";
        if (!trainerId.isBlank()) details += " · " + trainerId;
        NpcNetworking.sendDialogue(player, new NpcNetworking.DialogueState(
                DIALOGUE_PREFIX + trainer.getUuid(), name, "Entrenador de Radical Cobblemon Trainers",
                List.copyOf(pages), List.copyOf(choices), details,
                true, false, false, !eligible));
    }

    private static void startAdaptiveNativeBattle(ServerPlayerEntity player, Entity trainer) {
        if (playerBusy(player)) {
            player.sendMessage(Text.literal("§cYa estás en una batalla Pokémon."), false);
            return;
        }
        if (!canBattleAgainst(trainer, player)) {
            player.sendMessage(Text.literal("§eRadical todavía no permite que desafíes a este entrenador."), false);
            openDialogue(player, trainer, false);
            return;
        }
        String trainerId = trainerId(trainer);
        if (trainerId.isBlank()) {
            player.sendMessage(Text.literal("§cNo pude identificar el perfil RCT de este entrenador."), false);
            return;
        }

        Pokemon[] team = null;
        int[] originalLevels = null;
        Permit permit = new Permit(player.getUuid(), trainer.getUuid());
        try {
            Object nativeTrainer = registeredTrainer(trainerId);
            if (nativeTrainer == null) throw new IllegalStateException("trainer registry entry not found: " + trainerId);
            Object teamValue = nativeTrainer.getClass().getMethod("getTeam").invoke(nativeTrainer);
            if (!(teamValue instanceof Pokemon[] pokemonTeam) || pokemonTeam.length == 0) {
                throw new IllegalStateException("native RCT team is empty");
            }
            team = pokemonTeam;
            originalLevels = new int[team.length];
            int authoredMax = 1;
            for (int i = 0; i < team.length; i++) {
                originalLevels[i] = team[i] == null ? 1 : team[i].getLevel();
                authoredMax = Math.max(authoredMax, originalLevels[i]);
            }

            int target = targetLevel(player);
            int delta = target - authoredMax;
            for (int i = 0; i < team.length; i++) {
                if (team[i] == null) continue;
                team[i].setLevel(clamp(originalLevels[i] + delta, 1, 100));
            }

            NATIVE_START_PERMITS.put(permit, Boolean.TRUE);
            invokeStartBattleWith(trainer, player);
            AUTO_PROMPT_UNTIL.put(permit, System.currentTimeMillis() + AUTO_PROMPT_COOLDOWN_MS);
            player.sendMessage(Text.literal("§d⚔ Radical adaptativo §7· §fRival ~Nv." + target
                    + " §7· se conservan sus reglas, IA y progresión originales."), false);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.error("Could not start adaptive native RCT battle {}", trainerId, exception);
            player.sendMessage(Text.literal("§cNo se pudo iniciar el combate adaptativo de Radical. Revisa latest.log si se repite."), false);
        } finally {
            NATIVE_START_PERMITS.remove(permit);
            if (team != null && originalLevels != null) {
                for (int i = 0; i < Math.min(team.length, originalLevels.length); i++) {
                    if (team[i] != null) team[i].setLevel(originalLevels[i]);
                }
            }
        }
    }

    private static int targetLevel(ServerPlayerEntity player) {
        int target = averageTopThree(player);
        RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
        if (target <= 0) target = Math.max(5, cap.highestPartyLevel());
        // World trainers follow the same adaptive rule as Chaina dungeon trainers: use the player's
        // real party level. Radical still owns prerequisites/cooldowns/progression, but its regional
        // level cap is not used to make the opponent weaker than the challenger.
        return clamp(target, 5, 100);
    }

    private static int averageTopThree(ServerPlayerEntity player) {
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                List<Integer> levels = new ArrayList<>();
                for (Pokemon pokemon : party) if (pokemon != null) levels.add(pokemon.getLevel());
                levels.sort(Collections.reverseOrder());
                int count = Math.min(3, levels.size());
                if (count == 0) return 0;
                int sum = 0;
                for (int i = 0; i < count; i++) sum += levels.get(i);
                return Math.max(1, Math.round(sum / (float) count));
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not inspect party for native RCT scaling: {}", exception.toString());
        }
        return 0;
    }

    private static Object registeredTrainer(String trainerId) throws ReflectiveOperationException {
        Class<?> apiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
        Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
        Object rct = apiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
        if (rct == null) return null;
        Object registry = rct.getClass().getMethod("getTrainerRegistry").invoke(rct);
        return registry.getClass().getMethod("getById", String.class, Class.class).invoke(registry, trainerId, trainerNpcClass);
    }

    private static void invokeStartBattleWith(Entity trainer, ServerPlayerEntity player) throws ReflectiveOperationException {
        for (Method method : trainer.getClass().getMethods()) {
            if (!method.getName().equals("startBattleWith") || method.getParameterCount() != 1) continue;
            if (!method.getParameterTypes()[0].isInstance(player)) continue;
            method.invoke(trainer, player);
            return;
        }
        throw new NoSuchMethodException("TrainerMob.startBattleWith(Player)");
    }

    private static BlockReason battleBlockReason(Entity trainer, ServerPlayerEntity player) {
        RctCobbleverseBridge.LevelCapStatus capStatus = RctCobbleverseBridge.levelCap(player);
        try {
            Class<?> rctClass = Class.forName("com.gitlab.srcmc.rctmod.api.RCTMod");
            Object rct = rctClass.getMethod("getInstance").invoke(null);
            Object manager = invokeCompatible(rct, "getTrainerManager");
            Object playerData = invokeCompatible(manager, "getData", player);
            Object trainerData = invokeCompatible(manager, "getData", trainer);

            int cooldown = number(invokeCompatible(trainer, "getCooldown"), 0);
            if (cooldown > 0) {
                int seconds = Math.max(1, (int)Math.ceil(cooldown / 20.0));
                return new BlockReason("Este entrenador está en cooldown durante unos " + seconds + " s más.",
                        "Espera a que termine el cooldown y vuelve a hablar conmigo.");
            }
            if (bool(invokeCompatible(trainer, "isInBattle"), false)) {
                return new BlockReason("Este entrenador ya está combatiendo con otro jugador.",
                        "Espera a que termine esa batalla.");
            }
            if (bool(invokeCompatible(rct, "isInBattle", player), false) || playerBusy(player)) {
                return new BlockReason("Ya estás participando en otra batalla Pokémon.",
                        "Termina tu combate actual antes de iniciar este desafío.");
            }

            int activePokemon = number(invokeCompatible(manager, "getActivePokemon", player), -1);
            if (activePokemon == 0) {
                return new BlockReason("No tienes Pokémon activos disponibles para combatir.",
                        "Cura o añade al menos un Pokémon utilizable a tu equipo.");
            }

            int playerLevel = number(invokeCompatible(manager, "getPlayerLevel", player), capStatus.highestPartyLevel());
            int levelCap = number(invokeCompatible(playerData, "getLevelCap"), capStatus.cap());
            if (levelCap > 0 && playerLevel > levelCap) {
                int shownHighest = Math.max(playerLevel, capStatus.highestPartyLevel());
                return new BlockReason("Tu equipo supera el límite de nivel actual de Radical: tu nivel más alto es Nv."
                        + shownHighest + " y tu límite actual es Nv." + levelCap + ".",
                        "Avanza en la progresión de Radical para aumentar el límite o usa temporalmente un equipo que no lo supere.");
            }

            Object completedSeries = invokeCompatible(playerData, "getCompletedSeries");
            Object missingSeriesStream = invokeCompatible(trainerData, "getMissingSeriesRequirements", completedSeries);
            Object missingSeries = firstFromStream(missingSeriesStream);
            if (missingSeries != null) {
                return new BlockReason("Te falta completar una serie requerida antes de desafiar a este entrenador: " + missingSeries + ".",
                        "Completa esa serie de Radical y vuelve a intentarlo.");
            }

            Object defeatedTrainerIds = invokeCompatible(playerData, "getDefeatedTrainerIds");
            Object missingRequirementsStream = invokeCompatible(trainerData, "getMissingRequirements", defeatedTrainerIds);
            Object currentSeries = invokeCompatible(playerData, "getCurrentSeries");
            for (Object missingId : streamValues(missingRequirementsStream)) {
                try {
                    Object requiredData = invokeCompatible(manager, "getData", missingId);
                    if (bool(invokeCompatible(requiredData, "isOfSeries", currentSeries), false)) {
                        String id = String.valueOf(missingId);
                        return new BlockReason("Antes debes derrotar a un entrenador requerido de tu serie actual: " + id + ".",
                                "Busca y derrota a ese entrenador para desbloquear este combate.");
                    }
                } catch (ReflectiveOperationException | RuntimeException ignored) {
                }
            }

            boolean sameSeries = bool(invokeCompatible(trainerData, "isOfSeries", currentSeries), true);
            if (!sameSeries) {
                Object memory = invokeCompatible(manager, "getBattleMemory", trainer);
                int defeats = number(invokeCompatible(memory, "getDefeatByCount", trainerId(trainer), player), 0);
                if (defeats <= 0) {
                    return new BlockReason("Este entrenador pertenece a una serie distinta de la que tienes activa en Radical.",
                            "Cambia o avanza tu serie activa antes de desafiarlo.");
                }
            }

            boolean persistent = bool(invokeCompatible(trainer, "isPersistenceRequired"), false);
            if (!persistent) {
                if (bool(invokeCompatible(trainer, "wasDefeatedBy", player.getUuid()), false)) {
                    return new BlockReason("Ya derrotaste a este entrenador y su encuentro no admite otra derrota ahora mismo.",
                            "Busca otro entrenador de Radical o espera a que aparezca uno nuevo.");
                }
                if (bool(invokeCompatible(trainer, "wasVictoriousAgainst", player.getUuid()), false)) {
                    return new BlockReason("Este entrenador ya ganó contra ti y su encuentro actual quedó agotado.",
                            "Busca otro entrenador de Radical o espera a que aparezca uno nuevo.");
                }
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not resolve exact RCT trainer block reason: {}", exception.toString());
        }

        if (capStatus.available() && capStatus.cap() > 0 && capStatus.highestPartyLevel() > capStatus.cap()) {
            return new BlockReason("Tu equipo supera el límite de nivel actual de Radical: tienes un Pokémon Nv."
                    + capStatus.highestPartyLevel() + " y tu límite actual es Nv." + capStatus.cap() + ".",
                    "Avanza en la progresión de Radical para aumentar el límite o usa temporalmente un equipo dentro del cap.");
        }
        return new BlockReason("Radical tiene un requisito de progresión pendiente para este entrenador.",
                "Puede ser una serie, un entrenador previo, un cooldown u otra regla propia de RCT.");
    }

    private static Object invokeCompatible(Object target, String name, Object... args) throws ReflectiveOperationException {
        if (target == null) throw new NullPointerException("reflection target is null for " + name);
        Method best = null;
        outer: for (Method method : target.getClass().getMethods()) {
            if (!method.getName().equals(name) || method.getParameterCount() != args.length) continue;
            Class<?>[] types = method.getParameterTypes();
            for (int i = 0; i < types.length; i++) {
                Object arg = args[i];
                if (arg == null) continue;
                if (!wrap(types[i]).isAssignableFrom(arg.getClass())) continue outer;
            }
            best = method;
            break;
        }
        if (best == null) throw new NoSuchMethodException(target.getClass().getName() + "." + name);
        return best.invoke(target, args);
    }

    private static Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) return type;
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        if (type == char.class) return Character.class;
        return type;
    }

    private static int number(Object value, int fallback) {
        return value instanceof Number number ? number.intValue() : fallback;
    }

    private static boolean bool(Object value, boolean fallback) {
        return value instanceof Boolean b ? b : fallback;
    }

    private static Object firstFromStream(Object value) {
        if (value instanceof Stream<?> stream) {
            try (stream) { return stream.findFirst().orElse(null); }
        }
        if (value instanceof Iterable<?> iterable) {
            for (Object entry : iterable) return entry;
        }
        return null;
    }

    private static List<Object> streamValues(Object value) {
        if (value instanceof Stream<?> stream) {
            try (stream) { return new ArrayList<>(stream.toList()); }
        }
        List<Object> result = new ArrayList<>();
        if (value instanceof Iterable<?> iterable) for (Object entry : iterable) result.add(entry);
        return result;
    }

    private record BlockReason(String message, String hint) {}

    private static boolean canBattleAgainst(Entity trainer, ServerPlayerEntity player) {
        try {
            for (Method method : trainer.getClass().getMethods()) {
                if (!method.getName().equals("canBattleAgainst") || method.getParameterCount() != 1) continue;
                if (!method.getParameterTypes()[0].isInstance(player)) continue;
                Object result = method.invoke(trainer, player);
                return !(result instanceof Boolean allowed) || allowed;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not query TrainerMob.canBattleAgainst: {}", exception.toString());
        }
        // If a future RCT build hides the helper, let its own startBattleWith perform the authoritative check.
        return true;
    }

    private static String trainerId(Entity trainer) {
        try {
            Object value = trainer.getClass().getMethod("getTrainerId").invoke(trainer);
            return value == null ? "" : value.toString();
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return "";
        }
    }

    private static Entity resolveTrainer(ServerPlayerEntity player, String rawId) {
        try {
            UUID uuid = UUID.fromString(rawId.substring(DIALOGUE_PREFIX.length()));
            Entity entity = player.getServerWorld().getEntity(uuid);
            if (entity == null || !isNativeWorldTrainer(entity) || player.getWorld() != entity.getWorld()
                    || player.squaredDistanceTo(entity) > 100.0D) return null;
            return entity;
        } catch (IllegalArgumentException | IndexOutOfBoundsException exception) {
            return null;
        }
    }

    public static boolean isNativeWorldTrainer(Object entity) {
        if (entity == null) return false;
        Class<?> type = entity.getClass();
        while (type != null) {
            if (TRAINER_MOB_CLASS.equals(type.getName())) return true;
            type = type.getSuperclass();
        }
        return false;
    }

    private static boolean playerBusy(ServerPlayerEntity player) {
        try {
            Class<?> registryClass = Class.forName("com.cobblemon.mod.common.battles.BattleRegistry");
            Object instance = registryClass.getField("INSTANCE").get(null);
            for (Method method : registryClass.getMethods()) {
                if (!"getBattleByParticipatingPlayer".equals(method.getName()) || method.getParameterCount() != 1) continue;
                return method.invoke(instance, player) != null;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private record Permit(UUID playerId, UUID trainerId) {}
}
