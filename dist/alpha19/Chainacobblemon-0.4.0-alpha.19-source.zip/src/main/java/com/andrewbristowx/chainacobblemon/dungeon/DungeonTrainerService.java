package com.andrewbristowx.chainacobblemon.dungeon;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.andrewbristowx.chainacobblemon.data.PlayerData;
import com.andrewbristowx.chainacobblemon.events.treasure.TreasureHuntService;
import com.andrewbristowx.chainacobblemon.npc.NpcNetworking;
import com.andrewbristowx.chainacobblemon.npc.ServiceNpcEntity;
import com.andrewbristowx.chainacobblemon.registry.ModRegistries;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructureStart;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.structure.Structure;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Populates supported third-party dungeons with persistent Chainacobblemon trainer encounters.
 * Trainers scale independently for every challenger from the player's real party levels. Dungeon
 * encounters deliberately do not inherit RCT's regional level cap: the opponent adapts to the player,
 * never the other way around. They never grant chest loot directly; ChainaDungeonLoot remains the
 * single owner of dungeon chest rewards.
 */
public final class DungeonTrainerService {
    private static final int SCAN_INTERVAL_TICKS = 100;
    private static final Map<UUID, String> LAST_ANNOUNCED_STRUCTURE = new ConcurrentHashMap<>();
    private static int ticks;

    private DungeonTrainerService() {}

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks % SCAN_INTERVAL_TICKS != 0) return;
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) inspectPlayer(player, false);
        });
    }

    /**
     * Inspects only the player's already-loaded position. It never calls /locate and never forces chunk generation.
     * Existing alpha.10 trainers are upgraded in-place with roles instead of being duplicated.
     */
    public static int inspectPlayer(ServerPlayerEntity player, boolean notify) {
        if (player == null || player.isSpectator()) return 0;
        ServerWorld world = player.getServerWorld();
        StructureAccessor accessor = world.getStructureAccessor();
        Registry<Structure> registry = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
        ChunkPos chunkPos = new ChunkPos(player.getBlockPos());
        List<StructureStart> starts = accessor.getStructureStarts(chunkPos, structure -> {
            Identifier id = registry.getId(structure);
            return id != null && isSupportedStructure(id);
        });

        int prepared = 0;
        String activeStructure = "";
        for (StructureStart start : starts) {
            if (start == null || !start.hasChildren() || !accessor.structureContains(player.getBlockPos(), start)) continue;
            Identifier structureId = registry.getId(start.getStructure());
            if (structureId == null) continue;
            String structureKey = structureKey(world, structureId, start);
            activeStructure = structureKey;
            PackResult result = ensurePack(world, player, structureId, structureKey);
            prepared += result.changed();
            announceEntry(player, structureId, structureKey, result.total());
        }
        if (activeStructure.isBlank()) LAST_ANNOUNCED_STRUCTURE.remove(player.getUuid());

        if (notify) {
            int value = prepared;
            player.sendMessage(Text.literal(value > 0
                    ? "§dChainacobblemon: §f" + value + "§d entrenador(es) de dungeon preparados o actualizados cerca de ti."
                    : "§7Chainacobblemon: no hay una mazmorra compatible nueva en tu posición, o su contenido ya está preparado."), false);
        }
        return prepared;
    }

    public static boolean isSupportedStructure(Identifier id) {
        if (id == null) return false;
        String namespace = id.getNamespace().toLowerCase(Locale.ROOT);
        return namespace.equals("dungeons_arise")
                || namespace.equals("betterdungeons")
                || namespace.equals("mr_dungeons_andtaverns")
                || namespace.equals("dungeons_and_taverns")
                || namespace.equals("dungeonsandtaverns")
                || namespace.equals("mvs")
                || namespace.equals("repurposed_structures")
                || namespace.equals("bosses_of_mass_destruction");
    }

    public static boolean isDungeonTrainer(ServiceNpcEntity npc) {
        return npc != null && npc.isDungeonTrainer();
    }

    public static List<String> scaledTeam(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null) return npc == null ? List.of() : npc.pokemonTeam();
        Tier tier = Tier.parse(npc.dungeonTier());
        Theme theme = Theme.parse(npc.dungeonTheme());
        Role role = Role.parse(npc.dungeonRole());
        RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
        boolean treasureEvent = npc.dungeonStructureKey().startsWith("treasure_event:");
        int realAverage = averageTopThree(player);
        int playerLevel = Math.max(5, realAverage > 0 ? realAverage : cap.highestPartyLevel());
        // Dungeon trainers follow the player's REAL party, not the regional RCT cap. Team size, role
        // and BattleAI provide the difficulty curve; a normal Scout should not become lower-level just
        // because the player happens to be above the story cap. Guardians may sit slightly above the
        // player while Treasure Hunt keeps its own checkpoint offset.
        int target = treasureEvent
                ? playerLevel + TreasureHuntService.levelOffsetFor(npc)
                : playerLevel + Math.max(0, role.levelOffset);
        target = Math.max(5, Math.min(100, target));

        List<String> pool = theme.species(target);
        int teamSize = Math.min(6, Math.max(2, tier.baseTeamSize + role.teamSizeBonus));
        int start = Math.floorMod(Objects.hash(player.getUuid(), npc.dungeonStructureKey(), role.id), pool.size());
        List<String> team = new ArrayList<>(teamSize);
        for (int i = 0; i < teamSize; i++) {
            String species = pool.get((start + i) % pool.size());
            int level = Math.max(5, target - Math.max(0, teamSize - i - 2));
            team.add(treasureEvent ? competitiveTreasureSpec(species, level) : species + " level=" + level);
        }
        return List.copyOf(team);
    }

    public static int targetLevel(ServerPlayerEntity player, ServiceNpcEntity npc) {
        int max = 0;
        for (String spec : scaledTeam(player, npc)) {
            int idx = spec.lastIndexOf("level=");
            if (idx >= 0) {
                try { max = Math.max(max, Integer.parseInt(spec.substring(idx + 6).trim())); }
                catch (NumberFormatException ignored) {}
            }
        }
        return max;
    }

    /** Guardian encounters are locked until that player has beaten the other trainers in this dungeon. */
    public static boolean canChallenge(ServerPlayerEntity player, ServiceNpcEntity npc, boolean message) {
        if (!isDungeonTrainer(npc)) return true;
        if (npc.dungeonStructureKey().startsWith("treasure_event:") && !TreasureHuntService.canChallengeTrainer(player, npc)) {
            if (message) player.sendMessage(Text.literal("§eEsta sala sigue bloqueada para ti. §fDerrota al entrenador anterior primero."), false);
            return false;
        }
        Role role = Role.parse(npc.dungeonRole());
        if (!role.guardian) return true;
        List<ServiceNpcEntity> peers = trainersFor((ServerWorld) npc.getWorld(), npc.dungeonStructureKey());
        int missing = 0;
        for (ServiceNpcEntity peer : peers) {
            if (peer == npc || Role.parse(peer.dungeonRole()).guardian) continue;
            if (!hasDefeated(player, peer)) missing++;
        }
        if (missing == 0) return true;
        if (message) {
            player.sendMessage(Text.literal("§eEl Guardián todavía no acepta tu reto. §fDerrota a " + missing
                    + "§e entrenador(es) de esta mazmorra primero."), false);
        }
        return false;
    }

    public static boolean hasDefeated(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null) return false;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        return data.defeatedDungeonTrainers.contains(trainerVictoryKey(npc));
    }

    public static boolean isCleared(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (player == null || npc == null) return false;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        return data.clearedDungeons.contains(npc.dungeonStructureKey());
    }

    public static void onVictory(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (!isDungeonTrainer(npc)) return;
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        boolean firstTrainerVictory = data.defeatedDungeonTrainers.add(trainerVictoryKey(npc));
        List<ServiceNpcEntity> peers = trainersFor((ServerWorld) npc.getWorld(), npc.dungeonStructureKey());
        long defeated = peers.stream().filter(peer -> data.defeatedDungeonTrainers.contains(trainerVictoryKey(peer))).count();
        int total = peers.size();
        boolean clearedNow = total > 0 && defeated >= total && data.clearedDungeons.add(npc.dungeonStructureKey());
        Chainacobblemon.playerDataManager().saveNow(player.getUuid());

        if (firstTrainerVictory) {
            player.sendMessage(Text.literal("§d⚔ Entrenador de mazmorra derrotado · §f" + defeated + "/" + total), false);
        }
        if (npc.dungeonStructureKey().startsWith("treasure_event:")) {
            if (firstTrainerVictory) TreasureHuntService.onTrainerVictory(player, npc);
            if (clearedNow) player.sendMessage(Text.literal("§6✦ Todos tus guardianes han caído. §f¡Busca la Poké Ball del tesoro!"), false);
        } else if (clearedNow) {
            player.sendMessage(Text.literal("§d✦ Mazmorra completada para ti. §7Tu Tesoro de Dungeon de Chaina está listo."), false);
            ChainaDungeonLootService.onDungeonCleared(player, npc);
        } else if (Role.parse(npc.dungeonRole()).guardian && firstTrainerVictory) {
            player.sendMessage(Text.literal("§d✦ Guardián derrotado. §7Aún quedan encuentros pendientes en esta mazmorra."), false);
        }
        // Treasure gates/progress are announced in chat/HUD. Do not open another dialogue while Cobblemon
        // is still closing its BattleGUI; doing so can capture a stale BattleGUI as the parent screen.
        if (!npc.dungeonStructureKey().startsWith("treasure_event:")) {
            NpcNetworking.DialogueState state = dialogueState(player, npc);
            if (state != null) NpcNetworking.sendDialogue(player, state);
        }
    }

    public static NpcNetworking.DialogueState dialogueState(ServerPlayerEntity player, ServiceNpcEntity npc) {
        if (!isDungeonTrainer(npc)) return null;
        Tier tier = Tier.parse(npc.dungeonTier());
        Theme theme = Theme.parse(npc.dungeonTheme());
        Role role = Role.parse(npc.dungeonRole());
        boolean defeated = hasDefeated(player, npc);
        boolean cleared = isCleared(player, npc);
        boolean unlocked = canChallenge(player, npc, false);
        List<ServiceNpcEntity> peers = trainersFor((ServerWorld) npc.getWorld(), npc.dungeonStructureKey());
        PlayerData data = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid());
        long wins = peers.stream().filter(peer -> data.defeatedDungeonTrainers.contains(trainerVictoryKey(peer))).count();
        int total = peers.size();
        int target = targetLevel(player, npc);

        List<String> pages = new ArrayList<>();
        if (cleared) {
            pages.add("Ya superaste los encuentros Pokémon de esta mazmorra. Puedes volver a retarme cuando quieras.");
        } else if (!unlocked) {
            pages.add("Has llegado hasta mí, pero todavía no has demostrado suficiente dominio de esta mazmorra.");
            pages.add("Derrota a los demás entrenadores de aquí y vuelve. Entonces aceptaré tu desafío.");
        } else if (defeated) {
            pages.add("Buen combate. Ya me derrotaste una vez, pero mi equipo volverá a adaptarse a tu progreso actual.");
        } else {
            pages.add(role.intro(theme));
            pages.add(npc.dungeonStructureKey().startsWith("treasure_event:")
                    ? "En la Cacería mi equipo se adapta al promedio de tus 3 Pokémon más altos, sin bajar tus Pokémon reales."
                    : "Mi equipo se genera para tu progreso actual y respeta tu límite de nivel de Cobbleverse/RCT.");
        }

        List<NpcNetworking.DialogueChoice> choices = new ArrayList<>();
        if (unlocked) {
            choices.add(new NpcNetworking.DialogueChoice("battle", defeated ? "⚔ Revancha" : role.battleLabel,
                    "Combate adaptativo de dungeon."));
        }
        choices.add(new NpcNetworking.DialogueChoice("close", "Salir", "Continúa explorando la dungeon."));
        String reward = "Progreso dungeon: " + wins + "/" + total
                + " · Equipo objetivo ~Nv." + target
                + " · Botín de cofres: sistema de mazmorras de Chaina";
        return new NpcNetworking.DialogueState(npc.npcId(),
                npc.getCustomName() == null ? role.displayName + " · " + theme.displayName() : npc.getCustomName().getString(),
                tier.displayName() + " · Tema " + theme.displayName(),
                List.copyOf(pages), List.copyOf(choices), reward, false, defeated, defeated, !unlocked);
    }

    public static int countLoaded(MinecraftServer server) {
        if (server == null) return 0;
        int count = 0;
        for (ServerWorld world : server.getWorlds()) count += allDungeonTrainers(world).size();
        return count;
    }

    public static Set<String> supportedNamespaces() {
        return Set.of("dungeons_arise", "betterdungeons", "mr_dungeons_andtaverns", "dungeons_and_taverns",
                "dungeonsandtaverns", "mvs", "repurposed_structures", "bosses_of_mass_destruction");
    }

    private static String structureKey(ServerWorld world, Identifier structureId, StructureStart start) {
        return world.getRegistryKey().getValue() + ":" + structureId + "@" + start.getPos().x + "," + start.getPos().z;
    }

    private static PackResult ensurePack(ServerWorld world, ServerPlayerEntity player, Identifier structureId, String structureKey) {
        Tier tier = classifyTier(structureId);
        Theme theme = classifyTheme(structureId);
        List<Role> desired = tier.roles();
        List<ServiceNpcEntity> existing = trainersFor(world, structureKey);
        existing.sort(Comparator.comparing(ServiceNpcEntity::npcId));

        Set<Role> occupied = new HashSet<>();
        List<ServiceNpcEntity> needsRole = new ArrayList<>();
        for (ServiceNpcEntity npc : existing) {
            Role stored = Role.find(npc.dungeonRole());
            if (stored != null && desired.contains(stored) && occupied.add(stored)) {
                ensureMetadata(npc, tier, theme, stored, structureKey);
            } else {
                needsRole.add(npc);
            }
        }

        int changed = 0;
        for (Role role : desired) {
            if (occupied.contains(role)) continue;
            if (!needsRole.isEmpty()) {
                ServiceNpcEntity npc = needsRole.remove(0);
                configureDungeonNpc(npc, tier, theme, role, structureKey);
                occupied.add(role);
                changed++;
                continue;
            }
            if (spawnRole(world, player, tier, theme, role, structureKey, desired.indexOf(role))) {
                occupied.add(role);
                changed++;
            }
        }
        int total = trainersFor(world, structureKey).size();
        if (changed > 0) {
            Chainacobblemon.LOGGER.info("Prepared/updated {} dungeon trainer(s) for {} [{} / {}] total={}",
                    changed, structureId, tier.id, theme.id, total);
        }
        return new PackResult(changed, total);
    }

    private static void ensureMetadata(ServiceNpcEntity npc, Tier tier, Theme theme, Role role, String structureKey) {
        if (npc.dungeonStructureKey().isBlank()) npc.setDungeonStructureKey(structureKey);
        if (npc.dungeonTier().isBlank()) npc.setDungeonTier(tier.id);
        if (npc.dungeonTheme().isBlank()) npc.setDungeonTheme(theme.id);
        if (npc.dungeonRole().isBlank()) npc.setDungeonRole(role.id);
        relocateIfUnsafe(npc);
    }

    private static void configureDungeonNpc(ServiceNpcEntity npc, Tier tier, Theme theme, Role role, String structureKey) {
        npc.setDungeonStructureKey(structureKey);
        npc.setDungeonTier(tier.id);
        npc.setDungeonTheme(theme.id);
        npc.setDungeonRole(role.id);
        npc.setCustomName(Text.literal(role.displayName + " · " + theme.displayName()));
        npc.setCustomNameVisible(true);
        npc.setDialogue(role.intro(theme) + " Mi equipo se adapta a cada retador.");
        // Placeholder only keeps the battle option available; the real team is generated per challenger.
        npc.setPokemonTeam(List.of("eevee level=10"));
        npc.setBattleRewards(List.of());
        npc.setBattleRewardRepeatable(false);
    }

    private static boolean spawnRole(ServerWorld world, ServerPlayerEntity player, Tier tier, Theme theme, Role role,
                                     String structureKey, int index) {
        ServiceNpcEntity npc = ModRegistries.CUSTOM_NPC.create(world);
        if (npc == null) return false;
        int[][] offsets = {{4, 0}, {-4, 0}, {0, 4}, {0, -4}, {7, 7}, {-7, 7}};
        int[] offset = offsets[index % offsets.length];
        BlockPos pos = findSafeNear(world, player.getBlockPos().add(offset[0], 0, offset[1]));
        if (pos == null) pos = findSafeNear(world, player.getBlockPos());
        if (pos == null) return false;
        npc.refreshPositionAndAngles(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                player.getYaw() + 180.0F, 0.0F);
        String shortHash = Integer.toHexString(structureKey.hashCode()).replace('-', '0');
        if (shortHash.length() > 6) shortHash = shortHash.substring(0, 6);
        npc.setNpcId("dng_" + tier.id + "_" + theme.id + "_" + shortHash + index);
        configureDungeonNpc(npc, tier, theme, role, structureKey);
        return world.spawnEntity(npc);
    }

    private static void announceEntry(ServerPlayerEntity player, Identifier structureId, String structureKey, int total) {
        String previous = LAST_ANNOUNCED_STRUCTURE.put(player.getUuid(), structureKey);
        if (structureKey.equals(previous)) return;
        Tier tier = classifyTier(structureId);
        Theme theme = classifyTheme(structureId);
        boolean cleared = Chainacobblemon.playerDataManager().getOrLoad(player.getUuid()).clearedDungeons.contains(structureKey);
        player.sendMessage(Text.literal("§5⌂ Mazmorra Pokémon detectada · §f" + tier.displayName()
                + " §7/ §f" + theme.displayName() + " §7· entrenadores: §f" + total
                + (cleared ? " §a· COMPLETADA" : " §d· progreso individual")), false);
    }

    private static List<ServiceNpcEntity> trainersFor(ServerWorld world, String structureKey) {
        if (world == null || structureKey == null || structureKey.isBlank()) return List.of();
        List<ServiceNpcEntity> result = new ArrayList<>();
        result.addAll(world.getEntitiesByType(ModRegistries.CUSTOM_NPC,
                npc -> structureKey.equals(npc.dungeonStructureKey())));
        result.addAll(world.getEntitiesByType(ModRegistries.CUSTOM_SLIM_NPC,
                npc -> structureKey.equals(npc.dungeonStructureKey())));
        return result;
    }

    private static List<ServiceNpcEntity> allDungeonTrainers(ServerWorld world) {
        List<ServiceNpcEntity> result = new ArrayList<>();
        result.addAll(world.getEntitiesByType(ModRegistries.CUSTOM_NPC, ServiceNpcEntity::isDungeonTrainer));
        result.addAll(world.getEntitiesByType(ModRegistries.CUSTOM_SLIM_NPC, ServiceNpcEntity::isDungeonTrainer));
        return result;
    }

    private static String trainerVictoryKey(ServiceNpcEntity npc) {
        String structure = npc.dungeonStructureKey();
        if (structure == null || structure.isBlank()) {
            structure = npc.getWorld().getRegistryKey().getValue() + ":unknown";
        }
        return structure + "#" + npc.npcId();
    }

    private static BlockPos findSafeNear(ServerWorld world, BlockPos base) {
        if (world == null || base == null) return null;
        // Prefer the same floor first, then expand horizontally. This avoids the old behaviour where a
        // vertical-only scan could put a trainer inside stairs, railings or decorative ship blocks.
        int[] yOffsets = {0, 1, -1, 2, -2, 3, -3, 4, -4};
        for (int radius = 0; radius <= 8; radius++) {
            for (int dy : yOffsets) {
                int y = base.getY() + dy;
                if (y < world.getBottomY() + 2 || y > world.getBottomY() + world.getHeight() - 3) continue;
                for (int dx = -radius; dx <= radius; dx++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        if (radius > 0 && Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                        BlockPos pos = new BlockPos(base.getX() + dx, y, base.getZ() + dz);
                        if (isSafeStandingPos(world, pos)) return pos;
                    }
                }
            }
        }
        return null;
    }

    private static boolean isSafeStandingPos(ServerWorld world, BlockPos pos) {
        BlockPos head = pos.up();
        BlockPos floor = pos.down();
        var feetState = world.getBlockState(pos);
        var headState = world.getBlockState(head);
        var floorState = world.getBlockState(floor);
        if (!world.getFluidState(pos).isEmpty() || !world.getFluidState(head).isEmpty()) return false;
        if (!feetState.getCollisionShape(world, pos).isEmpty()) return false;
        if (!headState.getCollisionShape(world, head).isEmpty()) return false;
        // Full cubes only: no stairs, slabs, fences, walls or other partial collision surfaces.
        return floorState.isFullCube(world, floor) && world.getFluidState(floor).isEmpty();
    }

    private static void relocateIfUnsafe(ServiceNpcEntity npc) {
        if (!(npc.getWorld() instanceof ServerWorld world)) return;
        BlockPos current = npc.getBlockPos();
        if (isSafeStandingPos(world, current)) return;
        BlockPos safe = findSafeNear(world, current);
        if (safe == null) return;
        npc.refreshPositionAndAngles(safe.getX() + 0.5D, safe.getY(), safe.getZ() + 0.5D, npc.getYaw(), npc.getPitch());
        Chainacobblemon.LOGGER.info("Relocated unsafe dungeon trainer {} from {} to {}", npc.npcId(), current, safe);
    }

    /**
     * Treasure Maze opponents use explicit four-attack sets. Cobblemon's PokemonProperties supports the
     * comma-separated moves property; this prevents randomly generated high-level opponents from ending
     * up with passive/utility-heavy natural movesets that can spend turns without threatening the player.
     * No held items are assigned, so trainer battles cannot leak held-item rewards.
     */
    private static String competitiveTreasureSpec(String species, int level) {
        String moves = switch (species.toLowerCase(Locale.ROOT)) {
            case "venusaur" -> "energyball,sludgebomb,earthpower,weatherball";
            case "vileplume" -> "gigadrain,sludgebomb,moonblast,acid";
            case "victreebel" -> "powerwhip,sludgebomb,knockoff,suckerpunch";
            case "exeggutor" -> "psychic,gigadrain,sludgebomb,stompingtantrum";
            case "leafeon" -> "leafblade,xscissor,dig,quickattack";
            case "roserade" -> "energyball,sludgebomb,dazzlinggleam,shadowball";
            case "breloom" -> "seedbomb,drainpunch,rocktomb,machpunch";
            case "shiftry" -> "leafblade,knockoff,rockslide,xscissor";

            case "golem" -> "earthquake,stoneedge,firepunch,thunderpunch";
            case "rhydon" -> "earthquake,stoneedge,megahorn,icepunch";
            case "onix" -> "earthquake,rockslide,ironhead,bodypress";
            case "aerodactyl" -> "rockslide,aerialace,crunch,earthquake";
            case "tyranitar" -> "crunch,stoneedge,earthquake,icepunch";
            case "aggron" -> "headsmash,earthquake,icepunch,bodypress";
            case "gigalith" -> "stoneedge,earthquake,bodypress,heavyslam";
            case "rampardos" -> "headsmash,earthquake,zenheadbutt,firepunch";

            case "alakazam" -> "psychic,shadowball,focusblast,dazzlinggleam";
            case "espeon" -> "psychic,shadowball,dazzlinggleam,grassknot";
            case "gardevoir" -> "psychic,moonblast,shadowball,thunderbolt";
            case "slowking" -> "surf,psychic,icebeam,flamethrower";
            case "metagross" -> "meteormash,zenheadbutt,earthquake,bulletpunch";
            case "xatu" -> "psychic,airslash,heatwave,gigadrain";
            case "bronzong" -> "psychic,flashcannon,bodypress,earthquake";
            case "reuniclus" -> "psychic,focusblast,shadowball,energyball";

            case "gengar" -> "shadowball,sludgebomb,thunderbolt,focusblast";
            case "mismagius" -> "shadowball,mysticalfire,powergem,dazzlinggleam";
            case "dusknoir" -> "shadowpunch,icepunch,firepunch,earthquake";
            case "banette" -> "shadowclaw,knockoff,suckerpunch,gunkshot";
            case "chandelure" -> "shadowball,flamethrower,energyball,psychic";
            case "drifblim" -> "shadowball,airslash,thunderbolt,psychic";
            case "spiritomb" -> "darkpulse,shadowball,psychic,icywind";
            case "froslass" -> "icebeam,shadowball,thunderbolt,psychic";

            case "snorlax" -> "bodyslam,earthquake,crunch,heavyslam";
            case "machamp" -> "closecombat,stoneedge,knockoff,icepunch";
            case "scizor" -> "bulletpunch,xscissor,closecombat,knockoff";
            case "dragonite" -> "dragonclaw,aerialace,earthquake,firepunch";
            case "arcanine" -> "flareblitz,extremespeed,crunch,playrough";
            case "lucario" -> "closecombat,flashcannon,darkpulse,extremespeed";
            case "magnezone" -> "thunderbolt,flashcannon,voltswitch,triattack";
            case "electivire" -> "thunderpunch,icepunch,earthquake,firepunch";
            default -> "";
        };
        String base = species + " level=" + Math.max(1, Math.min(100, level));
        return moves.isBlank() ? base : base + " moves=" + moves;
    }

    private static int averageTopThree(ServerPlayerEntity player) {
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (java.lang.reflect.Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                List<Integer> levels = new ArrayList<>();
                for (Pokemon pokemon : party) if (pokemon != null) levels.add(pokemon.getLevel());
                levels.sort(Collections.reverseOrder());
                int count = Math.min(3, levels.size());
                if (count == 0) return 0;
                int sum = 0;
                for (int i = 0; i < count; i++) sum += levels.get(i);
                return Math.max(1, Math.round(sum / (float) count));
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not inspect party for Treasure scaling: {}", exception.toString());
        }
        return 0;
    }

    private static Tier classifyTier(Identifier id) {
        String path = id.getPath().toLowerCase(Locale.ROOT);
        if (containsAny(path, "plague", "kayra", "thornborn", "monastery", "palace", "citadel", "end", "nether", "boss", "mega")) return Tier.EPIC;
        if (containsAny(path, "castle", "keep", "fort", "temple", "vault", "asylum", "corsair", "galley", "stronghold", "tower")) return Tier.TREASURE;
        if (containsAny(path, "dungeon", "crypt", "mine", "foundry", "shrine", "ruin", "lab", "windmill", "pub")) return Tier.RARE;
        return Tier.COMMON;
    }

    private static Theme classifyTheme(Identifier id) {
        String path = id.getPath().toLowerCase(Locale.ROOT);
        if (containsAny(path, "ship", "corsair", "galley", "ocean", "fishing", "water")) return Theme.WATER;
        if (containsAny(path, "nether", "forge", "foundry", "volcano", "fire")) return Theme.FIRE;
        if (containsAny(path, "crypt", "asylum", "grave", "haunt", "plague", "thornborn")) return Theme.GHOST;
        if (containsAny(path, "temple", "monastery", "shrine", "library", "magic")) return Theme.PSYCHIC;
        if (containsAny(path, "mine", "quarry", "fort", "keep", "castle", "stone")) return Theme.ROCK;
        if (containsAny(path, "ice", "snow", "frozen")) return Theme.ICE;
        if (containsAny(path, "greenwood", "garden", "jungle", "forest", "tree")) return Theme.GRASS;
        if (containsAny(path, "dark", "illager", "bandit")) return Theme.DARK;
        return Theme.MIXED;
    }

    private static boolean containsAny(String value, String... tokens) {
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }

    private enum Tier {
        COMMON("common", "Común", 2, -2, List.of(Role.SCOUT)),
        RARE("rare", "Rara", 3, 0, List.of(Role.SCOUT, Role.VETERAN)),
        TREASURE("treasure", "Tesoro", 4, 1, List.of(Role.SCOUT, Role.VETERAN, Role.GUARDIAN)),
        EPIC("epic", "Épica", 5, 2, List.of(Role.SCOUT, Role.VETERAN, Role.ELITE, Role.GUARDIAN));

        final String id;
        final String label;
        final int baseTeamSize;
        final int levelOffset;
        final List<Role> roles;

        Tier(String id, String label, int baseTeamSize, int levelOffset, List<Role> roles) {
            this.id = id;
            this.label = label;
            this.baseTeamSize = baseTeamSize;
            this.levelOffset = levelOffset;
            this.roles = roles;
        }

        List<Role> roles() { return roles; }
        String displayName() { return "Dungeon " + label; }

        static Tier parse(String value) {
            for (Tier tier : values()) if (tier.id.equalsIgnoreCase(value)) return tier;
            return COMMON;
        }
    }

    private enum Role {
        SCOUT("scout", "Explorador Pokémon", "⚔ Combatir", -1, 0, false),
        VETERAN("veteran", "Entrenador veterano", "⚔ Desafiar", 0, 0, false),
        ELITE("elite", "Entrenador élite", "⚔ Desafiar élite", 1, 0, false),
        GUARDIAN("guardian", "Guardián Pokémon", "⚔ Retar al Guardián", 2, 1, true);

        final String id;
        final String displayName;
        final String battleLabel;
        final int levelOffset;
        final int teamSizeBonus;
        final boolean guardian;

        Role(String id, String displayName, String battleLabel, int levelOffset, int teamSizeBonus, boolean guardian) {
            this.id = id;
            this.displayName = displayName;
            this.battleLabel = battleLabel;
            this.levelOffset = levelOffset;
            this.teamSizeBonus = teamSizeBonus;
            this.guardian = guardian;
        }

        String intro(Theme theme) {
            return switch (this) {
                case SCOUT -> "Estoy explorando esta zona. Si quieres seguir avanzando, demuestra cómo peleas contra mi equipo de " + theme.displayName() + ".";
                case VETERAN -> "Llegaste más lejos que la mayoría. Aquí los combates ya no son de práctica: prepárate para un equipo de " + theme.displayName() + ".";
                case ELITE -> "Esta parte de la dungeon está reservada para entrenadores capaces de adaptarse. Yo también lo haré.";
                case GUARDIAN -> "Has alcanzado el corazón de la dungeon. Soy su Guardián Pokémon; solo lucharé cuando hayas superado a los demás.";
            };
        }

        static Role find(String value) {
            if (value == null || value.isBlank()) return null;
            for (Role role : values()) if (role.id.equalsIgnoreCase(value)) return role;
            return null;
        }

        static Role parse(String value) {
            Role found = find(value);
            return found == null ? VETERAN : found;
        }
    }

    private enum Theme {
        WATER("water", "Agua",
                List.of("squirtle", "psyduck", "poliwag", "wooper", "buizel", "wingull", "horsea", "marill"),
                List.of("starmie", "vaporeon", "gyarados", "lapras", "slowbro", "cloyster", "milotic", "gastrodon")),
        FIRE("fire", "Fuego",
                List.of("charmander", "growlithe", "vulpix", "ponyta", "slugma", "numel", "magby", "houndour"),
                List.of("arcanine", "rapidash", "magmar", "flareon", "ninetales", "charizard", "houndoom", "camerupt")),
        GHOST("ghost", "Fantasma",
                List.of("gastly", "misdreavus", "duskull", "shuppet", "drifloon", "litwick", "yamask", "phantump"),
                List.of("gengar", "mismagius", "dusknoir", "banette", "chandelure", "drifblim", "spiritomb", "froslass")),
        PSYCHIC("psychic", "Psíquico",
                List.of("abra", "ralts", "slowpoke", "natu", "spoink", "solosis", "drowzee", "baltoy"),
                List.of("alakazam", "espeon", "gardevoir", "slowking", "metagross", "xatu", "bronzong", "reuniclus")),
        ROCK("rock", "Roca",
                List.of("geodude", "rhyhorn", "onix", "kabuto", "aron", "nosepass", "roggenrola", "cranidos"),
                List.of("golem", "rhydon", "onix", "aerodactyl", "tyranitar", "aggron", "gigalith", "rampardos")),
        ICE("ice", "Hielo",
                List.of("seel", "snorunt", "sneasel", "swinub", "snover", "spheal", "smoochum", "bergmite"),
                List.of("dewgong", "cloyster", "lapras", "glaceon", "weavile", "mamoswine", "abomasnow", "froslass")),
        GRASS("grass", "Planta",
                List.of("bulbasaur", "oddish", "bellsprout", "exeggcute", "budew", "shroomish", "hoppip", "seedot"),
                List.of("venusaur", "vileplume", "victreebel", "exeggutor", "leafeon", "roserade", "breloom", "shiftry")),
        DARK("dark", "Siniestro",
                List.of("poochyena", "houndour", "murkrow", "sneasel", "sandile", "pawniard", "stunky", "purrloin"),
                List.of("umbreon", "houndoom", "absol", "honchkrow", "krookodile", "bisharp", "skuntank", "weavile")),
        MIXED("mixed", "Aventura",
                List.of("pikachu", "eevee", "machop", "scyther", "dratini", "growlithe", "riolu", "magnemite"),
                List.of("snorlax", "machamp", "scizor", "dragonite", "arcanine", "lucario", "magnezone", "electivire"));

        final String id;
        final String label;
        final List<String> earlySpecies;
        final List<String> advancedSpecies;

        Theme(String id, String label, List<String> earlySpecies, List<String> advancedSpecies) {
            this.id = id;
            this.label = label;
            this.earlySpecies = earlySpecies;
            this.advancedSpecies = advancedSpecies;
        }

        List<String> species(int targetLevel) { return targetLevel < 30 ? earlySpecies : advancedSpecies; }
        String displayName() { return label; }

        static Theme parse(String value) {
            for (Theme theme : values()) if (theme.id.equalsIgnoreCase(value)) return theme;
            return MIXED;
        }
    }

    private record PackResult(int changed, int total) {}
}
