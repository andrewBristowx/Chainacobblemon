package com.andrewbristowx.chainacobblemon.npc;

import com.andrewbristowx.chainacobblemon.Chainacobblemon;
import com.andrewbristowx.chainacobblemon.challenge.RctCobbleverseBridge;
import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Adapts the TrainerMob entities spawned natively by Radical Cobblemon Trainers without replacing
 * RCT's own battle/progression pipeline. Right click and automatic sight challenges both pass through
 * Chaina's dialogue first. Immediately before native RCT creates the battle, the registered NPC team
 * is level-shifted; RCT clones that team into the battle and the registry template is restored in a
 * finally block, so the next player gets an independent level calculation.
 */
public final class RctWorldTrainerService {
    private static final String TRAINER_MOB_CLASS = "com.gitlab.srcmc.rctmod.world.entities.TrainerMob";
    private static final String DIALOGUE_PREFIX = "rct-world:";
    private static final long AUTO_PROMPT_COOLDOWN_MS = 15_000L;
    private static final Map<Permit, Boolean> NATIVE_START_PERMITS = new ConcurrentHashMap<>();
    private static final Map<Permit, Long> AUTO_PROMPT_UNTIL = new ConcurrentHashMap<>();
    private static boolean initialized;

    private RctWorldTrainerService() {}

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (hand != Hand.MAIN_HAND || world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)
                    || !isNativeWorldTrainer(entity)) {
                return ActionResult.PASS;
            }
            openDialogue(serverPlayer, entity, false);
            return ActionResult.SUCCESS;
        });
        Chainacobblemon.LOGGER.info("RCT world-trainer dialogue/adaptive bridge initialized");
    }

    /** Called from the optional TrainerMob mixin. true means cancel the native start for now. */
    public static boolean interceptStart(Object rawTrainer, ServerPlayerEntity player) {
        if (!(rawTrainer instanceof Entity trainer) || !isNativeWorldTrainer(trainer) || player == null) return false;
        Permit key = new Permit(player.getUuid(), trainer.getUuid());
        if (NATIVE_START_PERMITS.remove(key) != null) return false;
        if (playerBusy(player)) return false;

        long now = System.currentTimeMillis();
        long until = AUTO_PROMPT_UNTIL.getOrDefault(key, 0L);
        if (now >= until) {
            AUTO_PROMPT_UNTIL.put(key, now + AUTO_PROMPT_COOLDOWN_MS);
            openDialogue(player, trainer, true);
        }
        // Even while the prompt is on cooldown, block TrainerMob's force-battle loop. The player
        // explicitly accepts through Chaina's dialogue, which grants a one-shot native-start permit.
        return true;
    }

    public static boolean handleDialogueAction(ServerPlayerEntity player, String rawId, String rawAction) {
        if (rawId == null || !rawId.toLowerCase(Locale.ROOT).startsWith(DIALOGUE_PREFIX)) return false;
        Entity trainer = resolveTrainer(player, rawId);
        if (trainer == null) {
            player.sendMessage(Text.literal("§cEse entrenador de Radical ya no está disponible cerca de ti."), false);
            return true;
        }
        String action = rawAction == null ? "" : rawAction.trim().toLowerCase(Locale.ROOT);
        if ("battle".equals(action)) startAdaptiveNativeBattle(player, trainer);
        return true;
    }

    private static void openDialogue(ServerPlayerEntity player, Entity trainer, boolean automatic) {
        if (player == null || trainer == null || player.getWorld() != trainer.getWorld() || player.squaredDistanceTo(trainer) > 144.0D) return;
        boolean eligible = canBattleAgainst(trainer, player);
        int target = targetLevel(player);
        String trainerId = trainerId(trainer);
        String name = trainer.getCustomName() != null ? trainer.getCustomName().getString() : trainer.getName().getString();
        if (name == null || name.isBlank()) name = "Entrenador Radical";

        List<String> pages = new ArrayList<>();
        if (eligible) {
            pages.add(automatic
                    ? "¡Te he visto! Antes de combatir, prepararé un equipo acorde a tu progreso actual."
                    : "¿Quieres combatir? Mi equipo se adaptará a tu nivel actual para que el reto siga siendo justo.");
            pages.add("Se conserva mi equipo original: Pokémon, movimientos, objetos y reglas de Radical. Solo se ajustan temporalmente sus niveles para esta pelea.");
        } else {
            pages.add("Todavía no puedo combatir contigo según las reglas de progresión de Radical Cobblemon Trainers.");
            pages.add("Cumple sus requisitos, cooldown o progresión y vuelve a intentarlo.");
        }

        List<NpcNetworking.DialogueChoice> choices = new ArrayList<>();
        if (eligible) choices.add(new NpcNetworking.DialogueChoice("battle", "⚔ Combatir", "Batalla adaptativa usando las reglas originales de RCT."));
        choices.add(new NpcNetworking.DialogueChoice("close", "Salir", "No iniciar el combate."));

        String details = "Equipo adaptado ~Nv." + target
                + " · IA y progresión de Radical"
                + (trainerId.isBlank() ? "" : " · " + trainerId);
        NpcNetworking.sendDialogue(player, new NpcNetworking.DialogueState(
                DIALOGUE_PREFIX + trainer.getUuid(), name, "Entrenador de Radical Cobblemon Trainers",
                List.copyOf(pages), List.copyOf(choices), details,
                true, false, false, !eligible));
    }

    private static void startAdaptiveNativeBattle(ServerPlayerEntity player, Entity trainer) {
        if (playerBusy(player)) {
            player.sendMessage(Text.literal("§cYa estás en una batalla Pokémon."), false);
            return;
        }
        if (!canBattleAgainst(trainer, player)) {
            player.sendMessage(Text.literal("§eRadical todavía no permite que desafíes a este entrenador."), false);
            openDialogue(player, trainer, false);
            return;
        }
        String trainerId = trainerId(trainer);
        if (trainerId.isBlank()) {
            player.sendMessage(Text.literal("§cNo pude identificar el perfil RCT de este entrenador."), false);
            return;
        }

        Pokemon[] team = null;
        int[] originalLevels = null;
        Permit permit = new Permit(player.getUuid(), trainer.getUuid());
        try {
            Object nativeTrainer = registeredTrainer(trainerId);
            if (nativeTrainer == null) throw new IllegalStateException("trainer registry entry not found: " + trainerId);
            Object teamValue = nativeTrainer.getClass().getMethod("getTeam").invoke(nativeTrainer);
            if (!(teamValue instanceof Pokemon[] pokemonTeam) || pokemonTeam.length == 0) {
                throw new IllegalStateException("native RCT team is empty");
            }
            team = pokemonTeam;
            originalLevels = new int[team.length];
            int authoredMax = 1;
            for (int i = 0; i < team.length; i++) {
                originalLevels[i] = team[i] == null ? 1 : team[i].getLevel();
                authoredMax = Math.max(authoredMax, originalLevels[i]);
            }

            int target = targetLevel(player);
            int delta = target - authoredMax;
            for (int i = 0; i < team.length; i++) {
                if (team[i] == null) continue;
                team[i].setLevel(clamp(originalLevels[i] + delta, 1, 100));
            }

            NATIVE_START_PERMITS.put(permit, Boolean.TRUE);
            invokeStartBattleWith(trainer, player);
            AUTO_PROMPT_UNTIL.put(permit, System.currentTimeMillis() + AUTO_PROMPT_COOLDOWN_MS);
            player.sendMessage(Text.literal("§d⚔ Radical adaptativo §7· §fRival ~Nv." + target
                    + " §7· se conservan sus reglas, IA y progresión originales."), false);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.error("Could not start adaptive native RCT battle {}", trainerId, exception);
            player.sendMessage(Text.literal("§cNo se pudo iniciar el combate adaptativo de Radical. Revisa latest.log si se repite."), false);
        } finally {
            NATIVE_START_PERMITS.remove(permit);
            if (team != null && originalLevels != null) {
                for (int i = 0; i < Math.min(team.length, originalLevels.length); i++) {
                    if (team[i] != null) team[i].setLevel(originalLevels[i]);
                }
            }
        }
    }

    private static int targetLevel(ServerPlayerEntity player) {
        int target = averageTopThree(player);
        RctCobbleverseBridge.LevelCapStatus cap = RctCobbleverseBridge.levelCap(player);
        if (target <= 0) target = Math.max(5, cap.highestPartyLevel());
        // World trainers follow the same adaptive rule as Chaina dungeon trainers: use the player's
        // real party level. Radical still owns prerequisites/cooldowns/progression, but its regional
        // level cap is not used to make the opponent weaker than the challenger.
        return clamp(target, 5, 100);
    }

    private static int averageTopThree(ServerPlayerEntity player) {
        try {
            Object storage = Cobblemon.INSTANCE.getStorage();
            for (Method method : storage.getClass().getMethods()) {
                if (!method.getName().equals("getParty") || method.getParameterCount() != 1) continue;
                Object result = method.invoke(storage, player);
                if (!(result instanceof PlayerPartyStore party)) continue;
                List<Integer> levels = new ArrayList<>();
                for (Pokemon pokemon : party) if (pokemon != null) levels.add(pokemon.getLevel());
                levels.sort(Collections.reverseOrder());
                int count = Math.min(3, levels.size());
                if (count == 0) return 0;
                int sum = 0;
                for (int i = 0; i < count; i++) sum += levels.get(i);
                return Math.max(1, Math.round(sum / (float) count));
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not inspect party for native RCT scaling: {}", exception.toString());
        }
        return 0;
    }

    private static Object registeredTrainer(String trainerId) throws ReflectiveOperationException {
        Class<?> apiClass = Class.forName("com.gitlab.srcmc.rctapi.api.RCTApi");
        Class<?> trainerNpcClass = Class.forName("com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC");
        Object rct = apiClass.getMethod("getInstance", String.class).invoke(null, "rctmod");
        if (rct == null) return null;
        Object registry = rct.getClass().getMethod("getTrainerRegistry").invoke(rct);
        return registry.getClass().getMethod("getById", String.class, Class.class).invoke(registry, trainerId, trainerNpcClass);
    }

    private static void invokeStartBattleWith(Entity trainer, ServerPlayerEntity player) throws ReflectiveOperationException {
        for (Method method : trainer.getClass().getMethods()) {
            if (!method.getName().equals("startBattleWith") || method.getParameterCount() != 1) continue;
            if (!method.getParameterTypes()[0].isInstance(player)) continue;
            method.invoke(trainer, player);
            return;
        }
        throw new NoSuchMethodException("TrainerMob.startBattleWith(Player)");
    }

    private static boolean canBattleAgainst(Entity trainer, ServerPlayerEntity player) {
        try {
            for (Method method : trainer.getClass().getMethods()) {
                if (!method.getName().equals("canBattleAgainst") || method.getParameterCount() != 1) continue;
                if (!method.getParameterTypes()[0].isInstance(player)) continue;
                Object result = method.invoke(trainer, player);
                return !(result instanceof Boolean allowed) || allowed;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Chainacobblemon.LOGGER.debug("Could not query TrainerMob.canBattleAgainst: {}", exception.toString());
        }
        // If a future RCT build hides the helper, let its own startBattleWith perform the authoritative check.
        return true;
    }

    private static String trainerId(Entity trainer) {
        try {
            Object value = trainer.getClass().getMethod("getTrainerId").invoke(trainer);
            return value == null ? "" : value.toString();
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return "";
        }
    }

    private static Entity resolveTrainer(ServerPlayerEntity player, String rawId) {
        try {
            UUID uuid = UUID.fromString(rawId.substring(DIALOGUE_PREFIX.length()));
            Entity entity = player.getServerWorld().getEntity(uuid);
            if (entity == null || !isNativeWorldTrainer(entity) || player.getWorld() != entity.getWorld()
                    || player.squaredDistanceTo(entity) > 100.0D) return null;
            return entity;
        } catch (IllegalArgumentException | IndexOutOfBoundsException exception) {
            return null;
        }
    }

    public static boolean isNativeWorldTrainer(Object entity) {
        if (entity == null) return false;
        Class<?> type = entity.getClass();
        while (type != null) {
            if (TRAINER_MOB_CLASS.equals(type.getName())) return true;
            type = type.getSuperclass();
        }
        return false;
    }

    private static boolean playerBusy(ServerPlayerEntity player) {
        try {
            Class<?> registryClass = Class.forName("com.cobblemon.mod.common.battles.BattleRegistry");
            Object instance = registryClass.getField("INSTANCE").get(null);
            for (Method method : registryClass.getMethods()) {
                if (!"getBattleByParticipatingPlayer".equals(method.getName()) || method.getParameterCount() != 1) continue;
                return method.invoke(instance, player) != null;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private record Permit(UUID playerId, UUID trainerId) {}
}
